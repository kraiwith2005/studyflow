<?php
/* Tasks: the list page, and adding / editing / deleting / ticking off assignments, exams and personal tasks. */

function tasks_page(): void
{
    $uid = user_id();
    $filter = in_array(query('filter'), ['school', 'personal'], true) ? query('filter') : 'all';
    $showCompleted = query_bool('completed');
    $search = trim((string) query('q', ''));
    $highOnly = query_bool('high');
    $terms = terms_of($uid);
    $term = null;
    foreach ($terms as $t) if ((int) $t->id === (int) query('term')) $term = $t;

    $where = [];
    $params = [];
    if ($filter === 'school') $where[] = "t.type <> 'personal'";
    if ($filter === 'personal') $where[] = "t.type = 'personal'";
    if (! $showCompleted) $where[] = 't.completed_at IS NULL';
    if ($highOnly) $where[] = "t.priority = 'high'";
    if ($search !== '') {
        // Escape LIKE wildcards so "%" or "_" are searched literally.
        $like = '%'.addcslashes($search, '\\%_').'%';
        $where[] = '(t.title LIKE ? OR t.notes LIKE ? OR s.name LIKE ?)';
        array_push($params, $like, $like, $like);
    }
    if ($term) {
        $where[] = 't.due_date BETWEEN ? AND ?';
        array_push($params, $term->start_date, $term->end_date);
    }
    // Open tasks first by due date; completed ones at the end.
    $tasks = tasks_query($uid, implode(' AND ', $where), $params,
        "t.completed_at IS NOT NULL, t.due_date, FIELD(t.priority, 'high', 'normal', 'low'), t.due_time IS NULL, t.due_time, t.title");

    $of = fn ($type) => array_values(array_filter($tasks, fn ($t) => $t->type === $type));

    page('tasks/index', [
        'title' => __('Tasks'),
        'groups' => [
            'assessments' => ['assignment' => $of('assignment'), 'exam' => $of('exam')],
            'other' => ['personal' => $of('personal')],
        ],
        'count' => count($tasks),
        'filter' => $filter,
        'showCompleted' => $showCompleted,
        'search' => $search,
        'highOnly' => $highOnly,
        'terms' => $terms,
        'term' => $term,
        'subjects' => subjects_of($uid),
        'linkable' => linkable_tasks($uid),
        'returnUrl' => current_page(),
    ]);
}

function task_store(): void
{
    $data = task_validated(null);
    db_insert('tasks', $data + ['user_id' => user_id()]);
    back_to_page(__(':type “:title” added.', ['type' => task_type_label($data['type']), 'title' => $data['title']]));
}

function task_update(int $id): void
{
    $task = own_task(user_id(), $id) ?? abort(404);
    $data = task_validated($task);
    db_update('tasks', $data, $task->id, user_id());
    back_to_page(__('Changes saved.'));
}

function task_destroy(int $id): void
{
    $task = own_task(user_id(), $id) ?? abort(404);
    db_exec('DELETE FROM tasks WHERE id = ? AND user_id = ?', [$task->id, user_id()]);
    back_to_page(__('“:title” deleted.', ['title' => $task->title]));
}

function task_toggle(int $id): void
{
    $task = own_task(user_id(), $id) ?? abort(404);
    db_update('tasks', ['completed_at' => $task->done ? null : now_sql()], $task->id, user_id());
    back_to_page($task->done ? __('Marked as not done.') : __('Marked as done.'));
}

/** Checked form data, or back to the page with the dialog open and the errors shown. */
function task_validated(?object $task): array
{
    $uid = user_id();
    $type = $task->type ?? input_str('type');
    $data = [
        'type' => $type,
        'title' => input_str('title'),
        'subject_id' => input_str('subject_id'),
        'due_date' => input_str('due_date'),
        'due_time' => input_str('due_time'),
        'notes' => is_string(input('notes')) ? input('notes') : '',
        'link' => input_str('link'),
        'priority' => input_str('priority'),
    ];
    $errors = validate($data, [
        'type' => 'required|in:'.implode(',', TASK_TYPES),
        'title' => 'required|string|max:120',
        'subject_id' => ($type === 'personal' ? 'nullable' : 'required').'|integer',
        'due_date' => 'required|date',
        'due_time' => 'nullable|time',
        'notes' => 'nullable|string|max:2000',
        'link' => 'nullable|string|max:500|url',
        'priority' => 'nullable|in:'.implode(',', PRIORITIES),
    ], [
        'title.required' => __('Enter a title.'),
        'subject_id.required' => __('Choose a subject.'),
        'link.url' => __('Enter a full link starting with http:// or https://'),
    ]);
    if (! isset($errors['subject_id']) && $data['subject_id'] !== '' && ! own_subject($uid, $data['subject_id'])) {
        add_error($errors, 'subject_id', validation_message('subject_id', 'exists', [], []));
    }
    if ($errors) {
        flash_errors($errors, 'task');
        flash('reopen', $task ? "task-{$task->id}" : 'new-'.(in_array($type, TASK_TYPES, true) ? $type : 'assignment'));
        back_to_page();
    }

    $notes = trim(str_replace(["\r\n", "\r"], "\n", $data['notes']));
    $out = [
        'title' => $data['title'],
        'subject_id' => $type === 'personal' || $data['subject_id'] === '' ? null : (int) $data['subject_id'],
        'due_date' => $data['due_date'],
        'due_time' => $data['due_time'] === '' ? null : $data['due_time'],
        'notes' => $notes === '' ? null : $notes,
        'link' => $data['link'] === '' ? null : $data['link'],
        'priority' => $data['priority'] === '' ? 'normal' : $data['priority'],
    ];
    if (! $task) $out['type'] = $type;   // the type can't change after creation
    return $out;
}
