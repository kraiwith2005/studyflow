<?php
/* Study page (Focus timer, Plan & Log) and the timer's JSON actions used by js/study.js. */

function study_page(): void
{
    $uid = user_id();
    $tab = query('tab') === 'log' ? 'log' : 'focus';
    [$weekCount, $weekMinutes] = week_study_totals($uid);

    $subjects = subjects_of($uid);
    $subjectFilter = null;
    foreach ($subjects as $s) if ((int) $s->id === (int) query('subject')) $subjectFilter = $s;
    $where = $subjectFilter ? ' AND ss.subject_id = '.(int) $subjectFilter->id : '';

    $completed = sessions_query($uid, "ss.status = 'completed'".$where, [], 'ss.date DESC, ss.start_time DESC');
    $planned = sessions_query($uid, "ss.status = 'planned'".$where, [], 'ss.date, ss.start_time');
    $todayPlanned = sessions_query($uid, "ss.status = 'planned' AND ss.date = ?", [today()->format('Y-m-d')], 'ss.start_time');
    $active = linkable_tasks($uid);

    page('study/index', [
        'title' => __('Study'),
        'tab' => $tab,
        'weekCount' => $weekCount,
        'weekMinutes' => $weekMinutes,
        'timer' => timer_of($uid),
        'todayPlanned' => $todayPlanned,
        'assessments' => $active,
        'subjects' => $subjects,
        'subjectFilter' => $subjectFilter,
        'completed' => $completed,
        'completedMinutes' => array_sum(array_map(fn ($s) => (int) $s->actual_minutes, $completed)),
        'planned' => $planned,
        'linkable' => $active,
        'returnUrl' => current_page(),
    ]);
}

/* ---------- Timer (JSON) ---------- */

function timer_start(): void
{
    $uid = user_id();
    if (timer_of($uid)) {
        json_response(['message' => __('A timer is already running. Stop it first.')], 409);
    }
    $target = input_str('target');
    if (! preg_match('/^(session|task|subject):(\d+)$/', $target, $m)) {
        $msg = validation_message('target', $target === '' ? 'required' : 'regex', [], []);
        json_response(['message' => $msg, 'errors' => ['target' => [$msg]]], 422);
    }
    [$kind, $id] = [$m[1], (int) $m[2]];

    $fields = match ($kind) {
        'session' => (function () use ($uid, $id) {
            $s = db_one("SELECT * FROM study_sessions WHERE id = ? AND user_id = ? AND status = 'planned'", [$id, $uid]) ?? abort(404);
            return ['study_session_id' => $s->id, 'subject_id' => $s->subject_id, 'task_id' => $s->task_id, 'label' => $s->title];
        })(),
        'task' => (function () use ($uid, $id) {
            $t = db_one("SELECT * FROM tasks WHERE id = ? AND user_id = ? AND type <> 'personal' AND completed_at IS NULL", [$id, $uid]) ?? abort(404);
            return ['task_id' => $t->id, 'subject_id' => $t->subject_id, 'label' => __('Study for :title', ['title' => $t->title])];
        })(),
        'subject' => (function () use ($uid, $id) {
            $s = own_subject($uid, $id) ?? abort(404);
            return ['subject_id' => $s->id, 'label' => $s->name];
        })(),
    };

    $now = now_sql();
    db_insert('study_timers', $fields + [
        'user_id' => $uid, 'status' => 'running', 'first_started_at' => $now, 'started_at' => $now, 'accumulated_seconds' => 0,
    ]);
    json_response(['timer' => timer_client(timer_of($uid))]);
}

function timer_pause(): void
{
    $uid = user_id();
    $timer = timer_of($uid) ?? abort(404);
    if ($timer->status === 'running') {
        db_exec("UPDATE study_timers SET status = 'paused', accumulated_seconds = ?, started_at = NULL, updated_at = ? WHERE user_id = ?",
            [timer_elapsed($timer), now_sql(), $uid]);
    }
    json_response(['timer' => timer_client(timer_of($uid))]);
}

function timer_resume(): void
{
    $uid = user_id();
    $timer = timer_of($uid) ?? abort(404);
    if ($timer->status === 'paused') {
        db_exec("UPDATE study_timers SET status = 'running', started_at = ?, updated_at = ? WHERE user_id = ?", [now_sql(), now_sql(), $uid]);
    }
    json_response(['timer' => timer_client(timer_of($uid))]);
}

/** Stop and record the time as a completed study session. */
function timer_stop(): void
{
    $uid = user_id();
    $timer = timer_of($uid) ?? abort(404);
    $minutes = (int) round(timer_elapsed($timer) / 60);

    if ($minutes < 1) {
        db_exec('DELETE FROM study_timers WHERE user_id = ?', [$uid]);
        json_response(['saved' => false, 'message' => __('Less than a minute was recorded, so nothing was saved.')]);
    }

    $minutes = min($minutes, 600);
    $start = new DateTimeImmutable($timer->first_started_at);
    $startMin = (int) $start->format('G') * 60 + (int) $start->format('i');
    if ($startMin + $minutes > 24 * 60) $startMin = 24 * 60 - $minutes;   // crossed midnight: keep it within the day it started
    $startTime = sprintf('%02d:%02d', intdiv($startMin, 60), $startMin % 60);

    $planned = $timer->study_session_id
        ? db_one('SELECT * FROM study_sessions WHERE id = ? AND user_id = ?', [$timer->study_session_id, $uid]) : null;
    if ($planned) {
        db_update('study_sessions', ['status' => 'completed', 'actual_minutes' => $minutes], (int) $planned->id, $uid);
        $sessionId = (int) $planned->id;
    } else {
        $sessionId = db_insert('study_sessions', [
            'user_id' => $uid, 'subject_id' => $timer->subject_id, 'task_id' => $timer->task_id, 'title' => $timer->label,
            'date' => $start->format('Y-m-d'), 'start_time' => $startTime, 'duration_minutes' => $minutes,
            'status' => 'completed', 'actual_minutes' => $minutes,
        ]);
    }
    db_exec('DELETE FROM study_timers WHERE user_id = ?', [$uid]);

    $message = __('Saved :time of study.', ['time' => duration_label($minutes)]);
    flash('status', $message);
    json_response(['saved' => true, 'minutes' => $minutes, 'session_id' => $sessionId, 'message' => $message]);
}

function timer_discard(): void
{
    db_exec('DELETE FROM study_timers WHERE user_id = ?', [user_id()]);
    json_response(['discarded' => true]);
}

/** "45 min" / "2 hr" / "1 hr 30 min" used in the Study page totals. */
function fmt_minutes(int $m): string
{
    if ($m < 60) return __(':mm', ['m' => $m]);
    return $m % 60 ? __(':hh :mm', ['h' => intdiv($m, 60), 'm' => $m % 60]) : __(':hh', ['h' => intdiv($m, 60)]);
}
