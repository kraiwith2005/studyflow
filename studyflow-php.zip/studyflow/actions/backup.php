<?php
/* Backup & data: export to a JSON file, import it back, or clear everything. */

const BACKUP_VERSION = 2;   // v2 adds tasks and study sessions (v1 files still import)

function backup_export(): void
{
    $uid = user_id();
    $planner = planner($uid);
    $subjects = db_all('SELECT * FROM subjects WHERE user_id = ? ORDER BY sort_order, name', [$uid]);
    $periods = db_all('SELECT * FROM periods WHERE user_id = ? ORDER BY sort_order, start_time', [$uid]);
    $tasks = db_all('SELECT * FROM tasks WHERE user_id = ? ORDER BY id', [$uid]);
    $subjectRef = array_flip(array_map(fn ($s) => (int) $s->id, $subjects));   // db id => index in the file
    $periodRef = array_flip(array_map(fn ($p) => (int) $p->id, $periods));
    $taskRef = array_flip(array_map(fn ($t) => (int) $t->id, $tasks));
    $ref = fn ($map, $id) => $id === null ? null : ($map[(int) $id] ?? null);
    $hm = fn ($t) => $t === null ? null : substr($t, 0, 5);
    $iso = fn ($dt) => $dt === null ? null : (new DateTimeImmutable($dt))->format(DATE_ATOM);

    $data = [
        'app' => 'StudyFlow',
        'version' => BACKUP_VERSION,
        'exported_at' => date(DATE_ATOM),
        'settings' => [
            'timetable_type' => $planner->timetable_type,
            'repeat_cycle' => $planner->repeat_cycle,
            'cycle_anchor' => $planner->cycle_anchor ? substr($planner->cycle_anchor, 0, 10) : null,
        ],
        'subjects' => array_map(fn ($s) => ['name' => $s->name, 'color' => $s->color], $subjects),
        'terms' => array_map(fn ($t) => ['name' => $t->name, 'start_date' => $t->start_date, 'end_date' => $t->end_date],
            db_all('SELECT * FROM terms WHERE user_id = ? ORDER BY start_date', [$uid])),
        'periods' => array_map(fn ($p) => ['name' => $p->name, 'kind' => $p->kind, 'start_time' => $hm($p->start_time), 'end_time' => $hm($p->end_time)], $periods),
        'timetable_slots' => array_map(fn ($s) => ['period' => $ref($periodRef, $s->period_id), 'day' => (int) $s->day, 'week' => $s->week, 'subject' => $ref($subjectRef, $s->subject_id)],
            db_all('SELECT * FROM timetable_slots WHERE user_id = ? ORDER BY id', [$uid])),
        'recurring_classes' => array_map(fn ($c) => [
            'subject' => $ref($subjectRef, $c->subject_id), 'name' => $c->name, 'day' => (int) $c->day,
            'start_time' => $hm($c->start_time), 'end_time' => $hm($c->end_time), 'week' => $c->week, 'location' => $c->location, 'teacher' => $c->teacher,
        ], db_all('SELECT * FROM recurring_classes WHERE user_id = ? ORDER BY day, start_time', [$uid])),
        'tasks' => array_map(fn ($t) => [
            'subject' => $ref($subjectRef, $t->subject_id), 'type' => $t->type, 'title' => $t->title, 'due_date' => $t->due_date,
            'due_time' => $hm($t->due_time), 'link' => $t->link, 'priority' => $t->priority, 'notes' => $t->notes, 'completed_at' => $iso($t->completed_at),
        ], $tasks),
        'study_sessions' => array_map(fn ($s) => [
            'subject' => $ref($subjectRef, $s->subject_id), 'task' => $ref($taskRef, $s->task_id), 'title' => $s->title, 'date' => $s->date,
            'start_time' => $hm($s->start_time), 'duration_minutes' => (int) $s->duration_minutes, 'status' => $s->status,
            'actual_minutes' => $s->actual_minutes === null ? null : (int) $s->actual_minutes,
        ], db_all('SELECT * FROM study_sessions WHERE user_id = ? ORDER BY id', [$uid])),
    ];

    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="studyflow-backup-'.date('Y-m-d').'.json"');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function backup_import(): void
{
    $file = $_FILES['backup'] ?? null;
    if (! $file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) backup_fail(__('Choose a backup file to import.'));
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE || $file['size'] > 5 * 1024 * 1024) {
        backup_fail(__('The backup file must be smaller than 5 MB.'));
    }
    if ($file['error'] !== UPLOAD_ERR_OK || ! is_uploaded_file($file['tmp_name'])) backup_fail(__('Choose a backup file to import.'));

    $decoded = json_decode((string) file_get_contents($file['tmp_name']), true);
    if (! is_array($decoded)) backup_fail(__('This file is not valid JSON.'));

    try {
        backup_check($decoded);
    } catch (InvalidArgumentException $e) {
        backup_fail(__($e->getMessage()));
    }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        planner_restore(user_id(), $decoded);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('Backup import failed: '.$e->getMessage());
        backup_fail(__('The backup is incomplete or damaged.'));
    }
    back_to_settings('backup', __('Backup imported. Your planner has been restored.'));
}

function backup_clear(): void
{
    if (input_str('confirm') !== 'CLEAR') backup_fail(__('Type CLEAR to confirm.'));
    $pdo = db();
    $pdo->beginTransaction();
    planner_clear(user_id());
    $pdo->commit();
    back_to_settings('backup', __('All planner data cleared.'));
}

function backup_fail(string $message): never
{
    flash('_errors', ['backup' => ['backup' => [$message]]]);
    back_to_settings('backup');
}

/** Delete everything the user has planned (the account itself stays). */
function planner_clear(int $uid): void
{
    foreach (['study_timers', 'study_sessions', 'tasks', 'recurring_classes', 'timetable_slots', 'periods', 'terms', 'subjects', 'planner_settings'] as $table) {
        db_exec("DELETE FROM `$table` WHERE user_id = ?", [$uid]);
    }
}

/** Replace all planner data with a checked backup. */
function planner_restore(int $uid, array $data): void
{
    planner_clear($uid);
    $s = $data['settings'] ?? [];
    db_insert('planner_settings', [
        'user_id' => $uid,
        'timetable_type' => in_array($s['timetable_type'] ?? '', ['school', 'university', 'custom'], true) ? $s['timetable_type'] : 'school',
        'repeat_cycle' => ($s['repeat_cycle'] ?? '') === 'ab' ? 'ab' : 'weekly',
        'cycle_anchor' => backup_date($s['cycle_anchor'] ?? null),
        'periods_initialized' => 1,
    ]);

    $subjectIds = [];
    foreach ($data['subjects'] as $i => $sub) {
        $subjectIds[$i] = db_insert('subjects', [
            'user_id' => $uid, 'name' => mb_substr(trim($sub['name']), 0, 80),
            'color' => preg_match('/^#[0-9a-f]{6}$/i', (string) ($sub['color'] ?? '')) ? strtolower($sub['color']) : '#8a948c',
            'sort_order' => $i,
        ]);
    }
    foreach ($data['terms'] as $t) {
        db_insert('terms', ['user_id' => $uid, 'name' => mb_substr($t['name'], 0, 60), 'start_date' => $t['start_date'], 'end_date' => $t['end_date']]);
    }
    $periods = $data['periods'];
    if (! $periods) {
        $n = 0;
        foreach (DEFAULT_PERIODS as [$name, $kind, $start, $end]) {
            $label = match ($name) { 'Recess' => __('Recess'), 'Lunch' => __('Lunch'), default => __('Period :n', ['n' => ++$n]) };
            $periods[] = ['name' => $label, 'kind' => $kind, 'start_time' => $start, 'end_time' => $end];
        }
    }
    $periodIds = [];
    foreach ($periods as $i => $p) {
        $periodIds[$i] = db_insert('periods', [
            'user_id' => $uid, 'name' => mb_substr($p['name'], 0, 40), 'kind' => ($p['kind'] ?? '') === 'break' ? 'break' : 'class',
            'start_time' => $p['start_time'], 'end_time' => $p['end_time'], 'sort_order' => $i,
        ]);
    }
    $seen = [];
    foreach ($data['timetable_slots'] as $slot) {
        if (! isset($periodIds[$slot['period'] ?? -1], $subjectIds[$slot['subject'] ?? -1])) continue;
        $week = ($slot['week'] ?? '') === 'B' ? 'B' : 'A';
        $key = $periodIds[$slot['period']].'-'.(int) $slot['day'].'-'.$week;
        if (isset($seen[$key])) {
            db_exec('UPDATE timetable_slots SET subject_id = ? WHERE id = ?', [$subjectIds[$slot['subject']], $seen[$key]]);
            continue;
        }
        $seen[$key] = db_insert('timetable_slots', [
            'user_id' => $uid, 'period_id' => $periodIds[$slot['period']], 'day' => (int) $slot['day'], 'week' => $week, 'subject_id' => $subjectIds[$slot['subject']],
        ]);
    }
    foreach ($data['recurring_classes'] as $c) {
        db_insert('recurring_classes', [
            'user_id' => $uid,
            'subject_id' => isset($c['subject']) ? ($subjectIds[$c['subject']] ?? null) : null,
            'name' => isset($c['name']) && is_string($c['name']) ? mb_substr($c['name'], 0, 80) : null,
            'day' => (int) $c['day'], 'start_time' => $c['start_time'], 'end_time' => $c['end_time'],
            'week' => in_array($c['week'] ?? '', ['every', 'A', 'B'], true) ? $c['week'] : 'every',
            'location' => isset($c['location']) && is_string($c['location']) ? mb_substr($c['location'], 0, 120) : null,
            'teacher' => isset($c['teacher']) && is_string($c['teacher']) ? mb_substr($c['teacher'], 0, 80) : null,
        ]);
    }
    $taskIds = [];
    foreach ($data['tasks'] ?? [] as $i => $t) {
        $subject = isset($t['subject']) ? ($subjectIds[$t['subject']] ?? null) : null;
        $type = $t['type'] ?? '';
        if ($type === 'homework') $type = 'assignment';   // older backups: homework is now an assignment
        if (! in_array($type, TASK_TYPES, true)) $type = 'assignment';
        if ($type !== 'personal' && ! $subject) continue;   // its subject is missing
        $completed = null;
        if (! empty($t['completed_at']) && is_string($t['completed_at']) && ($ts = strtotime($t['completed_at'])) !== false) {
            $completed = date('Y-m-d H:i:s', $ts);
        }
        $taskIds[$i] = db_insert('tasks', [
            'user_id' => $uid, 'subject_id' => $type === 'personal' ? null : $subject, 'type' => $type,
            'title' => mb_substr($t['title'], 0, 120), 'due_date' => $t['due_date'], 'due_time' => backup_time($t['due_time'] ?? null),
            'link' => is_string($t['link'] ?? null) ? mb_substr($t['link'], 0, 500) : null,
            'priority' => in_array($t['priority'] ?? '', PRIORITIES, true) ? $t['priority'] : 'normal',
            'notes' => isset($t['notes']) && is_string($t['notes']) ? mb_substr($t['notes'], 0, 2000) : null,
            'completed_at' => $completed,
        ]);
    }
    foreach ($data['study_sessions'] ?? [] as $s) {
        db_insert('study_sessions', [
            'user_id' => $uid,
            'subject_id' => isset($s['subject']) ? ($subjectIds[$s['subject']] ?? null) : null,
            'task_id' => isset($s['task']) ? ($taskIds[$s['task']] ?? null) : null,
            'title' => mb_substr($s['title'], 0, 120), 'date' => $s['date'], 'start_time' => $s['start_time'],
            'duration_minutes' => (int) $s['duration_minutes'],
            'status' => ($s['status'] ?? '') === 'completed' ? 'completed' : 'planned',
            'actual_minutes' => isset($s['actual_minutes']) ? (int) $s['actual_minutes'] : null,
        ]);
    }
}

/** Throws InvalidArgumentException (with an English message to translate) when the file isn't a usable backup. */
function backup_check(array $data): void
{
    $fail = fn (string $m) => throw new InvalidArgumentException($m);
    if (($data['app'] ?? null) !== 'StudyFlow' || ! is_int($data['version'] ?? null)) $fail('This file is not a StudyFlow backup.');
    if ($data['version'] > BACKUP_VERSION) $fail('This backup was made by a newer version of StudyFlow.');
    foreach (['subjects', 'terms', 'periods', 'timetable_slots', 'recurring_classes'] as $key) {
        if (! is_array($data[$key] ?? null)) $fail('The backup is incomplete or damaged.');
    }
    foreach (['tasks', 'study_sessions'] as $key) {
        if (isset($data[$key]) && ! is_array($data[$key])) $fail('The backup is incomplete or damaged.');
    }
    $all = array_merge($data['subjects'], $data['terms'], $data['periods'], $data['timetable_slots'], $data['recurring_classes'], $data['tasks'] ?? [], $data['study_sessions'] ?? []);
    foreach ($all as $row) if (! is_array($row)) $fail('The backup is incomplete or damaged.');

    $time = '/^([01]\d|2[0-3]):[0-5]\d$/';
    foreach ($data['subjects'] as $s) {
        if (! is_string($s['name'] ?? null) || trim($s['name']) === '') $fail('A subject in the backup has no name.');
    }
    foreach ($data['terms'] as $t) {
        if (! is_string($t['name'] ?? null) || ! backup_date($t['start_date'] ?? null) || ! backup_date($t['end_date'] ?? null) || $t['end_date'] < $t['start_date']) {
            $fail('A term in the backup has invalid dates.');
        }
    }
    foreach (array_merge($data['periods'], $data['recurring_classes']) as $p) {
        $st = $p['start_time'] ?? '';
        $en = $p['end_time'] ?? '';
        if (! is_string($st) || ! is_string($en) || ! preg_match($time, $st) || ! preg_match($time, $en) || $en <= $st) {
            $fail('A period or class in the backup has invalid times.');
        }
    }
    foreach ($data['periods'] as $p) {
        if (! is_string($p['name'] ?? null)) $fail('A period in the backup has no name.');
    }
    foreach ($data['tasks'] ?? [] as $t) {
        if (! is_string($t['title'] ?? null) || ! backup_date($t['due_date'] ?? null)) $fail('A task in the backup is missing its title or date.');
    }
    foreach ($data['study_sessions'] ?? [] as $s) {
        if (! is_string($s['title'] ?? null) || ! backup_date($s['date'] ?? null) || ! is_string($s['start_time'] ?? null) || ! preg_match($time, $s['start_time'])
            || (int) ($s['duration_minutes'] ?? 0) < 1 || (int) $s['duration_minutes'] > 600) {   // timer sessions can be any length
            $fail('A study session in the backup is invalid.');
        }
    }
    foreach (array_merge($data['timetable_slots'], $data['recurring_classes']) as $c) {
        if (! is_int($c['day'] ?? null) || $c['day'] < 1 || $c['day'] > 7) $fail('A class in the backup has an invalid day.');
    }
}

function backup_date($value): ?string
{
    return is_string($value) && valid_date($value) ? $value : null;
}

function backup_time($value): ?string
{
    return is_string($value) && valid_time($value) ? $value : null;
}
