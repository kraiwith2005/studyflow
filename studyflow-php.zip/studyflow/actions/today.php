<?php
/* Today: classes, what is due and the study plan for today. */

function today_page(): void
{
    $uid = user_id();
    $today = today();
    $date = $today->format('Y-m-d');

    $day = calendar_days($uid, $today, $today, true)[$date];
    $classes = array_values(array_filter($day['timed'], fn ($i) => $i['kind'] === 'class'));
    usort($classes, fn ($a, $b) => $a['start'] <=> $b['start']);

    $open = tasks_query($uid, 't.completed_at IS NULL AND t.due_date <= ?', [$today->modify('+7 days')->format('Y-m-d')],
        "t.due_date, FIELD(t.priority, 'high', 'normal', 'low'), t.due_time IS NULL, t.due_time");

    $sessions = sessions_query($uid, 'ss.date = ?', [$date], 'ss.start_time');
    $done = array_values(array_filter($sessions, fn ($s) => $s->status === 'completed'));
    [$weekCount, $weekMinutes] = week_study_totals($uid);

    page('today/index', [
        'title' => __('Today'),
        'todayDate' => $today,
        'classes' => $classes,
        'overdue' => array_values(array_filter($open, fn ($t) => $t->due_date < $date)),
        'dueToday' => array_values(array_filter($open, fn ($t) => $t->due_date === $date)),
        'dueSoon' => array_values(array_filter($open, fn ($t) => $t->due_date > $date)),
        'plannedToday' => array_values(array_filter($sessions, fn ($s) => $s->status === 'planned')),
        'doneToday' => $done,
        'weekCount' => $weekCount,
        'weekMinutes' => $weekMinutes,
        'subjects' => subjects_of($uid),
        'linkable' => linkable_tasks($uid),
        'returnUrl' => current_page(),
    ]);
}

/** The person finished or skipped the first-run tour. */
function tour_done(): void
{
    db_exec('UPDATE users SET tour_completed_at = ?, updated_at = ? WHERE id = ?', [now_sql(), now_sql(), user_id()]);
    http_response_code(204);
    exit;
}
