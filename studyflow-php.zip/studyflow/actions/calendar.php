<?php
/* Calendar: month, week and day views. */

function calendar_page(): void
{
    $uid = user_id();
    $view = in_array(query('view'), ['month', 'week', 'day'], true) ? query('view') : 'month';
    $date = valid_date(query('date')) ? to_date(query('date')) : today();

    $firstOfMonth = $date->modify('first day of this month');
    [$start, $end, $prev, $next] = match ($view) {
        'month' => [
            week_start_sunday($firstOfMonth),
            week_start_sunday($date->modify('last day of this month'))->modify('+6 days'),
            $firstOfMonth->modify('-1 month'),
            $firstOfMonth->modify('+1 month'),
        ],
        'week' => [
            week_start_sunday($date),
            week_start_sunday($date)->modify('+6 days'),
            $date->modify('-7 days'), $date->modify('+7 days'),
        ],
        'day' => [$date, $date, $date->modify('-1 day'), $date->modify('+1 day')],
    };

    $days = calendar_days($uid, $start, $end, $view !== 'month');

    // Hours shown in Week/Day: 7 AM – 9 PM, widened to fit anything earlier or later.
    [$fromHour, $toHour] = [7, 21];
    foreach ($days as $day) {
        foreach ($day['timed'] as $item) {
            $fromHour = min($fromHour, (int) substr($item['start'], 0, 2));
            $endH = (int) substr($item['end'], 0, 2) + ((int) substr($item['end'], 3, 2) > 0 ? 1 : 0);
            $toHour = max($toHour, min(24, $endH));
        }
    }

    $planner = planner($uid);

    page('calendar/index', [
        'title' => __('Calendar'),
        'view' => $view,
        'date' => $date,
        'prev' => $prev,
        'next' => $next,
        'days' => $days,
        'fromHour' => $fromHour,
        'toHour' => $toHour,
        'heading' => match ($view) {
            'month' => fmt_date($date, 'month'),
            'week' => week_title($start, $end),
            'day' => fmt_date($date, 'long'),
        },
        'subjects' => subjects_of($uid),
        'linkable' => linkable_tasks($uid),
        'weekLetter' => $planner->repeat_cycle === 'ab' ? week_letter($planner, $date) : null,
        'returnUrl' => current_page(),
    ]);
}

function week_title(DateTimeImmutable $start, DateTimeImmutable $end): string
{
    if (locale() === 'th') {
        return $start->format('n') === $end->format('n')
            ? $start->format('j').' – '.fmt_date($end)
            : fmt_date($start).' – '.fmt_date($end);
    }
    return $start->format('M j').' – '.$end->format('M j, Y');
}

/** Link to a calendar view for a date. */
function cal_url(string $view, $date): string
{
    return url('/calendar', ['view' => $view, 'date' => $date instanceof DateTimeImmutable ? $date->format('Y-m-d') : $date]);
}
