<?php
/* Manage account: profile, password, delete account, and the light / dark theme. */

function account_page(): void
{
    page('account', ['title' => __('Manage account'), 'user' => current_user()]);
}

function account_profile(): void
{
    $user = current_user();
    $data = [
        'first_name' => input_str('first_name'),
        'last_name' => input_str('last_name'),
        'email' => strtolower(input_str('email')),
    ];
    $errors = validate($data, [
        'first_name' => 'required|string|max:60',
        'last_name' => 'required|string|max:60',
        'email' => 'required|email|max:255',
    ]);
    if (! isset($errors['email']) && db_value('SELECT 1 FROM users WHERE email = ? AND id <> ?', [$data['email'], $user->id])) {
        add_error($errors, 'email', validation_message('email', 'unique', [], []));
    }
    if ($errors) {
        flash_errors($errors);
        redirect('/account');
    }
    db_update_user($user->id, $data);
    flash('status', __('Profile saved.'));
    redirect('/account');
}

function account_password(): void
{
    $user = current_user();
    $data = [
        'current_password' => (string) input('current_password', ''),
        'password' => (string) input('password', ''),
        'password_confirmation' => (string) input('password_confirmation', ''),
    ];
    $rules = ['password' => PASSWORD_RULE.'|confirmed'];
    if ($user->has_password) $rules = ['current_password' => 'required'] + $rules;
    $errors = validate($data, $rules);
    if ($user->has_password && ! isset($errors['current_password']) && ! password_verify($data['current_password'], $user->password)) {
        add_error($errors, 'current_password', __('Your current password is incorrect.'));
    }
    if ($errors) {
        flash_errors($errors, 'password');
        redirect('/account');
    }
    db_update_user($user->id, ['password' => password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12])]);
    flash('status', __('Password updated.'));
    redirect('/account');
}

function account_delete(): void
{
    $user = current_user();
    $errors = [];
    if ($user->has_password) {
        $password = (string) input('password', '');
        if ($password === '') add_error($errors, 'password', validation_message('password', 'required', [], []));
        elseif (! password_verify($password, $user->password)) add_error($errors, 'password', __('Your password is incorrect.'));
    } else {
        $typed = input_str('confirm_email');
        if ($typed === '') add_error($errors, 'confirm_email', validation_message('confirm_email', 'required', [], []));
        elseif ($typed !== $user->email) add_error($errors, 'confirm_email', __('Type your email address exactly as shown.'));
    }
    if ($errors) {
        flash_errors($errors, 'delete');
        redirect('/settings');
    }

    $id = (int) $user->id;
    logout_user();
    db_exec('DELETE FROM users WHERE id = ?', [$id]);   // planner data goes with it (foreign keys cascade)
    flash('status', __('Your account and all its data have been deleted.'));
    redirect('/sign-in');
}

/** JSON from the moon / sun button. */
function save_theme(): void
{
    $theme = input_str('theme');
    if (! in_array($theme, ['light', 'dark'], true)) {
        $msg = validation_message('theme', $theme === '' ? 'required' : 'in', [], []);
        json_response(['message' => $msg, 'errors' => ['theme' => [$msg]]], 422);
    }
    db_update_user(user_id(), ['theme' => $theme]);
    json_response(['saved' => true, 'theme' => $theme]);
}

function db_update_user(int $id, array $data): void
{
    $data['updated_at'] = now_sql();
    $set = implode(', ', array_map(fn ($c) => "`$c` = ?", array_keys($data)));
    db_exec("UPDATE users SET $set WHERE id = ?", [...array_values($data), $id]);
    $GLOBALS['RELOAD_USER'] = true;
}
