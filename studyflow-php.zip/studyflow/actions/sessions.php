<?php
/* Planned study sessions: add, edit, delete, mark as done. */

function study_session_store(): void
{
    $data = session_validated(null);
    db_insert('study_sessions', $data + ['user_id' => user_id()]);
    back_to_page(($data['status'] ?? null) === 'completed'
        ? __('Study logged: :title', ['title' => $data['title']])
        : __('Study session “:title” added.', ['title' => $data['title']]));
}

function study_session_update(int $id): void
{
    $s = own_session(user_id(), $id) ?? abort(404);
    db_update('study_sessions', session_validated($s), $s->id, user_id());
    back_to_page(__('Changes saved.'));
}

function study_session_destroy(int $id): void
{
    $s = own_session(user_id(), $id) ?? abort(404);
    db_exec('DELETE FROM study_sessions WHERE id = ? AND user_id = ?', [$s->id, user_id()]);
    back_to_page(__('“:title” deleted.', ['title' => $s->title]));
}

function study_session_toggle(int $id): void
{
    $s = own_session(user_id(), $id) ?? abort(404);
    $done = ! $s->done;
    db_update('study_sessions', [
        'status' => $done ? 'completed' : 'planned',
        'actual_minutes' => $done ? ($s->actual_minutes ?? $s->duration_minutes) : null,
    ], $s->id, user_id());
    back_to_page($done ? __('Marked as done.') : __('Marked as not done.'));
}

function session_validated(?object $session): array
{
    $uid = user_id();
    $data = [
        'title' => input_str('title'),
        'subject_id' => input_str('subject_id'),
        'date' => input_str('date'),
        'start_time' => input_str('start_time'),
        'duration_minutes' => input_str('duration_minutes'),
        'task_id' => input_str('task_id'),
    ];
    $errors = validate($data, [
        'title' => 'required|string|max:120',
        'subject_id' => 'required|integer',
        'date' => 'required|date',
        'start_time' => 'required|time',
        'duration_minutes' => 'required|integer|between:1,600',
        'task_id' => 'nullable|integer',
    ], [
        'title.required' => __('Enter a title.'),
        'subject_id.required' => __('Choose a subject.'),
        'duration_minutes.required' => __('Choose a duration.'),
    ]);
    if (! isset($errors['subject_id']) && ! own_subject($uid, $data['subject_id'])) {
        add_error($errors, 'subject_id', validation_message('subject_id', 'exists', [], []));
    }
    if (! isset($errors['task_id']) && $data['task_id'] !== '') {
        $t = own_task($uid, $data['task_id']);
        if (! $t || $t->type === 'personal') add_error($errors, 'task_id', validation_message('task_id', 'exists', [], []));
    }
    if (! $errors) {
        [$h, $m] = array_map('intval', explode(':', $data['start_time']));
        if ($h * 60 + $m + (int) $data['duration_minutes'] > 24 * 60) {
            add_error($errors, 'start_time', __('The session must end by midnight.'));
        }
    }
    if ($errors) {
        flash_errors($errors, 'session');
        flash('reopen', $session ? "session-{$session->id}" : 'new-session');
        back_to_page();
    }

    $out = [
        'title' => $data['title'],
        'subject_id' => (int) $data['subject_id'],
        'date' => $data['date'],
        'start_time' => $data['start_time'],
        'duration_minutes' => (int) $data['duration_minutes'],
        'task_id' => $data['task_id'] === '' ? null : (int) $data['task_id'],
    ];
    if (! $session && in_array((string) input('mark_done'), ['1', 'true', 'on', 'yes'], true)) {   // "Log study": already happened
        $out['status'] = 'completed';
        $out['actual_minutes'] = $out['duration_minutes'];
    }
    return $out;
}
