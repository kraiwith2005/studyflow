<?php
/* Start page, language switch and the public information pages. */

function home(): void
{
    redirect(current_user() ? '/today' : '/sign-in');
}

/** ไทย / EN: remember the choice in a cookie for a year, then return to the same page. */
function change_locale(string $code): void
{
    if (! in_array($code, LOCALES, true)) abort(404);
    setcookie('locale', $code, ['expires' => time() + 365 * 86400, 'path' => (BASE === '' ? '/' : BASE.'/'), 'samesite' => 'Lax']);
    $back = (string) input('back', '');
    if (! preg_match('#^/[a-z0-9\-/]*(\?[^\s]*)?$#i', $back) || str_starts_with($back, '//')) {
        $back = current_user() ? '/today' : '/sign-in';
    }
    header('Location: '.BASE.$back);
    exit;
}

function legal_privacy(): void { legal_page('privacy'); }
function legal_terms(): void { legal_page('terms'); }
function legal_cookies(): void { legal_page('cookies'); }

function legal_page(string $name): void
{
    $file = locale() === 'th' ? "legal/th/$name" : "legal/$name";
    // The page file sets $title and $updated, so render it here and pass them on.
    ob_start();
    include ROOT.'/views/'.$file.'.php';
    $content = ob_get_clean();
    echo view('layouts/legal', ['content' => $content, 'title' => $title, 'updated' => $updated]);
}
