<?php
/* Settings page, subjects and terms. */

const SETTINGS_SECTIONS = ['subjects', 'terms', 'timetable', 'backup'];

function settings_page(): void
{
    $uid = user_id();
    $planner = planner($uid);
    $subjects = db_all('SELECT s.*, (SELECT COUNT(*) FROM timetable_slots ts WHERE ts.subject_id = s.id) AS slots_count
                        FROM subjects s WHERE s.user_id = ? ORDER BY s.sort_order, s.name', [$uid]);
    $periods = db_all('SELECT * FROM periods WHERE user_id = ? ORDER BY sort_order, start_time', [$uid]);
    $weeks = plan_weeks($planner);
    $slots = db_all('SELECT * FROM timetable_slots WHERE user_id = ? AND week IN ('.implode(',', array_fill(0, count($weeks), '?')).')', [$uid, ...$weeks]);
    $grid = [];
    foreach ($slots as $s) $grid["{$s->period_id}-{$s->day}-{$s->week}"] = (int) $s->subject_id;
    $recurring = recurring_classes_of($uid);

    page('settings/index', [
        'title' => __('Settings'),
        'user' => current_user(),
        'planner' => $planner,
        'subjects' => $subjects,
        'terms' => terms_of($uid),
        'periods' => $periods,
        'grid' => $grid,
        'recurring' => $recurring,
        'classCount' => (uses_grid($planner) ? count($slots) : 0) + count($recurring),
        'open' => array_values(array_intersect(explode(',', (string) query('open', '')), SETTINGS_SECTIONS)),
    ]);
}

/* ---------- Subjects ---------- */

function subject_store(): void
{
    $uid = user_id();
    $data = subject_validated(null);
    $max = (int) db_value('SELECT COALESCE(MAX(sort_order), 0) FROM subjects WHERE user_id = ?', [$uid]);
    db_insert('subjects', $data + ['user_id' => $uid, 'sort_order' => $max + 1]);
    back_to_settings('subjects', __('Subject “:name” added.', ['name' => $data['name']]));
}

function subject_update(int $id): void
{
    $subject = own_subject(user_id(), $id) ?? abort(404);
    db_update('subjects', subject_validated($subject), (int) $subject->id, user_id());
    back_to_settings('subjects', __('Subject saved.'));
}

function subject_destroy(int $id): void
{
    $subject = own_subject(user_id(), $id) ?? abort(404);
    // Grid cells are removed with it; recurring classes keep their own name (database foreign keys).
    db_exec('DELETE FROM subjects WHERE id = ? AND user_id = ?', [$subject->id, user_id()]);
    back_to_settings('subjects', __('Subject “:name” deleted.', ['name' => $subject->name]));
}

function subject_validated(?object $subject): array
{
    $data = ['name' => input_str('name'), 'color' => input_str('color')];
    $errors = validate($data, [
        'name' => 'required|string|max:80',
        'color' => 'required|regex:/^#[0-9a-fA-F]{6}$/',
    ], [
        'name.required' => __('Enter a subject name.'),
        'color.regex' => __('Choose a colour.'),
    ]);
    if (! isset($errors['name'])) {
        $taken = db_value('SELECT id FROM subjects WHERE user_id = ? AND name = ? AND id <> ?', [user_id(), $data['name'], $subject->id ?? 0]);
        if ($taken) add_error($errors, 'name', __('You already have a subject with this name.'));
    }
    if ($errors) {
        flash_errors($errors, 'subject');
        flash('reopen', $subject ? "subject-{$subject->id}" : 'subject-new');
        back_to_settings('subjects');
    }
    $data['color'] = strtolower($data['color']);
    return $data;
}

/* ---------- Terms ---------- */

function own_term(int $uid, $id): ?object
{
    return is_numeric($id) ? db_one('SELECT * FROM terms WHERE id = ? AND user_id = ?', [(int) $id, $uid]) : null;
}

function term_store(): void
{
    $data = term_validated(null);
    db_insert('terms', $data + ['user_id' => user_id()]);
    back_to_settings('terms', __('Term “:name” added.', ['name' => $data['name']]));
}

function term_update(int $id): void
{
    $term = own_term(user_id(), $id) ?? abort(404);
    db_update('terms', term_validated($term), (int) $term->id, user_id());
    back_to_settings('terms', __('Term saved.'));
}

function term_destroy(int $id): void
{
    $term = own_term(user_id(), $id) ?? abort(404);
    db_exec('DELETE FROM terms WHERE id = ? AND user_id = ?', [$term->id, user_id()]);
    back_to_settings('terms', __('Term “:name” deleted.', ['name' => $term->name]));
}

function term_validated(?object $term): array
{
    $data = ['name' => input_str('name'), 'start_date' => input_str('start_date'), 'end_date' => input_str('end_date')];
    $errors = validate($data, [
        'name' => 'required|string|max:60',
        'start_date' => 'required|date',
        'end_date' => 'required|date|after_or_equal:start_date',
    ], [
        'name.required' => __('Enter a term name.'),
        'end_date.after_or_equal' => __('The end date must be on or after the start date.'),
    ]);
    if (! $errors) {
        $overlap = db_one('SELECT name FROM terms WHERE user_id = ? AND id <> ? AND start_date <= ? AND end_date >= ? LIMIT 1',
            [user_id(), $term->id ?? 0, $data['end_date'], $data['start_date']]);
        if ($overlap) add_error($errors, 'start_date', __('These dates overlap “:name”. Terms can’t overlap.', ['name' => $overlap->name]));
    }
    if ($errors) {
        flash_errors($errors, 'term');
        flash('reopen', $term ? "term-{$term->id}" : 'term-new');
        back_to_settings('terms');
    }
    return $data;
}
