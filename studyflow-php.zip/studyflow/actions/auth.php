<?php
/* Create an account, sign in and out, and reset a forgotten password. */

function sign_up_form(): void
{
    page('auth/sign_up', ['title' => __('Create your account')], 'guest');
}

function sign_up(): void
{
    $data = [
        'first_name' => input_str('first_name'),
        'last_name' => input_str('last_name'),
        'email' => strtolower(input_str('email')),
        'password' => (string) input('password', ''),
    ];
    $errors = validate($data, [
        'first_name' => 'required|string|max:60',
        'last_name' => 'required|string|max:60',
        'email' => 'required|string|email|max:255',
        'password' => PASSWORD_RULE,
    ]);
    if (! isset($errors['email']) && db_value('SELECT 1 FROM users WHERE email = ?', [$data['email']])) {
        add_error($errors, 'email', __('An account with this email already exists. Sign in instead.'));
    }
    if ($errors) {
        flash_errors($errors);
        redirect('/sign-up');
    }
    $id = db_insert('users', [
        'first_name' => $data['first_name'],
        'last_name' => $data['last_name'],
        'email' => $data['email'],
        'password' => password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]),
    ]);
    login_user($id);
    redirect('/today');
}

function sign_in_form(): void
{
    page('auth/sign_in', ['title' => __('Sign in')], 'guest');
}

function sign_in(): void
{
    $data = ['email' => strtolower(input_str('email')), 'password' => (string) input('password', '')];
    $errors = validate($data, ['email' => 'required|string|email', 'password' => 'required|string']);
    if ($errors) {
        flash_errors($errors);
        redirect('/sign-in');
    }
    // At most 5 wrong tries per minute for each email + IP address.
    $key = 'login|'.$data['email'].'|'.client_ip();
    if ($wait = too_many_attempts($key, 5)) {
        flash_errors(['email' => [__('Too many sign-in attempts. Try again in :seconds seconds.', ['seconds' => $wait])]]);
        redirect('/sign-in');
    }
    $user = db_one('SELECT id, password FROM users WHERE email = ?', [$data['email']]);
    if (! $user || ! $user->password || ! password_verify($data['password'], $user->password)) {
        hit_attempt($key, 60);
        flash_errors(['email' => [__('The email or password is incorrect.')]]);
        redirect('/sign-in');
    }
    clear_attempts($key);
    login_user((int) $user->id);
    // Go to the page the person wanted before signing in, otherwise Today.
    $intended = $_SESSION['intended'] ?? '/today';
    unset($_SESSION['intended']);
    header('Location: '.BASE.(preg_match('#^/[a-z]#', $intended) ? $intended : '/today'));
    exit;
}

function sign_out(): void
{
    logout_user();
    redirect('/sign-in');
}

/* ---------- Forgotten password ---------- */

function forgot_form(): void
{
    page('auth/forgot_password', ['title' => __('Reset your password')], 'guest');
}

function forgot_send(): void
{
    $email = strtolower(input_str('email'));
    $errors = validate(['email' => $email], ['email' => 'required|email']);
    if ($errors) {
        flash_errors($errors);
        redirect('/forgot-password');
    }
    $key = 'reset|'.client_ip();
    if (too_many_attempts($key, 5)) abort(429);
    hit_attempt($key, 60);

    $user = db_one('SELECT id, first_name, email FROM users WHERE email = ?', [$email]);
    if ($user) {
        $token = bin2hex(random_bytes(32));
        db_exec('REPLACE INTO password_reset_tokens (email, token, created_at) VALUES (?, ?, ?)', [$email, hash('sha256', $token), now_sql()]);
        send_reset_link($user, $token);
    }
    // Same message whether or not the account exists, so emails can't be probed.
    flash('status', __('If an account exists for that email, a reset link is on its way.'));
    redirect('/forgot-password');
}

function send_reset_link(object $user, string $token): void
{
    global $CONFIG;
    $scheme = ((! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')) ? 'https' : 'http';
    $link = $scheme.'://'.($_SERVER['HTTP_HOST'] ?? 'localhost').url('/reset-password/'.$token, ['email' => $user->email]);
    if (($CONFIG['reset_mode'] ?? 'log') === 'mail') {
        $subject = 'StudyFlow: '.__('Reset your password');
        $body = __('Use this link to choose a new password (valid for 60 minutes):')."\n\n".$link."\n";
        @mail($user->email, '=?UTF-8?B?'.base64_encode($subject).'?=', $body,
            "From: StudyFlow <{$CONFIG['mail_from']}>\r\nContent-Type: text/plain; charset=UTF-8");
    } else {
        file_put_contents(ROOT.'/storage/logs/password-reset.log', '['.now_sql().'] '.$user->email.' '.$link.PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

function reset_form(string $token): void
{
    page('auth/reset_password', ['title' => __('Choose a new password'), 'token' => $token, 'email' => (string) query('email', '')], 'guest');
}

function reset_save(): void
{
    $data = [
        'token' => input_str('token'),
        'email' => strtolower(input_str('email')),
        'password' => (string) input('password', ''),
        'password_confirmation' => (string) input('password_confirmation', ''),
    ];
    $errors = validate($data, ['token' => 'required', 'email' => 'required|email', 'password' => PASSWORD_RULE.'|confirmed']);
    if (! $errors) {
        // The link works once, for 60 minutes.
        $row = db_one('SELECT token, created_at FROM password_reset_tokens WHERE email = ?', [$data['email']]);
        $valid = $row && hash_equals($row->token, hash('sha256', $data['token'])) && strtotime($row->created_at) > time() - 3600;
        $user = $valid ? db_one('SELECT id FROM users WHERE email = ?', [$data['email']]) : null;
        if (! $user) add_error($errors, 'email', __('This reset link is invalid or has expired. Request a new one.'));
    }
    if ($errors) {
        flash_errors($errors);
        header('Location: '.url('/reset-password/'.rawurlencode($data['token']), ['email' => $data['email']]));
        exit;
    }
    db_exec('UPDATE users SET password = ?, remember_token = NULL, updated_at = ? WHERE id = ?',
        [password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]), now_sql(), $user->id]);
    db_exec('DELETE FROM password_reset_tokens WHERE email = ?', [$data['email']]);
    flash('status', __('Your password has been reset. Sign in with your new password.'));
    redirect('/sign-in');
}
