<?php
/* Timetable settings, period times, the grid and recurring classes. */

/** JSON: timetable type, repeat cycle and Week A anchor. */
function timetable_settings(): void
{
    $data = [
        'timetable_type' => input_str('timetable_type'),
        'repeat_cycle' => input_str('repeat_cycle'),
        'cycle_anchor' => input_str('cycle_anchor'),
    ];
    $errors = validate($data, [
        'timetable_type' => 'required|in:school,university,custom',
        'repeat_cycle' => 'required|in:weekly,ab',
        'cycle_anchor' => 'nullable|date',
    ]);
    if ($errors) json_response(['message' => reset($errors)[0], 'errors' => $errors], 422);

    if ($data['repeat_cycle'] === 'ab') {
        // Always store the Monday of the chosen Week A (default: this week).
        $anchor = $data['cycle_anchor'] !== '' ? to_date($data['cycle_anchor']) : today();
        $data['cycle_anchor'] = week_start_monday($anchor)->format('Y-m-d');
    } else {
        $data['cycle_anchor'] = null;
    }
    planner(user_id());
    db_exec('UPDATE planner_settings SET timetable_type = ?, repeat_cycle = ?, cycle_anchor = ?, updated_at = ? WHERE user_id = ?',
        [$data['timetable_type'], $data['repeat_cycle'], $data['cycle_anchor'], now_sql(), user_id()]);
    json_response(['saved' => true] + $data);
}

/** Replace the list of periods (Edit period times). */
function timetable_periods(): void
{
    $uid = user_id();
    $rows = input('periods', []);
    $rows = is_array($rows) ? array_values(array_filter($rows, 'is_array')) : [];

    $errors = [];
    if (! $rows) add_error($errors, 'periods', __('Keep at least one period.'));
    elseif (count($rows) > 20) add_error($errors, 'periods', validation_message('periods', 'max', ['max' => 20], [], 'array'));
    foreach ($rows as $i => $p) {
        if ($errors) break;
        $p = array_map(fn ($v) => is_string($v) ? trim($v) : $v, $p);
        $rows[$i] = $p;
        if (($p['name'] ?? '') === '') add_error($errors, "periods.$i.name", __('Every period needs a name.'));
        elseif (mb_strlen($p['name']) > 40) add_error($errors, "periods.$i.name", validation_message('name', 'max', ['max' => 40], [], 'string'));
        elseif (! in_array($p['kind'] ?? '', ['class', 'break'], true)) add_error($errors, "periods.$i.kind", validation_message('kind', 'in', [], []));
        elseif (($p['start_time'] ?? '') === '') add_error($errors, "periods.$i.start_time", __('Every period needs a start time.'));
        elseif (($p['end_time'] ?? '') === '') add_error($errors, "periods.$i.end_time", __('Every period needs an end time.'));
        elseif (! valid_time($p['start_time']) || ! valid_time($p['end_time'])) add_error($errors, "periods.$i.start_time", validation_message('start_time', 'date_format', ['format' => 'H:i'], []));
    }
    if (! $errors) {
        usort($rows, fn ($a, $b) => strcmp($a['start_time'], $b['start_time']));
        foreach ($rows as $i => $p) {
            if ($p['end_time'] <= $p['start_time']) {
                add_error($errors, 'periods', __('“:name” must end after it starts.', ['name' => $p['name']]));
                break;
            }
            if ($i > 0 && $p['start_time'] < $rows[$i - 1]['end_time']) {
                add_error($errors, 'periods', __('“:name” overlaps “:other”.', ['name' => $p['name'], 'other' => $rows[$i - 1]['name']]));
                break;
            }
        }
    }
    if ($errors) {
        flash_errors($errors, 'periods');
        flash('reopen', 'periods');
        back_to_settings('timetable');
    }

    $pdo = db();
    $pdo->beginTransaction();
    $ownIds = array_map('intval', array_column(db_all('SELECT id FROM periods WHERE user_id = ?', [$uid]), 'id'));
    $keep = [];
    foreach ($rows as $i => $p) {
        $values = ['name' => $p['name'], 'kind' => $p['kind'], 'start_time' => $p['start_time'], 'end_time' => $p['end_time'], 'sort_order' => $i];
        $id = (int) ($p['id'] ?? 0);
        if ($id && in_array($id, $ownIds, true)) {
            db_update('periods', $values, $id, $uid);
            $keep[] = $id;
        } else {
            $keep[] = db_insert('periods', $values + ['user_id' => $uid]);
        }
    }
    // Removed periods go (their grid cells too); a period that became a break can't hold classes.
    db_exec('DELETE FROM periods WHERE user_id = ? AND id NOT IN ('.implode(',', array_fill(0, count($keep), '?')).')', [$uid, ...$keep]);
    db_exec("DELETE ts FROM timetable_slots ts JOIN periods p ON p.id = ts.period_id WHERE ts.user_id = ? AND p.kind = 'break'", [$uid]);
    $pdo->commit();

    back_to_settings('timetable', __('Period times saved.'));
}

/** JSON: set or clear one grid cell. */
function timetable_slot(): void
{
    $uid = user_id();
    $planner = planner($uid);
    $data = [
        'period_id' => (string) input('period_id', ''),
        'day' => (string) input('day', ''),
        'week' => (string) input('week', ''),
        'subject_id' => (string) (input('subject_id') ?? ''),
    ];
    $errors = validate($data, [
        'period_id' => 'required|integer',
        'day' => 'required|integer|in:'.implode(',', grid_days($planner)),
        'week' => 'required|in:'.implode(',', plan_weeks($planner)),
        'subject_id' => 'nullable|integer',
    ]);
    if (! isset($errors['period_id']) && ! db_value("SELECT 1 FROM periods WHERE id = ? AND user_id = ? AND kind = 'class'", [(int) $data['period_id'], $uid])) {
        add_error($errors, 'period_id', validation_message('period_id', 'exists', [], []));
    }
    if (! isset($errors['subject_id']) && $data['subject_id'] !== '' && ! own_subject($uid, $data['subject_id'])) {
        add_error($errors, 'subject_id', validation_message('subject_id', 'exists', [], []));
    }
    if ($errors) json_response(['message' => reset($errors)[0], 'errors' => $errors], 422);

    $key = [$uid, (int) $data['period_id'], (int) $data['day'], $data['week']];
    if ($data['subject_id'] === '') {
        db_exec('DELETE FROM timetable_slots WHERE user_id = ? AND period_id = ? AND day = ? AND week = ?', $key);
    } elseif ($row = db_one('SELECT id FROM timetable_slots WHERE user_id = ? AND period_id = ? AND day = ? AND week = ?', $key)) {
        db_update('timetable_slots', ['subject_id' => (int) $data['subject_id']], (int) $row->id, $uid);
    } else {
        db_insert('timetable_slots', ['user_id' => $uid, 'period_id' => $key[1], 'day' => $key[2], 'week' => $key[3], 'subject_id' => (int) $data['subject_id']]);
    }

    $weeks = plan_weeks($planner);
    $grid = uses_grid($planner)
        ? (int) db_value('SELECT COUNT(*) FROM timetable_slots WHERE user_id = ? AND week IN ('.implode(',', array_fill(0, count($weeks), '?')).')', [$uid, ...$weeks]) : 0;
    $count = $grid + (int) db_value('SELECT COUNT(*) FROM recurring_classes WHERE user_id = ?', [$uid]);
    json_response(['saved' => true, 'class_count' => $count]);
}

function timetable_clear(): void
{
    db_exec('DELETE FROM timetable_slots WHERE user_id = ?', [user_id()]);
    back_to_settings('timetable', __('Timetable grid cleared.'));
}

/* ---------- Recurring classes ---------- */

function own_class(int $uid, $id): ?object
{
    return is_numeric($id) ? db_one('SELECT * FROM recurring_classes WHERE id = ? AND user_id = ?', [(int) $id, $uid]) : null;
}

function class_store(): void
{
    db_insert('recurring_classes', class_validated(null) + ['user_id' => user_id()]);
    back_to_settings('timetable', __('Class added.'));
}

function class_update(int $id): void
{
    $class = own_class(user_id(), $id) ?? abort(404);
    db_update('recurring_classes', class_validated($class), (int) $class->id, user_id());
    back_to_settings('timetable', __('Class saved.'));
}

function class_destroy(int $id): void
{
    $class = own_class(user_id(), $id) ?? abort(404);
    db_exec('DELETE FROM recurring_classes WHERE id = ? AND user_id = ?', [$class->id, user_id()]);
    back_to_settings('timetable', __('Class deleted.'));
}

function class_validated(?object $class): array
{
    $data = [];
    foreach (['name', 'subject_id', 'day', 'start_time', 'end_time', 'week', 'location', 'teacher'] as $f) $data[$f] = input_str($f);
    $errors = validate($data, [
        'name' => 'nullable|string|max:80',
        'subject_id' => 'nullable|integer',
        'day' => 'required|integer|between:1,7',
        'start_time' => 'required|time',
        'end_time' => 'required|time|after:start_time',
        'week' => 'required|in:every,A,B',
        'location' => 'nullable|string|max:120',
        'teacher' => 'nullable|string|max:80',
    ], ['end_time.after' => __('The end time must be after the start time.')]);
    if (! isset($errors['subject_id']) && $data['subject_id'] !== '' && ! own_subject(user_id(), $data['subject_id'])) {
        add_error($errors, 'subject_id', validation_message('subject_id', 'exists', [], []));
    }
    if ($data['name'] === '' && $data['subject_id'] === '') {
        add_error($errors, 'name', __('Pick a subject or enter a class name.'));
    }
    if ($errors) {
        flash_errors($errors, 'klass');
        flash('reopen', $class ? "class-{$class->id}" : 'class-new');
        back_to_settings('timetable');
    }
    return [
        'name' => $data['name'] ?: null,
        'subject_id' => $data['subject_id'] === '' ? null : (int) $data['subject_id'],
        'day' => (int) $data['day'],
        'start_time' => $data['start_time'],
        'end_time' => $data['end_time'],
        'week' => $data['week'],
        'location' => $data['location'] ?: null,
        'teacher' => $data['teacher'] ?: null,
    ];
}
