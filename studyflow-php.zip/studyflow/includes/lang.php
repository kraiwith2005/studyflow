<?php
/*
 * Two languages: Thai (default) and English.
 * The English text itself is the key; lang/th.json holds the Thai version.
 * The choice is kept in a "locale" cookie for a year.
 */

const LOCALES = ['th', 'en'];

function set_locale_from_cookie(): void
{
    $c = $_COOKIE['locale'] ?? '';
    $GLOBALS['LOCALE'] = in_array($c, LOCALES, true) ? $c : 'th';
}

function locale(): string
{
    return $GLOBALS['LOCALE'] ?? 'th';
}

/** Translate a sentence and fill in :placeholders. */
function __(string $text, array $replace = []): string
{
    static $th = null;
    if (locale() === 'th') {
        if ($th === null) $th = json_decode((string) file_get_contents(ROOT.'/lang/th.json'), true) ?: [];
        $text = $th[$text] ?? $text;
    }
    return fill_placeholders($text, $replace);
}

/** Plural form: "1 day|2 days". Thai has a single form. */
function trans_choice(string $text, int $count, array $replace = []): string
{
    $line = __($text);           // translated (still with |)
    $parts = explode('|', $line);
    $chosen = (count($parts) > 1 && $count !== 1) ? $parts[1] : $parts[0];
    return fill_placeholders($chosen, $replace + ['count' => $count]);
}

function fill_placeholders(string $text, array $replace): string
{
    if (! $replace) return $text;
    // Longest names first so ":hh" is not broken by ":h".
    uksort($replace, fn ($a, $b) => strlen($b) - strlen($a));
    foreach ($replace as $k => $v) {
        $text = str_replace(':'.$k, (string) $v, $text);
    }
    return $text;
}

/** Strings that the JavaScript files need, in the current language. */
function js_strings(): array
{
    return [
        'saving' => __('Saving…'),
        'saved' => __('Saved'),
        'notSaved' => __('Not saved'),
        'showPassword' => __('Show password'),
        'hidePassword' => __('Hide password'),
        'toLight' => __('Switch to light mode'),
        'toDark' => __('Switch to dark mode'),
        'class' => __(':count class'),
        'classes' => __(':count classes'),
        'period' => __('Period :n'),
        'delete' => __('Delete'),
        'add' => __('Add'),
        'save' => __('Save'),
    ];
}
