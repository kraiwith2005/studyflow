<?php
/*
 * Loaded first on every request: settings, error handling, session,
 * database connection and the shared helper functions.
 */

define('ROOT', dirname(__DIR__));

if (! is_file(ROOT.'/config.php')) {
    http_response_code(500);
    exit('StudyFlow is not set up yet: copy config.sample.php to config.php and fill in the database details.');
}
$CONFIG = require ROOT.'/config.php';

date_default_timezone_set('Asia/Bangkok');
mb_internal_encoding('UTF-8');

// Errors: show them while developing, log them on the live site.
ini_set('display_errors', $CONFIG['debug'] ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', ROOT.'/storage/logs/php-error.log');
error_reporting(E_ALL);

// Base path, so the app works in a sub-folder (http://localhost/studyflow) and at a domain root.
$script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
define('BASE', rtrim(dirname($script), '/'));

require ROOT.'/includes/db.php';
require ROOT.'/includes/helpers.php';
require ROOT.'/includes/lang.php';
require ROOT.'/includes/auth.php';
require ROOT.'/includes/validate.php';
require ROOT.'/includes/models.php';

// Session cookie: HTTP only, same-site, secure when served over HTTPS.
$https = (! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('studyflow_session');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => (BASE === '' ? '/' : BASE.'/'),
    'httponly' => true,
    'secure' => $https,
    'samesite' => 'Lax',
]);
session_start();

// Flash data (messages and old form input) lives for exactly one request.
$GLOBALS['FLASH'] = $_SESSION['_flash'] ?? [];
unset($_SESSION['_flash']);

set_locale_from_cookie();
remember_login();   // signs the person back in from their "remember me" cookie
