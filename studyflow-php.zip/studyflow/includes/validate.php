<?php
/*
 * A small form validator.
 *
 *   $errors = validate($data, [
 *       'title' => 'required|string|max:120',
 *       'due_date' => 'required|date',          // Y-m-d
 *       'due_time' => 'nullable|time',          // H:i
 *   ], ['title.required' => __('Enter a title.')]);
 *
 * Returns [] when everything is fine, otherwise ['field' => ['message', ...]].
 * Checks that need the database (unique, belongs to this user) are done in the actions.
 */

function validate(array $data, array $rules, array $messages = []): array
{
    $errors = [];
    foreach ($rules as $field => $ruleString) {
        $value = $data[$field] ?? null;
        $list = explode('|', $ruleString);
        $empty = $value === null || $value === '' || (is_array($value) && ! $value);

        if ($empty) {
            if (in_array('required', $list, true)) $errors[$field][] = validation_message($field, 'required', [], $messages);
            continue;   // optional and empty: nothing else to check
        }
        $isNumber = in_array('integer', $list, true);
        foreach ($list as $rule) {
            [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);
            $ok = match ($name) {
                'required', 'nullable' => true,
                'string' => is_string($value),
                'array' => is_array($value),
                'integer' => is_int($value) || (is_string($value) && preg_match('/^-?\d+$/', $value)),
                'email' => is_string($value) && filter_var($value, FILTER_VALIDATE_EMAIL) !== false,
                'max' => is_array($value) ? count($value) <= (int) $arg : ($isNumber ? (int) $value <= (int) $arg : mb_strlen((string) $value) <= (int) $arg),
                'min' => is_array($value) ? count($value) >= (int) $arg : ($isNumber ? (int) $value >= (int) $arg : mb_strlen((string) $value) >= (int) $arg),
                'between' => (function () use ($value, $arg) { [$lo, $hi] = explode(',', $arg); return (int) $value >= (int) $lo && (int) $value <= (int) $hi; })(),
                'in' => in_array((string) $value, explode(',', (string) $arg), true),
                'date' => valid_date(is_string($value) ? $value : null),
                'time' => valid_time(is_string($value) ? $value : null),
                'regex' => is_string($value) && preg_match($arg, $value),
                'url' => is_string($value) && filter_var($value, FILTER_VALIDATE_URL) !== false && preg_match('#^https?://#i', $value),
                'confirmed' => $value === ($data[$field.'_confirmation'] ?? null),
                'letters' => is_string($value) && preg_match('/\pL/u', $value),
                'numbers' => is_string($value) && preg_match('/\pN/u', $value),
                'after' => ! valid_time($data[$arg] ?? null) || (string) $value > (string) $data[$arg],
                'after_or_equal' => ! valid_date($data[$arg] ?? null) || (string) $value >= (string) $data[$arg],
                default => true,
            };
            if (! $ok) {
                $key = match ($name) { 'date' => 'date_format', 'time' => 'date_format', 'letters' => 'password.letters', 'numbers' => 'password.numbers', default => $name };
                $params = match ($name) {
                    'max' => ['max' => $arg], 'min' => ['min' => $arg],
                    'between' => array_combine(['min', 'max'], explode(',', $arg)),
                    'date' => ['format' => 'Y-m-d'], 'time' => ['format' => 'H:i'],
                    'after', 'after_or_equal' => ['date' => attribute_name($arg)],
                    default => [],
                };
                $sub = in_array($name, ['max', 'min', 'between'], true) ? (is_array($value) ? 'array' : ($isNumber ? 'numeric' : 'string')) : null;
                $errors[$field][] = validation_message($field, $key, $params, $messages, $sub);
                break;   // one message per field is enough
            }
        }
    }
    return $errors;
}

/** Add an error by hand (used for checks that need the database). */
function add_error(array &$errors, string $field, string $message): void
{
    $errors[$field][] = $message;
}

function validation_lines(): array
{
    static $lines = [];
    $loc = locale();
    return $lines[$loc] ??= require ROOT.'/lang/'.$loc.'-validation.php';
}

function attribute_name(string $field): string
{
    return validation_lines()['attributes'][$field] ?? str_replace('_', ' ', $field);
}

function validation_message(string $field, string $rule, array $params, array $custom, ?string $sub = null): string
{
    $short = explode('.', $rule)[0];
    if (isset($custom[$field.'.'.$short])) return $custom[$field.'.'.$short];
    if (isset($custom[$field.'.'.$rule])) return $custom[$field.'.'.$rule];
    $lines = validation_lines();
    $line = $lines;
    foreach (explode('.', $rule) as $part) $line = $line[$part] ?? null;
    if (is_array($line)) $line = $line[$sub ?? 'string'] ?? reset($line);
    $line ??= 'The :attribute field is invalid.';
    return fill_placeholders($line, $params + ['attribute' => attribute_name($field)]);
}

/** Password rule used everywhere: at least 8 characters with letters and numbers. */
const PASSWORD_RULE = 'required|string|min:8|letters|numbers';
