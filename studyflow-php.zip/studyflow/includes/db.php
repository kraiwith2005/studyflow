<?php
/*
 * Database connection (MySQL / MariaDB through PDO) and three small helpers.
 * Every query uses prepared statements with ? placeholders, so values from
 * forms can never change the SQL itself (protects against SQL injection).
 */

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        global $CONFIG;
        $dsn = 'mysql:host='.$CONFIG['db_host'].';dbname='.$CONFIG['db_name'].';charset=utf8mb4';
        $pdo = new PDO($dsn, $CONFIG['db_user'], $CONFIG['db_pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        // Times are written as Bangkok time by PHP (now_sql), never with SQL NOW(),
        // so the database's own time zone setting doesn't matter.
    }
    return $pdo;
}

/** Run a query and return all rows (as objects). */
function db_all(string $sql, array $params = []): array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

/** Run a query and return the first row, or null. */
function db_one(string $sql, array $params = []): ?object
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row === false ? null : $row;
}

/** Run a query and return the first column of the first row. */
function db_value(string $sql, array $params = [])
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $v = $st->fetchColumn();
    return $v === false ? null : $v;
}

/** INSERT / UPDATE / DELETE. Returns the number of affected rows. */
function db_exec(string $sql, array $params = []): int
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->rowCount();
}

/** Insert a row from an array of column => value and return its new id. */
function db_insert(string $table, array $data): int
{
    $data += ['created_at' => now_sql(), 'updated_at' => now_sql()];
    $cols = array_keys($data);
    $sql = 'INSERT INTO `'.$table.'` (`'.implode('`,`', $cols).'`) VALUES ('.implode(',', array_fill(0, count($cols), '?')).')';
    db_exec($sql, array_values($data));
    return (int) db()->lastInsertId();
}

/** Update a row that belongs to the signed-in user. */
function db_update(string $table, array $data, int $id, int $userId): int
{
    $data['updated_at'] = now_sql();
    $set = implode(', ', array_map(fn ($c) => "`$c` = ?", array_keys($data)));
    return db_exec("UPDATE `$table` SET $set WHERE id = ? AND user_id = ?", [...array_values($data), $id, $userId]);
}

function now_sql(): string
{
    return date('Y-m-d H:i:s');
}
