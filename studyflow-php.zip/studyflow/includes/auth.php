<?php
/*
 * Signing in and out, the signed-in user, CSRF protection and rate limits.
 * Passwords are stored with password_hash() (bcrypt) and checked with password_verify().
 */

const REMEMBER_DAYS = 400;

/** The signed-in user (database row with extra display fields), or null. */
function current_user(): ?object
{
    static $user = false;
    if ($user === false || isset($GLOBALS['RELOAD_USER'])) {
        unset($GLOBALS['RELOAD_USER']);
        $id = $_SESSION['user_id'] ?? null;
        $user = $id ? db_one('SELECT * FROM users WHERE id = ?', [$id]) : null;
        if ($user) decorate_user($user);
        elseif ($id) unset($_SESSION['user_id']);   // account was deleted
    }
    return $user;
}

function user_id(): int
{
    return (int) current_user()->id;
}

function decorate_user(object $u): void
{
    $u->full_name = trim($u->first_name.' '.$u->last_name);
    $u->initial = mb_strtoupper(mb_substr($u->first_name ?: $u->email, 0, 1));
    $palette = ['#9b4dca', '#3f7cc4', '#c2477a', '#2f8a6b', '#c27a2c', '#5b5bd6', '#b5483b'];
    $u->avatar_color = $palette[crc32(strtolower($u->email)) % count($palette)];
    $u->has_password = ! empty($u->password);
}

/** Pages that need a signed-in user. */
function require_login(): void
{
    if (! current_user()) {
        if (wants_json()) json_response(['message' => 'Unauthenticated.'], 401);
        if ($_SERVER['REQUEST_METHOD'] === 'GET') $_SESSION['intended'] = current_page();
        redirect('/sign-in');
    }
}

/** Pages only for people who are not signed in (sign-in, sign-up…). */
function require_guest(): void
{
    if (current_user()) redirect('/today');
}

function login_user(int $id): void
{
    session_regenerate_id(true);            // new session id: protects against session fixation
    $_SESSION['user_id'] = $id;
    $GLOBALS['RELOAD_USER'] = true;
    set_remember_cookie($id);
}

function logout_user(): void
{
    $u = current_user();
    if ($u) db_exec('UPDATE users SET remember_token = NULL WHERE id = ?', [$u->id]);
    clear_remember_cookie();
    $_SESSION = [];
    session_regenerate_id(true);
    $GLOBALS['RELOAD_USER'] = true;
}

/* "Remember me": a long-lived cookie with a random token; only its hash is stored. */
function set_remember_cookie(int $id): void
{
    $token = bin2hex(random_bytes(30));
    db_exec('UPDATE users SET remember_token = ? WHERE id = ?', [hash('sha256', $token), $id]);
    setcookie('studyflow_remember', $id.'|'.$token, remember_cookie_options(time() + REMEMBER_DAYS * 86400));
}

function clear_remember_cookie(): void
{
    setcookie('studyflow_remember', '', remember_cookie_options(time() - 3600));
}

function remember_cookie_options(int $expires): array
{
    $https = (! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    return ['expires' => $expires, 'path' => (BASE === '' ? '/' : BASE.'/'), 'httponly' => true, 'secure' => $https, 'samesite' => 'Lax'];
}

function remember_login(): void
{
    if (! empty($_SESSION['user_id']) || empty($_COOKIE['studyflow_remember'])) return;
    [$id, $token] = array_pad(explode('|', (string) $_COOKIE['studyflow_remember'], 2), 2, '');
    $row = ctype_digit($id) ? db_one('SELECT id, remember_token FROM users WHERE id = ?', [(int) $id]) : null;
    if ($row && $row->remember_token && hash_equals($row->remember_token, hash('sha256', $token))) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $row->id;
    } else {
        clear_remember_cookie();
    }
}

/* ---------- CSRF: every form and request that changes data must carry this token ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['_token'])) $_SESSION['_token'] = bin2hex(random_bytes(20));
    return $_SESSION['_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="'.e(csrf_token()).'">';
}

/** Forms can only send GET and POST; this hidden field tells the app to treat a POST as PUT/PATCH/DELETE. */
function method_field(string $method): string
{
    return '<input type="hidden" name="_method" value="'.e($method).'">';
}

function check_csrf(): void
{
    $sent = $_POST['_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (! is_string($sent) || empty($_SESSION['_token']) || ! hash_equals($_SESSION['_token'], $sent)) {
        abort(419);
    }
}

/* ---------- Rate limits (e.g. 5 wrong passwords per minute) ---------- */

/** Seconds to wait if $key has been tried $max times or more; 0 if allowed. */
function too_many_attempts(string $key, int $max): int
{
    $row = db_one('SELECT attempts, reset_at FROM login_attempts WHERE `key` = ?', [$key]);
    if (! $row || strtotime($row->reset_at) <= time()) return 0;
    return $row->attempts >= $max ? max(1, strtotime($row->reset_at) - time()) : 0;
}

function hit_attempt(string $key, int $seconds = 60): void
{
    $row = db_one('SELECT attempts, reset_at FROM login_attempts WHERE `key` = ?', [$key]);
    if (! $row || strtotime($row->reset_at) <= time()) {
        db_exec('REPLACE INTO login_attempts (`key`, attempts, reset_at) VALUES (?, 1, ?)', [$key, date('Y-m-d H:i:s', time() + $seconds)]);
    } else {
        db_exec('UPDATE login_attempts SET attempts = attempts + 1 WHERE `key` = ?', [$key]);
    }
}

function clear_attempts(string $key): void
{
    db_exec('DELETE FROM login_attempts WHERE `key` = ?', [$key]);
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
