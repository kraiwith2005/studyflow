<?php
/*
 * Small helper functions used by the pages.
 */

/* ---------- Output ---------- */

/** Escape text before printing it into HTML (prevents XSS). */
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/** Link to a page inside the app, e.g. url('/tasks', ['filter' => 'school']). */
function url(string $path = '/', array $query = []): string
{
    $query = array_filter($query, fn ($v) => $v !== null && $v !== '');
    return BASE.$path.($query ? '?'.http_build_query($query) : '');
}

/** Link to a CSS/JS file with a version number so browsers reload it after changes. */
function asset(string $path): string
{
    $file = ROOT.'/'.$path;
    return BASE.'/'.$path.(is_file($file) ? '?v='.filemtime($file) : '');
}

/** Print a PHP value as JSON inside a <script> or an HTML attribute. */
function js($value): string
{
    return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
}

function checked(bool $on): string { return $on ? 'checked' : ''; }
function selected(bool $on): string { return $on ? 'selected' : ''; }

/* ---------- Views ---------- */

$GLOBALS['SECTIONS'] = [];

/** Render views/<name>.php with the given variables and return the HTML. */
function view(string $__view, array $__data = []): string
{
    extract($__data, EXTR_SKIP);
    ob_start();
    include ROOT.'/views/'.$__view.'.php';
    return ob_get_clean();
}

/** Render a page inside a layout (views/layouts/<layout>.php) and send it. */
function page(string $name, array $data = [], string $layout = 'app'): void
{
    $content = view($name, $data);
    echo view('layouts/'.$layout, $data + ['content' => $content]);
}

/** Collect extra HTML for a named area of the layout (e.g. 'scripts', 'banner'). */
function section_start(string $name): void { $GLOBALS['SECTION_NAME'] = $name; ob_start(); }
function section_end(): void
{
    $name = $GLOBALS['SECTION_NAME'];
    $GLOBALS['SECTIONS'][$name] = ($GLOBALS['SECTIONS'][$name] ?? '').ob_get_clean();
}
function section(string $name): string { return $GLOBALS['SECTIONS'][$name] ?? ''; }

/** Inline SVG icon (views/partials/icons.php holds the shapes). */
function icon(string $name, string $class = '', int $size = 18): string
{
    static $paths = null;
    $paths ??= require ROOT.'/views/partials/icons.php';
    $cls = $class !== '' ? ' class="'.e($class).'"' : '';
    return '<svg'.$cls.' width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        .($paths[$name] ?? '').'</svg>';
}

/* ---------- Requests ---------- */

/** Current path inside the app, without the sub-folder, e.g. "/tasks". */
function current_path(): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    if (BASE !== '' && str_starts_with($path, BASE)) $path = substr($path, strlen(BASE));
    $path = '/'.trim($path, '/');
    return $path;
}

/** Current path + query string (used to come back to the same page after a form). */
function current_page(): string
{
    $q = $_SERVER['QUERY_STRING'] ?? '';
    return current_path().($q !== '' ? '?'.$q : '');
}

/** Form fields and JSON bodies, merged. */
function input(?string $key = null, $default = null)
{
    static $data = null;
    if ($data === null) {
        $data = $_POST;
        $type = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($type, 'application/json')) {
            $json = json_decode((string) file_get_contents('php://input'), true);
            if (is_array($json)) $data = $json + $data;
        }
    }
    if ($key === null) return $data;
    return array_key_exists($key, $data) ? $data[$key] : $default;
}

/** Trimmed text from a form field ('' when missing). */
function input_str(string $key): string
{
    $v = input($key);
    return is_scalar($v) ? trim((string) $v) : '';
}

function query(string $key, $default = null)
{
    return $_GET[$key] ?? $default;
}

function query_bool(string $key): bool
{
    return in_array($_GET[$key] ?? '', ['1', 'true', 'on', 'yes'], true);
}

function wants_json(): bool
{
    return str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')
        || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
}

/** Is this the page in the menu that should be highlighted? */
function is_page(string $path): bool
{
    $p = current_path();
    return $p === $path || str_starts_with($p, $path.'/');
}

/* ---------- Responses ---------- */

function redirect(string $path, array $query = []): never
{
    header('Location: '.url($path, $query));
    exit;
}

/** Go back to a page of this app (only our own pages are allowed, so links can't send people elsewhere). */
function back_to(string $pageWithQuery, string $fallback = '/calendar'): never
{
    if (! preg_match('#^/(today|calendar|tasks|study)(\?[^\s]*)?$#', $pageWithQuery)) {
        $pageWithQuery = $fallback;
    }
    header('Location: '.BASE.$pageWithQuery);
    exit;
}

/** Back to Settings with one section open. */
function back_to_settings(string $section, ?string $status = null): never
{
    if ($status) flash('status', $status);
    header('Location: '.url('/settings', ['open' => $section]).'#'.$section);
    exit;
}

function json_response($data, int $code = 200): never
{
    if (! headers_sent()) http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function abort(int $code): never
{
    // 419 and 429 need their reason text, otherwise some servers turn them into 500.
    $reason = [403 => 'Forbidden', 404 => 'Not Found', 405 => 'Method Not Allowed', 419 => 'Page Expired', 429 => 'Too Many Requests'][$code] ?? 'Error';
    header(($_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.1').' '.$code.' '.$reason, true, $code);
    if (wants_json()) json_response(['message' => $code === 404 ? 'Not found' : 'Error'], $code);
    $title = [403 => 'Forbidden', 404 => __('Page not found'), 405 => 'Method not allowed', 419 => __('This page expired. Please try again.'), 429 => __('Too many requests. Please wait a moment.')][$code] ?? 'Error';
    echo '<!DOCTYPE html><meta charset="utf-8"><title>'.e($title).'</title><link rel="stylesheet" href="'.e(asset('css/app.css')).'">'
        .'<div class="auth-main" style="padding:80px 20px;text-align:center"><div><h1 class="page-title" style="font-size:48px">'.$code.'</h1><p>'.e($title).'</p>'
        .'<p><a href="'.e(url('/')).'">StudyFlow</a></p></div></div>';
    exit;
}

/* ---------- Flash data: messages, errors and old input for the next page ---------- */

function flash(string $key, $value): void
{
    $_SESSION['_flash'][$key] = $value;
}

function flashed(string $key, $default = null)
{
    return $GLOBALS['FLASH'][$key] ?? $default;
}

/** Keep what the person typed so the form can be shown again after an error. */
function flash_input(array $except = ['password', 'password_confirmation', 'current_password', '_token', '_method']): void
{
    flash('_old', array_diff_key(input(), array_flip($except)));
}

/** A value the person typed before the page reloaded (supports "periods.0.name"). */
function old(string $key, $default = null)
{
    $value = $GLOBALS['FLASH']['_old'] ?? null;
    if ($value === null) return $default;
    foreach (explode('.', $key) as $part) {
        if (! is_array($value) || ! array_key_exists($part, $value)) return $default;
        $value = $value[$part];
    }
    return $value;
}

function has_old(): bool
{
    return isset($GLOBALS['FLASH']['_old']);
}

/** First error message for a field in a group ("bag") of errors, or null. */
function error_for(string $field, string $bag = 'default'): ?string
{
    return $GLOBALS['FLASH']['_errors'][$bag][$field][0] ?? null;
}

function has_errors(string $bag = 'default'): bool
{
    return ! empty($GLOBALS['FLASH']['_errors'][$bag]);
}

/** Print the red error line under a field. */
function field_error(string $field, string $bag = 'default'): string
{
    $m = error_for($field, $bag);
    return $m === null ? '' : '<span class="field-error">'.e($m).'</span>';
}

function invalid(string $field, string $bag = 'default'): string
{
    return error_for($field, $bag) === null ? '' : 'is-invalid';
}

/** Store errors (and the typed input) for the next page. */
function flash_errors(array $errors, string $bag = 'default'): void
{
    $all = $_SESSION['_flash']['_errors'] ?? [];
    $all[$bag] = $errors;
    flash('_errors', $all);
    flash_input();
}

/* ---------- Dates and times ---------- */

function today(): DateTimeImmutable
{
    return new DateTimeImmutable('today');
}

function to_date($d): DateTimeImmutable
{
    return $d instanceof DateTimeImmutable ? $d : new DateTimeImmutable(substr((string) $d, 0, 10));
}

/** "13:20:00" -> "13:20" (Thai) or "1:20 PM" (English) */
function fmt_time(?string $time): string
{
    if (! $time) return '';
    [$h, $m] = array_map('intval', explode(':', $time));
    if (locale() === 'th') return sprintf('%02d:%02d', $h, $m);
    return sprintf('%d:%02d %s', ($h % 12) ?: 12, $m, $h < 12 ? 'AM' : 'PM');
}

/**
 * Thai: "8 พ.ย. 2569" (Buddhist year) · English: "8 Nov 2026".
 * $style: 'short' | 'long' (with weekday) | 'month' (month and year)
 */
function fmt_date($date, string $style = 'short'): string
{
    if (! $date) return '';
    $d = to_date($date);
    if (locale() !== 'th') {
        return match ($style) {
            'long' => $d->format('l j F Y'),
            'month' => $d->format('F Y'),
            default => $d->format('j M Y'),
        };
    }
    $short = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    $full = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
    $days = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
    $year = (int) $d->format('Y') + 543;
    $m = (int) $d->format('n') - 1;
    $day = (int) $d->format('j');
    return match ($style) {
        'long' => 'วัน'.$days[(int) $d->format('w')].'ที่ '.$day.' '.$full[$m].' '.$year,
        'month' => $full[$m].' '.$year,
        default => $day.' '.$short[$m].' '.$year,
    };
}

/** ISO day 1 (Mon) – 7 (Sun) -> name. $short for grid headers. */
function day_name(int $iso, bool $short = false): string
{
    $th = [1 => ['จันทร์', 'จ.'], 2 => ['อังคาร', 'อ.'], 3 => ['พุธ', 'พ.'], 4 => ['พฤหัสบดี', 'พฤ.'], 5 => ['ศุกร์', 'ศ.'], 6 => ['เสาร์', 'ส.'], 7 => ['อาทิตย์', 'อา.']];
    $en = [1 => ['Monday', 'MON'], 2 => ['Tuesday', 'TUE'], 3 => ['Wednesday', 'WED'], 4 => ['Thursday', 'THU'], 5 => ['Friday', 'FRI'], 6 => ['Saturday', 'SAT'], 7 => ['Sunday', 'SUN']];
    $set = locale() === 'th' ? $th : $en;
    return $set[$iso][$short ? 1 : 0];
}

/** Sunday that starts the week containing $d. */
function week_start_sunday(DateTimeImmutable $d): DateTimeImmutable
{
    return $d->modify('-'.$d->format('w').' days');
}

/** Monday that starts the ISO week containing $d. */
function week_start_monday(DateTimeImmutable $d): DateTimeImmutable
{
    return $d->modify('-'.((int) $d->format('N') - 1).' days');
}

/** Whole days from $a to $b (negative when $b is earlier). */
function days_between(DateTimeImmutable $a, DateTimeImmutable $b): int
{
    return (int) $a->diff($b)->format('%r%a');
}

function valid_date(?string $s): bool
{
    if (! is_string($s) || ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $s)) return false;
    [$y, $m, $d] = array_map('intval', explode('-', $s));
    return checkdate($m, $d, $y);
}

function valid_time(?string $s): bool
{
    return is_string($s) && (bool) preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $s);
}

/** Milliseconds since 1970 for a 'Y-m-d H:i:s' Bangkok time (used by the timer). */
function ms(?string $datetime): ?int
{
    return $datetime ? (int) (strtotime($datetime) * 1000) : null;
}

/** After a form on Today / Calendar / Tasks / Study: go back to that page, with an optional message. */
function back_to_page(?string $status = null): never
{
    if ($status) flash('status', $status);
    back_to((string) input('return', ''), '/calendar');
}
