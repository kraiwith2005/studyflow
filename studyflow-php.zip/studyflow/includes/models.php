<?php
/*
 * Data functions shared by several pages: subjects, tasks, study sessions,
 * timetable settings, the calendar builder and the item details given to JavaScript.
 */

const TASK_TYPES = ['assignment', 'exam', 'personal'];
const PRIORITIES = ['high', 'normal', 'low'];
const PERSONAL_COLOR = '#6b7a99';
const SESSION_COLOR = '#4E7894';
const CLASS_COLOR = '#8a948c';
const DURATIONS = [15, 20, 30, 45, 60, 75, 90, 105, 120, 150, 180];
const SUBJECT_PRESETS = ['#3b5fe0', '#cb3a31', '#4a9e52', '#7a3fe0', '#dc6428', '#48a0e0', '#c93b78', '#c48d31', '#3f9470', '#5045dd', '#ecaed5', '#f4f4f1'];
const DEFAULT_PERIODS = [
    ['Period 1', 'class', '08:40', '09:35'], ['Period 2', 'class', '09:35', '10:30'], ['Recess', 'break', '10:30', '10:50'],
    ['Period 3', 'class', '10:50', '11:45'], ['Period 4', 'class', '11:45', '12:40'], ['Lunch', 'break', '12:40', '13:20'],
    ['Period 5', 'class', '13:20', '14:15'], ['Period 6', 'class', '14:15', '15:10'],
];

/* ---------- Subjects ---------- */

function subjects_of(int $uid): array
{
    return db_all('SELECT * FROM subjects WHERE user_id = ? ORDER BY sort_order, name', [$uid]);
}

/** Does this subject belong to the user? */
function own_subject(int $uid, $id): ?object
{
    return is_numeric($id) ? db_one('SELECT * FROM subjects WHERE id = ? AND user_id = ?', [(int) $id, $uid]) : null;
}

/* ---------- Tasks ---------- */

/** Load tasks with their subject (name, color) and study totals. $where/$params add conditions. */
function tasks_query(int $uid, string $where = '', array $params = [], string $order = ''): array
{
    $sql = "SELECT t.*, s.name AS subject_name, s.color AS subject_color,
              (SELECT COUNT(*) FROM study_sessions ss WHERE ss.task_id = t.id AND ss.status = 'planned') AS planned_sessions,
              (SELECT COUNT(*) FROM study_sessions ss WHERE ss.task_id = t.id AND ss.status = 'completed') AS done_sessions,
              (SELECT SUM(ss.actual_minutes) FROM study_sessions ss WHERE ss.task_id = t.id AND ss.status = 'completed') AS done_minutes
            FROM tasks t LEFT JOIN subjects s ON s.id = t.subject_id
            WHERE t.user_id = ?".($where !== '' ? " AND ($where)" : '').
            ($order !== '' ? " ORDER BY $order" : " ORDER BY t.due_date, t.title");
    $rows = db_all($sql, [$uid, ...$params]);
    foreach ($rows as $t) decorate_task($t);
    return $rows;
}

function decorate_task(object $t): void
{
    $t->color = $t->subject_color ?? PERSONAL_COLOR;
    $t->done = $t->completed_at !== null;
    $t->due_hm = $t->due_time ? substr($t->due_time, 0, 5) : null;
    $t->planned_sessions = (int) ($t->planned_sessions ?? 0);
    $t->done_sessions = (int) ($t->done_sessions ?? 0);
    $t->done_minutes = (int) ($t->done_minutes ?? 0);
}

function own_task(int $uid, $id): ?object
{
    $rows = is_numeric($id) ? tasks_query($uid, 't.id = ?', [(int) $id]) : [];
    return $rows[0] ?? null;
}

/** Open assignments and exams, for "Link to assessment" lists. */
function linkable_tasks(int $uid): array
{
    return tasks_query($uid, "t.type <> 'personal' AND t.completed_at IS NULL", [], 't.due_date, t.due_time IS NULL, t.due_time, t.title');
}

function task_type_label(string $type): string
{
    return ['assignment' => __('Assignment'), 'exam' => __('Exam'), 'personal' => __('Personal task')][$type] ?? $type;
}

function priority_label(string $p): string
{
    return match ($p) { 'high' => __('High priority'), 'low' => __('Low priority'), default => __('Normal priority') };
}

/** "Due in 3 days", "Overdue by 2 days"… and the colour tone of the badge. */
function due_label(object $t): array
{
    if ($t->done) return [__('Done'), 'done'];
    $days = days_between(today(), to_date($t->due_date));
    $exam = $t->type === 'exam';
    return match (true) {
        $days < 0 => [trans_choice('Overdue by :count day|Overdue by :count days', -$days), 'overdue'],
        $days === 0 => [$exam ? __('Exam today') : __('Due today'), 'soon'],
        $days === 1 => [$exam ? __('Exam tomorrow') : __('Due tomorrow'), 'soon'],
        default => [trans_choice($exam ? 'Exam in :count day|Exam in :count days' : 'Due in :count day|Due in :count days', $days), $days <= 7 ? 'week' : 'later'],
    };
}

/* ---------- Study sessions ---------- */

function sessions_query(int $uid, string $where = '', array $params = [], string $order = 'ss.date, ss.start_time'): array
{
    $rows = db_all("SELECT ss.*, s.name AS subject_name, s.color AS subject_color, t.title AS task_title
                    FROM study_sessions ss
                    LEFT JOIN subjects s ON s.id = ss.subject_id
                    LEFT JOIN tasks t ON t.id = ss.task_id
                    WHERE ss.user_id = ?".($where !== '' ? " AND ($where)" : '')." ORDER BY $order", [$uid, ...$params]);
    foreach ($rows as $s) decorate_session($s);
    return $rows;
}

function decorate_session(object $s): void
{
    $s->color = $s->subject_color ?? SESSION_COLOR;
    $s->done = $s->status === 'completed';
    $s->start_hm = substr($s->start_time, 0, 5);
    [$h, $m] = array_map('intval', explode(':', $s->start_time));
    $end = $h * 60 + $m + (int) $s->duration_minutes;
    $s->end_hm = sprintf('%02d:%02d', intdiv($end, 60) % 24, $end % 60);
    if ($end >= 24 * 60) $s->end_hm = '24:00';
}

function own_session(int $uid, $id): ?object
{
    $rows = is_numeric($id) ? sessions_query($uid, 'ss.id = ?', [(int) $id]) : [];
    return $rows[0] ?? null;
}

/** "45 min", "1 hr 30 min", "2 hr" */
function duration_label(int $minutes): string
{
    if ($minutes <= 60) return __(':m min', ['m' => $minutes]);
    $h = intdiv($minutes, 60);
    $m = $minutes % 60;
    return $m ? __(':hh :mm', ['h' => $h, 'm' => $m]) : __(':hh', ['h' => $h]);
}

/** Completed study this week (Sunday – Saturday): [count, minutes]. */
function week_study_totals(int $uid): array
{
    $start = week_start_sunday(today());
    $row = db_one("SELECT COUNT(*) AS n, COALESCE(SUM(actual_minutes), 0) AS m FROM study_sessions
                   WHERE user_id = ? AND status = 'completed' AND date BETWEEN ? AND ?",
        [$uid, $start->format('Y-m-d'), $start->modify('+6 days')->format('Y-m-d')]);
    return [(int) $row->n, (int) $row->m];
}

/* ---------- Study timer (one row per user) ---------- */

function timer_of(int $uid): ?object
{
    return db_one('SELECT * FROM study_timers WHERE user_id = ?', [$uid]);
}

function timer_elapsed(object $t): int
{
    $running = ($t->status === 'running' && $t->started_at) ? time() - strtotime($t->started_at) : 0;
    return (int) $t->accumulated_seconds + max(0, $running);
}

/** What the browser needs to show and tick the timer. */
function timer_client(object $t): array
{
    return [
        'status' => $t->status,
        'label' => $t->label,
        'accumulated' => (int) $t->accumulated_seconds,
        'startedAt' => ms($t->started_at),
        'elapsed' => timer_elapsed($t),
    ];
}

/* ---------- Terms ---------- */

function terms_of(int $uid): array
{
    $rows = db_all('SELECT * FROM terms WHERE user_id = ? ORDER BY start_date', [$uid]);
    $today = today()->format('Y-m-d');
    foreach ($rows as $t) {
        $t->is_current = $t->start_date <= $today && $today <= $t->end_date;
        $days = days_between(to_date($t->start_date), to_date($t->end_date)) + 1;
        $t->length_label = $days >= 14 ? trans_choice(':count week|:count weeks', (int) ceil($days / 7)) : trans_choice(':count day|:count days', $days);
    }
    return $rows;
}

/* ---------- Timetable settings ---------- */

/** The user's timetable settings, created with default periods the first time. */
function planner(int $uid): object
{
    $p = db_one('SELECT * FROM planner_settings WHERE user_id = ?', [$uid]);
    if (! $p) {
        db_exec("INSERT INTO planner_settings (user_id, timetable_type, repeat_cycle, periods_initialized, created_at, updated_at) VALUES (?, 'school', 'weekly', 0, ?, ?)", [$uid, now_sql(), now_sql()]);
        $p = db_one('SELECT * FROM planner_settings WHERE user_id = ?', [$uid]);
    }
    if (! $p->periods_initialized) {
        $n = 0;
        foreach (DEFAULT_PERIODS as $i => [$name, $kind, $start, $end]) {
            $label = match ($name) { 'Recess' => __('Recess'), 'Lunch' => __('Lunch'), default => __('Period :n', ['n' => ++$n]) };
            db_insert('periods', ['user_id' => $uid, 'name' => $label, 'kind' => $kind, 'start_time' => $start, 'end_time' => $end, 'sort_order' => $i]);
        }
        db_exec('UPDATE planner_settings SET periods_initialized = 1 WHERE user_id = ?', [$uid]);
        $p->periods_initialized = 1;
    }
    return $p;
}

function uses_grid(object $p): bool { return $p->timetable_type !== 'university'; }
/** Days in the grid: Mon–Fri for school, Mon–Sun for custom. */
function grid_days(object $p): array { return $p->timetable_type === 'custom' ? [1, 2, 3, 4, 5, 6, 7] : [1, 2, 3, 4, 5]; }
function plan_weeks(object $p): array { return $p->repeat_cycle === 'ab' ? ['A', 'B'] : ['A']; }

/** Week A or B for a date (counted in whole weeks from the Monday of Week A). */
function week_letter(object $p, DateTimeImmutable $date): string
{
    if ($p->repeat_cycle !== 'ab' || ! $p->cycle_anchor) return 'A';
    $weeks = intdiv(days_between(week_start_monday(to_date($p->cycle_anchor)), week_start_monday($date)), 7);
    return $weeks % 2 === 0 ? 'A' : 'B';
}

function recurring_classes_of(int $uid): array
{
    $rows = db_all('SELECT r.*, s.name AS subject_name, s.color AS subject_color FROM recurring_classes r
                    LEFT JOIN subjects s ON s.id = r.subject_id WHERE r.user_id = ? ORDER BY r.day, r.start_time', [$uid]);
    foreach ($rows as $r) {
        $r->display_name = $r->name ?: ($r->subject_name ?? __('Untitled class'));
        $r->color = $r->subject_color ?? CLASS_COLOR;
    }
    return $rows;
}

/** Shown on Today, Calendar, Tasks and Study until subjects, terms and timetable are set. */
function setup_progress(int $uid): array
{
    $steps = [
        'subjects' => (bool) db_value('SELECT 1 FROM subjects WHERE user_id = ? LIMIT 1', [$uid]),
        'terms' => (bool) db_value('SELECT 1 FROM terms WHERE user_id = ? LIMIT 1', [$uid]),
        'timetable' => (bool) db_value('SELECT 1 FROM timetable_slots WHERE user_id = ? LIMIT 1', [$uid])
                    || (bool) db_value('SELECT 1 FROM recurring_classes WHERE user_id = ? LIMIT 1', [$uid]),
    ];
    return ['steps' => $steps, 'done' => count(array_filter($steps)), 'total' => count($steps)];
}

/* ---------- Calendar: items for a range of days ---------- */

/** @return array<string, array{allDay: array, timed: array}> keyed by Y-m-d */
function calendar_days(int $uid, DateTimeImmutable $start, DateTimeImmutable $end, bool $withClasses): array
{
    $days = [];
    for ($d = $start; $d <= $end; $d = $d->modify('+1 day')) $days[$d->format('Y-m-d')] = ['allDay' => [], 'timed' => []];
    $from = $start->format('Y-m-d');
    $to = $end->format('Y-m-d');

    foreach (tasks_query($uid, 't.due_date BETWEEN ? AND ?', [$from, $to],
        "t.due_time IS NULL, t.due_time, FIELD(t.type, 'exam', 'assignment', 'personal'), t.title") as $t) {
        $days[$t->due_date]['allDay'][] = task_payload($t);
    }
    foreach (sessions_query($uid, 'ss.date BETWEEN ? AND ?', [$from, $to], 'ss.start_time') as $s) {
        $days[$s->date]['timed'][] = session_payload($s);
    }
    if ($withClasses) {
        foreach (calendar_classes($uid, $start, $end) as $date => $items) {
            array_push($days[$date]['timed'], ...$items);
        }
    }
    foreach ($days as &$day) {
        usort($day['timed'], fn ($a, $b) => [$a['start'], $a['end']] <=> [$b['start'], $b['end']]);
        $day['timed'] = calendar_lanes($day['timed']);
    }
    return $days;
}

/** Timetable classes for each date, respecting term dates, Week A/B and the timetable type. */
function calendar_classes(int $uid, DateTimeImmutable $start, DateTimeImmutable $end): array
{
    $p = planner($uid);
    $terms = db_all('SELECT start_date, end_date FROM terms WHERE user_id = ?', [$uid]);
    $slots = [];
    if (uses_grid($p)) {
        foreach (db_all('SELECT ts.day, ts.week, p.name AS period_name, p.start_time, p.end_time, s.name, s.color
                         FROM timetable_slots ts JOIN periods p ON p.id = ts.period_id JOIN subjects s ON s.id = ts.subject_id
                         WHERE ts.user_id = ?', [$uid]) as $row) {
            $slots[$row->day.'-'.$row->week][] = $row;
        }
    }
    $recurring = [];
    foreach (recurring_classes_of($uid) as $c) $recurring[$c->day][] = $c;

    $out = [];
    for ($d = $start; $d <= $end; $d = $d->modify('+1 day')) {
        $ymd = $d->format('Y-m-d');
        // Outside every term = holidays: no classes. With no terms set, classes run all year.
        if ($terms && ! array_filter($terms, fn ($t) => $t->start_date <= $ymd && $ymd <= $t->end_date)) continue;
        $iso = (int) $d->format('N');
        $week = week_letter($p, $d);
        $items = [];
        if (in_array($iso, grid_days($p), true)) {
            foreach ($slots[$iso.'-'.$week] ?? [] as $s) {
                $items[] = class_item($s->name, $s->color, $s->start_time, $s->end_time, $s->period_name, null, null, $ymd);
            }
        }
        foreach ($recurring[$iso] ?? [] as $c) {
            if ($c->week !== 'every' && $p->repeat_cycle === 'ab' && $c->week !== $week) continue;
            $items[] = class_item($c->display_name, $c->color, $c->start_time, $c->end_time, null, $c->location, $c->teacher, $ymd);
        }
        if ($items) $out[$ymd] = $items;
    }
    return $out;
}

function class_item(string $title, string $color, string $start, string $end, ?string $period, ?string $location, ?string $teacher, string $date): array
{
    return ['kind' => 'class', 'title' => $title, 'color' => $color, 'start' => substr($start, 0, 5), 'end' => substr($end, 0, 5),
        'period' => $period, 'location' => $location, 'teacher' => $teacher, 'date' => $date, 'done' => false];
}

/** Side-by-side columns for overlapping timed items: adds 'lane' and 'lanes'. */
function calendar_lanes(array $items): array
{
    $min = fn ($t) => (int) substr($t, 0, 2) * 60 + (int) substr($t, 3, 2);
    $clusters = [];
    $current = [];
    $clusterEnd = -1;
    foreach ($items as $item) {
        $s = $min($item['start']);
        if ($current && $s >= $clusterEnd) { $clusters[] = $current; $current = []; $clusterEnd = -1; }
        $current[] = $item;
        $clusterEnd = max($clusterEnd, $min($item['end']));
    }
    if ($current) $clusters[] = $current;
    $out = [];
    foreach ($clusters as $cluster) {
        $laneEnds = [];
        foreach ($cluster as &$item) {
            $s = $min($item['start']);
            $lane = 0;
            while (isset($laneEnds[$lane]) && $laneEnds[$lane] > $s) $lane++;
            $laneEnds[$lane] = $min($item['end']);
            $item['lane'] = $lane;
        }
        unset($item);
        foreach ($cluster as $item) { $item['lanes'] = count($laneEnds); $out[] = $item; }
    }
    return $out;
}

/* ---------- Item details for the JavaScript dialog ---------- */

function task_payload(object $t): array
{
    return [
        'kind' => 'task', 'id' => (int) $t->id, 'type' => $t->type, 'typeLabel' => task_type_label($t->type),
        'title' => $t->title, 'subject' => $t->subject_name, 'subject_id' => $t->subject_id !== null ? (int) $t->subject_id : null,
        'color' => $t->color, 'done' => $t->done, 'date' => $t->due_date,
        'due_time' => $t->due_hm, 'notes' => $t->notes, 'link' => $t->link,
        'priority' => $t->priority, 'priorityLabel' => priority_label($t->priority),
    ];
}

function session_payload(object $s): array
{
    return [
        'kind' => 'session', 'id' => (int) $s->id, 'title' => $s->title,
        'subject' => $s->subject_name, 'subject_id' => $s->subject_id !== null ? (int) $s->subject_id : null,
        'color' => $s->color, 'start' => $s->start_hm, 'end' => $s->end_hm,
        'duration' => (int) $s->duration_minutes, 'done' => $s->done,
        'task_id' => $s->task_id !== null ? (int) $s->task_id : null, 'task' => $s->task_title, 'date' => $s->date,
    ];
}

/** Item as JSON for a data-item="…" attribute (labels and links added). */
function item_json(array $i): string
{
    $i['dateLabel'] = fmt_date($i['date'], 'long');
    if (isset($i['start'])) $i['timeLabel'] = fmt_time($i['start']).' – '.fmt_time($i['end']);
    if (! empty($i['due_time'])) $i['timeLabel'] = fmt_time($i['due_time']);
    if ($i['kind'] === 'task') {
        $base = url('/tasks/'.$i['id']);
        $i['urls'] = ['update' => $base, 'destroy' => $base, 'toggle' => $base.'/toggle'];
    } elseif ($i['kind'] === 'session') {
        $i['typeLabel'] = __('Study session');
        $i['durationLabel'] = duration_label($i['duration']);
        $base = url('/sessions/'.$i['id']);
        $i['urls'] = ['update' => $base, 'destroy' => $base, 'toggle' => $base.'/toggle'];
    } else {
        $i['typeLabel'] = __('Class');
    }
    return json_encode($i, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
