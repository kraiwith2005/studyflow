-- StudyFlow database (MySQL / MariaDB)
-- Import this file in phpMyAdmin (XAMPP: http://localhost/phpmyadmin)
-- into an empty database, e.g. one called "studyflow".

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Accounts
CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  email VARCHAR(255) NOT NULL,
  email_verified_at TIMESTAMP NULL DEFAULT NULL,
  password VARCHAR(255) NULL DEFAULT NULL,               -- bcrypt hash from password_hash()
  google_id VARCHAR(255) NULL DEFAULT NULL,
  theme ENUM('light','dark') NULL DEFAULT NULL,          -- NULL = light (default)
  tour_completed_at TIMESTAMP NULL DEFAULT NULL,         -- when the first-run tour was finished
  remember_token VARCHAR(100) NULL DEFAULT NULL,         -- hash of the "remember me" cookie
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY users_email_unique (email),
  UNIQUE KEY users_google_id_unique (google_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One-time links for "Forgot password?" (only a hash of the token is stored)
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  email VARCHAR(255) NOT NULL PRIMARY KEY,
  token VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Counts wrong sign-in attempts (limit: 5 per minute)
CREATE TABLE IF NOT EXISTS login_attempts (
  `key` VARCHAR(255) NOT NULL PRIMARY KEY,
  attempts INT UNSIGNED NOT NULL DEFAULT 0,
  reset_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Timetable settings (one row per user)
CREATE TABLE IF NOT EXISTS planner_settings (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  timetable_type ENUM('school','university','custom') NOT NULL DEFAULT 'school',
  repeat_cycle ENUM('weekly','ab') NOT NULL DEFAULT 'weekly',
  cycle_anchor DATE NULL DEFAULT NULL,                   -- Monday of a "Week A"
  periods_initialized TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  CONSTRAINT planner_settings_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subjects (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(80) NOT NULL,
  color CHAR(7) NOT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY subjects_user_id_name_unique (user_id, name),
  CONSTRAINT subjects_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS terms (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(60) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY terms_user_id_start_date_index (user_id, start_date),
  CONSTRAINT terms_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Class periods and breaks of the grid timetable
CREATE TABLE IF NOT EXISTS periods (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(40) NOT NULL,
  kind ENUM('class','break') NOT NULL DEFAULT 'class',
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  CONSTRAINT periods_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One cell of the grid timetable: period × day × week (A/B)
CREATE TABLE IF NOT EXISTS timetable_slots (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  period_id BIGINT UNSIGNED NOT NULL,
  day TINYINT UNSIGNED NOT NULL,                         -- 1 = Monday … 7 = Sunday
  week ENUM('A','B') NOT NULL DEFAULT 'A',
  subject_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY timetable_slots_period_id_day_week_unique (period_id, day, week),
  CONSTRAINT timetable_slots_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT timetable_slots_period_id_foreign FOREIGN KEY (period_id) REFERENCES periods (id) ON DELETE CASCADE,
  CONSTRAINT timetable_slots_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Classes and activities that repeat every week (outside the grid)
CREATE TABLE IF NOT EXISTS recurring_classes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  subject_id BIGINT UNSIGNED NULL DEFAULT NULL,
  name VARCHAR(80) NULL DEFAULT NULL,
  day TINYINT UNSIGNED NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  week ENUM('every','A','B') NOT NULL DEFAULT 'every',
  location VARCHAR(120) NULL DEFAULT NULL,
  teacher VARCHAR(80) NULL DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY recurring_classes_user_id_day_index (user_id, day),
  CONSTRAINT recurring_classes_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT recurring_classes_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Assignments, exams and personal tasks
CREATE TABLE IF NOT EXISTS tasks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  subject_id BIGINT UNSIGNED NULL DEFAULT NULL,           -- empty for personal tasks
  type ENUM('assignment','exam','personal') NOT NULL,
  title VARCHAR(120) NOT NULL,
  due_date DATE NOT NULL,
  due_time TIME NULL DEFAULT NULL,
  notes TEXT NULL,
  link VARCHAR(500) NULL DEFAULT NULL,
  priority ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
  completed_at TIMESTAMP NULL DEFAULT NULL,              -- empty = not done yet
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY tasks_user_id_due_date_index (user_id, due_date),
  CONSTRAINT tasks_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT tasks_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Planned and completed study blocks
CREATE TABLE IF NOT EXISTS study_sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  subject_id BIGINT UNSIGNED NULL DEFAULT NULL,
  task_id BIGINT UNSIGNED NULL DEFAULT NULL,
  title VARCHAR(120) NOT NULL,
  date DATE NOT NULL,
  start_time TIME NOT NULL,
  duration_minutes SMALLINT UNSIGNED NOT NULL,
  status ENUM('planned','completed') NOT NULL DEFAULT 'planned',
  actual_minutes SMALLINT UNSIGNED NULL DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY study_sessions_user_id_date_index (user_id, date),
  CONSTRAINT study_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT study_sessions_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE SET NULL,
  CONSTRAINT study_sessions_task_id_foreign FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The study timer that is running or paused (at most one per user)
CREATE TABLE IF NOT EXISTS study_timers (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  subject_id BIGINT UNSIGNED NULL DEFAULT NULL,
  task_id BIGINT UNSIGNED NULL DEFAULT NULL,
  study_session_id BIGINT UNSIGNED NULL DEFAULT NULL,
  label VARCHAR(150) NOT NULL,
  status ENUM('running','paused') NOT NULL,
  first_started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  started_at TIMESTAMP NULL DEFAULT NULL,
  accumulated_seconds INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  CONSTRAINT study_timers_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT study_timers_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE SET NULL,
  CONSTRAINT study_timers_task_id_foreign FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE SET NULL,
  CONSTRAINT study_timers_study_session_id_foreign FOREIGN KEY (study_session_id) REFERENCES study_sessions (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
