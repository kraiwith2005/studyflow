<?php
// Default English validation messages (:attribute is the field name).
return [
    'after' => 'The :attribute field must be a date after :date.',
    'after_or_equal' => 'The :attribute field must be a date after or equal to :date.',
    'array' => 'The :attribute field must be an array.',
    'between' => ['numeric' => 'The :attribute field must be between :min and :max.', 'string' => 'The :attribute field must be between :min and :max characters.'],
    'confirmed' => 'The :attribute field confirmation does not match.',
    'date_format' => 'The :attribute field must match the format :format.',
    'email' => 'The :attribute field must be a valid email address.',
    'exists' => 'The selected :attribute is invalid.',
    'in' => 'The selected :attribute is invalid.',
    'integer' => 'The :attribute field must be an integer.',
    'max' => ['numeric' => 'The :attribute field must not be greater than :max.', 'string' => 'The :attribute field must not be greater than :max characters.', 'array' => 'The :attribute field must not have more than :max items.'],
    'min' => ['numeric' => 'The :attribute field must be at least :min.', 'string' => 'The :attribute field must be at least :min characters.', 'array' => 'The :attribute field must have at least :min items.'],
    'password' => ['letters' => 'The :attribute field must contain at least one letter.', 'numbers' => 'The :attribute field must contain at least one number.'],
    'regex' => 'The :attribute field format is invalid.',
    'required' => 'The :attribute field is required.',
    'string' => 'The :attribute field must be a string.',
    'unique' => 'The :attribute has already been taken.',
    'url' => 'The :attribute field must be a valid URL.',
    'attributes' => [],
];
