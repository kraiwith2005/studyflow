<h1 class="auth-title"><?= e(__('Welcome back')) ?></h1>
<p class="auth-sub"><?= e(__('Sign in to pick up where you left off.')) ?></p>

<?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

<form method="POST" action="<?= e(url('/sign-in')) ?>" novalidate data-once>
  <?= csrf_field() ?>
  <div class="field">
    <label class="label" for="email"><?= e(__('Email address')) ?></label>
    <input id="email" name="email" type="email" class="input <?= invalid('email') ?>"
           value="<?= e(old('email')) ?>" placeholder="<?= e(__('Enter your email address')) ?>" autocomplete="email" required autofocus>
    <?= field_error('email') ?>
  </div>

  <?= view('partials/password_field', [
    'id' => 'password', 'name' => 'password', 'label' => __('Password'),
    'placeholder' => __('Enter your password'), 'autocomplete' => 'current-password', 'forgot' => true,
  ]) ?>

  <div class="auth-actions">
    <button type="submit" class="btn btn-primary btn-block btn-lg"><?= e(__('Sign in')) ?> <?= icon('arrow', '', 16) ?></button>
  </div>
</form>

<p class="auth-switch"><?= e(__('New here?')) ?> <a href="<?= e(url('/sign-up')) ?>"><?= e(__('Create an account')) ?></a></p>
