<h1 class="auth-title"><?= e(__('Reset your password')) ?></h1>
<p class="auth-sub"><?= e(__('Enter the email you signed up with and we’ll send you a link to choose a new password.')) ?></p>

<?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

<form method="POST" action="<?= e(url('/forgot-password')) ?>" novalidate data-once>
  <?= csrf_field() ?>
  <div class="field">
    <label class="label" for="email"><?= e(__('Email address')) ?></label>
    <input id="email" name="email" type="email" class="input <?= invalid('email') ?>"
           value="<?= e(old('email')) ?>" placeholder="<?= e(__('Enter your email address')) ?>" autocomplete="email" required autofocus>
    <?= field_error('email') ?>
  </div>
  <div class="auth-actions">
    <button type="submit" class="btn btn-primary btn-block btn-lg"><?= e(__('Send reset link')) ?></button>
  </div>
</form>

<p class="auth-switch"><a href="<?= e(url('/sign-in')) ?>"><?= e(__('Back to sign in')) ?></a></p>
