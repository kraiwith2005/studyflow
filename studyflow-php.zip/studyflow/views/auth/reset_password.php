<h1 class="auth-title"><?= e(__('Choose a new password')) ?></h1>
<p class="auth-sub"><?= e(__('At least 8 characters, with letters and numbers.')) ?></p>

<form method="POST" action="<?= e(url('/reset-password')) ?>" novalidate data-once>
  <?= csrf_field() ?>
  <input type="hidden" name="token" value="<?= e($token) ?>">
  <div class="field">
    <label class="label" for="email"><?= e(__('Email address')) ?></label>
    <input id="email" name="email" type="email" class="input <?= invalid('email') ?>"
           value="<?= e(old('email', $email)) ?>" autocomplete="email" required>
    <?= field_error('email') ?>
  </div>
  <?= view('partials/password_field', ['id' => 'password', 'name' => 'password', 'label' => __('New password'),
    'placeholder' => __('New password'), 'autocomplete' => 'new-password']) ?>
  <?= view('partials/password_field', ['id' => 'password_confirmation', 'name' => 'password_confirmation',
    'label' => __('Confirm new password'), 'placeholder' => __('Type it again'), 'autocomplete' => 'new-password']) ?>
  <div class="auth-actions">
    <button type="submit" class="btn btn-primary btn-block btn-lg"><?= e(__('Reset password')) ?></button>
  </div>
</form>
