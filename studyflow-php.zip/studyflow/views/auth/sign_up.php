<h1 class="auth-title"><?= e(__('Create your account')) ?></h1>
<p class="auth-sub"><?= e(__('Add your schoolwork once. StudyFlow keeps the rest connected.')) ?></p>

<form method="POST" action="<?= e(url('/sign-up')) ?>" novalidate data-once>
  <?= csrf_field() ?>
  <div class="field-row">
    <div class="field">
      <label class="label" for="first_name"><?= e(__('First name')) ?></label>
      <input id="first_name" name="first_name" class="input <?= invalid('first_name') ?>"
             value="<?= e(old('first_name')) ?>" placeholder="<?= e(__('First name')) ?>" autocomplete="given-name" required autofocus>
      <?= field_error('first_name') ?>
    </div>
    <div class="field">
      <label class="label" for="last_name"><?= e(__('Last name')) ?></label>
      <input id="last_name" name="last_name" class="input <?= invalid('last_name') ?>"
             value="<?= e(old('last_name')) ?>" placeholder="<?= e(__('Last name')) ?>" autocomplete="family-name" required>
      <?= field_error('last_name') ?>
    </div>
  </div>

  <div class="field">
    <label class="label" for="email"><?= e(__('Email address')) ?></label>
    <input id="email" name="email" type="email" class="input <?= invalid('email') ?>"
           value="<?= e(old('email')) ?>" placeholder="<?= e(__('Enter your email address')) ?>" autocomplete="email" required>
    <?= field_error('email') ?>
  </div>

  <?= view('partials/password_field', [
    'id' => 'password', 'name' => 'password', 'label' => __('Password'),
    'placeholder' => __('Enter your password'), 'autocomplete' => 'new-password',
    'hint' => error_for('password') ? null : __('At least 8 characters, with letters and numbers.'),
  ]) ?>

  <div class="auth-actions">
    <button type="submit" class="btn btn-primary btn-block btn-lg"><?= e(__('Continue')) ?> <?= icon('arrow', '', 16) ?></button>
  </div>
</form>

<p class="auth-switch"><?= e(__('Already have an account?')) ?> <a href="<?= e(url('/sign-in')) ?>"><?= e(__('Sign in')) ?></a></p>
<p class="auth-legal">
  <?= __('By creating an account, you agree to the :terms and acknowledge the :privacy. This does not opt you into marketing messages.', [
    'terms' => '<a href="'.e(url('/terms')).'">'.e(__('Terms of Use')).'</a>',
    'privacy' => '<a href="'.e(url('/privacy')).'">'.e(__('Privacy Policy')).'</a>',
  ]) ?>
</p>
