<?php $todayStr = $todayDate->format('Y-m-d'); ?>
<?php section_start('banner'); include ROOT.'/views/partials/setup_banner.php'; section_end(); ?>

<div class="page" id="today-page" data-reopen="<?= e(flashed('reopen')) ?>">
  <div class="page-head">
    <div>
      <h1 class="page-title"><?= e(__('Today')) ?></h1>
      <p class="page-sub"><?= e(fmt_date($todayDate, 'long')) ?></p>
    </div>
    <button type="button" class="btn btn-primary btn-lg" data-add-date="<?= e($todayStr) ?>">
      <?= icon('plus') ?> <?= e(__('Add item')) ?>
    </button>
  </div>

  <?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

  <div class="today-grid">
    <section class="card today-card">
      <div class="card-title"><?= e(__('Classes today')) ?></div>
      <?php if (! $classes): ?>
        <p class="today-empty"><?= e(__('No classes today.')) ?></p>
      <?php else: ?>
        <ul class="today-list">
          <?php foreach ($classes as $c): ?>
            <li class="today-row" style="--c: <?= e($c['color']) ?>">
              <span class="today-time"><?= e(fmt_time($c['start'])) ?></span>
              <span class="today-main">
                <span class="today-name"><?= e($c['title']) ?></span>
                <span class="today-meta"><?= e(fmt_time($c['start']).'–'.fmt_time($c['end'])) ?><?php if (! empty($c['location'])): ?> · <?= e($c['location']) ?><?php endif; ?></span>
              </span>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>

    <section class="card today-card">
      <div class="card-title"><?= e(__('Due')) ?></div>
      <?php if (! $overdue && ! $dueToday && ! $dueSoon): ?>
        <p class="today-empty"><?= e(__('Nothing due in the next 7 days.')) ?></p>
      <?php else: ?>
        <?php foreach ([['overdue', __('Overdue'), $overdue], ['today', __('Due today'), $dueToday], ['soon', __('Next 7 days'), $dueSoon]] as [$tone, $heading, $items]): ?>
          <?php if ($items): ?>
            <p class="today-subhead tone-<?= $tone ?>"><?= e($heading) ?> · <?= count($items) ?></p>
            <ul class="today-list">
              <?php foreach ($items as $t): [$dueText, $dueTone] = due_label($t); ?>
                <li class="today-row is-task" style="--c: <?= e($t->color) ?>">
                  <form method="POST" action="<?= e(url('/tasks/'.$t->id.'/toggle')) ?>" class="task-check-form">
                    <?= csrf_field() ?><?= method_field('PATCH') ?>
                    <input type="hidden" name="return" value="<?= e($returnUrl) ?>">
                    <button type="submit" class="task-check" aria-label="<?= e(__('Mark “:name” as done', ['name' => $t->title])) ?>">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                    </button>
                  </form>
                  <button type="button" class="today-main today-btn" data-item="<?= e(item_json(task_payload($t))) ?>">
                    <span class="today-name">
                      <?php if ($t->priority === 'high'): ?><span class="prio-flag" aria-label="<?= e(__('High priority')) ?>">!</span><?php endif; ?>
                      <?= e($t->title) ?>
                    </span>
                    <span class="today-meta">
                      <?php if ($t->subject_name !== null): ?><span class="swatch-dot" style="background: <?= e($t->color) ?>"></span><?= e($t->subject_name) ?> · <?php endif; ?>
                      <?= e(fmt_date($t->due_date)) ?><?php if ($t->due_hm): ?> <?= e(__('at :time', ['time' => fmt_time($t->due_hm)])) ?><?php endif; ?>
                    </span>
                  </button>
                  <span class="due-badge tone-<?= e($dueTone) ?>"><?= e($dueText) ?></span>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        <?php endforeach; ?>
      <?php endif; ?>
    </section>

    <section class="card today-card">
      <div class="card-title"><?= e(__('Study plan')) ?></div>
      <p class="today-stat">
        <?= e(__('This week')) ?>: <strong><?= e(trans_choice(':count session|:count sessions', $weekCount)) ?></strong>
        · <strong><?= e(duration_label($weekMinutes)) ?></strong>
      </p>
      <?php if (! $plannedToday && ! $doneToday): ?>
        <p class="today-empty"><?= e(__('No study blocks planned for today.')) ?></p>
        <a class="btn btn-outline btn-sm" href="<?= e(url('/study')) ?>"><?= e(__('Go to Study')) ?></a>
      <?php else: ?>
        <ul class="today-list">
          <?php foreach ($plannedToday as $s): ?>
            <li class="today-row" style="--c: <?= e($s->color) ?>">
              <span class="today-time"><?= e(fmt_time($s->start_time)) ?></span>
              <button type="button" class="today-main today-btn" data-item="<?= e(item_json(session_payload($s))) ?>">
                <span class="today-name"><?= e($s->title) ?></span>
                <span class="today-meta"><?= e(duration_label((int) $s->duration_minutes)) ?><?php if ($s->subject_name !== null): ?> · <?= e($s->subject_name) ?><?php endif; ?></span>
              </button>
              <a class="btn btn-primary btn-sm" href="<?= e(url('/study')) ?>"><?= e(__('Start')) ?></a>
            </li>
          <?php endforeach; ?>
          <?php foreach ($doneToday as $s): ?>
            <li class="today-row is-done" style="--c: <?= e($s->color) ?>">
              <span class="today-time"><?= e(fmt_time($s->start_time)) ?></span>
              <span class="today-main">
                <span class="today-name"><?= e($s->title) ?></span>
                <span class="today-meta"><?= e(__('Done')) ?> · <?= e(duration_label((int) ($s->actual_minutes ?: $s->duration_minutes))) ?></span>
              </span>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>
  </div>
</div>

<?php include ROOT.'/views/calendar/dialogs.php'; ?>

<?php section_start('scripts'); ?>
<script src="<?= e(asset('js/calendar.js')) ?>"></script>
<?php section_end(); ?>
