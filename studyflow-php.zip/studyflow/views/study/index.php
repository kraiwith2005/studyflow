<?php $tabUrl = fn ($t) => url('/study', ['tab' => $t === 'focus' ? null : $t]); ?>
<?php section_start('banner'); include ROOT.'/views/partials/setup_banner.php'; section_end(); ?>

<div class="page" id="study-page">
  <div class="page-head">
    <div>
      <h1 class="page-title"><?= e(__('Study')) ?></h1>
      <p class="page-sub"><?= e(__('Plan preparation, focus on the work, and keep a clear record of what you completed.')) ?></p>
    </div>
  </div>

  <?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

  <div class="study-bar">
    <nav class="seg" aria-label="<?= e(__('Study')) ?>">
      <a class="seg-btn <?= $tab === 'focus' ? 'is-active' : '' ?>" href="<?= e($tabUrl('focus')) ?>" <?= $tab === 'focus' ? 'aria-current="page"' : '' ?>><?= e(__('Focus')) ?></a>
      <a class="seg-btn <?= $tab === 'log' ? 'is-active' : '' ?>" href="<?= e($tabUrl('log')) ?>" <?= $tab === 'log' ? 'aria-current="page"' : '' ?>><?= e(__('Plan & Log')) ?></a>
    </nav>
    <span class="study-stats">
      <strong><?= e(__('This week')) ?></strong>
      <span class="dot-sep">•</span> <?= e(trans_choice(':count completed session|:count completed sessions', $weekCount)) ?>
      <span class="dot-sep">•</span> <strong><?= e(fmt_minutes($weekMinutes)) ?></strong>
    </span>
  </div>

  <?php include ROOT.'/views/study/'.($tab === 'focus' ? 'focus' : 'log').'.php'; ?>
</div>

<?php include ROOT.'/views/calendar/dialogs.php'; ?>

<?php section_start('scripts'); ?>
<script src="<?= e(asset('js/calendar.js')) ?>"></script>
<script src="<?= e(asset('js/study.js')) ?>"></script>
<?php section_end(); ?>
