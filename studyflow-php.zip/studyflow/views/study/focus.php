<?php
$state = $timer->status ?? 'ready';
$vis = fn (string $when) => in_array($state, explode(' ', $when), true) ? '' : 'hidden';
$timerJs = [
  'timer' => $timer ? timer_client($timer) : null,
  'serverNow' => time() * 1000,
  'urls' => ['start' => url('/study/timer'), 'pause' => url('/study/timer/pause'), 'resume' => url('/study/timer/resume'), 'stop' => url('/study/timer/stop'), 'discard' => url('/study/timer')],
  'strings' => [
    'ready' => __('READY'), 'running' => __('RUNNING'), 'paused' => __('PAUSED'),
    'choose' => __('Choose what you’re studying first.'),
    'discardQ' => __('Discard this timer?'), 'discardText' => __('The time on the timer won’t be saved.'), 'discard' => __('Discard'),
  ],
];
?>
<section class="card timer-card" id="timer" data-state="<?= e($state) ?>">
  <div class="timer-left">
    <div class="timer-title">
      <span><?= e(__('Study timer')) ?></span>
      <span class="state-badge" data-state-badge><?= e(['ready' => __('READY'), 'running' => __('RUNNING'), 'paused' => __('PAUSED')][$state]) ?></span>
    </div>
    <p class="timer-sub"><?= e(__('Choose an assessment or subject, then record the time you actually study.')) ?></p>

    <div class="timer-pick" data-when="ready" <?= $vis('ready') ?>>
      <label class="sr-only" for="timer-target"><?= e(__('Choose what you’re studying')) ?></label>
      <select id="timer-target" class="select timer-select">
        <option value=""><?= e(__('Choose what you’re studying')) ?></option>
        <?php if ($todayPlanned): ?>
          <optgroup label="<?= e(__('Planned for today')) ?>">
            <?php foreach ($todayPlanned as $s): ?><option value="session:<?= $s->id ?>"><?= e(fmt_time($s->start_time).' · '.$s->title) ?></option><?php endforeach; ?>
          </optgroup>
        <?php endif; ?>
        <?php if ($assessments): ?>
          <optgroup label="<?= e(__('Assessments')) ?>">
            <?php foreach ($assessments as $t): ?><option value="task:<?= $t->id ?>"><?= e(task_type_label($t->type).' · '.$t->title) ?></option><?php endforeach; ?>
          </optgroup>
        <?php endif; ?>
        <?php if ($subjects): ?>
          <optgroup label="<?= e(__('Subjects')) ?>">
            <?php foreach ($subjects as $s): ?><option value="subject:<?= $s->id ?>"><?= e($s->name) ?></option><?php endforeach; ?>
          </optgroup>
        <?php endif; ?>
      </select>
      <span class="field-error" data-timer-error hidden></span>
      <?php if (! $subjects): ?>
        <span class="field-hint"><a href="<?= e(url('/settings', ['open' => 'subjects'])) ?>#subjects"><?= e(__('Add a subject in Settings first.')) ?></a></span>
      <?php endif; ?>
    </div>
    <div class="timer-now" data-when="running paused" <?= $vis('running paused') ?>>
      <span class="timer-now-k"><?= e(__('Studying')) ?></span>
      <span class="timer-now-v" data-timer-label><?= e($timer->label ?? '') ?></span>
    </div>
  </div>

  <div class="timer-right">
    <div class="timer-display" data-timer-display aria-live="off">00:00:00</div>
    <div class="timer-actions">
      <button type="button" class="btn btn-primary btn-lg" data-act="start" data-when="ready" <?= $vis('ready') ?>><?= icon('play') ?> <?= e(__('Start')) ?></button>
      <button type="button" class="btn btn-outline btn-lg" data-act="pause" data-when="running" <?= $vis('running') ?>><?= e(__('Pause')) ?></button>
      <button type="button" class="btn btn-primary btn-lg" data-act="resume" data-when="paused" <?= $vis('paused') ?>><?= icon('play') ?> <?= e(__('Resume')) ?></button>
      <button type="button" class="btn btn-primary btn-lg" data-act="stop" data-when="running paused" <?= $vis('running paused') ?>><?= e(__('Stop & save')) ?></button>
      <button type="button" class="btn btn-ghost" data-act="discard" data-when="paused" <?= $vis('paused') ?>><?= e(__('Discard')) ?></button>
    </div>
  </div>
</section>
<script>window.SF_TIMER = <?= json_encode($timerJs, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?>;</script>

<section class="card upcoming-card">
  <div class="upcoming-head">
    <h2 class="card-title"><?= e(__('Other upcoming assessments')) ?></h2>
    <p class="card-sub" style="margin-bottom:0"><?= e(__('Plan, study or review another assessment.')) ?></p>
  </div>
  <?php if (! $assessments): ?>
    <div class="empty upcoming-empty">
      <div class="empty-title"><?= e(__('No active assessments')) ?></div>
      <div class="empty-sub"><?= e(__('Assignments and exams will appear here automatically.')) ?></div>
    </div>
  <?php else: ?>
    <div class="upcoming-list">
      <?php foreach ($assessments as $t): [$dueText, $dueTone] = due_label($t); ?>
        <div class="up-row" style="--c: <?= e($t->color) ?>">
          <div class="up-main">
            <div class="up-title"><?= e($t->title) ?></div>
            <div class="task-meta">
              <span class="swatch-dot" style="background: <?= e($t->color) ?>"></span><?= e(task_type_label($t->type).' · '.$t->subject_name.' · '.fmt_date($t->due_date)) ?>
              <?php if ($t->planned_sessions): ?> · <?= e(trans_choice(':count session planned|:count sessions planned', $t->planned_sessions)) ?><?php endif; ?>
              <?php if ($t->done_minutes): ?> · <?= e(__(':time studied', ['time' => duration_label($t->done_minutes)])) ?><?php endif; ?>
            </div>
          </div>
          <span class="due-badge tone-<?= e($dueTone) ?>"><?= e($dueText) ?></span>
          <div class="up-actions">
            <button type="button" class="btn btn-outline btn-sm" data-plan-task="<?= $t->id ?>" data-plan-subject="<?= e($t->subject_id) ?>"
                    data-plan-title="<?= e(__('Study for :title', ['title' => $t->title])) ?>"><?= e(__('Plan study')) ?></button>
            <button type="button" class="btn btn-primary btn-sm" data-study-now="task:<?= $t->id ?>" <?= $timer ? 'disabled' : '' ?>><?= e(__('Study now')) ?></button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
