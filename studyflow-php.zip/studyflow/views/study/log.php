<div class="log-tools">
  <nav class="chip-filter" aria-label="<?= e(__('Subject')) ?>">
    <a class="fchip <?= $subjectFilter ? '' : 'is-active' ?>" href="<?= e(url('/study', ['tab' => 'log'])) ?>"><?= e(__('All')) ?></a>
    <?php foreach ($subjects as $s): ?>
      <a class="fchip <?= $subjectFilter && (int) $subjectFilter->id === (int) $s->id ? 'is-active' : '' ?>" style="--c: <?= e($s->color) ?>" href="<?= e(url('/study', ['tab' => 'log', 'subject' => $s->id])) ?>">
        <span class="swatch-dot" style="background: <?= e($s->color) ?>"></span><?= e($s->name) ?></a>
    <?php endforeach; ?>
  </nav>
  <button type="button" class="btn btn-primary" data-log-study data-subject="<?= e($subjectFilter->id ?? '') ?>"><?= icon('plus') ?> <?= e(__('Log study')) ?></button>
</div>

<section class="card log-card">
  <div class="log-head">
    <div>
      <h2 class="card-title"><?= e(__('Completed study')) ?></h2>
      <div class="log-sub"><?= e(trans_choice(':count session|:count sessions', count($completed)).' · '.fmt_minutes($completedMinutes)) ?></div>
    </div>
    <?php if ($completed): ?>
      <button type="button" class="link-btn" data-toggle-history aria-expanded="false" aria-controls="history"
              data-show="<?= e(__('Show history')) ?>" data-hide="<?= e(__('Hide history')) ?>"><?= e(__('Show history')) ?></button>
    <?php endif; ?>
  </div>
  <div class="log-list" id="history" hidden>
    <?php foreach ($completed as $s): ?>
      <button type="button" class="log-row" style="--c: <?= e($s->color) ?>" data-item="<?= e(item_json(session_payload($s))) ?>">
        <span class="log-date"><?= e(fmt_date($s->date)) ?><span><?= e(fmt_time($s->start_time)) ?></span></span>
        <span class="log-main">
          <span class="log-title"><?= e($s->title) ?></span>
          <span class="task-meta"><?php if ($s->subject_name !== null): ?><span class="swatch-dot" style="background: <?= e($s->color) ?>"></span><?= e($s->subject_name) ?><?php endif; ?> <?php if ($s->task_title !== null): ?> · <?= e($s->task_title) ?> <?php endif; ?></span>
        </span>
        <span class="log-min"><?= e(fmt_minutes((int) $s->actual_minutes)) ?></span>
      </button>
    <?php endforeach; ?>
  </div>
</section>

<section class="card log-card">
  <div class="log-head">
    <div>
      <h2 class="card-title"><?= e(__('Planned sessions')) ?></h2>
      <div class="log-sub"><?= e(__('Scheduled preparation. These don’t count as study until completed.')) ?></div>
    </div>
    <span class="log-count"><?= e(trans_choice(':count planned|:count planned', count($planned))) ?></span>
  </div>
  <?php if (! $planned): ?>
    <div class="empty upcoming-empty">
      <div class="empty-title"><?= e(__('Nothing planned')) ?></div>
      <div class="empty-sub"><?= e(__('Use “Plan study” on an assessment to schedule preparation on the Calendar.')) ?></div>
    </div>
  <?php else: ?>
    <div class="log-list">
      <?php foreach ($planned as $s): $late = $s->date < today()->format('Y-m-d'); ?>
        <div class="log-row is-static" style="--c: <?= e($s->color) ?>">
          <span class="log-date"><?= e(fmt_date($s->date)) ?><span><?= e(fmt_time($s->start_hm).' – '.fmt_time($s->end_hm)) ?></span></span>
          <button type="button" class="log-main log-open" data-item="<?= e(item_json(session_payload($s))) ?>">
            <span class="log-title"><?= e($s->title) ?> <?php if ($late): ?><span class="due-badge tone-overdue"><?= e(__('Missed')) ?></span><?php endif; ?></span>
            <span class="task-meta"><?php if ($s->subject_name !== null): ?><span class="swatch-dot" style="background: <?= e($s->color) ?>"></span><?= e($s->subject_name) ?><?php endif; ?> <?php if ($s->task_title !== null): ?> · <?= e($s->task_title) ?> <?php endif; ?> · <?= e(duration_label((int) $s->duration_minutes)) ?></span>
          </button>
          <a class="btn btn-outline btn-sm" href="<?= e(url('/study')) ?>?start=session:<?= $s->id ?>" <?= $timer ? 'aria-disabled="true" tabindex="-1" style="pointer-events:none;opacity:.5"' : '' ?>><?= e(__('Start')) ?></a>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
