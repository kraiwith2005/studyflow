<?php
[$dueText, $dueTone] = due_label($task);
$prep = [];
if ($task->planned_sessions) $prep[] = trans_choice(':count session planned|:count sessions planned', $task->planned_sessions);
if ($task->done_sessions) $prep[] = __(':time studied', ['time' => duration_label($task->done_minutes)]);
$canPlan = $task->type !== 'personal' && ! $task->done;
?>
<div class="task-row <?= $task->done ? 'is-done' : '' ?> is-prio-<?= e($task->priority) ?>" style="--c: <?= e($task->color) ?>">
  <form method="POST" action="<?= e(url('/tasks/'.$task->id.'/toggle')) ?>" class="task-check-form">
    <?= csrf_field() ?><?= method_field('PATCH') ?>
    <input type="hidden" name="return" value="<?= e($returnUrl) ?>">
    <button type="submit" class="task-check" aria-pressed="<?= $task->done ? 'true' : 'false' ?>"
            aria-label="<?= e($task->done ? __('Mark “:name” as not done', ['name' => $task->title]) : __('Mark “:name” as done', ['name' => $task->title])) ?>">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
    </button>
  </form>
  <button type="button" class="task-main" data-item="<?= e(item_json(task_payload($task))) ?>">
    <span class="task-title">
      <?php if ($task->priority === 'high'): ?><span class="prio-flag" title="<?= e(__('High priority')) ?>" aria-label="<?= e(__('High priority')) ?>">!</span><?php endif; ?>
      <?= e($task->title) ?>
      <?php if ($task->notes): ?><span class="task-icon" title="<?= e(__('Notes')) ?>" aria-label="<?= e(__('Notes')) ?>">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h10"/></svg></span><?php endif; ?>
      <?php if ($task->link): ?><span class="task-icon" title="<?= e(__('Link')) ?>" aria-label="<?= e(__('Link')) ?>">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg></span><?php endif; ?>
    </span>
    <span class="task-meta">
      <?php if ($task->subject_name !== null): ?><span class="swatch-dot" style="background: <?= e($task->color) ?>"></span><?= e($task->subject_name) ?> · <?php endif; ?>
      <?= e(fmt_date($task->due_date)) ?><?php if ($task->due_hm): ?> <?= e(__('at :time', ['time' => fmt_time($task->due_hm)])) ?><?php endif; ?>
      <?php if ($prep): ?> · <?= e(implode(' · ', $prep)) ?><?php endif; ?>
    </span>
  </button>
  <span class="due-badge tone-<?= e($dueTone) ?>"><?= e($dueText) ?></span>
  <?php if ($canPlan): ?>
    <button type="button" class="btn btn-outline btn-sm task-plan" data-plan-task="<?= $task->id ?>" data-plan-subject="<?= e($task->subject_id) ?>" data-plan-title="<?= e(__('Study for :title', ['title' => $task->title])) ?>"><?= e(__('Plan study')) ?></button>
  <?php endif; ?>
</div>
