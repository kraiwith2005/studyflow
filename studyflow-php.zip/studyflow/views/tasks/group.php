<div class="tgroup <?= $type === 'personal' ? 'is-personal' : '' ?> <?= $type === 'exam' ? 'is-exam' : '' ?>" data-group="<?= e($type) ?>">
  <div class="tgroup-head">
    <button type="button" class="tgroup-toggle" aria-expanded="true" aria-controls="group-<?= e($type) ?>" aria-label="<?= e(__('Show or hide :name', ['name' => $groupMeta[$type][0]])) ?>">
      <?= icon('chevron', '', 18) ?>
    </button>
    <div class="tgroup-text">
      <div class="tgroup-name"><?= e($groupMeta[$type][0]) ?></div>
      <div class="tgroup-count"><?= e(trans_choice(':count item|:count items', count($items))) ?></div>
    </div>
    <button type="button" class="btn btn-primary" data-add-type="<?= e($type) ?>"><?= icon('plus') ?> <?= e(__('Add')) ?></button>
  </div>
  <div class="tgroup-body" id="group-<?= e($type) ?>">
    <?php foreach ($items as $task) include ROOT.'/views/tasks/item.php'; ?>
    <?php if (! $items): ?>
      <div class="empty">
        <div class="empty-title"><?= e($groupMeta[$type][1]) ?></div>
        <div class="empty-sub"><?= e(__('Click “Add” to create one.')) ?></div>
      </div>
    <?php endif; ?>
  </div>
</div>
