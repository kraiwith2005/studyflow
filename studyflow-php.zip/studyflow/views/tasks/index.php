<?php
$tasksUrl = fn (array $over) => url('/tasks', array_merge([
    'filter' => $filter === 'all' ? null : $filter,
    'completed' => $showCompleted ? 1 : null,
    'term' => $term->id ?? null,
    'q' => $search !== '' ? $search : null,
    'high' => $highOnly ? 1 : null,
], $over));
$groupMeta = [
  'assignment' => [__('Assignments'), __('No assignments yet')],
  'exam' => [__('Exams'), __('No exams yet')],
  'personal' => [__('Personal tasks'), __('No personal tasks yet')],
];
$filterOpen = $filter !== 'all' || $term || $highOnly;
?>
<?php section_start('banner'); include ROOT.'/views/partials/setup_banner.php'; section_end(); ?>

<div class="page" id="tasks-page">
  <div class="page-head">
    <div>
      <h1 class="page-title"><?= e(__('Tasks')) ?></h1>
      <p class="page-sub"><?= e(__('Add schoolwork once, then follow each assessment from preparation to deadline.')) ?></p>
    </div>
  </div>

  <?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

  <div class="task-tools">
    <form method="GET" action="<?= e(url('/tasks')) ?>" class="task-search" role="search">
      <?php if ($filter !== 'all'): ?><input type="hidden" name="filter" value="<?= e($filter) ?>"><?php endif; ?>
      <?php if ($showCompleted): ?><input type="hidden" name="completed" value="1"><?php endif; ?>
      <?php if ($term): ?><input type="hidden" name="term" value="<?= (int) $term->id ?>"><?php endif; ?>
      <?php if ($highOnly): ?><input type="hidden" name="high" value="1"><?php endif; ?>
      <label class="sr-only" for="task-search"><?= e(__('Search tasks')) ?></label>
      <svg class="task-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      <input id="task-search" type="search" name="q" value="<?= e($search) ?>" class="input input-rect task-search-input" placeholder="<?= e(__('Search tasks')) ?>" maxlength="80">
      <?php if ($search !== ''): ?><a class="task-search-clear" href="<?= e($tasksUrl(['q' => null])) ?>" aria-label="<?= e(__('Clear search')) ?>">&times;</a><?php endif; ?>
    </form>
    <button type="button" class="pill-btn <?= $filterOpen ? 'is-on' : '' ?>" data-toggle-filter aria-expanded="<?= $filterOpen ? 'true' : 'false' ?>" aria-controls="filter-bar"><?= e(__('Filter')) ?></button>
    <a class="pill-btn <?= $showCompleted ? 'is-on' : '' ?>" href="<?= e($tasksUrl(['completed' => $showCompleted ? null : 1])) ?>" aria-pressed="<?= $showCompleted ? 'true' : 'false' ?>">
      <?= e($showCompleted ? __('Hide completed') : __('Show completed')) ?>
    </a>
  </div>

  <div class="filter-bar" id="filter-bar" <?= $filterOpen ? '' : 'hidden' ?>>
    <nav class="seg" aria-label="<?= e(__('Filter')) ?>">
      <?php foreach (['all' => __('All'), 'school' => __('School'), 'personal' => __('Personal')] as $f => $label): ?>
        <a class="seg-btn <?= $filter === $f ? 'is-active' : '' ?>" href="<?= e($tasksUrl(['filter' => $f === 'all' ? null : $f])) ?>" <?= $filter === $f ? 'aria-current="true"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
    <a class="pill-btn pill-urgent <?= $highOnly ? 'is-on' : '' ?>" href="<?= e($tasksUrl(['high' => $highOnly ? null : 1])) ?>" aria-pressed="<?= $highOnly ? 'true' : 'false' ?>"><?= e(__('High priority only')) ?></a>
    <?php if ($terms): ?>
      <label class="sr-only" for="term-filter"><?= e(__('Term')) ?></label>
      <select id="term-filter" class="select select-sm" data-term-filter data-base="<?= e($tasksUrl(['term' => null])) ?>">
        <option value=""><?= e(__('All terms')) ?></option>
        <?php foreach ($terms as $t): ?><option value="<?= $t->id ?>" <?= selected($term && (int) $term->id === (int) $t->id) ?>><?= e($t->name) ?></option><?php endforeach; ?>
      </select>
    <?php endif; ?>
  </div>

  <p class="task-count">
    <?= e(trans_choice(':count task showing|:count tasks showing', $count)) ?>
    <?php if ($search !== ''): ?> · <?= e(__('matching “:q”', ['q' => $search])) ?><?php endif; ?>
  </p>
  <?php if ($count === 0 && ($search !== '' || $highOnly)): ?>
    <div class="empty"><?= e(__('No tasks match. Try another word or clear the filters.')) ?>
      <a href="<?= e(url('/tasks')) ?>"><?= e(__('Clear all')) ?></a>
    </div>
  <?php endif; ?>

  <section class="task-section" aria-labelledby="sec-assess" <?= $filter === 'personal' ? 'hidden' : '' ?>>
    <h2 class="eyebrow" id="sec-assess"><?= e(__('ASSESSMENTS')) ?></h2>
    <p class="section-sub"><?= e(__('Assignments and exams move from preparation to their due date. Plan study sessions for each one.')) ?></p>
    <?php foreach ($groups['assessments'] as $type => $items) include ROOT.'/views/tasks/group.php'; ?>
  </section>

  <section class="task-section" aria-labelledby="sec-other">
    <h2 class="eyebrow" id="sec-other"><?= e(__('OTHER WORK')) ?></h2>
    <p class="section-sub"><?= e(__('Personal tasks stay lightweight and easy to clear.')) ?></p>
    <?php foreach ($groups['other'] as $type => $items): ?>
      <?php if (! ($filter === 'school' && $type === 'personal') && ! ($filter === 'personal' && $type !== 'personal')) include ROOT.'/views/tasks/group.php'; ?>
    <?php endforeach; ?>
  </section>
</div>

<?php include ROOT.'/views/calendar/dialogs.php'; ?>

<?php section_start('scripts'); ?>
<script src="<?= e(asset('js/calendar.js')) ?>"></script>
<script src="<?= e(asset('js/tasks.js')) ?>"></script>
<?php section_end(); ?>
