<?php /* Password input with a show/hide button. Needs: $id, $name, $label, $placeholder, $autocomplete; optional $forgot, $hint, $bag */
$bag = $bag ?? 'default'; ?>
<div class="field">
  <?php if (! empty($forgot)): ?>
    <div class="label-row">
      <label class="label" for="<?= e($id) ?>"><?= e($label) ?></label>
      <a class="forgot-link" href="<?= e(url('/forgot-password')) ?>"><?= e(__('Forgot password?')) ?></a>
    </div>
  <?php else: ?>
    <label class="label" for="<?= e($id) ?>"><?= e($label) ?></label>
  <?php endif; ?>
  <div class="input-wrap">
    <input id="<?= e($id) ?>" name="<?= e($name) ?>" type="password" class="input <?= invalid($name, $bag) ?>"
           placeholder="<?= e($placeholder) ?>" autocomplete="<?= e($autocomplete) ?>" required>
    <button type="button" class="input-action" data-toggle-password="<?= e($id) ?>" aria-label="<?= e(__('Show password')) ?>" aria-pressed="false">
      <?= icon('eye') ?>
    </button>
  </div>
  <?php if (! empty($hint)): ?><span class="field-hint"><?= e($hint) ?></span><?php endif; ?>
  <?= field_error($name, $bag) ?>
</div>
