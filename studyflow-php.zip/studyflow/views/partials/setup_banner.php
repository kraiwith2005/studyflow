<?php $progress = setup_progress(user_id()); ?>
<?php if ($progress['done'] < $progress['total']): ?>
<section class="setup" aria-label="<?= e(__('Planner setup')) ?>">
  <div class="setup-head">
    <div>
      <div class="setup-title"><?= e(__('Complete your planner setup')) ?></div>
      <div class="setup-sub"><?= e(__('Add these once so your calendar, tasks, study plans and timetable work properly.')) ?></div>
    </div>
    <span class="setup-count"><?= e(__(':done of :total complete', ['done' => $progress['done'], 'total' => $progress['total']])) ?></span>
  </div>
  <div class="setup-cards">
    <?php foreach (['subjects' => __('Subjects'), 'terms' => __('Terms'), 'timetable' => __('Timetable')] as $key => $label): ?>
      <?php $done = $progress['steps'][$key]; ?>
      <a href="<?= e(url('/settings', ['open' => $key])) ?>#<?= $key ?>" class="setup-card <?= $done ? 'is-done' : '' ?>">
        <span class="setup-card-name"><?= e($label) ?></span>
        <span class="setup-card-action"><?= e($done ? __('Complete') : __('Set up now')) ?></span>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>
