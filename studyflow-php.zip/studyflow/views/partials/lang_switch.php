<?php /* ไทย / EN switch (posts to /locale/th or /locale/en) */ ?>
<form method="POST" class="lang-switch" aria-label="<?= e(__('Language')) ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="back" value="<?= e(current_page()) ?>">
  <?php foreach (['th' => 'ไทย', 'en' => 'EN'] as $code => $label): ?>
    <button type="submit" formaction="<?= e(url('/locale/'.$code)) ?>" class="lang-btn <?= locale() === $code ? 'is-active' : '' ?>"
            lang="<?= $code ?>" <?= locale() === $code ? 'aria-current="true"' : '' ?>><?= $label ?></button>
  <?php endforeach; ?>
</form>
