<?php $backupErrors = $GLOBALS['FLASH']['_errors']['backup'] ?? []; ?>
<section class="acc <?= $isOpen('backup') ? 'is-open' : '' ?>" id="backup" data-acc="backup">
  <button type="button" class="acc-head" aria-expanded="<?= $isOpen('backup') ? 'true' : 'false' ?>" aria-controls="backup-body">
    <span class="sec-icon purple"><?= icon('database', '', 20) ?></span>
    <span class="acc-text">
      <span class="acc-title"><?= e(__('Backup & data')) ?></span><br>
      <span class="acc-sub"><?= e(__('Export, import or clear your planner data.')) ?></span>
    </span>
    <?= icon('chevron', 'acc-chev', 20) ?>
  </button>
  <div class="acc-body" id="backup-body">
    <?php if ($backupErrors): ?><div class="form-error-box" role="alert"><?= e(reset($backupErrors)[0]) ?></div><?php endif; ?>
    <div class="backup-list">
      <div class="backup-row">
        <div>
          <div class="row-title"><?= e(__('Export backup')) ?></div>
          <div class="row-meta"><?= e(__('Download your subjects, terms, timetable, tasks and study sessions as a JSON file.')) ?></div>
        </div>
        <a href="<?= e(url('/settings/backup/export')) ?>" class="btn btn-outline"><?= icon('download', '', 16) ?> <?= e(__('Export')) ?></a>
      </div>
      <div class="backup-row">
        <div>
          <div class="row-title"><?= e(__('Import backup')) ?></div>
          <div class="row-meta"><?= e(__('Restore from a StudyFlow backup file. This replaces your current planner data.')) ?></div>
        </div>
        <form method="POST" action="<?= e(url('/settings/backup/import')) ?>" enctype="multipart/form-data" id="import-form"
              data-confirm="<?= e(__('Replace your planner with this backup?')) ?>" data-confirm-text="<?= e(__('Your current planner data will be replaced by the file’s contents.')) ?>" data-confirm-label="<?= e(__('Import')) ?>">
          <?= csrf_field() ?>
          <label class="btn btn-outline" style="position:relative">
            <?= icon('upload', '', 16) ?> <?= e(__('Import')) ?>
            <input type="file" name="backup" accept=".json,application/json" data-auto-submit
                   style="position:absolute;inset:0;opacity:0;cursor:pointer" aria-label="<?= e(__('Choose backup file')) ?>">
          </label>
        </form>
      </div>
      <div class="backup-row danger">
        <div>
          <div class="row-title"><?= e(__('Clear all data')) ?></div>
          <div class="row-meta"><?= e(__('Remove all subjects, terms, timetable, tasks and study sessions. Your account stays.')) ?></div>
        </div>
        <button type="button" class="btn btn-outline link-danger" data-open-dialog="clear-dialog"><?= e(__('Clear all data')) ?></button>
      </div>
    </div>
  </div>
</section>

<dialog class="dlg" id="clear-dialog">
  <form method="POST" action="<?= e(url('/settings/backup/clear')) ?>" class="dlg-body" data-once>
    <?= csrf_field() ?><?= method_field('DELETE') ?>
    <div class="dlg-title"><?= e(__('Clear all planner data?')) ?></div>
    <p class="dlg-text"><?= e(__('Subjects, terms, period times, classes, tasks and study sessions will be deleted. Export a backup first if you might need it. This can’t be undone.')) ?></p>
    <div class="field">
      <label class="label" for="clear-confirm"><?= __('Type :word to confirm', ['word' => '<strong>CLEAR</strong>']) ?></label>
      <input id="clear-confirm" name="confirm" class="input input-rect" autocomplete="off" data-match="CLEAR">
    </div>
    <div class="form-buttons">
      <button type="submit" class="btn btn-danger" data-match-submit disabled><?= e(__('Clear all data')) ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close><?= e(__('Cancel')) ?></button>
    </div>
  </form>
</dialog>
