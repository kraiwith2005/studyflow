<?php
$reopen = (string) flashed('reopen', '');
$isOpen = fn ($key) => in_array($key, $open, true);
?>
<div class="page" id="settings" data-reopen="<?= e($reopen) ?>">
  <div class="page-head">
    <div>
      <h1 class="page-title"><?= e(__('Settings')) ?></h1>
      <p class="page-sub"><?= e(__('Manage your subjects, terms, timetable, data and support.')) ?></p>
    </div>
  </div>

  <?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

  <div class="acc-stack">
    <?php foreach (['subjects', 'terms', 'timetable', 'backup', 'support'] as $part) include ROOT.'/views/settings/'.$part.'.php'; ?>
  </div>
</div>

<dialog class="dlg" id="confirm-dialog">
  <div class="dlg-body">
    <div class="dlg-title" data-confirm-title><?= e(__('Are you sure?')) ?></div>
    <p class="dlg-text" data-confirm-text></p>
    <div class="form-buttons" style="margin-top:0">
      <button type="button" class="btn btn-danger" data-confirm-ok><?= e(__('Delete')) ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close><?= e(__('Cancel')) ?></button>
    </div>
  </div>
</dialog>

<?php section_start('scripts'); ?>
<script src="<?= e(asset('js/settings.js')) ?>"></script>
<?php section_end(); ?>
