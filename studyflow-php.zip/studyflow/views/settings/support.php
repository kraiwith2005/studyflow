<?php $supportEmail = $GLOBALS['CONFIG']['support_email'] ?? ''; ?>
<section class="acc" id="support">
  <div class="support-main">
    <span class="sec-icon red"><?= icon('lifebuoy', '', 20) ?></span>
    <div class="acc-text">
      <div class="acc-title"><?= e(__('Support')) ?></div>
      <div class="acc-sub"><?= e(__('Need help or have an idea? Tell us what would make planning easier. We read feedback and use it to guide improvements.')) ?></div>
    </div>
    <a class="support-email" href="mailto:<?= e($supportEmail) ?>"><?= e($supportEmail) ?></a>
  </div>
  <div class="support-foot">
    <a href="<?= e(url('/privacy')) ?>"><?= e(__('Privacy')) ?></a>
    <a href="<?= e(url('/terms')) ?>"><?= e(__('Terms of Use')) ?></a>
    <a href="<?= e(url('/cookies')) ?>"><?= e(__('Cookies')) ?></a>
    <button type="button" class="link-btn link-danger" data-open-dialog="delete-account-dialog"><?= e(__('Delete account')) ?></button>
  </div>
</section>

<dialog class="dlg" id="delete-account-dialog" <?= has_errors('delete') ? 'data-autoshow' : '' ?>>
  <form method="POST" action="<?= e(url('/account')) ?>" class="dlg-body" novalidate data-once>
    <?= csrf_field() ?><?= method_field('DELETE') ?>
    <div class="dlg-title"><?= e(__('Delete your account?')) ?></div>
    <p class="dlg-text"><?= e(__('Your account and all of its planner data will be permanently deleted. This can’t be undone.')) ?></p>
    <?php if ($user->has_password): ?>
      <?= view('partials/password_field', ['id' => 'delete-password', 'name' => 'password', 'bag' => 'delete',
        'label' => __('Enter your password to confirm'), 'placeholder' => __('Password'), 'autocomplete' => 'current-password']) ?>
    <?php else: ?>
      <div class="field">
        <label class="label" for="confirm-email"><?= __('Type :word to confirm', ['word' => '<strong>'.e($user->email).'</strong>']) ?></label>
        <input id="confirm-email" name="confirm_email" class="input input-rect" autocomplete="off">
        <?= field_error('confirm_email', 'delete') ?>
      </div>
    <?php endif; ?>
    <div class="form-buttons">
      <button type="submit" class="btn btn-danger"><?= e(__('Delete account')) ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close><?= e(__('Cancel')) ?></button>
    </div>
  </form>
</dialog>
