<?php
$editing = str_starts_with($reopen, 'subject-') && $reopen !== 'subject-new' ? (int) substr($reopen, 8) : null;
?>
<section class="acc <?= $isOpen('subjects') ? 'is-open' : '' ?>" id="subjects" data-acc="subjects">
  <button type="button" class="acc-head" aria-expanded="<?= $isOpen('subjects') ? 'true' : 'false' ?>" aria-controls="subjects-body">
    <span class="sec-icon blue"><?= icon('book', '', 20) ?></span>
    <span class="acc-text">
      <span class="acc-title"><?= e(__('Subjects')) ?></span><br>
      <span class="acc-sub"><?= e(trans_choice(':count subject configured.|:count subjects configured.', count($subjects))) ?></span>
    </span>
    <?= icon('chevron', 'acc-chev', 20) ?>
  </button>
  <div class="acc-body" id="subjects-body">
    <div class="acc-toolbar">
      <button type="button" class="btn btn-primary" data-open-dialog="subject-dialog"
              data-action="<?= e(url('/settings/subjects')) ?>" data-method="POST"
              data-title="<?= e(__('New subject')) ?>" data-submit="<?= e(__('Add')) ?>" data-values='{"name":"","color":"<?= e(SUBJECT_PRESETS[0]) ?>"}'>
        <?= icon('plus') ?> <?= e(__('Add subject')) ?>
      </button>
    </div>

    <?php if (! $subjects): ?>
      <div class="empty">
        <div class="empty-title"><?= e(__('No subjects yet')) ?></div>
        <div class="empty-sub"><?= e(__('Add subjects before filling your timetable grid.')) ?></div>
      </div>
    <?php else: ?>
      <div class="rows">
        <?php foreach ($subjects as $subject): ?>
          <div class="row-item">
            <span class="swatch-dot" style="background: <?= e($subject->color) ?>"></span>
            <div class="row-main">
              <div class="row-title"><?= e($subject->name) ?></div>
              <div class="row-meta"><?= e(trans_choice(':count timetable cell|:count timetable cells', (int) $subject->slots_count)) ?></div>
            </div>
            <div class="row-actions">
              <button type="button" class="icon-action" aria-label="<?= e(__('Edit :name', ['name' => $subject->name])) ?>" data-open-dialog="subject-dialog"
                      data-action="<?= e(url('/settings/subjects/'.$subject->id)) ?>" data-method="PUT"
                      data-title="<?= e(__('Edit subject')) ?>" data-submit="<?= e(__('Save')) ?>"
                      data-values="<?= e(json_encode(['name' => $subject->name, 'color' => $subject->color])) ?>">
                <?= icon('pencil', '', 16) ?>
              </button>
              <form method="POST" action="<?= e(url('/settings/subjects/'.$subject->id)) ?>"
                    data-confirm="<?= e(__('Delete “:name”?', ['name' => $subject->name])) ?>"
                    data-confirm-text="<?= e(($subject->slots_count ? trans_choice('It will also be removed from :count timetable cell.|It will also be removed from :count timetable cells.', (int) $subject->slots_count).' ' : '').__('This can’t be undone.')) ?>">
                <?= csrf_field() ?><?= method_field('DELETE') ?>
                <button type="submit" class="icon-action danger" aria-label="<?= e(__('Delete :name', ['name' => $subject->name])) ?>"><?= icon('trash', '', 16) ?></button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<dialog class="dlg dlg-wide" id="subject-dialog" <?= str_starts_with($reopen, 'subject-') ? 'data-autoshow' : '' ?>>
  <form method="POST" class="dlg-body" novalidate data-once
        action="<?= e($editing ? url('/settings/subjects/'.$editing) : url('/settings/subjects')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="_method" value="<?= $editing ? 'PUT' : 'POST' ?>">
    <label class="dlg-title" for="subject-name" data-dialog-title style="display:block"><?= e($editing ? __('Edit subject') : __('New subject')) ?></label>
    <input id="subject-name" name="name" class="input input-rect <?= invalid('name', 'subject') ?>"
           placeholder="<?= e(__('Subject name')) ?>" maxlength="80" value="<?= e(old('name')) ?>" required data-enable-submit>
    <?= field_error('name', 'subject') ?>

    <div style="margin-top:16px">
      <div class="label"><?= e(__('Colour')) ?></div>
      <div class="field-hint" style="font-size:14px;margin-top:4px"><?= e(__('Choose a preset or use any custom shade.')) ?></div>
      <?php $current = (string) old('color', SUBJECT_PRESETS[0]); ?>
      <div class="swatches" role="radiogroup" aria-label="<?= e(__('Subject colour')) ?>">
        <?php foreach (SUBJECT_PRESETS as $hex): ?>
          <button type="button" class="swatch" role="radio" style="background: <?= $hex ?>" data-color="<?= $hex ?>"
                  aria-checked="<?= strtolower($current) === $hex ? 'true' : 'false' ?>" aria-label="<?= e(__('Colour :hex', ['hex' => $hex])) ?>"></button>
        <?php endforeach; ?>
      </div>
      <label class="btn btn-outline btn-sm custom-colour">
        <span class="custom-preview" data-colour-preview style="background: <?= e($current) ?>"></span>
        <?= e(__('Custom colour')) ?>
        <input type="color" name="color" value="<?= e($current) ?>" data-colour-input aria-label="<?= e(__('Custom colour')) ?>">
      </label>
      <?= field_error('color', 'subject') ?>
    </div>

    <div class="form-buttons">
      <button type="submit" class="btn btn-primary" data-dialog-submit disabled><?= e($editing ? __('Save') : __('Add')) ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close><?= e(__('Cancel')) ?></button>
    </div>
  </form>
</dialog>
