<?php
$termOpen = str_starts_with($reopen, 'term-');
$termEditing = $termOpen && $reopen !== 'term-new' ? (int) substr($reopen, 5) : null;
$todayStr = today()->format('Y-m-d');
?>
<section class="acc <?= $isOpen('terms') ? 'is-open' : '' ?>" id="terms" data-acc="terms">
  <button type="button" class="acc-head" aria-expanded="<?= $isOpen('terms') ? 'true' : 'false' ?>" aria-controls="terms-body">
    <span class="sec-icon orange"><?= icon('calendar', '', 20) ?></span>
    <span class="acc-text">
      <span class="acc-title"><?= e(__('Terms')) ?></span><br>
      <span class="acc-sub"><?= e(trans_choice(':count term configured.|:count terms configured.', count($terms))) ?></span>
    </span>
    <?= icon('chevron', 'acc-chev', 20) ?>
  </button>
  <div class="acc-body" id="terms-body">
    <div class="acc-toolbar">
      <button type="button" class="btn btn-primary" data-open-panel="term-panel"
              data-action="<?= e(url('/settings/terms')) ?>" data-method="POST" data-title="<?= e(__('New term')) ?>" data-submit="<?= e(__('Add')) ?>"
              data-values="<?= e(json_encode(['name' => '', 'start_date' => $todayStr, 'end_date' => $todayStr])) ?>">
        <?= icon('plus') ?> <?= e(__('Add term')) ?>
      </button>
    </div>

    <div class="panel <?= $termOpen ? 'is-open' : '' ?>" id="term-panel">
      <form method="POST" novalidate data-once
            action="<?= e($termEditing ? url('/settings/terms/'.$termEditing) : url('/settings/terms')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="_method" value="<?= $termEditing ? 'PUT' : 'POST' ?>">
        <div class="panel-title" data-panel-title><?= e($termEditing ? __('Edit term') : __('New term')) ?></div>
        <div class="grid-3" style="margin-top:16px">
          <div class="field">
            <label class="label label-muted" for="term-name"><?= e(__('Name')) ?></label>
            <input id="term-name" name="name" class="input input-rect <?= invalid('name', 'term') ?>"
                   placeholder="<?= e(__('e.g. Term 1')) ?>" maxlength="60" value="<?= e(old('name')) ?>" required>
            <?= field_error('name', 'term') ?>
          </div>
          <div class="field">
            <label class="label label-muted" for="term-start"><?= e(__('Start date')) ?></label>
            <input id="term-start" name="start_date" type="date" class="input input-rect <?= invalid('start_date', 'term') ?>"
                   value="<?= e(old('start_date', $todayStr)) ?>" required>
            <?= field_error('start_date', 'term') ?>
          </div>
          <div class="field">
            <label class="label label-muted" for="term-end"><?= e(__('End date')) ?></label>
            <input id="term-end" name="end_date" type="date" class="input input-rect <?= invalid('end_date', 'term') ?>"
                   value="<?= e(old('end_date', $todayStr)) ?>" required>
            <?= field_error('end_date', 'term') ?>
          </div>
        </div>
        <div class="form-buttons">
          <button type="submit" class="btn btn-primary" data-panel-submit><?= e($termEditing ? __('Save') : __('Add')) ?></button>
          <button type="button" class="btn btn-outline" data-panel-close><?= e(__('Cancel')) ?></button>
        </div>
      </form>
    </div>

    <?php if (! $terms): ?>
      <div class="empty">
        <div class="empty-title"><?= e(__('No terms yet')) ?></div>
        <div class="empty-sub"><?= e(__('Add term dates so tasks can be grouped automatically.')) ?></div>
      </div>
    <?php else: ?>
      <div class="rows">
        <?php foreach ($terms as $term): ?>
          <div class="row-item">
            <div class="row-main">
              <div class="row-title"><?= e($term->name) ?> <?php if ($term->is_current): ?><span class="badge"><?= e(__('Current')) ?></span><?php endif; ?></div>
              <div class="row-meta"><?= e(fmt_date($term->start_date).' – '.fmt_date($term->end_date)) ?>
                · <?= e($term->length_label) ?></div>
            </div>
            <div class="row-actions">
              <button type="button" class="icon-action" aria-label="<?= e(__('Edit :name', ['name' => $term->name])) ?>" data-open-panel="term-panel"
                      data-action="<?= e(url('/settings/terms/'.$term->id)) ?>" data-method="PUT" data-title="<?= e(__('Edit term')) ?>" data-submit="<?= e(__('Save')) ?>"
                      data-values="<?= e(json_encode(['name' => $term->name, 'start_date' => $term->start_date, 'end_date' => $term->end_date])) ?>">
                <?= icon('pencil', '', 16) ?>
              </button>
              <form method="POST" action="<?= e(url('/settings/terms/'.$term->id)) ?>"
                    data-confirm="<?= e(__('Delete “:name”?', ['name' => $term->name])) ?>" data-confirm-text="<?= e(__('The term dates will be removed. This can’t be undone.')) ?>">
                <?= csrf_field() ?><?= method_field('DELETE') ?>
                <button type="submit" class="icon-action danger" aria-label="<?= e(__('Delete :name', ['name' => $term->name])) ?>"><?= icon('trash', '', 16) ?></button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
