<?php
$typeHelp = [
  'school' => __('School mode uses a grid so you can fill your periods × 5 days quickly. Week and day calendar views show classes. Month view stays clean.'),
  'university' => __('University mode skips the grid. Add each lecture, tutorial or lab with its own day and time below. Week and day calendar views show classes.'),
  'custom' => __('Custom mode uses a grid with your own periods across all 7 days, including weekends. Week and day calendar views show classes.'),
];
$periodsHaveErrors = has_errors('periods');
$classOpen = str_starts_with($reopen, 'class-');
$classEditing = $classOpen && $reopen !== 'class-new' ? (int) substr($reopen, 6) : null;
$ab = $planner->repeat_cycle === 'ab';
$days = grid_days($planner);
$timeRange = fn ($p) => fmt_time($p->start_time).' – '.fmt_time($p->end_time);
$editPeriods = old('periods', array_map(fn ($p) => ['id' => $p->id, 'name' => $p->name, 'kind' => $p->kind,
    'start_time' => substr($p->start_time, 0, 5), 'end_time' => substr($p->end_time, 0, 5)], $periods));
if (! is_array($editPeriods)) $editPeriods = [];
$subjectById = [];
foreach ($subjects as $s) $subjectById[(int) $s->id] = $s;
$periodErrors = $GLOBALS['FLASH']['_errors']['periods'] ?? [];
$firstPeriodError = $periodErrors ? reset($periodErrors)[0] : null;
?>
<section class="acc <?= $isOpen('timetable') ? 'is-open' : '' ?>" id="timetable" data-acc="timetable">
  <button type="button" class="acc-head" aria-expanded="<?= $isOpen('timetable') ? 'true' : 'false' ?>" aria-controls="timetable-body">
    <span class="sec-icon teal"><?= icon('grid', '', 20) ?></span>
    <span class="acc-text">
      <span class="acc-title"><?= e(__('Timetable')) ?></span><br>
      <span class="acc-sub"><?= e($ab ? __('Week A / Week B timetable') : __('Weekly timetable')) ?> · <span data-class-count><?= e(trans_choice(':count class|:count classes', $classCount)) ?></span></span>
    </span>
    <?= icon('chevron', 'acc-chev', 20) ?>
  </button>
  <div class="acc-body" id="timetable-body">

    <div class="subcard" id="tt-settings" data-url="<?= e(url('/settings/timetable')) ?>">
      <div class="grid-2">
        <div class="field">
          <label class="label label-muted" for="tt-type"><?= e(__('Timetable type')) ?></label>
          <select id="tt-type" class="select" data-tt-setting="timetable_type">
            <option value="school" <?= selected($planner->timetable_type === 'school') ?>><?= e(__('School grid')) ?></option>
            <option value="university" <?= selected($planner->timetable_type === 'university') ?>><?= e(__('University')) ?></option>
            <option value="custom" <?= selected($planner->timetable_type === 'custom') ?>><?= e(__('Custom')) ?></option>
          </select>
        </div>
        <div class="field">
          <label class="label label-muted" for="tt-cycle"><?= e(__('Repeat cycle')) ?></label>
          <select id="tt-cycle" class="select" data-tt-setting="repeat_cycle">
            <option value="weekly" <?= selected(! $ab) ?>><?= e(__('Every week')) ?></option>
            <option value="ab" <?= selected($ab) ?>><?= e(__('Week A / Week B')) ?></option>
          </select>
        </div>
        <?php if ($ab): ?>
          <div class="field">
            <label class="label label-muted" for="tt-anchor"><?= e(__('Week A starts on')) ?></label>
            <input id="tt-anchor" type="date" class="input input-rect" data-tt-setting="cycle_anchor"
                   value="<?= e($planner->cycle_anchor ? substr($planner->cycle_anchor, 0, 10) : '') ?>">
            <span class="field-hint"><?= e(__('Pick any day in a Week A. The weeks then alternate A, B, A, B…')) ?></span>
          </div>
        <?php endif; ?>
      </div>
      <p class="hint-text"><?= e($typeHelp[$planner->timetable_type] ?? '') ?></p>
    </div>

    <?php if (uses_grid($planner)): ?>
      <div class="subcard">
        <div class="subcard-head">
          <div>
            <div class="subcard-title"><?= e(__('Period times')) ?></div>
            <div class="subcard-sub"><?= e(__('Set these once, then fill the timetable grid below.')) ?></div>
          </div>
          <button type="button" class="btn btn-outline" data-toggle-periods <?= $periodsHaveErrors ? 'hidden' : '' ?>><?= e(__('Edit period times')) ?></button>
        </div>

        <div class="period-list" id="period-view" <?= $periodsHaveErrors ? 'hidden' : '' ?>>
          <?php foreach ($periods as $period): ?>
            <div class="period-item">
              <div>
                <div class="period-name"><?= e($period->name) ?></div>
                <div class="period-kind"><?= e($period->kind === 'break' ? __('Break') : __('Class period')) ?></div>
              </div>
              <div class="period-time"><?= e($timeRange($period)) ?></div>
            </div>
          <?php endforeach; ?>
        </div>

        <form method="POST" action="<?= e(url('/settings/timetable/periods')) ?>" id="period-editor" novalidate data-once <?= $periodsHaveErrors ? '' : 'hidden' ?>>
          <?= csrf_field() ?><?= method_field('PUT') ?>
          <?php if ($firstPeriodError): ?><div class="form-error-box" role="alert"><?= e($firstPeriodError) ?></div><?php endif; ?>
          <div class="period-edit-row period-edit-head" aria-hidden="true">
            <span><?= e(__('Name')) ?></span><span><?= e(__('Type')) ?></span><span><?= e(__('Start')) ?></span><span><?= e(__('End')) ?></span><span style="width:34px"></span>
          </div>
          <div id="period-rows">
            <?php foreach (array_values($editPeriods) as $i => $p): if (! is_array($p)) continue; ?>
              <div class="period-edit-row" data-period-row>
                <input type="hidden" name="periods[<?= $i ?>][id]" value="<?= e($p['id'] ?? '') ?>">
                <input class="input input-rect" name="periods[<?= $i ?>][name]" value="<?= e($p['name'] ?? '') ?>" maxlength="40" aria-label="<?= e(__('Period name')) ?>" required>
                <select class="select" name="periods[<?= $i ?>][kind]" aria-label="<?= e(__('Period type')) ?>">
                  <option value="class" <?= selected(($p['kind'] ?? '') === 'class') ?>><?= e(__('Class')) ?></option>
                  <option value="break" <?= selected(($p['kind'] ?? '') === 'break') ?>><?= e(__('Break')) ?></option>
                </select>
                <input class="input input-rect" type="time" name="periods[<?= $i ?>][start_time]" value="<?= e($p['start_time'] ?? '') ?>" aria-label="<?= e(__('Start time')) ?>" required>
                <input class="input input-rect" type="time" name="periods[<?= $i ?>][end_time]" value="<?= e($p['end_time'] ?? '') ?>" aria-label="<?= e(__('End time')) ?>" required>
                <button type="button" class="icon-action danger" data-remove-period aria-label="<?= e(__('Remove period')) ?>"><?= icon('trash', '', 16) ?></button>
              </div>
            <?php endforeach; ?>
          </div>
          <button type="button" class="btn btn-outline btn-sm" style="margin-top:14px" data-add-period><?= icon('plus', '', 16) ?> <?= e(__('Add period')) ?></button>
          <p class="hint-text"><?= e(__('Periods are sorted by start time when you save. Removing a period also clears its cells in the grid.')) ?></p>
          <div class="form-buttons">
            <button type="submit" class="btn btn-primary"><?= e(__('Save period times')) ?></button>
            <a href="<?= e(url('/settings', ['open' => 'timetable'])) ?>#timetable" class="btn btn-outline" data-cancel-periods><?= e(__('Cancel')) ?></a>
          </div>
        </form>
      </div>

      <div class="subcard" id="tt-grid" data-url="<?= e(url('/settings/timetable/slot')) ?>">
        <div class="subcard-head">
          <div>
            <div class="subcard-title"><?= e(__('Timetable grid')) ?></div>
            <div class="subcard-sub"><?= e(__('Pick a subject in each cell. Empty means no class. Changes save automatically.')) ?></div>
          </div>
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <?php if ($ab): ?>
              <div class="week-tabs" role="tablist" aria-label="<?= e(__('Week')) ?>">
                <button type="button" class="week-tab is-active" role="tab" aria-selected="true" data-week-tab="A"><?= e(__('Week A')) ?></button>
                <button type="button" class="week-tab" role="tab" aria-selected="false" data-week-tab="B"><?= e(__('Week B')) ?></button>
              </div>
            <?php endif; ?>
            <form method="POST" action="<?= e(url('/settings/timetable/grid')) ?>"
                  data-confirm="<?= e(__('Clear the whole grid?')) ?>" data-confirm-text="<?= e($ab ? __('Every cell in Week A and Week B will be emptied. Your subjects and period times stay.') : __('Every cell will be emptied. Your subjects and period times stay.')) ?>" data-confirm-label="<?= e(__('Clear grid')) ?>">
              <?= csrf_field() ?><?= method_field('DELETE') ?>
              <button type="submit" class="btn btn-outline"><?= e(__('Clear grid')) ?></button>
            </form>
          </div>
        </div>

        <?php foreach (plan_weeks($planner) as $week): ?>
          <div class="week-pane" data-week-pane="<?= $week ?>" <?= $week !== 'A' ? 'hidden' : '' ?>>
            <div class="tt-wrap">
              <table class="tt">
                <thead>
                  <tr>
                    <th scope="col"><?= e(__('PERIOD')) ?></th>
                    <?php foreach ($days as $d): ?><th scope="col"><?= e(day_name($d, true)) ?></th><?php endforeach; ?>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($periods as $period): ?>
                    <?php if ($period->kind === 'break'): ?>
                      <tr class="tt-break">
                        <td><div class="tt-pname"><?= e($period->name) ?></div><div class="tt-ptime"><?= e($timeRange($period)) ?></div></td>
                        <td colspan="<?= count($days) ?>" class="tt-break-label"><?= e(__('Break')) ?></td>
                      </tr>
                    <?php else: ?>
                      <tr>
                        <td><div class="tt-pname"><?= e($period->name) ?></div><div class="tt-ptime"><?= e($timeRange($period)) ?></div></td>
                        <?php foreach ($days as $d):
                          $sid = $grid["{$period->id}-{$d}-{$week}"] ?? null;
                          $sub = $sid ? ($subjectById[$sid] ?? null) : null; ?>
                          <td>
                            <select class="select cell <?= $sub ? 'has-subject' : '' ?>" <?= $sub ? 'style="--c: '.e($sub->color).'"' : '' ?>
                                    data-period="<?= $period->id ?>" data-day="<?= $d ?>" data-week="<?= $week ?>"
                                    aria-label="<?= e($period->name.', '.day_name($d).($ab ? ', '.__('Week '.$week) : '')) ?>"
                                    <?= $subjects ? '' : 'disabled' ?>>
                              <option value=""><?= e(__('Empty')) ?></option>
                              <?php foreach ($subjects as $s): ?>
                                <option value="<?= $s->id ?>" data-color="<?= e($s->color) ?>" <?= selected($sid === (int) $s->id) ?>><?= e($s->name) ?></option>
                              <?php endforeach; ?>
                            </select>
                          </td>
                        <?php endforeach; ?>
                      </tr>
                    <?php endif; ?>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if (! $subjects): ?>
          <div class="notice"><?= e(__('Add subjects first, then you can fill the timetable grid.')) ?>
            <a href="<?= e(url('/settings', ['open' => 'subjects'])) ?>#subjects"><?= e(__('Go to Subjects')) ?></a></div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="subcard">
      <div class="subcard-head">
        <div>
          <div class="subcard-title"><?= e(uses_grid($planner) ? __('Other recurring commitments') : __('Weekly classes')) ?></div>
          <div class="subcard-sub"><?= e(uses_grid($planner)
              ? __('Mentor periods, training, sport, work and other repeating commitments that don’t belong in the grid.')
              : __('Lectures, tutorials, labs and anything else that repeats each week.')) ?></div>
        </div>
        <button type="button" class="btn btn-primary" data-open-panel="class-panel"
                data-action="<?= e(url('/settings/classes')) ?>" data-method="POST" data-title="<?= e(__('Add one class')) ?>" data-submit="<?= e(__('Add')) ?>"
                data-values="<?= e(json_encode(['name' => '', 'subject_id' => '', 'day' => '1', 'start_time' => '09:00', 'end_time' => '10:00', 'week' => 'every', 'location' => '', 'teacher' => ''])) ?>">
          <?= icon('plus') ?> <?= e(__('Add class')) ?>
        </button>
      </div>

      <div class="panel <?= $classOpen ? 'is-open' : '' ?>" id="class-panel" style="background:var(--surface-2)">
        <form method="POST" novalidate data-once
              action="<?= e($classEditing ? url('/settings/classes/'.$classEditing) : url('/settings/classes')) ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="_method" value="<?= $classEditing ? 'PUT' : 'POST' ?>">
          <div class="panel-title" data-panel-title><?= e($classEditing ? __('Edit class') : __('Add one class')) ?></div>
          <p class="panel-sub"><?= e(__('Pick the subject, day and time. That’s all you need. Name, room and teacher are optional.')) ?></p>
          <div class="grid-2">
            <div class="field">
              <label class="label label-muted" for="class-name"><?= e(__('Class name')) ?> <span style="opacity:.7">(<?= e(__('optional')) ?>)</span></label>
              <input id="class-name" name="name" class="input input-rect <?= invalid('name', 'klass') ?>" maxlength="80"
                     placeholder="<?= e(__('Leave blank to use the subject name')) ?>" value="<?= e(old('name')) ?>">
              <?= field_error('name', 'klass') ?>
            </div>
            <div class="field">
              <label class="label label-muted" for="class-subject"><?= e(__('Subject')) ?></label>
              <select id="class-subject" name="subject_id" class="select">
                <option value=""><?= e(__('No subject / custom')) ?></option>
                <?php foreach ($subjects as $s): ?><option value="<?= $s->id ?>" <?= selected((string) old('subject_id') === (string) $s->id) ?>><?= e($s->name) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label class="label label-muted" for="class-day"><?= e(__('Day')) ?></label>
              <select id="class-day" name="day" class="select">
                <?php foreach (range(1, 7) as $n): ?><option value="<?= $n ?>" <?= selected((string) old('day', '1') === (string) $n) ?>><?= e(day_name($n)) ?></option><?php endforeach; ?>
              </select>
            </div>
            <?php if ($ab): ?>
              <div class="field">
                <label class="label label-muted" for="class-week"><?= e(__('Repeats')) ?></label>
                <select id="class-week" name="week" class="select">
                  <option value="every" <?= selected(old('week', 'every') === 'every') ?>><?= e(__('Every week')) ?></option>
                  <option value="A" <?= selected(old('week') === 'A') ?>><?= e(__('Week A only')) ?></option>
                  <option value="B" <?= selected(old('week') === 'B') ?>><?= e(__('Week B only')) ?></option>
                </select>
              </div>
            <?php else: ?>
              <input type="hidden" name="week" value="every">
            <?php endif; ?>
            <div class="field">
              <label class="label label-muted" for="class-start"><?= e(__('Start time')) ?></label>
              <input id="class-start" name="start_time" type="time" class="input input-rect <?= invalid('start_time', 'klass') ?>" value="<?= e(old('start_time', '09:00')) ?>" required>
              <?= field_error('start_time', 'klass') ?>
            </div>
            <div class="field">
              <label class="label label-muted" for="class-end"><?= e(__('End time')) ?></label>
              <input id="class-end" name="end_time" type="time" class="input input-rect <?= invalid('end_time', 'klass') ?>" value="<?= e(old('end_time', '10:00')) ?>" required>
              <?= field_error('end_time', 'klass') ?>
            </div>
            <div class="field">
              <label class="label label-muted" for="class-location"><?= e(__('Location')) ?></label>
              <input id="class-location" name="location" class="input input-rect" maxlength="120" placeholder="<?= e(__('Room, campus, building')) ?>" value="<?= e(old('location')) ?>">
            </div>
            <div class="field">
              <label class="label label-muted" for="class-teacher"><?= e(__('Teacher / tutor')) ?></label>
              <input id="class-teacher" name="teacher" class="input input-rect" maxlength="80" placeholder="<?= e(__('Optional')) ?>" value="<?= e(old('teacher')) ?>">
            </div>
          </div>
          <div class="form-buttons">
            <button type="submit" class="btn btn-primary" data-panel-submit><?= e($classEditing ? __('Save') : __('Add')) ?></button>
            <button type="button" class="btn btn-outline" data-panel-close><?= e(__('Cancel')) ?></button>
          </div>
        </form>
      </div>

      <?php if (! $recurring): ?>
        <div class="empty">
          <div class="empty-title"><?= e(__('No classes added yet')) ?></div>
          <div class="empty-sub"><?= e(__('Add lectures, tutorials, labs, sport, work or other weekly commitments.')) ?></div>
        </div>
      <?php else: ?>
        <div class="rows">
          <?php foreach ($recurring as $c):
            $cVals = ['name' => $c->name ?? '', 'subject_id' => (string) ($c->subject_id ?? ''), 'day' => (string) $c->day, 'start_time' => substr($c->start_time, 0, 5), 'end_time' => substr($c->end_time, 0, 5), 'week' => $c->week, 'location' => $c->location ?? '', 'teacher' => $c->teacher ?? '']; ?>
            <div class="row-item">
              <span class="swatch-dot" style="background: <?= e($c->color) ?>"></span>
              <div class="row-main">
                <div class="row-title"><?= e($c->display_name) ?>
                  <?php if ($ab && $c->week !== 'every'): ?><span class="badge"><?= e(__('Week '.$c->week)) ?></span><?php endif; ?></div>
                <div class="row-meta"><?= e(day_name((int) $c->day).' · '.fmt_time($c->start_time).' – '.fmt_time($c->end_time).($c->location ? ' · '.$c->location : '').($c->teacher ? ' · '.$c->teacher : '')) ?></div>
              </div>
              <div class="row-actions">
                <button type="button" class="icon-action" aria-label="<?= e(__('Edit :name', ['name' => $c->display_name])) ?>" data-open-panel="class-panel"
                        data-action="<?= e(url('/settings/classes/'.$c->id)) ?>" data-method="PUT" data-title="<?= e(__('Edit class')) ?>" data-submit="<?= e(__('Save')) ?>"
                        data-values="<?= e(json_encode($cVals)) ?>">
                  <?= icon('pencil', '', 16) ?>
                </button>
                <form method="POST" action="<?= e(url('/settings/classes/'.$c->id)) ?>"
                      data-confirm="<?= e(__('Delete “:name”?', ['name' => $c->display_name])) ?>" data-confirm-text="<?= e(__('It will no longer appear in your timetable.')) ?>">
                  <?= csrf_field() ?><?= method_field('DELETE') ?>
                  <button type="submit" class="icon-action danger" aria-label="<?= e(__('Delete :name', ['name' => $c->display_name])) ?>"><?= icon('trash', '', 16) ?></button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<template id="period-row-template">
  <div class="period-edit-row" data-period-row>
    <input type="hidden" data-f="id" value="">
    <input class="input input-rect" data-f="name" maxlength="40" aria-label="<?= e(__('Period name')) ?>" required>
    <select class="select" data-f="kind" aria-label="<?= e(__('Period type')) ?>"><option value="class"><?= e(__('Class')) ?></option><option value="break"><?= e(__('Break')) ?></option></select>
    <input class="input input-rect" type="time" data-f="start_time" aria-label="<?= e(__('Start time')) ?>" required>
    <input class="input input-rect" type="time" data-f="end_time" aria-label="<?= e(__('End time')) ?>" required>
    <button type="button" class="icon-action danger" data-remove-period aria-label="<?= e(__('Remove period')) ?>"><?= icon('trash', '', 16) ?></button>
  </div>
</template>
