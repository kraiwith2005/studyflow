<div class="month" role="grid" aria-label="<?= e($heading) ?>">
  <?php foreach ([7, 1, 2, 3, 4, 5, 6] as $iso): ?>
    <div class="month-dow" role="columnheader"><?= e(day_name($iso, true)) ?></div>
  <?php endforeach; ?>
  <?php foreach ($days as $d => $day):
    $c = to_date($d);
    $items = array_merge($day['allDay'], $day['timed']);
    $shown = array_slice($items, 0, 3); ?>
    <div class="mcell <?= $c->format('n') !== $date->format('n') ? 'is-other' : '' ?> <?= $d === $todayStr ? 'is-today' : '' ?>"
         role="gridcell" data-add-date="<?= e($d) ?>">
      <a class="mnum" href="<?= e(cal_url('day', $d)) ?>" aria-label="<?= e(fmt_date($c, 'long')) ?>"><?= $c->format('j') ?></a>
      <?php foreach ($shown as $item) include ROOT.'/views/calendar/chip.php'; ?>
      <?php if (count($items) > 3): ?>
        <a class="more-link" href="<?= e(cal_url('day', $d)) ?>"><?= e(__('+:n more', ['n' => count($items) - 3])) ?></a>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>
