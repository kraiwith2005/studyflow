<?php $todayStr = today()->format('Y-m-d'); ?>
<?php section_start('banner'); include ROOT.'/views/partials/setup_banner.php'; section_end(); ?>

<div class="page page-wide" id="calendar" data-reopen="<?= e(flashed('reopen')) ?>">
  <div class="cal-head">
    <div>
      <h1 class="page-title"><?= e(__('Calendar')) ?></h1>
      <p class="page-sub"><?= e(__('Plan study blocks, assignments, exams, reminders and timetable classes.')) ?></p>
    </div>
    <button type="button" class="btn btn-primary btn-lg" data-add-date="<?= e($view === 'month' && $date->format('Y-m') === today()->format('Y-m') ? $todayStr : $date->format('Y-m-d')) ?>">
      <?= icon('plus') ?> <?= e(__('Add item')) ?>
    </button>
  </div>

  <?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

  <div class="cal">
    <div class="cal-bar">
      <a class="cal-nav" href="<?= e(cal_url($view, $prev)) ?>" aria-label="<?= e(__('Previous')) ?>"><?= icon('back') ?></a>
      <a class="cal-nav" href="<?= e(cal_url($view, $next)) ?>" aria-label="<?= e(__('Next')) ?>"><?= icon('arrow') ?></a>
      <a class="cal-today" href="<?= e(cal_url($view, $todayStr)) ?>"><?= e(__('Today')) ?></a>
      <h2 class="cal-title"><?= e($heading) ?></h2>
      <?php if ($weekLetter && $view !== 'month'): ?><span class="cal-week-letter"><?= e(__('Week '.$weekLetter)) ?></span><?php endif; ?>
      <nav class="seg cal-views" aria-label="<?= e(__('Calendar view')) ?>">
        <?php foreach (['month' => __('Month'), 'week' => __('Week'), 'day' => __('Day')] as $v => $label): ?>
          <a class="seg-btn <?= $view === $v ? 'is-active' : '' ?>" href="<?= e(cal_url($v, $date)) ?>" <?= $view === $v ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
        <?php endforeach; ?>
      </nav>
    </div>

    <?php include ROOT.'/views/calendar/'.($view === 'month' ? 'month' : 'timegrid').'.php'; ?>
  </div>
</div>

<?php include ROOT.'/views/calendar/dialogs.php'; ?>

<?php section_start('scripts'); ?>
<script src="<?= e(asset('js/calendar.js')) ?>"></script>
<?php section_end(); ?>
