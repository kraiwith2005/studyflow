<?php
/* The add / edit / details dialogs used by Today, Calendar and Tasks.
   Needs: $subjects, $linkable, $returnUrl */
$reopen = (string) flashed('reopen', '');
$sessionOpen = str_starts_with($reopen, 'new-session') || str_starts_with($reopen, 'session-');
$sessionEdit = str_starts_with($reopen, 'session-') ? (int) substr($reopen, 8) : null;
$taskOpen = (str_starts_with($reopen, 'new-') && $reopen !== 'new-session') || str_starts_with($reopen, 'task-');
$taskEdit = str_starts_with($reopen, 'task-') ? (int) substr($reopen, 5) : null;
$taskType = old('type', 'assignment');
if (! in_array($taskType, TASK_TYPES, true)) $taskType = 'assignment';
$taskLabels = [
  'assignment' => ['add' => __('Add assignment'), 'edit' => __('Edit assignment'), 'placeholder' => __('Assignment title'), 'date' => __('Due date'), 'time' => __('Due time')],
  'exam' => ['add' => __('Add exam'), 'edit' => __('Edit exam'), 'placeholder' => __('Exam title'), 'date' => __('Exam date'), 'time' => __('Start time')],
  'personal' => ['add' => __('Add personal task'), 'edit' => __('Edit personal task'), 'placeholder' => __('Personal task title'), 'date' => __('Date'), 'time' => __('Time')],
];
$ttLink = __('Timetable classes are added from :link.', ['link' => '<a href="'.e(url('/settings', ['open' => 'timetable'])).'#timetable">'.e(__('Settings').' → '.__('Timetable')).'</a>']);
$subjectsLink = url('/settings', ['open' => 'subjects']).'#subjects';
?>

<dialog class="dlg" id="add-dialog" aria-labelledby="add-title">
  <div class="dlg-head">
    <div>
      <div class="dlg-title" id="add-title" data-add-date-label></div>
      <div class="dlg-date"><?= e(__('Add to calendar')) ?></div>
    </div>
    <button type="button" class="dlg-x" data-dialog-close aria-label="<?= e(__('Close')) ?>"><?= icon('close') ?></button>
  </div>
  <div class="dlg-body">
    <div class="type-list">
      <button type="button" class="type-btn" data-choose="session"><?= e(__('Study session')) ?> <?= icon('plus') ?></button>
      <button type="button" class="type-btn" data-choose="personal"><?= e(__('Personal task')) ?> <?= icon('plus') ?></button>
      <button type="button" class="type-btn" data-choose="assignment"><?= e(__('Assignment')) ?> <?= icon('plus') ?></button>
      <button type="button" class="type-btn" data-choose="exam"><?= e(__('Exam')) ?> <?= icon('plus') ?></button>
    </div>
    <div class="note-box"><?= $ttLink ?></div>
  </div>
</dialog>

<dialog class="dlg dlg-wide" id="session-dialog" <?= $sessionOpen ? 'data-autoshow' : '' ?>>
  <form method="POST" novalidate data-once action="<?= e($sessionEdit ? url('/sessions/'.$sessionEdit) : url('/sessions')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="_method" value="<?= $sessionEdit ? 'PUT' : 'POST' ?>">
    <input type="hidden" name="return" value="<?= e($returnUrl) ?>">
    <input type="hidden" name="mark_done" value="<?= e(old('mark_done')) ?>">
    <div class="dlg-head">
      <div>
        <div class="dlg-title" data-form-title><?= e(old('mark_done') ? __('Log study') : ($sessionEdit ? __('Edit study session') : __('Add study session'))) ?></div>
        <div class="dlg-date" data-form-date></div>
      </div>
      <button type="button" class="dlg-x" data-dialog-close aria-label="<?= e(__('Close')) ?>"><?= icon('close') ?></button>
    </div>
    <div class="dlg-body dlg-scroll">
      <div class="field">
        <label class="label" for="s-title"><?= e(__('Title')) ?><span class="req">*</span></label>
        <input id="s-title" name="title" class="input input-rect <?= invalid('title', 'session') ?>" maxlength="120"
               placeholder="<?= e(__('Study session title')) ?>" value="<?= e(old('title')) ?>" required>
        <?= field_error('title', 'session') ?>
      </div>
      <div class="field">
        <label class="label" for="s-subject"><?= e(__('Subject')) ?><span class="req">*</span></label>
        <select id="s-subject" name="subject_id" class="select <?= invalid('subject_id', 'session') ?>" required>
          <option value=""><?= e(__('Select subject')) ?></option>
          <?php foreach ($subjects as $s): ?><option value="<?= $s->id ?>" <?= selected((string) old('subject_id') === (string) $s->id) ?>><?= e($s->name) ?></option><?php endforeach; ?>
        </select>
        <?= field_error('subject_id', 'session') ?>
        <?php if (! $subjects): ?><span class="field-hint"><a href="<?= e($subjectsLink) ?>"><?= e(__('Add a subject in Settings first.')) ?></a></span><?php endif; ?>
      </div>
      <div class="time-box">
        <div class="time-box-title"><?= e(__('Calendar time')) ?></div>
        <div class="time-box-sub"><?= e(__('This is where the item appears in the hourly calendar.')) ?></div>
        <div class="field">
          <label class="label" for="s-date"><?= e(__('Date')) ?><span class="req">*</span></label>
          <input id="s-date" name="date" type="date" class="input input-rect <?= invalid('date', 'session') ?>" value="<?= e(old('date')) ?>" required>
          <?= field_error('date', 'session') ?>
        </div>
        <div class="grid-2" style="margin-top:16px">
          <div class="field">
            <label class="label" for="s-start"><?= e(__('Start time')) ?><span class="req">*</span></label>
            <input id="s-start" name="start_time" type="time" class="input input-rect <?= invalid('start_time', 'session') ?>" value="<?= e(old('start_time', '16:00')) ?>" required>
            <?= field_error('start_time', 'session') ?>
          </div>
          <div class="field">
            <label class="label" for="s-duration"><?= e(__('Duration')) ?><span class="req">*</span></label>
            <select id="s-duration" name="duration_minutes" class="select" required>
              <?php foreach (DURATIONS as $m): ?><option value="<?= $m ?>" <?= selected((string) old('duration_minutes', '60') === (string) $m) ?>><?= e(duration_label($m)) ?></option><?php endforeach; ?>
            </select>
            <?= field_error('duration_minutes', 'session') ?>
          </div>
        </div>
      </div>
      <div class="field" style="margin-top:18px">
        <label class="label" for="s-task"><?= e(__('Link to assessment')) ?></label>
        <select id="s-task" name="task_id" class="select">
          <option value=""><?= e(__('Not linked')) ?></option>
          <?php foreach ($linkable as $t): ?>
            <option value="<?= $t->id ?>" <?= selected((string) old('task_id') === (string) $t->id) ?>><?= e(task_type_label($t->type).' · '.$t->title.' ('.fmt_date($t->due_date).')') ?></option>
          <?php endforeach; ?>
          <?php if (! $linkable): ?><option value="" disabled><?= e(__('No active assessments')) ?></option><?php endif; ?>
        </select>
        <span class="field-hint"><?= e(__('Optional. Useful when this study block is for a specific assignment or exam.')) ?></span>
      </div>
      <div class="form-buttons">
        <button type="submit" class="btn btn-primary" data-form-submit><?= e($sessionEdit ? __('Save') : __('Add')) ?></button>
        <button type="button" class="btn btn-outline" data-dialog-close><?= e(__('Cancel')) ?></button>
      </div>
    </div>
  </form>
</dialog>

<dialog class="dlg dlg-wide" id="task-dialog" data-labels="<?= e(json_encode($taskLabels, JSON_UNESCAPED_UNICODE)) ?>" <?= $taskOpen ? 'data-autoshow' : '' ?>>
  <form method="POST" novalidate data-once action="<?= e($taskEdit ? url('/tasks/'.$taskEdit) : url('/tasks')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="_method" value="<?= $taskEdit ? 'PUT' : 'POST' ?>">
    <input type="hidden" name="return" value="<?= e($returnUrl) ?>">
    <input type="hidden" name="type" value="<?= e($taskType) ?>">
    <div class="dlg-head">
      <div>
        <div class="dlg-title" data-form-title><?= e($taskLabels[$taskType][$taskEdit ? 'edit' : 'add']) ?></div>
        <div class="dlg-date" data-form-date></div>
      </div>
      <button type="button" class="dlg-x" data-dialog-close aria-label="<?= e(__('Close')) ?>"><?= icon('close') ?></button>
    </div>
    <div class="dlg-body">
      <div class="field">
        <label class="label" for="t-title"><?= e(__('Title')) ?><span class="req">*</span></label>
        <input id="t-title" name="title" class="input input-rect <?= invalid('title', 'task') ?>" maxlength="120"
               placeholder="<?= e($taskLabels[$taskType]['placeholder']) ?>" value="<?= e(old('title')) ?>" required>
        <?= field_error('title', 'task') ?>
      </div>
      <div class="field" data-subject-field <?= $taskType === 'personal' ? 'hidden' : '' ?>>
        <label class="label" for="t-subject"><?= e(__('Subject')) ?><span class="req">*</span></label>
        <select id="t-subject" name="subject_id" class="select <?= invalid('subject_id', 'task') ?>">
          <option value=""><?= e(__('Select subject')) ?></option>
          <?php foreach ($subjects as $s): ?><option value="<?= $s->id ?>" <?= selected((string) old('subject_id') === (string) $s->id) ?>><?= e($s->name) ?></option><?php endforeach; ?>
        </select>
        <?= field_error('subject_id', 'task') ?>
        <?php if (! $subjects): ?><span class="field-hint"><a href="<?= e($subjectsLink) ?>"><?= e(__('Add a subject in Settings first.')) ?></a></span><?php endif; ?>
      </div>
      <div class="field-row">
        <div class="field">
          <label class="label" for="t-date" data-date-label><?= e($taskLabels[$taskType]['date']) ?><span class="req">*</span></label>
          <input id="t-date" name="due_date" type="date" class="input input-rect <?= invalid('due_date', 'task') ?>" value="<?= e(old('due_date')) ?>" required>
          <?= field_error('due_date', 'task') ?>
        </div>
        <div class="field">
          <label class="label" for="t-time" data-time-label><?= e($taskLabels[$taskType]['time']) ?></label>
          <input id="t-time" name="due_time" type="time" class="input input-rect <?= invalid('due_time', 'task') ?>" value="<?= e(old('due_time')) ?>">
          <?= field_error('due_time', 'task') ?>
          <span class="field-hint"><?= e(__('Optional. Leave empty if there is no set time.')) ?></span>
        </div>
      </div>
      <div class="field">
        <span class="label"><?= e(__('Priority')) ?></span>
        <div class="seg seg-field" role="radiogroup" aria-label="<?= e(__('Priority')) ?>">
          <?php foreach (['low' => __('Low'), 'normal' => __('Normal'), 'high' => __('High')] as $p => $plabel): ?>
            <label class="seg-btn seg-radio is-<?= $p ?>">
              <input type="radio" name="priority" value="<?= $p ?>" <?= checked(old('priority', 'normal') === $p) ?>>
              <span><?= e($plabel) ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="field">
        <label class="label" for="t-link"><?= e(__('Link')) ?></label>
        <input id="t-link" name="link" type="url" inputmode="url" class="input input-rect <?= invalid('link', 'task') ?>"
               maxlength="500" placeholder="https://classroom.google.com/…" value="<?= e(old('link')) ?>">
        <?= field_error('link', 'task') ?>
        <span class="field-hint"><?= e(__('Optional. Where the work is handed in or where the brief lives.')) ?></span>
      </div>
      <div class="field">
        <label class="label" for="t-notes"><?= e(__('Notes')) ?></label>
        <textarea id="t-notes" name="notes" class="input input-rect textarea <?= invalid('notes', 'task') ?>"
                  rows="3" maxlength="2000" placeholder="<?= e(__('e.g. submit as PDF, max 10 pages')) ?>"><?= e(old('notes')) ?></textarea>
        <?= field_error('notes', 'task') ?>
      </div>
      <div class="form-buttons">
        <button type="submit" class="btn btn-primary" data-form-submit><?= e($taskEdit ? __('Save') : __('Add')) ?></button>
        <button type="button" class="btn btn-outline" data-dialog-close><?= e(__('Cancel')) ?></button>
      </div>
    </div>
  </form>
</dialog>

<dialog class="dlg" id="detail-dialog" aria-labelledby="detail-title">
  <div class="dlg-head">
    <div style="min-width:0">
      <div class="detail-type"><span class="swatch-dot" data-d="dot"></span><span data-d="typeLabel"></span></div>
      <div class="dlg-title" id="detail-title" data-d="title" style="margin-top:4px"></div>
    </div>
    <button type="button" class="dlg-x" data-dialog-close aria-label="<?= e(__('Close')) ?>"><?= icon('close') ?></button>
  </div>
  <div class="dlg-body">
    <div class="detail-rows">
      <div class="detail-row" data-row="dateLabel"><span class="detail-k"><?= e(__('Date')) ?></span><span class="detail-v" data-d="dateLabel"></span></div>
      <div class="detail-row" data-row="timeLabel"><span class="detail-k"><?= e(__('Time')) ?></span><span class="detail-v" data-d="timeLabel"></span></div>
      <div class="detail-row" data-row="subject"><span class="detail-k"><?= e(__('Subject')) ?></span><span class="detail-v" data-d="subject"></span></div>
      <div class="detail-row" data-row="task"><span class="detail-k"><?= e(__('For')) ?></span><span class="detail-v" data-d="task"></span></div>
      <div class="detail-row" data-row="period"><span class="detail-k"><?= e(__('Period')) ?></span><span class="detail-v" data-d="period"></span></div>
      <div class="detail-row" data-row="location"><span class="detail-k"><?= e(__('Location')) ?></span><span class="detail-v" data-d="location"></span></div>
      <div class="detail-row" data-row="teacher"><span class="detail-k"><?= e(__('Teacher / tutor')) ?></span><span class="detail-v" data-d="teacher"></span></div>
      <div class="detail-row" data-row="status"><span class="detail-k"><?= e(__('Status')) ?></span><span class="detail-v" data-d="status"></span></div>
      <div class="detail-row" data-row="priorityLabel"><span class="detail-k"><?= e(__('Priority')) ?></span><span class="detail-v" data-d="priorityLabel"></span></div>
      <div class="detail-row" data-row="notes"><span class="detail-k"><?= e(__('Notes')) ?></span><span class="detail-v detail-notes" data-d="notes"></span></div>
      <div class="detail-row" data-row="linkRow"><span class="detail-k"><?= e(__('Link')) ?></span><span class="detail-v"><a class="detail-link" data-d-link target="_blank" rel="noopener noreferrer"></a></span></div>
    </div>
    <div class="detail-actions" data-actions>
      <form method="POST" data-toggle-form>
        <?= csrf_field() ?><?= method_field('PATCH') ?>
        <input type="hidden" name="return" value="<?= e($returnUrl) ?>">
        <button type="submit" class="btn btn-primary btn-sm" data-toggle-label></button>
      </form>
      <button type="button" class="btn btn-outline btn-sm" data-edit><?= icon('pencil', '', 15) ?> <?= e(__('Edit')) ?></button>
      <form method="POST" data-delete-form data-confirm="" data-confirm-text="<?= e(__('This can’t be undone.')) ?>">
        <?= csrf_field() ?><?= method_field('DELETE') ?>
        <input type="hidden" name="return" value="<?= e($returnUrl) ?>">
        <button type="submit" class="btn btn-ghost btn-sm link-danger"><?= icon('trash', '', 15) ?> <?= e(__('Delete')) ?></button>
      </form>
    </div>
    <p class="note-box" data-class-note hidden><?= $ttLink ?></p>
  </div>
</dialog>

<dialog class="dlg" id="confirm-dialog">
  <div class="dlg-body">
    <div class="dlg-title" data-confirm-title></div>
    <p class="dlg-text" data-confirm-text></p>
    <div class="form-buttons" style="margin-top:0">
      <button type="button" class="btn btn-danger" data-confirm-ok><?= e(__('Delete')) ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close><?= e(__('Cancel')) ?></button>
    </div>
  </div>
</dialog>

<?php
$calJs = [
  'today' => today()->format('Y-m-d'),
  'titles' => ['addSession' => __('Add study session'), 'editSession' => __('Edit study session'), 'logStudy' => __('Log study')],
  'strings' => [
    'done' => __('Done'), 'notDone' => __('Not done yet'),
    'markDone' => __('Mark as done'), 'markNotDone' => __('Mark as not done'),
    'deleteQ' => __('Delete “:name”?'),
  ],
];
?>
<script>
  window.SF_CAL = <?= json_encode($calJs, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?>;
</script>
