<?php
$hourH = 52;
$cols = count($days);
$toMin = fn ($t) => (int) substr($t, 0, 2) * 60 + (int) substr($t, 3, 2);
$base = $fromHour * 60;
$pxPerMin = $hourH / 60;
?>
<div class="tgrid-scroll">
  <div class="tgrid <?= $view === 'day' ? 'is-day' : '' ?>" style="--cols: <?= $cols ?>; --hour-h: <?= $hourH ?>px"
       data-from-hour="<?= $fromHour ?>" data-hour-h="<?= $hourH ?>">

    <?php if ($view === 'week'): ?>
      <div class="trow">
        <div class="thead-cell"></div>
        <?php foreach ($days as $d => $day): $c = to_date($d); ?>
          <div class="thead-cell <?= $d === $todayStr ? 'is-today' : '' ?>">
            <div class="th-dow"><?= e(day_name((int) $c->format('N'), true)) ?></div>
            <a class="th-num" href="<?= e(cal_url('day', $d)) ?>" aria-label="<?= e(fmt_date($c, 'long')) ?>"><?= $c->format('j') ?></a>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="day-head">
        <span class="th-num" style="<?= $date->format('Y-m-d') === $todayStr ? 'background:var(--primary);color:var(--on-primary)' : '' ?>"><?= $date->format('j') ?></span>
        <div>
          <div class="th-dow"><?= e(day_name((int) $date->format('N'))) ?></div>
          <div style="font-weight:600"><?= e(fmt_date($date, 'month')) ?></div>
        </div>
      </div>
    <?php endif; ?>

    <div class="trow allday-row">
      <div class="allday-label"><?= e(__('ALL DAY')) ?></div>
      <?php foreach ($days as $d => $day): ?>
        <div class="allday-cell" data-add-date="<?= e($d) ?>">
          <?php foreach ($day['allDay'] as $item) include ROOT.'/views/calendar/chip.php'; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="trow tbody">
      <div class="hour-gutter">
        <?php for ($h = $fromHour; $h < $toHour; $h++): ?>
          <div class="hour-label"><?= $h === $fromHour ? '' : e(fmt_time(sprintf('%02d:00', $h))) ?></div>
        <?php endfor; ?>
      </div>
      <?php foreach ($days as $d => $day): ?>
        <div class="tcol <?= $d === $todayStr ? 'is-today' : '' ?>" data-add-date="<?= e($d) ?>" data-timed>
          <?php for ($h = $fromHour; $h < $toHour; $h++): ?><div class="hour-line"></div><?php endfor; ?>
          <?php foreach ($day['timed'] as $item):
            $top = ($toMin($item['start']) - $base) * $pxPerMin;
            $height = max(22, ($toMin($item['end']) - $toMin($item['start'])) * $pxPerMin - 2);
            $w = 100 / $item['lanes']; ?>
            <button type="button" class="ev is-<?= e($item['kind']) ?> <?= $item['done'] ? 'is-done' : '' ?>"
                    style="--c: <?= e($item['color']) ?>; top: <?= $top ?>px; height: <?= $height ?>px; left: calc(<?= $item['lane'] * $w ?>% + 2px); width: calc(<?= $w ?>% - 4px)"
                    data-item="<?= e(item_json($item)) ?>">
              <span class="ev-title"><?= e($item['title']) ?></span>
              <span class="ev-meta"><?= e(fmt_time($item['start']).' – '.fmt_time($item['end']).(! empty($item['location']) ? ' · '.$item['location'] : '')) ?></span>
            </button>
          <?php endforeach; ?>
          <?php if ($d === $todayStr):
            $nowMin = (int) date('G') * 60 + (int) date('i');
            if ($nowMin >= $base && $nowMin <= $toHour * 60): ?>
              <div class="now-line" style="top: <?= ($nowMin - $base) * $pxPerMin ?>px" aria-hidden="true"></div>
          <?php endif; endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
