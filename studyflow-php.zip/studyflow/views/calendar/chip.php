<button type="button" class="chip <?= $item['done'] ? 'is-done' : '' ?> <?= ($item['type'] ?? '') === 'exam' ? 'is-exam' : '' ?>"
        style="--c: <?= e($item['color']) ?>" data-item="<?= e(item_json($item)) ?>">
  <?php if ($item['kind'] === 'session'): ?>
    <span class="chip-time"><?= e(fmt_time($item['start'])) ?></span>
  <?php elseif (! empty($item['due_time'])): ?>
    <span class="chip-time"><?= e(fmt_time($item['due_time'])) ?></span>
  <?php elseif ($item['type'] !== 'personal'): ?>
    <span class="chip-tag"><?= e(['assignment' => __('Assign.'), 'exam' => __('Exam')][$item['type']]) ?></span>
  <?php endif; ?>
  <span class="chip-text"><?= e($item['title']) ?></span>
</button>
