<!DOCTYPE html>
<html lang="<?= locale() ?>">
<head>
  <?php include ROOT.'/views/partials/head.php'; ?>
</head>
<body>
  <div class="auth-page">
    <aside class="auth-brand" aria-label="StudyFlow">
      <?php include ROOT.'/views/partials/brand.php'; ?>
      <div class="auth-hero">
        <p class="auth-hero-title"><?= e(__('Your schoolwork, in one flow')) ?></p>
        <ul class="auth-points">
          <li><?= e(__('All your subjects’ work in one place')) ?></li>
          <li><?= e(__('Colour-coded deadlines so nothing slips')) ?></li>
          <li><?= e(__('Study timer')) ?></li>
        </ul>
      </div>
    </aside>

    <div class="auth-side">
      <header class="auth-top"><?php include ROOT.'/views/partials/lang_switch.php'; ?></header>
      <main class="auth-main">
        <div class="auth-card">
          <?= $content ?>
        </div>
      </main>
    </div>
  </div>
  <script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
