<?php $user = current_user(); ?>
<!DOCTYPE html>
<html lang="<?= locale() ?>" <?= $user->theme ? 'data-theme="'.e($user->theme).'"' : '' ?>>
<head>
  <?php include ROOT.'/views/partials/head.php'; ?>
</head>
<body>
  <header class="app-header">
    <div class="app-header-inner">
      <?php include ROOT.'/views/partials/brand.php'; ?>

      <nav class="app-nav" aria-label="<?= e(__('Main')) ?>">
        <?php foreach (['/today' => __('Today'), '/calendar' => __('Calendar'), '/tasks' => __('Tasks'), '/study' => __('Study'), '/settings' => __('Settings')] as $path => $label): ?>
          <a href="<?= e(url($path)) ?>" class="nav-link <?= is_page($path) ? 'is-active' : '' ?>"
             <?= is_page($path) ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
        <?php endforeach; ?>
      </nav>

      <div class="header-tools">
        <?php $activeTimer = is_page('/study') ? null : timer_of((int) $user->id); ?>
        <?php if ($activeTimer): ?>
          <a href="<?= e(url('/study')) ?>" class="timer-pill is-<?= e($activeTimer->status) ?>" data-timer-pill
             data-accum="<?= (int) $activeTimer->accumulated_seconds ?>" data-started="<?= e(ms($activeTimer->started_at)) ?>"
             data-server-now="<?= time() * 1000 ?>" data-status="<?= e($activeTimer->status) ?>"
             title="<?= e($activeTimer->label) ?>" aria-label="<?= e(__('Study timer: :label', ['label' => $activeTimer->label])) ?>">
            <span class="timer-pill-dot" aria-hidden="true"></span><span data-pill-time><?= gmdate('H:i:s', timer_elapsed($activeTimer)) ?></span>
          </a>
        <?php endif; ?>
        <?php include ROOT.'/views/partials/lang_switch.php'; ?>
        <span id="save-status" class="save-status" data-state="saved" role="status" aria-live="polite"><?= e(__('Saved')) ?></span>

        <button type="button" id="theme-toggle" class="icon-btn" data-url="<?= e(url('/preferences/theme')) ?>"
                aria-label="<?= e($user->theme === 'dark' ? __('Switch to light mode') : __('Switch to dark mode')) ?>">
          <?= icon('moon', 'theme-icon-moon') ?>
          <?= icon('sun', 'theme-icon-sun') ?>
        </button>

        <div class="menu-wrap">
          <button type="button" id="avatar-btn" class="avatar" style="background: <?= e($user->avatar_color) ?>"
                  aria-haspopup="menu" aria-expanded="false" aria-controls="avatar-menu"
                  aria-label="<?= e(__('Account menu for :name', ['name' => $user->full_name])) ?>"><?= e($user->initial) ?></button>
          <div id="avatar-menu" class="menu" role="menu">
            <div class="menu-head">
              <span class="avatar avatar-lg" style="background: <?= e($user->avatar_color) ?>" aria-hidden="true"><?= e($user->initial) ?></span>
              <div>
                <div class="menu-name"><?= e($user->full_name) ?></div>
                <div class="menu-email"><?= e($user->email) ?></div>
              </div>
            </div>
            <a href="<?= e(url('/account')) ?>" class="menu-item" role="menuitem"><?= icon('gear') ?> <?= e(__('Manage account')) ?></a>
            <a href="<?= e(url('/today', ['tour' => 1])) ?>" class="menu-item" role="menuitem" data-replay-tour><?= icon('calendar') ?> <?= e(__('Show the tour again')) ?></a>
            <form method="POST" action="<?= e(url('/sign-out')) ?>">
              <?= csrf_field() ?>
              <button type="submit" class="menu-item" role="menuitem"><?= icon('signout') ?> <?= e(__('Sign out')) ?></button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </header>

  <?= section('banner') ?>

  <main class="app-main">
    <?= $content ?>
  </main>

  <script>window.SF_I18N = <?= js(js_strings()) ?>;</script>
  <script src="<?= e(asset('js/app.js')) ?>"></script>
  <?= section('scripts') ?>
  <?php if (is_page('/today') && (! $user->tour_completed_at || query_bool('tour'))): ?>
    <?php
      $tour = [
        'doneUrl' => url('/tour/done'),
        'labels' => ['next' => __('Next'), 'back' => __('Back'), 'skip' => __('Skip tour'), 'finish' => __('Start using StudyFlow'), 'step' => __('Step :n of :total')],
        'steps' => [
          ['target' => null, 'title' => __('Welcome to StudyFlow'), 'text' => __('All your schoolwork in one place. This quick tour shows where everything is. It takes under a minute.')],
          ['target' => '.app-nav a[href$="/today"]', 'title' => __('Today'), 'text' => __('Open StudyFlow to see today’s classes, what’s due and your study plan at a glance.')],
          ['target' => '.app-nav a[href$="/calendar"]', 'title' => __('Calendar'), 'text' => __('Every deadline, exam and class by month, week or day. Tap a day to add something to it.')],
          ['target' => '.app-nav a[href$="/tasks"]', 'title' => __('Tasks'), 'text' => __('All your work in one list, sorted by due date. Search, mark priority and tick things off.')],
          ['target' => '.app-nav a[href$="/study"]', 'title' => __('Study'), 'text' => __('Time your study sessions and see how much you studied this week.')],
          ['target' => '.app-nav a[href$="/settings"]', 'title' => __('Start here: Settings'), 'text' => __('Add your subjects, term dates and timetable first. Everything else uses them.')],
          ['target' => '#today-page [data-add-date]', 'title' => __('Add your first item'), 'text' => __('Add an assignment, exam, personal task or study block. Only the title, subject and date are required.')],
        ],
      ];
    ?>
    <script>window.SF_TOUR = <?= js($tour) ?>;</script>
    <script src="<?= e(asset('js/tour.js')) ?>"></script>
  <?php endif; ?>
</body>
</html>
