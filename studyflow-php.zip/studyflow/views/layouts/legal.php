<?php $u = current_user(); ?>
<!DOCTYPE html>
<html lang="<?= locale() ?>" <?= ($u && $u->theme) ? 'data-theme="'.e($u->theme).'"' : '' ?>>
<head>
  <?php include ROOT.'/views/partials/head.php'; ?>
</head>
<body>
  <div class="auth-page">
    <header class="auth-top"><?php include ROOT.'/views/partials/brand.php'; ?><?php include ROOT.'/views/partials/lang_switch.php'; ?></header>
    <main class="auth-main">
      <article class="auth-card legal-card legal">
        <h1 class="auth-title"><?= e($title) ?></h1>
        <p class="auth-sub" style="margin-bottom:8px"><?= e(__('Last updated :date', ['date' => fmt_date($updated)])) ?></p>
        <?= $content ?>
        <p class="auth-switch" style="text-align:left;margin-top:30px">
          <a href="<?= e($u ? url('/settings').'#support' : url('/sign-in')) ?>">← <?= e(__('Back to StudyFlow')) ?></a>
        </p>
      </article>
    </main>
  </div>
</body>
</html>
