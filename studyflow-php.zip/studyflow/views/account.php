<div class="page page-narrow">
  <div class="page-head">
    <div>
      <h1 class="page-title"><?= e(__('Manage account')) ?></h1>
      <p class="page-sub"><?= e(__('Update your name, email and password.')) ?></p>
    </div>
  </div>

  <?php if (flashed('status')): ?><div class="alert alert-success" role="status"><?= e(flashed('status')) ?></div><?php endif; ?>

  <section class="card">
    <h2 class="card-title"><?= e(__('Profile')) ?></h2>
    <p class="card-sub"><?= e(__('Your name appears in the account menu.')) ?></p>
    <form method="POST" action="<?= e(url('/account/profile')) ?>" novalidate data-once>
      <?= csrf_field() ?><?= method_field('PUT') ?>
      <div class="field-row">
        <div class="field">
          <label class="label" for="first_name"><?= e(__('First name')) ?></label>
          <input id="first_name" name="first_name" class="input <?= invalid('first_name') ?>"
                 value="<?= e(old('first_name', $user->first_name)) ?>" autocomplete="given-name" required>
          <?= field_error('first_name') ?>
        </div>
        <div class="field">
          <label class="label" for="last_name"><?= e(__('Last name')) ?></label>
          <input id="last_name" name="last_name" class="input <?= invalid('last_name') ?>"
                 value="<?= e(old('last_name', $user->last_name)) ?>" autocomplete="family-name" required>
          <?= field_error('last_name') ?>
        </div>
      </div>
      <div class="field">
        <label class="label" for="email"><?= e(__('Email address')) ?></label>
        <input id="email" name="email" type="email" class="input <?= invalid('email') ?>"
               value="<?= e(old('email', $user->email)) ?>" autocomplete="email" required>
        <?= field_error('email') ?>
      </div>
      <div class="form-actions"><button type="submit" class="btn btn-primary"><?= e(__('Save profile')) ?></button></div>
    </form>
  </section>

  <section class="card">
    <h2 class="card-title"><?= e($user->has_password ? __('Change password') : __('Set a password')) ?></h2>
    <p class="card-sub">
      <?= e($user->has_password ? __('Enter your current password, then choose a new one.') : __('You signed up with Google. Add a password to also sign in with your email.')) ?>
    </p>
    <form method="POST" action="<?= e(url('/account/password')) ?>" novalidate data-once>
      <?= csrf_field() ?><?= method_field('PUT') ?>
      <?php if ($user->has_password): ?>
        <?= view('partials/password_field', ['id' => 'current_password', 'name' => 'current_password', 'bag' => 'password',
          'label' => __('Current password'), 'placeholder' => __('Current password'), 'autocomplete' => 'current-password']) ?>
      <?php endif; ?>
      <?= view('partials/password_field', ['id' => 'new_password', 'name' => 'password', 'bag' => 'password',
        'label' => __('New password'), 'placeholder' => __('At least 8 characters'), 'autocomplete' => 'new-password']) ?>
      <?= view('partials/password_field', ['id' => 'password_confirmation', 'name' => 'password_confirmation', 'bag' => 'password',
        'label' => __('Confirm new password'), 'placeholder' => __('Type it again'), 'autocomplete' => 'new-password']) ?>
      <div class="form-actions"><button type="submit" class="btn btn-primary"><?= e(__('Update password')) ?></button></div>
    </form>
  </section>
</div>
