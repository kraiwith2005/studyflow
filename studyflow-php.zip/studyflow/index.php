<?php
/*
 * StudyFlow — every request comes here (see .htaccess) and is sent to the
 * matching action below. Pages are in actions/, HTML templates in views/.
 */

require __DIR__.'/includes/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'];
// HTML forms can only send GET or POST; a hidden _method field turns a POST into PUT / PATCH / DELETE.
if ($method === 'POST' && isset($_POST['_method'])) {
    $method = strtoupper((string) $_POST['_method']);
}
if (! in_array($method, ['GET', 'HEAD'], true)) {
    check_csrf();
}
if ($method === 'HEAD') $method = 'GET';

/*
 * [HTTP method, path, file in actions/, function, who may open it]
 *   guest = only when signed out · auth = only when signed in · any = everyone
 *   {id} matches a number and is passed to the function.
 */
$routes = [
    ['GET', '/', 'home.php', 'home', 'any'],
    ['POST', '/locale/{locale}', 'home.php', 'change_locale', 'any'],
    ['GET', '/privacy', 'home.php', 'legal_privacy', 'any'],
    ['GET', '/terms', 'home.php', 'legal_terms', 'any'],
    ['GET', '/cookies', 'home.php', 'legal_cookies', 'any'],

    ['GET', '/sign-up', 'auth.php', 'sign_up_form', 'guest'],
    ['POST', '/sign-up', 'auth.php', 'sign_up', 'guest'],
    ['GET', '/sign-in', 'auth.php', 'sign_in_form', 'guest'],
    ['POST', '/sign-in', 'auth.php', 'sign_in', 'guest'],
    ['GET', '/forgot-password', 'auth.php', 'forgot_form', 'guest'],
    ['POST', '/forgot-password', 'auth.php', 'forgot_send', 'guest'],
    ['GET', '/reset-password/{token}', 'auth.php', 'reset_form', 'guest'],
    ['POST', '/reset-password', 'auth.php', 'reset_save', 'guest'],
    ['POST', '/sign-out', 'auth.php', 'sign_out', 'auth'],

    ['GET', '/today', 'today.php', 'today_page', 'auth'],
    ['POST', '/tour/done', 'today.php', 'tour_done', 'auth'],
    ['GET', '/calendar', 'calendar.php', 'calendar_page', 'auth'],

    ['GET', '/tasks', 'tasks.php', 'tasks_page', 'auth'],
    ['POST', '/tasks', 'tasks.php', 'task_store', 'auth'],
    ['PUT', '/tasks/{id}', 'tasks.php', 'task_update', 'auth'],
    ['DELETE', '/tasks/{id}', 'tasks.php', 'task_destroy', 'auth'],
    ['PATCH', '/tasks/{id}/toggle', 'tasks.php', 'task_toggle', 'auth'],

    ['POST', '/sessions', 'sessions.php', 'study_session_store', 'auth'],
    ['PUT', '/sessions/{id}', 'sessions.php', 'study_session_update', 'auth'],
    ['DELETE', '/sessions/{id}', 'sessions.php', 'study_session_destroy', 'auth'],
    ['PATCH', '/sessions/{id}/toggle', 'sessions.php', 'study_session_toggle', 'auth'],

    ['GET', '/study', 'study.php', 'study_page', 'auth'],
    ['POST', '/study/timer', 'study.php', 'timer_start', 'auth'],
    ['POST', '/study/timer/pause', 'study.php', 'timer_pause', 'auth'],
    ['POST', '/study/timer/resume', 'study.php', 'timer_resume', 'auth'],
    ['POST', '/study/timer/stop', 'study.php', 'timer_stop', 'auth'],
    ['DELETE', '/study/timer', 'study.php', 'timer_discard', 'auth'],

    ['GET', '/settings', 'settings.php', 'settings_page', 'auth'],
    ['POST', '/settings/subjects', 'settings.php', 'subject_store', 'auth'],
    ['PUT', '/settings/subjects/{id}', 'settings.php', 'subject_update', 'auth'],
    ['DELETE', '/settings/subjects/{id}', 'settings.php', 'subject_destroy', 'auth'],
    ['POST', '/settings/terms', 'settings.php', 'term_store', 'auth'],
    ['PUT', '/settings/terms/{id}', 'settings.php', 'term_update', 'auth'],
    ['DELETE', '/settings/terms/{id}', 'settings.php', 'term_destroy', 'auth'],
    ['PUT', '/settings/timetable', 'timetable.php', 'timetable_settings', 'auth'],
    ['PUT', '/settings/timetable/periods', 'timetable.php', 'timetable_periods', 'auth'],
    ['PUT', '/settings/timetable/slot', 'timetable.php', 'timetable_slot', 'auth'],
    ['DELETE', '/settings/timetable/grid', 'timetable.php', 'timetable_clear', 'auth'],
    ['POST', '/settings/classes', 'timetable.php', 'class_store', 'auth'],
    ['PUT', '/settings/classes/{id}', 'timetable.php', 'class_update', 'auth'],
    ['DELETE', '/settings/classes/{id}', 'timetable.php', 'class_destroy', 'auth'],
    ['GET', '/settings/backup/export', 'backup.php', 'backup_export', 'auth'],
    ['POST', '/settings/backup/import', 'backup.php', 'backup_import', 'auth'],
    ['DELETE', '/settings/backup/clear', 'backup.php', 'backup_clear', 'auth'],

    ['GET', '/account', 'account.php', 'account_page', 'auth'],
    ['PUT', '/account/profile', 'account.php', 'account_profile', 'auth'],
    ['PUT', '/account/password', 'account.php', 'account_password', 'auth'],
    ['DELETE', '/account', 'account.php', 'account_delete', 'auth'],
    ['POST', '/preferences/theme', 'account.php', 'save_theme', 'auth'],
];

$path = current_path();
$pathMatched = false;
foreach ($routes as [$verb, $pattern, $file, $function, $who]) {
    $regex = '#^'.preg_replace(['#\{id\}#', '#\{[a-z]+\}#'], ['(\d+)', '([^/]+)'], $pattern).'$#';
    if (! preg_match($regex, $path, $m)) continue;
    $pathMatched = true;
    if ($verb !== $method) continue;

    if ($who === 'auth') require_login();
    if ($who === 'guest') require_guest();

    require_once __DIR__.'/actions/'.$file;
    $function(...array_slice($m, 1));
    exit;
}
abort($pathMatched ? 405 : 404);
