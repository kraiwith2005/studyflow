<?php
/*
 * StudyFlow configuration.
 * Copy this file to config.php and fill in your own values.
 * (config.php is not shared on GitHub because it holds the database password.)
 */
return [
    // Database (XAMPP default: user "root", empty password)
    'db_host' => '127.0.0.1',
    'db_name' => 'studyflow',
    'db_user' => 'root',
    'db_pass' => '',

    // true while developing on your own computer: shows PHP errors on the page.
    // Keep false on the public website.
    'debug' => false,

    // Support email shown in Settings > Help
    'support_email' => 'mystudyplanner.studio@gmail.com',

    // Password reset links:
    //   'log'  = write the link to storage/logs/password-reset.log (no email is sent)
    //   'mail' = send it with PHP mail()
    'reset_mode' => 'log',
    'mail_from' => 'no-reply@example.com',
];
