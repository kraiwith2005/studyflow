<?php
// cookies.php : นโยบายคุกกี้
require 'includes/start.php';
$title = 'คุกกี้';
$updated = '2026-11-25';
include 'includes/legal_header.php';
?>
<p>StudyFlow ใช้เฉพาะคุกกี้ที่จำเป็นต่อการทำงาน ไม่มีคุกกี้โฆษณาหรือคุกกี้ติดตามพฤติกรรม</p>
<h2>คุกกี้ที่เราใช้</h2>
<ul>
  <li><strong>studyflow_session</strong> ทำให้คุณอยู่ในระบบระหว่างใช้งาน (จำไว้ 30 วันจนกว่าจะออกจากระบบ)</li>
</ul>
<p>คุกกี้นี้จำเป็นต่อการทำงาน จึงไม่สามารถปิดได้โดยไม่ทำให้ StudyFlow หยุดทำงาน</p>
<?php include 'includes/legal_footer.php'; ?>
