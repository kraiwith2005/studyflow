<?php
// =====================================================================
//  account-delete.php : ลบบัญชี (ต้องกรอกรหัสผ่านยืนยัน)
//  ข้อมูลทุกอย่างของผู้ใช้ถูกลบตามไปด้วย เพราะฐานข้อมูลตั้งไว้ ON DELETE CASCADE
// =====================================================================
require 'includes/start.php';
require_post();
$user = current_user();
$password = $_POST['password'] ?? '';

$errors = [];
if ($password == '') {
    $errors['password'] = 'กรุณากรอกรหัสผ่าน';
} elseif (! password_verify($password, (string) $user['password'])) {
    $errors['password'] = 'รหัสผ่านไม่ถูกต้อง';
}
if (count($errors) > 0) {
    set_errors('delete', $errors);
    redirect('settings');
}

logout_user();
db_run('DELETE FROM users WHERE id = ?', [$user['id']]);
set_message('ลบบัญชีและข้อมูลทั้งหมดแล้ว');
redirect('sign-in');
