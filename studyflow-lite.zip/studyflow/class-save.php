<?php
// =====================================================================
//  class-save.php : บันทึกคาบเรียนในตารางเรียน (เพิ่มใหม่ หรือ แก้ไขเมื่อมี ?id=)
// =====================================================================
require 'includes/start.php';
require_post();
$userId = user_id();

$class = null;
if (get('id') != '') {
    $class = find_class($userId, get('id'));
    if ($class == null) {
        redirect('settings');
    }
}

// 1) รับค่า
$subjectId = post('subject_id');
$name = post('name');
$day = (int) post('day');
$startTime = post('start_time');
$endTime = post('end_time');
$location = post('location');
$teacher = post('teacher');

// 2) ตรวจข้อมูล
$errors = [];
if ($subjectId != '' && find_subject($userId, $subjectId) == null) {
    $errors['subject_id'] = 'ไม่พบวิชานี้';
}
if ($subjectId == '' && $name == '') {
    $errors['name'] = 'เลือกวิชา หรือพิมพ์ชื่อคาบ';   // ต้องมีอย่างใดอย่างหนึ่ง
} elseif (mb_strlen($name) > 80) {
    $errors['name'] = 'ชื่อคาบยาวเกิน 80 ตัวอักษร';
}
if ($day < 1 || $day > 7) {
    $day = 1;
}
if (! is_time($startTime)) {
    $errors['start_time'] = 'กรุณาเลือกเวลาเริ่ม';
}
if (! is_time($endTime)) {
    $errors['end_time'] = 'กรุณาเลือกเวลาเลิก';
} elseif (is_time($startTime) && $endTime <= $startTime) {
    $errors['end_time'] = 'เวลาเลิกต้องหลังเวลาเริ่ม';
}

if (count($errors) > 0) {
    set_errors('class', $errors, $class != null ? 'class-' . $class['id'] : 'class-new');
    redirect('settings', [], 'timetable');
}

// 3) ช่องที่เว้นว่าง เก็บเป็น NULL
if ($subjectId == '') {
    $subjectId = null;
}
if ($name == '') {
    $name = null;
}
if ($location == '') {
    $location = null;
}
if ($teacher == '') {
    $teacher = null;
}

// 4) บันทึก
if ($class == null) {
    db_run('INSERT INTO recurring_classes (user_id, subject_id, name, day, start_time, end_time, location, teacher, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [$userId, $subjectId, $name, $day, $startTime, $endTime, $location, $teacher, now(), now()]);
    set_message('เพิ่มคาบเรียนแล้ว');
} else {
    db_run('UPDATE recurring_classes SET subject_id = ?, name = ?, day = ?, start_time = ?, end_time = ?, location = ?, teacher = ?, updated_at = ?
            WHERE id = ? AND user_id = ?',
        [$subjectId, $name, $day, $startTime, $endTime, $location, $teacher, now(), $class['id'], $userId]);
    set_message('บันทึกคาบเรียนแล้ว');
}
redirect('settings', [], 'timetable');
