<?php
// =====================================================================
//  tasks.php : หน้ารายการงาน  (ค้นหา / ตัวกรอง / แสดงที่เสร็จแล้ว)
//    ?q=คำค้น   ?filter=school|personal   ?completed=1
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();

// ---------- 1) อ่านตัวกรองจาก URL ----------
$search = get('q');
$filter = get('filter');                 // school = เฉพาะงานเรียน, personal = เฉพาะงานส่วนตัว
if ($filter != 'school' && $filter != 'personal') {
    $filter = 'all';
}
$showCompleted = get('completed') == '1';

// ---------- 2) สร้างเงื่อนไข SQL ทีละข้อ ----------
$conditions = [];
$params = [];
if ($filter == 'school') {
    $conditions[] = "t.type <> 'personal'";
}
if ($filter == 'personal') {
    $conditions[] = "t.type = 'personal'";
}
if (! $showCompleted) {
    $conditions[] = 't.completed_at IS NULL';
}
if ($search != '') {
    // ค้นจาก ชื่องาน / บันทึกย่อ / ชื่อวิชา   (ใส่ \ หน้า % และ _ เพื่อให้ค้นตัวอักษรนั้นตรง ๆ)
    $like = '%' . addcslashes($search, '\\%_') . '%';
    $conditions[] = '(t.title LIKE ? OR t.notes LIKE ? OR s.name LIKE ?)';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

// งานที่ยังไม่เสร็จขึ้นก่อน -> วันส่ง -> เวลาส่ง
$tasks = get_tasks($userId, implode(' AND ', $conditions), $params,
    "t.completed_at IS NOT NULL, t.due_date, t.due_time IS NULL, t.due_time, t.title");

// ---------- 3) แยกงานตามประเภท ----------
$groups = ['assignment' => [], 'exam' => [], 'personal' => []];
foreach ($tasks as $task) {
    $groups[$task->type][] = $task;
}
$groupNames = [
    'assignment' => ['งานที่มอบหมาย', 'ยังไม่มีงานที่มอบหมาย'],
    'exam' => ['การสอบ', 'ยังไม่มีการสอบ'],
    'personal' => ['งานส่วนตัว', 'ยังไม่มีงานส่วนตัว'],
];

// ลิงก์ของหน้านี้ โดยเปลี่ยนตัวกรองบางตัว  เช่น tasks_link(['completed' => 1])
function tasks_link($change)
{
    global $search, $filter, $showCompleted;
    $query = [
        'filter' => $filter == 'all' ? null : $filter,
        'completed' => $showCompleted ? 1 : null,
        'q' => $search,
    ];
    foreach ($change as $key => $value) {
        $query[$key] = $value;
    }
    return url('tasks', $query);
}

// แสดงงาน 1 แถว
function show_task_row($task)
{
    $badge = $task->dueBadge();
    $details = [];   // รายละเอียดการเตรียมตัว เช่น "วางแผนอ่านไว้ 2 ครั้ง"
    if ($task->plannedSessions > 0) {
        $details[] = 'วางแผนอ่านไว้ ' . $task->plannedSessions . ' ครั้ง';
    }
    if ($task->doneMinutes > 0) {
        $details[] = 'อ่านแล้ว ' . duration_text($task->doneMinutes);
    }
    $canPlan = $task->type != 'personal' && ! $task->isDone();
    ?>
    <div class="task-row <?= $task->isDone() ? 'is-done' : '' ?>" style="--c: <?= e($task->color) ?>">
      <form method="POST" action="<?= e(url('task-toggle', ['id' => $task->id])) ?>" class="task-check-form">
        <?= csrf_field() ?>
        <input type="hidden" name="return" value="<?= e(current_page()) ?>">
        <button type="submit" class="task-check" aria-pressed="<?= $task->isDone() ? 'true' : 'false' ?>"
                aria-label="ทำเครื่องหมายว่า “<?= e($task->title) ?>” <?= $task->isDone() ? 'ยังไม่เสร็จ' : 'เสร็จแล้ว' ?>">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
        </button>
      </form>
      <button type="button" class="task-main" data-item="<?= e(item_json($task->toArray())) ?>">
        <span class="task-title">
          <?= e($task->title) ?>
          <?php if ($task->notes != ''): ?><span class="task-icon" title="บันทึกย่อ" aria-label="บันทึกย่อ">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h10"/></svg></span><?php endif; ?>
          <?php if ($task->link != ''): ?><span class="task-icon" title="ลิงก์" aria-label="ลิงก์">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg></span><?php endif; ?>
        </span>
        <span class="task-meta">
          <?php if ($task->subjectName != null): ?><span class="swatch-dot" style="background: <?= e($task->color) ?>"></span><?= e($task->subjectName) ?> · <?php endif; ?>
          <?= thai_date($task->dueDate) ?><?php if ($task->dueTime != ''): ?> เวลา <?= $task->dueTime ?><?php endif; ?>
          <?php if (count($details) > 0): ?> · <?= implode(' · ', $details) ?><?php endif; ?>
        </span>
      </button>
      <span class="due-badge tone-<?= $badge[1] ?>"><?= $badge[0] ?></span>
      <?php if ($canPlan): ?>
        <button type="button" class="btn btn-outline btn-sm task-plan" data-plan-task="<?= $task->id ?>" data-plan-subject="<?= e($task->subjectId) ?>"
                data-plan-title="เตรียม <?= e($task->title) ?>">วางแผนอ่าน</button>
      <?php endif; ?>
    </div>
    <?php
}

// แสดงกลุ่มงาน 1 ประเภท (หัวกลุ่ม + ทุกแถว)
function show_group($type, $tasks, $names)
{
    ?>
    <div class="tgroup <?= $type == 'personal' ? 'is-personal' : '' ?> <?= $type == 'exam' ? 'is-exam' : '' ?>" data-group="<?= $type ?>">
      <div class="tgroup-head">
        <button type="button" class="tgroup-toggle" aria-expanded="true" aria-controls="group-<?= $type ?>" aria-label="แสดงหรือซ่อน <?= $names[0] ?>">
          <?= icon('chevron', '', 18) ?>
        </button>
        <div class="tgroup-text">
          <div class="tgroup-name"><?= $names[0] ?></div>
          <div class="tgroup-count"><?= count($tasks) ?> รายการ</div>
        </div>
        <button type="button" class="btn btn-primary" data-add-type="<?= $type ?>"><?= icon('plus') ?> เพิ่ม</button>
      </div>
      <div class="tgroup-body" id="group-<?= $type ?>">
        <?php foreach ($tasks as $task): ?>
          <?php show_task_row($task); ?>
        <?php endforeach; ?>
        <?php if (count($tasks) == 0): ?>
          <div class="empty">
            <div class="empty-title"><?= $names[1] ?></div>
            <div class="empty-sub">กด “เพิ่ม” เพื่อสร้างรายการ</div>
          </div>
        <?php endif; ?>
      </div>
    </div>
    <?php
}

// ข้อมูลสำหรับกล่องเพิ่ม/แก้ไข
$subjects = get_subjects($userId);
$assessments = open_assessments($userId);
$filterOpen = $filter != 'all';

$title = 'งาน';
$page = 'tasks';
$scripts = ['js/calendar.js', 'js/tasks.js'];
include 'includes/header.php';
?>
<div class="page" id="tasks-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">งาน</h1>
      <p class="page-sub">บันทึกงานเรียนครั้งเดียว แล้วติดตามแต่ละงานตั้งแต่เตรียมตัวจนถึงวันส่ง</p>
    </div>
  </div>

  <?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

  <div class="task-tools">
    <?php // ช่องค้นหา (ส่งแบบ GET : คำค้นจะอยู่ใน URL) ?>
    <form method="GET" action="<?= e(url('tasks')) ?>" class="task-search" role="search">
      <?php if ($filter != 'all'): ?><input type="hidden" name="filter" value="<?= e($filter) ?>"><?php endif; ?>
      <?php if ($showCompleted): ?><input type="hidden" name="completed" value="1"><?php endif; ?>
      <label class="sr-only" for="task-search">ค้นหางาน</label>
      <svg class="task-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      <input id="task-search" type="search" name="q" value="<?= e($search) ?>" class="input input-rect task-search-input" placeholder="ค้นหางาน" maxlength="80">
      <?php if ($search != ''): ?><a class="task-search-clear" href="<?= e(tasks_link(['q' => null])) ?>" aria-label="ล้างคำค้นหา">&times;</a><?php endif; ?>
    </form>
    <button type="button" class="pill-btn <?= $filterOpen ? 'is-on' : '' ?>" data-toggle-filter aria-expanded="<?= $filterOpen ? 'true' : 'false' ?>" aria-controls="filter-bar">ตัวกรอง</button>
    <a class="pill-btn <?= $showCompleted ? 'is-on' : '' ?>" href="<?= e(tasks_link(['completed' => $showCompleted ? null : 1])) ?>" aria-pressed="<?= $showCompleted ? 'true' : 'false' ?>">
      <?= $showCompleted ? 'ซ่อนที่เสร็จแล้ว' : 'แสดงที่เสร็จแล้ว' ?>
    </a>
  </div>

  <div class="filter-bar" id="filter-bar" <?= $filterOpen ? '' : 'hidden' ?>>
    <nav class="seg" aria-label="ตัวกรอง">
      <?php foreach (['all' => 'ทั้งหมด', 'school' => 'เรียน', 'personal' => 'ส่วนตัว'] as $key => $label): ?>
        <a class="seg-btn <?= $filter == $key ? 'is-active' : '' ?>" href="<?= e(tasks_link(['filter' => $key == 'all' ? null : $key])) ?>" <?= $filter == $key ? 'aria-current="true"' : '' ?>><?= $label ?></a>
      <?php endforeach; ?>
    </nav>
  </div>

  <p class="task-count">
    แสดง <?= count($tasks) ?> งาน
    <?php if ($search != ''): ?> · ที่ตรงกับ “<?= e($search) ?>”<?php endif; ?>
  </p>
  <?php if (count($tasks) == 0 && $search != ''): ?>
    <div class="empty">ไม่พบงานที่ตรงกัน ลองคำอื่นหรือล้างตัวกรอง
      <a href="<?= e(url('tasks')) ?>">ล้างทั้งหมด</a>
    </div>
  <?php endif; ?>

  <section class="task-section" aria-labelledby="sec-assess" <?= $filter == 'personal' ? 'hidden' : '' ?>>
    <h2 class="eyebrow" id="sec-assess">งานประเมินผล</h2>
    <p class="section-sub">งานที่มอบหมายและการสอบ ติดตามได้ตั้งแต่เตรียมตัวจนถึงวันกำหนด วางแผนช่วงอ่านหนังสือให้แต่ละรายการได้</p>
    <?php show_group('assignment', $groups['assignment'], $groupNames['assignment']); ?>
    <?php show_group('exam', $groups['exam'], $groupNames['exam']); ?>
  </section>

  <section class="task-section" aria-labelledby="sec-other">
    <h2 class="eyebrow" id="sec-other">งานอื่น ๆ</h2>
    <p class="section-sub">งานส่วนตัว จัดการง่าย ทำเสร็จก็ติ๊กออกได้ทันที</p>
    <?php if ($filter != 'school'): ?>
      <?php show_group('personal', $groups['personal'], $groupNames['personal']); ?>
    <?php endif; ?>
  </section>
</div>

<?php include 'includes/dialogs.php'; ?>
<?php include 'includes/footer.php'; ?>
