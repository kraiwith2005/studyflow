<?php
// session-delete.php : ลบการอ่านหนังสือ
require 'includes/start.php';
require_post();

$session = find_session(user_id(), get('id'));
if ($session == null) {
    redirect('study');
}

db_run('DELETE FROM study_sessions WHERE id = ? AND user_id = ?', [$session['id'], user_id()]);
set_message('ลบ “' . $session['title'] . '” แล้ว');
go_back();
