<?php
// =====================================================================
//  subject-save.php : บันทึกรายวิชา (เพิ่มใหม่ หรือ แก้ไขเมื่อมี ?id=)
// =====================================================================
require 'includes/start.php';
require_post();
$userId = user_id();

$subject = null;
if (get('id') != '') {
    $subject = find_subject($userId, get('id'));
    if ($subject == null) {
        redirect('settings');
    }
}

$name = post('name');
$color = strtolower(post('color'));

// ตรวจข้อมูล
$errors = [];
if ($name == '') {
    $errors['name'] = 'กรอกชื่อวิชา';
} elseif (mb_strlen($name) > 80) {
    $errors['name'] = 'ชื่อวิชายาวเกิน 80 ตัวอักษร';
} else {
    // ห้ามมีชื่อวิชาซ้ำกัน (ไม่นับวิชาที่กำลังแก้ไขอยู่)
    $sameName = db_select_one('SELECT id FROM subjects WHERE user_id = ? AND name = ? AND id <> ?',
        [$userId, $name, $subject != null ? $subject['id'] : 0]);
    if ($sameName != null) {
        $errors['name'] = 'มีวิชาชื่อนี้อยู่แล้ว';
    }
}
// สีต้องเป็นรหัสสีแบบ #RRGGBB เช่น #3b5fe0
if (! preg_match('/^#[0-9a-f]{6}$/', $color)) {
    $errors['color'] = 'เลือกสี';
}

if (count($errors) > 0) {
    set_errors('subject', $errors, $subject != null ? 'subject-' . $subject['id'] : 'subject-new');
    redirect('settings');
}

if ($subject == null) {
    // วิชาใหม่ต่อท้ายรายการ
    $last = db_select_one('SELECT COALESCE(MAX(sort_order), 0) AS last_order FROM subjects WHERE user_id = ?', [$userId]);
    db_run('INSERT INTO subjects (user_id, name, color, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
        [$userId, $name, $color, $last['last_order'] + 1, now(), now()]);
    set_message('เพิ่มวิชา “' . $name . '” แล้ว');
} else {
    db_run('UPDATE subjects SET name = ?, color = ?, updated_at = ? WHERE id = ? AND user_id = ?',
        [$name, $color, now(), $subject['id'], $userId]);
    set_message('บันทึกวิชาแล้ว');
}
redirect('settings');
