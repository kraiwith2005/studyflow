<?php
// task-delete.php : ลบงาน
require 'includes/start.php';
require_post();

$task = find_task(user_id(), get('id'));
if ($task == null) {
    redirect('tasks');
}

db_run('DELETE FROM tasks WHERE id = ? AND user_id = ?', [$task->id, user_id()]);
set_message('ลบ “' . $task->title . '” แล้ว');
go_back();
