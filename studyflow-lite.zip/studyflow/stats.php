<?php
// =====================================================================
//  stats.php : หน้าสถิติและการวิเคราะห์
//    - สรุปตัวเลขสัปดาห์นี้
//    - บทวิเคราะห์ (ระบบคำนวณแล้วสรุปเป็นข้อความให้อัตโนมัติ)
//    - กราฟเส้น เวลาอ่าน 30 วันล่าสุด
//    - กราฟแท่ง เวลาอ่านรายวัน (อาทิตย์ - เสาร์)
//    - กราฟแท่ง เวลาอ่านแยกตามวิชา (30 วันล่าสุด)
//    - ตาราง จำนวนงานแยกตามวิชา (ค้าง / เลยกำหนด / เสร็จแล้ว)
//  กราฟวาดด้วย HTML + CSS : ความสูง/ความยาวของแท่ง = ค่า ÷ ค่าสูงสุด × 100 %
//  (เทียบ Python : groupby แล้ว plot(kind='bar') ในบทที่ 11-12)
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();
$today = today();

// ---------- 1) เวลาอ่านรายวันของสัปดาห์นี้ ----------
$weekStart = week_start($today);
$weekEnd = add_days($weekStart, 6);

// SQL รวมนาทีของแต่ละวัน (GROUP BY = จับกลุ่มตามวัน แล้ว SUM รวมค่า)
$rows = db_select("SELECT date, SUM(actual_minutes) AS minutes
                   FROM study_sessions
                   WHERE user_id = ? AND status = 'completed' AND date BETWEEN ? AND ?
                   GROUP BY date", [$userId, $weekStart, $weekEnd]);

// เตรียม 7 วัน ค่าเริ่มต้น 0 นาที แล้วเติมค่าจาก SQL
$daily = [];
for ($i = 0; $i < 7; $i++) {
    $daily[add_days($weekStart, $i)] = 0;
}
foreach ($rows as $row) {
    $daily[$row['date']] = (int) $row['minutes'];
}

// ---------- 2) สรุปตัวเลขสัปดาห์นี้ ----------
list($weekCount, $weekMinutes) = week_study_totals($userId);
$average = $weekCount > 0 ? round($weekMinutes / $weekCount) : 0;   // เฉลี่ยต่อครั้ง

// ---------- 3) เวลาอ่านแยกตามวิชา (30 วันล่าสุด) ----------
$bySubject = db_select("SELECT COALESCE(s.name, 'ไม่มีวิชา') AS name, COALESCE(s.color, ?) AS color, SUM(ss.actual_minutes) AS minutes
                        FROM study_sessions ss
                        LEFT JOIN subjects s ON s.id = ss.subject_id
                        WHERE ss.user_id = ? AND ss.status = 'completed' AND ss.date BETWEEN ? AND ?
                        GROUP BY s.id, s.name, s.color
                        ORDER BY minutes DESC", [SESSION_COLOR, $userId, add_days($today, -29), $today]);

// ---------- 4) นับงานแยกตามวิชา ด้วย loop ----------
//  $taskTable['คณิตศาสตร์'] = ['color' => ..., 'open' => 2, 'overdue' => 1, 'done' => 5]
$taskTable = [];
$openTotal = 0;
$overdueTotal = 0;
foreach (get_tasks($userId) as $task) {
    $name = $task->subjectName ?? ($task->type == 'personal' ? 'งานส่วนตัว' : 'ไม่มีวิชา');
    if (! isset($taskTable[$name])) {
        $taskTable[$name] = ['color' => $task->color, 'open' => 0, 'overdue' => 0, 'done' => 0];
    }
    if ($task->isDone()) {
        $taskTable[$name]['done']++;
    } elseif ($task->dueDate < $today) {
        $taskTable[$name]['overdue']++;
        $overdueTotal++;
    } else {
        $taskTable[$name]['open']++;
        $openTotal++;
    }
}

// ---------- 5) เวลาอ่านรายวัน 30 วันล่าสุด (ใช้กับกราฟเส้น) ----------
$from30 = add_days($today, -29);
$rows30 = db_select("SELECT date, SUM(actual_minutes) AS minutes
                     FROM study_sessions
                     WHERE user_id = ? AND status = 'completed' AND date BETWEEN ? AND ?
                     GROUP BY date", [$userId, $from30, $today]);
$last30 = [];
for ($i = 0; $i < 30; $i++) {
    $last30[add_days($from30, $i)] = 0;
}
foreach ($rows30 as $row) {
    $last30[$row['date']] = (int) $row['minutes'];
}

// ---------- 6) วิเคราะห์ข้อมูล แล้วสรุปเป็นข้อความ ----------
//  แต่ละข้อ = ['tone' => 'good' (ดี) / 'warn' (ควรระวัง) / 'info' (ข้อมูล), 'text' => ข้อความ]
$insights = [];

// 6.1 เทียบเวลาอ่านสัปดาห์นี้กับสัปดาห์ที่แล้ว
$lastWeek = db_select_one("SELECT COALESCE(SUM(actual_minutes), 0) AS minutes FROM study_sessions
                           WHERE user_id = ? AND status = 'completed' AND date BETWEEN ? AND ?",
    [$userId, add_days($weekStart, -7), add_days($weekStart, -1)]);
$lastWeekMinutes = (int) $lastWeek['minutes'];
if ($lastWeekMinutes == 0 && $weekMinutes == 0) {
    $insights[] = ['tone' => 'warn', 'text' => 'สัปดาห์นี้และสัปดาห์ที่แล้วยังไม่มีบันทึกการอ่าน ลองใช้ตัวจับเวลาในหน้าอ่านหนังสือ'];
} elseif ($lastWeekMinutes == 0) {
    $insights[] = ['tone' => 'good', 'text' => 'สัปดาห์นี้อ่านไปแล้ว ' . duration_text($weekMinutes) . ' (สัปดาห์ที่แล้วไม่ได้อ่าน)'];
} else {
    $change = round(($weekMinutes - $lastWeekMinutes) / $lastWeekMinutes * 100);   // เปลี่ยนไปกี่ %
    if ($change >= 0) {
        $insights[] = ['tone' => 'good', 'text' => 'สัปดาห์นี้อ่านมากขึ้น ' . $change . '% เมื่อเทียบกับสัปดาห์ที่แล้ว (' . duration_text($lastWeekMinutes) . ' → ' . duration_text($weekMinutes) . ')'];
    } else {
        $insights[] = ['tone' => 'warn', 'text' => 'สัปดาห์นี้อ่านน้อยลง ' . (-$change) . '% เมื่อเทียบกับสัปดาห์ที่แล้ว (' . duration_text($lastWeekMinutes) . ' → ' . duration_text($weekMinutes) . ')'];
    }
}

// 6.2 ค่าเฉลี่ยต่อวัน และจำนวนวันที่อ่าน ใน 30 วัน
$total30 = 0;
$daysStudied = 0;
$bestDay = '';
foreach ($last30 as $date => $minutes) {
    $total30 += $minutes;
    if ($minutes > 0) {
        $daysStudied++;
    }
    if ($bestDay == '' || $minutes > $last30[$bestDay]) {
        $bestDay = $date;
    }
}
if ($total30 > 0) {
    $insights[] = ['tone' => 'info', 'text' => '30 วันล่าสุดอ่าน ' . $daysStudied . ' วัน เฉลี่ยวันละ ' . round($total30 / 30) . ' นาที อ่านมากที่สุดวันที่ ' . thai_date($bestDay) . ' (' . duration_text($last30[$bestDay]) . ')'];
}

// 6.3 วิชาที่อ่านมากที่สุด / น้อยที่สุด ($bySubject เรียงจากมากไปน้อยแล้ว)
if (count($bySubject) >= 2) {
    $top = $bySubject[0];
    $bottom = $bySubject[count($bySubject) - 1];
    $insights[] = ['tone' => 'info', 'text' => 'วิชาที่อ่านมากที่สุดคือ ' . $top['name'] . ' (' . duration_text((int) $top['minutes']) . ') น้อยที่สุดคือ ' . $bottom['name'] . ' (' . duration_text((int) $bottom['minutes']) . ')'];
}

// 6.4 วิชาที่มีงานต้องส่งใน 7 วัน แต่ 7 วันที่ผ่านมายังไม่ได้อ่านเลย
$rows = db_select("SELECT DISTINCT s.name FROM tasks t JOIN subjects s ON s.id = t.subject_id
                   WHERE t.user_id = ? AND t.completed_at IS NULL AND t.due_date BETWEEN ? AND ?
                     AND NOT EXISTS (SELECT 1 FROM study_sessions ss
                                     WHERE ss.subject_id = s.id AND ss.status = 'completed' AND ss.date BETWEEN ? AND ?)",
    [$userId, $today, add_days($today, 7), add_days($today, -6), $today]);
foreach ($rows as $row) {
    $insights[] = ['tone' => 'warn', 'text' => 'วิชา ' . $row['name'] . ' มีงานต้องส่งภายใน 7 วัน แต่ 7 วันที่ผ่านมายังไม่ได้อ่านเลย'];
}

// 6.5 งานที่เลยกำหนด
if ($overdueTotal > 0) {
    $insights[] = ['tone' => 'warn', 'text' => 'มีงานเลยกำหนด ' . $overdueTotal . ' งาน ควรจัดการก่อน'];
}

// 6.6 ทำงานเสร็จทันกำหนดกี่ % (นับเฉพาะงานที่เสร็จแล้ว)
$done = db_select_one("SELECT COUNT(*) AS total, SUM(DATE(completed_at) <= due_date) AS on_time
                       FROM tasks WHERE user_id = ? AND completed_at IS NOT NULL", [$userId]);
if ((int) $done['total'] > 0) {
    $percent = round($done['on_time'] / $done['total'] * 100);
    $insights[] = ['tone' => $percent >= 80 ? 'good' : 'warn', 'text' => 'ทำงานเสร็จทันกำหนด ' . $percent . '% (' . (int) $done['on_time'] . ' จาก ' . (int) $done['total'] . ' งาน)'];
}

// ค่าสูงสุด ใช้คำนวณความยาวแท่ง (ถ้าทุกค่าเป็น 0 ใช้ 1 กันการหารด้วยศูนย์)
function max_of($numbers)
{
    $max = 1;
    foreach ($numbers as $n) {
        if ($n > $max) {
            $max = $n;
        }
    }
    return $max;
}
$dailyMax = max_of($daily);
$subjectMinutes = [];
foreach ($bySubject as $row) {
    $subjectMinutes[] = (int) $row['minutes'];
}
$subjectMax = max_of($subjectMinutes);

// จุดของกราฟเส้น (SVG) : x = ลำดับวัน, y = นาที  (ค่ามาก -> จุดอยู่สูง)
$chartWidth = 700;
$chartHeight = 150;
$lineMax = max_of($last30);
$points = [];
$i = 0;
foreach ($last30 as $date => $minutes) {
    $x = round($i * $chartWidth / 29, 1);
    $y = round($chartHeight - $minutes / $lineMax * $chartHeight, 1);
    $points[] = ['x' => $x, 'y' => $y, 'date' => $date, 'minutes' => $minutes];
    $i++;
}

$title = 'สถิติ';
$page = 'stats';
include 'includes/header.php';
?>
<div class="page" id="stats-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">สถิติ</h1>
      <p class="page-sub">วิเคราะห์เวลาอ่านหนังสือและภาระงานของแต่ละวิชา</p>
    </div>
  </div>

  <?php // ---------- ตัวเลขสรุป ---------- ?>
  <div class="stat-cards">
    <div class="card stat-card">
      <div class="stat-k">อ่านสัปดาห์นี้</div>
      <div class="stat-v"><?= duration_text($weekMinutes) ?></div>
    </div>
    <div class="card stat-card">
      <div class="stat-k">จำนวนครั้ง</div>
      <div class="stat-v"><?= $weekCount ?> ครั้ง</div>
    </div>
    <div class="card stat-card">
      <div class="stat-k">เฉลี่ยต่อครั้ง</div>
      <div class="stat-v"><?= $average ?> นาที</div>
    </div>
    <div class="card stat-card">
      <div class="stat-k">งานค้าง</div>
      <div class="stat-v"><?= $openTotal ?> งาน<?php if ($overdueTotal > 0): ?> <span class="stat-late">เลยกำหนด <?= $overdueTotal ?></span><?php endif; ?></div>
    </div>
  </div>

  <?php // ---------- บทวิเคราะห์ ---------- ?>
  <section class="card">
    <h2 class="card-title">บทวิเคราะห์</h2>
    <p class="card-sub">ระบบสรุปจากข้อมูลการอ่านและงานของคุณ</p>
    <ul class="insights">
      <?php foreach ($insights as $insight): ?>
        <li class="insight is-<?= $insight['tone'] ?>"><?= e($insight['text']) ?></li>
      <?php endforeach; ?>
    </ul>
  </section>

  <?php // ---------- กราฟแท่ง : เวลาอ่านรายวัน ---------- ?>
  <section class="card">
    <h2 class="card-title">เวลาอ่านรายวัน</h2>
    <p class="card-sub">สัปดาห์นี้ <?= thai_date($weekStart) ?> – <?= thai_date($weekEnd) ?> (นาที)</p>
    <div class="vchart" role="img" aria-label="กราฟเวลาอ่านรายวัน">
      <?php foreach ($daily as $date => $minutes): ?>
        <?php $height = round($minutes / $dailyMax * 100); ?>
        <div class="vbar-col <?= $date == $today ? 'is-today' : '' ?>">
          <span class="vbar-num"><?= $minutes ?></span>
          <div class="vbar-track"><div class="vbar" style="height: <?= $height ?>%"></div></div>
          <span class="vbar-label"><?= DAYS_SHORT[(int) date('w', strtotime($date))] ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <?php // ---------- กราฟเส้น : เวลาอ่าน 30 วันล่าสุด (วาดด้วย SVG) ---------- ?>
  <section class="card">
    <h2 class="card-title">แนวโน้มเวลาอ่าน</h2>
    <p class="card-sub">30 วันล่าสุด (นาทีต่อวัน) · สูงสุด <?= $lineMax ?> นาที</p>
    <svg class="line-chart" viewBox="-10 -14 <?= $chartWidth + 20 ?> <?= $chartHeight + 44 ?>" role="img" aria-label="กราฟเส้นเวลาอ่าน 30 วันล่าสุด">
      <line x1="0" y1="<?= $chartHeight ?>" x2="<?= $chartWidth ?>" y2="<?= $chartHeight ?>" class="line-axis"/>
      <?php
      // ต่อจุดทุกจุดเป็นข้อความ "x,y x,y ..." สำหรับ <polyline>
      $pointText = '';
      foreach ($points as $p) {
          $pointText .= $p['x'] . ',' . $p['y'] . ' ';
      }
      ?>
      <polyline points="<?= trim($pointText) ?>" class="line-path"/>
      <?php foreach ($points as $index => $p): ?>
        <?php if ($p['minutes'] > 0): // วาดจุดเฉพาะวันที่อ่าน ?>
          <circle cx="<?= $p['x'] ?>" cy="<?= $p['y'] ?>" r="4" class="line-dot has-value">
            <title><?= thai_date($p['date']) ?> : <?= $p['minutes'] ?> นาที</title>
          </circle>
        <?php endif; ?>
        <?php if ($index % 7 == 1): // ป้ายวันที่ทุก 7 วัน (ลงท้ายที่วันนี้) ?>
          <text x="<?= $p['x'] ?>" y="<?= $chartHeight + 24 ?>" class="line-label"><?= (int) substr($p['date'], 8, 2) ?> <?= MONTHS_SHORT[(int) substr($p['date'], 5, 2) - 1] ?></text>
        <?php endif; ?>
      <?php endforeach; ?>
    </svg>
  </section>

  <?php // ---------- กราฟแท่งแนวนอน : เวลาอ่านแยกตามวิชา ---------- ?>
  <section class="card">
    <h2 class="card-title">เวลาอ่านแยกตามวิชา</h2>
    <p class="card-sub">30 วันล่าสุด</p>
    <?php if (count($bySubject) == 0): ?>
      <p class="today-empty">ยังไม่มีบันทึกการอ่านใน 30 วันล่าสุด</p>
    <?php else: ?>
      <div class="hchart">
        <?php foreach ($bySubject as $row): ?>
          <?php $width = round($row['minutes'] / $subjectMax * 100); ?>
          <div class="hbar-row">
            <span class="hbar-label"><span class="swatch-dot" style="background: <?= e($row['color']) ?>"></span><?= e($row['name']) ?></span>
            <div class="hbar-track"><div class="hbar" style="width: <?= $width ?>%; background: <?= e($row['color']) ?>"></div></div>
            <span class="hbar-num"><?= duration_text((int) $row['minutes']) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <?php // ---------- ตาราง : งานแยกตามวิชา ---------- ?>
  <section class="card">
    <h2 class="card-title">งานแยกตามวิชา</h2>
    <p class="card-sub">นับงานทั้งหมดที่บันทึกไว้</p>
    <?php if (count($taskTable) == 0): ?>
      <p class="today-empty">ยังไม่มีงาน</p>
    <?php else: ?>
      <div class="stat-table-wrap">
        <table class="stat-table">
          <thead>
            <tr><th>วิชา</th><th>ค้าง</th><th>เลยกำหนด</th><th>เสร็จแล้ว</th></tr>
          </thead>
          <tbody>
            <?php foreach ($taskTable as $name => $count): ?>
              <tr>
                <td><span class="swatch-dot" style="background: <?= e($count['color']) ?>"></span><?= e($name) ?></td>
                <td><?= $count['open'] ?></td>
                <td class="<?= $count['overdue'] > 0 ? 'is-late' : '' ?>"><?= $count['overdue'] ?></td>
                <td><?= $count['done'] ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>

  <?php // ---------- ดาวน์โหลดข้อมูลเป็นไฟล์ CSV (ใช้กับ analysis/analysis.py) ---------- ?>
  <section class="card">
    <h2 class="card-title">ดาวน์โหลดข้อมูล (CSV)</h2>
    <p class="card-sub">เปิดใน Excel ได้ หรือนำไปวิเคราะห์ต่อด้วย Python (pandas)</p>
    <div class="form-buttons" style="margin-top:0">
      <a class="btn btn-outline" href="<?= e(url('export', ['type' => 'study'])) ?>"><?= icon('download', '', 16) ?> การอ่านหนังสือ (study.csv)</a>
      <a class="btn btn-outline" href="<?= e(url('export', ['type' => 'tasks'])) ?>"><?= icon('download', '', 16) ?> งาน (tasks.csv)</a>
    </div>
  </section>
</div>
<?php include 'includes/footer.php'; ?>
