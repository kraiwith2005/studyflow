<?php
// =====================================================================
//  stats.php : หน้าสถิติ
//    - สรุปตัวเลขสัปดาห์นี้
//    - กราฟแท่ง เวลาอ่านรายวัน (อาทิตย์ - เสาร์)
//    - กราฟแท่ง เวลาอ่านแยกตามวิชา (30 วันล่าสุด)
//    - ตาราง จำนวนงานแยกตามวิชา (ค้าง / เลยกำหนด / เสร็จแล้ว)
//  กราฟวาดด้วย HTML + CSS : ความสูง/ความยาวของแท่ง = ค่า ÷ ค่าสูงสุด × 100 %
//  (เทียบ Python : groupby แล้ว plot(kind='bar') ในบทที่ 11-12)
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();
$today = today();

// ---------- 1) เวลาอ่านรายวันของสัปดาห์นี้ ----------
$weekStart = week_start($today);
$weekEnd = add_days($weekStart, 6);

// SQL รวมนาทีของแต่ละวัน (GROUP BY = จับกลุ่มตามวัน แล้ว SUM รวมค่า)
$rows = db_select("SELECT date, SUM(actual_minutes) AS minutes
                   FROM study_sessions
                   WHERE user_id = ? AND status = 'completed' AND date BETWEEN ? AND ?
                   GROUP BY date", [$userId, $weekStart, $weekEnd]);

// เตรียม 7 วัน ค่าเริ่มต้น 0 นาที แล้วเติมค่าจาก SQL
$daily = [];
for ($i = 0; $i < 7; $i++) {
    $daily[add_days($weekStart, $i)] = 0;
}
foreach ($rows as $row) {
    $daily[$row['date']] = (int) $row['minutes'];
}

// ---------- 2) สรุปตัวเลขสัปดาห์นี้ ----------
list($weekCount, $weekMinutes) = week_study_totals($userId);
$average = $weekCount > 0 ? round($weekMinutes / $weekCount) : 0;   // เฉลี่ยต่อครั้ง

// ---------- 3) เวลาอ่านแยกตามวิชา (30 วันล่าสุด) ----------
$bySubject = db_select("SELECT COALESCE(s.name, 'ไม่มีวิชา') AS name, COALESCE(s.color, ?) AS color, SUM(ss.actual_minutes) AS minutes
                        FROM study_sessions ss
                        LEFT JOIN subjects s ON s.id = ss.subject_id
                        WHERE ss.user_id = ? AND ss.status = 'completed' AND ss.date BETWEEN ? AND ?
                        GROUP BY s.id, s.name, s.color
                        ORDER BY minutes DESC", [SESSION_COLOR, $userId, add_days($today, -29), $today]);

// ---------- 4) นับงานแยกตามวิชา ด้วย loop ----------
//  $taskTable['คณิตศาสตร์'] = ['color' => ..., 'open' => 2, 'overdue' => 1, 'done' => 5]
$taskTable = [];
$openTotal = 0;
$overdueTotal = 0;
foreach (get_tasks($userId) as $task) {
    $name = $task->subjectName ?? ($task->type == 'personal' ? 'งานส่วนตัว' : 'ไม่มีวิชา');
    if (! isset($taskTable[$name])) {
        $taskTable[$name] = ['color' => $task->color, 'open' => 0, 'overdue' => 0, 'done' => 0];
    }
    if ($task->isDone()) {
        $taskTable[$name]['done']++;
    } elseif ($task->dueDate < $today) {
        $taskTable[$name]['overdue']++;
        $overdueTotal++;
    } else {
        $taskTable[$name]['open']++;
        $openTotal++;
    }
}

// ค่าสูงสุด ใช้คำนวณความยาวแท่ง (ถ้าทุกค่าเป็น 0 ใช้ 1 กันการหารด้วยศูนย์)
function max_of($numbers)
{
    $max = 1;
    foreach ($numbers as $n) {
        if ($n > $max) {
            $max = $n;
        }
    }
    return $max;
}
$dailyMax = max_of($daily);
$subjectMinutes = [];
foreach ($bySubject as $row) {
    $subjectMinutes[] = (int) $row['minutes'];
}
$subjectMax = max_of($subjectMinutes);

$title = 'สถิติ';
$page = 'stats';
include 'includes/header.php';
?>
<div class="page" id="stats-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">สถิติ</h1>
      <p class="page-sub">ดูภาพรวมเวลาอ่านหนังสือและภาระงานของแต่ละวิชา</p>
    </div>
  </div>

  <?php // ---------- ตัวเลขสรุป ---------- ?>
  <div class="stat-cards">
    <div class="card stat-card">
      <div class="stat-k">อ่านสัปดาห์นี้</div>
      <div class="stat-v"><?= duration_text($weekMinutes) ?></div>
    </div>
    <div class="card stat-card">
      <div class="stat-k">จำนวนครั้ง</div>
      <div class="stat-v"><?= $weekCount ?> ครั้ง</div>
    </div>
    <div class="card stat-card">
      <div class="stat-k">เฉลี่ยต่อครั้ง</div>
      <div class="stat-v"><?= $average ?> นาที</div>
    </div>
    <div class="card stat-card">
      <div class="stat-k">งานค้าง</div>
      <div class="stat-v"><?= $openTotal ?> งาน<?php if ($overdueTotal > 0): ?> <span class="stat-late">เลยกำหนด <?= $overdueTotal ?></span><?php endif; ?></div>
    </div>
  </div>

  <?php // ---------- กราฟแท่ง : เวลาอ่านรายวัน ---------- ?>
  <section class="card">
    <h2 class="card-title">เวลาอ่านรายวัน</h2>
    <p class="card-sub">สัปดาห์นี้ <?= thai_date($weekStart) ?> – <?= thai_date($weekEnd) ?> (นาที)</p>
    <div class="vchart" role="img" aria-label="กราฟเวลาอ่านรายวัน">
      <?php foreach ($daily as $date => $minutes): ?>
        <?php $height = round($minutes / $dailyMax * 100); ?>
        <div class="vbar-col <?= $date == $today ? 'is-today' : '' ?>">
          <span class="vbar-num"><?= $minutes ?></span>
          <div class="vbar-track"><div class="vbar" style="height: <?= $height ?>%"></div></div>
          <span class="vbar-label"><?= DAYS_SHORT[(int) date('w', strtotime($date))] ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <?php // ---------- กราฟแท่งแนวนอน : เวลาอ่านแยกตามวิชา ---------- ?>
  <section class="card">
    <h2 class="card-title">เวลาอ่านแยกตามวิชา</h2>
    <p class="card-sub">30 วันล่าสุด</p>
    <?php if (count($bySubject) == 0): ?>
      <p class="today-empty">ยังไม่มีบันทึกการอ่านใน 30 วันล่าสุด</p>
    <?php else: ?>
      <div class="hchart">
        <?php foreach ($bySubject as $row): ?>
          <?php $width = round($row['minutes'] / $subjectMax * 100); ?>
          <div class="hbar-row">
            <span class="hbar-label"><span class="swatch-dot" style="background: <?= e($row['color']) ?>"></span><?= e($row['name']) ?></span>
            <div class="hbar-track"><div class="hbar" style="width: <?= $width ?>%; background: <?= e($row['color']) ?>"></div></div>
            <span class="hbar-num"><?= duration_text((int) $row['minutes']) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <?php // ---------- ตาราง : งานแยกตามวิชา ---------- ?>
  <section class="card">
    <h2 class="card-title">งานแยกตามวิชา</h2>
    <p class="card-sub">นับงานทั้งหมดที่บันทึกไว้</p>
    <?php if (count($taskTable) == 0): ?>
      <p class="today-empty">ยังไม่มีงาน</p>
    <?php else: ?>
      <div class="stat-table-wrap">
        <table class="stat-table">
          <thead>
            <tr><th>วิชา</th><th>ค้าง</th><th>เลยกำหนด</th><th>เสร็จแล้ว</th></tr>
          </thead>
          <tbody>
            <?php foreach ($taskTable as $name => $count): ?>
              <tr>
                <td><span class="swatch-dot" style="background: <?= e($count['color']) ?>"></span><?= e($name) ?></td>
                <td><?= $count['open'] ?></td>
                <td class="<?= $count['overdue'] > 0 ? 'is-late' : '' ?>"><?= $count['overdue'] ?></td>
                <td><?= $count['done'] ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>

  <?php // ---------- ดาวน์โหลดข้อมูลเป็นไฟล์ CSV (ใช้กับ analysis/analysis.py) ---------- ?>
  <section class="card">
    <h2 class="card-title">ดาวน์โหลดข้อมูล (CSV)</h2>
    <p class="card-sub">เปิดใน Excel ได้ หรือนำไปวิเคราะห์ต่อด้วย Python (pandas)</p>
    <div class="form-buttons" style="margin-top:0">
      <a class="btn btn-outline" href="<?= e(url('export', ['type' => 'study'])) ?>"><?= icon('download', '', 16) ?> การอ่านหนังสือ (study.csv)</a>
      <a class="btn btn-outline" href="<?= e(url('export', ['type' => 'tasks'])) ?>"><?= icon('download', '', 16) ?> งาน (tasks.csv)</a>
    </div>
  </section>
</div>
<?php include 'includes/footer.php'; ?>
