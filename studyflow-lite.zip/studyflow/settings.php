<?php
// =====================================================================
//  settings.php : หน้าตั้งค่า  (จัดการรายวิชา + ช่วยเหลือ / ลบบัญชี)
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();
$user = current_user();

// รายวิชา พร้อมจำนวนงานในแต่ละวิชา
$subjects = db_select('SELECT s.*, (SELECT COUNT(*) FROM tasks t WHERE t.subject_id = s.id) AS task_count
                       FROM subjects s WHERE s.user_id = ? ORDER BY s.sort_order, s.name', [$userId]);

// กรอกฟอร์มวิชาผิด -> เปิดกล่องค้างไว้  reopen = 'subject-new' (เพิ่ม) หรือ 'subject-5' (แก้ไข id 5)
$reopen = reopen();
$editingId = 0;
if (str_starts_with($reopen, 'subject-') && $reopen != 'subject-new') {
    $editingId = (int) substr($reopen, 8);
}
$currentColor = old('color', SUBJECT_COLORS[0]);

$title = 'ตั้งค่า';
$page = 'settings';
$scripts = ['js/settings.js'];
include 'includes/header.php';
?>
<div class="page" id="settings">
  <div class="page-head">
    <div>
      <h1 class="page-title">ตั้งค่า</h1>
      <p class="page-sub">จัดการรายวิชา และการช่วยเหลือ</p>
    </div>
  </div>

  <?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

  <div class="acc-stack">
    <?php // ==================== รายวิชา ==================== ?>
    <section class="acc is-open" id="subjects" data-acc="subjects">
      <button type="button" class="acc-head" aria-expanded="true" aria-controls="subjects-body">
        <span class="sec-icon blue"><?= icon('book', '', 20) ?></span>
        <span class="acc-text">
          <span class="acc-title">วิชา</span><br>
          <span class="acc-sub">ตั้งค่าแล้ว <?= count($subjects) ?> วิชา</span>
        </span>
        <?= icon('chevron', 'acc-chev', 20) ?>
      </button>
      <div class="acc-body" id="subjects-body">
        <div class="acc-toolbar">
          <button type="button" class="btn btn-primary" data-open-dialog="subject-dialog"
                  data-action="<?= e(url('subject-save')) ?>" data-title="วิชาใหม่" data-submit="เพิ่ม"
                  data-name="" data-color="<?= SUBJECT_COLORS[0] ?>">
            <?= icon('plus') ?> เพิ่มวิชา
          </button>
        </div>

        <?php if (count($subjects) == 0): ?>
          <div class="empty">
            <div class="empty-title">ยังไม่มีวิชา</div>
            <div class="empty-sub">เพิ่มวิชาที่ลงเรียน แล้วจึงเพิ่มงานของแต่ละวิชาได้</div>
          </div>
        <?php else: ?>
          <div class="rows">
            <?php foreach ($subjects as $subject): ?>
              <div class="row-item">
                <span class="swatch-dot" style="background: <?= e($subject['color']) ?>"></span>
                <div class="row-main">
                  <div class="row-title"><?= e($subject['name']) ?></div>
                  <div class="row-meta">มีงาน <?= $subject['task_count'] ?> รายการ</div>
                </div>
                <div class="row-actions">
                  <?php // ปุ่มแก้ไข : JavaScript จะเอาค่าใน data-name / data-color ไปใส่ในฟอร์ม ?>
                  <button type="button" class="icon-action" aria-label="แก้ไข <?= e($subject['name']) ?>" data-open-dialog="subject-dialog"
                          data-action="<?= e(url('subject-save', ['id' => $subject['id']])) ?>" data-title="แก้ไขวิชา" data-submit="บันทึก"
                          data-name="<?= e($subject['name']) ?>" data-color="<?= e($subject['color']) ?>">
                    <?= icon('pencil', '', 16) ?>
                  </button>
                  <form method="POST" action="<?= e(url('subject-delete', ['id' => $subject['id']])) ?>"
                        data-confirm="ลบ “<?= e($subject['name']) ?>” ใช่ไหม?" data-confirm-text="งานของวิชานี้จะยังอยู่ แต่จะไม่มีวิชากำกับ การลบนี้ย้อนกลับไม่ได้">
                    <?= csrf_field() ?>
                    <button type="submit" class="icon-action danger" aria-label="ลบ <?= e($subject['name']) ?>"><?= icon('trash', '', 16) ?></button>
                  </form>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>

    <?php // ==================== ช่วยเหลือ ==================== ?>
    <section class="acc" id="support">
      <div class="support-main">
        <span class="sec-icon red"><?= icon('lifebuoy', '', 20) ?></span>
        <div class="acc-text">
          <div class="acc-title">ช่วยเหลือ</div>
          <div class="acc-sub">ต้องการความช่วยเหลือหรือมีไอเดีย? บอกเราได้ว่าอะไรจะช่วยให้วางแผนง่ายขึ้น เราอ่านทุกความคิดเห็นและนำมาปรับปรุง</div>
        </div>
        <a class="support-email" href="mailto:<?= e($config['support_email']) ?>"><?= e($config['support_email']) ?></a>
      </div>
      <div class="support-foot">
        <a href="<?= e(url('privacy')) ?>">ความเป็นส่วนตัว</a>
        <a href="<?= e(url('terms')) ?>">ข้อตกลงการใช้งาน</a>
        <a href="<?= e(url('cookies')) ?>">คุกกี้</a>
        <button type="button" class="link-btn link-danger" data-open-dialog="delete-account-dialog">ลบบัญชี</button>
      </div>
    </section>
  </div>
</div>

<?php // ---------- กล่องเพิ่ม / แก้ไขวิชา (ส่งไปที่ subject-save.php) ---------- ?>
<dialog class="dlg dlg-wide" id="subject-dialog" <?= str_starts_with($reopen, 'subject-') ? 'data-autoshow' : '' ?>>
  <form method="POST" class="dlg-body" novalidate data-once
        action="<?= e($editingId ? url('subject-save', ['id' => $editingId]) : url('subject-save')) ?>">
    <?= csrf_field() ?>
    <label class="dlg-title" for="subject-name" data-dialog-title style="display:block"><?= $editingId ? 'แก้ไขวิชา' : 'วิชาใหม่' ?></label>
    <input id="subject-name" name="name" class="input input-rect <?= invalid('subject', 'name') ?>"
           placeholder="ชื่อวิชา" maxlength="80" value="<?= e(old('name')) ?>" required data-enable-submit>
    <?= show_error('subject', 'name') ?>

    <div style="margin-top:16px">
      <div class="label">สี</div>
      <div class="field-hint" style="font-size:14px;margin-top:4px">เลือกสีสำเร็จรูป หรือกำหนดสีเอง</div>
      <div class="swatches" role="radiogroup" aria-label="สีวิชา">
        <?php foreach (SUBJECT_COLORS as $color): ?>
          <button type="button" class="swatch" role="radio" style="background: <?= $color ?>" data-color="<?= $color ?>"
                  aria-checked="<?= strtolower($currentColor) == $color ? 'true' : 'false' ?>" aria-label="สี <?= $color ?>"></button>
        <?php endforeach; ?>
      </div>
      <label class="btn btn-outline btn-sm custom-colour">
        <span class="custom-preview" data-colour-preview style="background: <?= e($currentColor) ?>"></span>
        กำหนดสีเอง
        <input type="color" name="color" value="<?= e($currentColor) ?>" data-colour-input aria-label="กำหนดสีเอง">
      </label>
      <?= show_error('subject', 'color') ?>
    </div>

    <div class="form-buttons">
      <button type="submit" class="btn btn-primary" data-dialog-submit disabled><?= $editingId ? 'บันทึก' : 'เพิ่ม' ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </form>
</dialog>

<?php // ---------- กล่องลบบัญชี (ส่งไปที่ account-delete.php) ---------- ?>
<dialog class="dlg" id="delete-account-dialog" <?= error_of('delete', 'password') != '' ? 'data-autoshow' : '' ?>>
  <form method="POST" action="<?= e(url('account-delete')) ?>" class="dlg-body" novalidate data-once>
    <?= csrf_field() ?>
    <div class="dlg-title">ลบบัญชีของคุณใช่ไหม?</div>
    <p class="dlg-text">บัญชีและข้อมูลทั้งหมดของคุณจะถูกลบถาวร การลบนี้ย้อนกลับไม่ได้</p>
    <?php
    $pw_id = 'delete-password'; $pw_name = 'password'; $pw_label = 'กรอกรหัสผ่านเพื่อยืนยัน'; $pw_placeholder = 'รหัสผ่าน'; $pw_form = 'delete';
    include 'includes/password_field.php';
    ?>
    <div class="form-buttons">
      <button type="submit" class="btn btn-danger">ลบบัญชี</button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </form>
</dialog>

<?php // ---------- ยืนยันก่อนลบวิชา ---------- ?>
<dialog class="dlg" id="confirm-dialog">
  <div class="dlg-body">
    <div class="dlg-title" data-confirm-title>แน่ใจหรือไม่?</div>
    <p class="dlg-text" data-confirm-text></p>
    <div class="form-buttons" style="margin-top:0">
      <button type="button" class="btn btn-danger" data-confirm-ok>ลบ</button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </div>
</dialog>

<?php include 'includes/footer.php'; ?>
