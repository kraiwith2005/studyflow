<?php
// =====================================================================
//  settings.php : หน้าตั้งค่า  (รายวิชา / ตารางเรียน / ช่วยเหลือ / ลบบัญชี)
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();
$user = current_user();

// รายวิชา พร้อมจำนวนงานในแต่ละวิชา
$subjects = db_select('SELECT s.*, (SELECT COUNT(*) FROM tasks t WHERE t.subject_id = s.id) AS task_count
                       FROM subjects s WHERE s.user_id = ? ORDER BY s.sort_order, s.name', [$userId]);

// กรอกฟอร์มวิชาผิด -> เปิดกล่องค้างไว้  reopen = 'subject-new' (เพิ่ม) หรือ 'subject-5' (แก้ไข id 5)
$reopen = reopen();
$editingId = 0;
if (str_starts_with($reopen, 'subject-') && $reopen != 'subject-new') {
    $editingId = (int) substr($reopen, 8);
}
$currentColor = old('color', SUBJECT_COLORS[0]);

// ตารางเรียน
$classes = get_classes($userId);
$classEditId = 0;
if (str_starts_with($reopen, 'class-') && $reopen != 'class-new') {
    $classEditId = (int) substr($reopen, 6);
}

$title = 'ตั้งค่า';
$page = 'settings';
$scripts = ['js/settings.js'];
include 'includes/header.php';
?>
<div class="page" id="settings">
  <div class="page-head">
    <div>
      <h1 class="page-title">ตั้งค่า</h1>
      <p class="page-sub">จัดการรายวิชา ตารางเรียน และการช่วยเหลือ</p>
    </div>
  </div>

  <?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

  <div class="acc-stack">
    <?php // ==================== รายวิชา ==================== ?>
    <section class="acc is-open" id="subjects" data-acc="subjects">
      <button type="button" class="acc-head" aria-expanded="true" aria-controls="subjects-body">
        <span class="sec-icon blue"><?= icon('book', '', 20) ?></span>
        <span class="acc-text">
          <span class="acc-title">วิชา</span><br>
          <span class="acc-sub">ตั้งค่าแล้ว <?= count($subjects) ?> วิชา</span>
        </span>
        <?= icon('chevron', 'acc-chev', 20) ?>
      </button>
      <div class="acc-body" id="subjects-body">
        <div class="acc-toolbar">
          <button type="button" class="btn btn-primary" data-open-dialog="subject-dialog"
                  data-action="<?= e(url('subject-save')) ?>" data-title="วิชาใหม่" data-submit="เพิ่ม"
                  data-values="<?= e(json_encode(['name' => '', 'color' => SUBJECT_COLORS[0]])) ?>">
            <?= icon('plus') ?> เพิ่มวิชา
          </button>
        </div>

        <?php if (count($subjects) == 0): ?>
          <div class="empty">
            <div class="empty-title">ยังไม่มีวิชา</div>
            <div class="empty-sub">เพิ่มวิชาที่ลงเรียน แล้วจึงเพิ่มงานของแต่ละวิชาได้</div>
          </div>
        <?php else: ?>
          <div class="rows">
            <?php foreach ($subjects as $subject): ?>
              <div class="row-item">
                <span class="swatch-dot" style="background: <?= e($subject['color']) ?>"></span>
                <div class="row-main">
                  <div class="row-title"><?= e($subject['name']) ?></div>
                  <div class="row-meta">มีงาน <?= $subject['task_count'] ?> รายการ</div>
                </div>
                <div class="row-actions">
                  <?php // ปุ่มแก้ไข : JavaScript จะเอาค่าเดิมใน data-values ไปใส่ในฟอร์ม ?>
                  <button type="button" class="icon-action" aria-label="แก้ไข <?= e($subject['name']) ?>" data-open-dialog="subject-dialog"
                          data-action="<?= e(url('subject-save', ['id' => $subject['id']])) ?>" data-title="แก้ไขวิชา" data-submit="บันทึก"
                          data-values="<?= e(json_encode(['name' => $subject['name'], 'color' => $subject['color']], JSON_UNESCAPED_UNICODE)) ?>">
                    <?= icon('pencil', '', 16) ?>
                  </button>
                  <form method="POST" action="<?= e(url('subject-delete', ['id' => $subject['id']])) ?>"
                        data-confirm="ลบ “<?= e($subject['name']) ?>” ใช่ไหม?" data-confirm-text="งานของวิชานี้จะยังอยู่ แต่จะไม่มีวิชากำกับ การลบนี้ย้อนกลับไม่ได้">
                    <?= csrf_field() ?>
                    <button type="submit" class="icon-action danger" aria-label="ลบ <?= e($subject['name']) ?>"><?= icon('trash', '', 16) ?></button>
                  </form>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>

    <?php // ==================== ตารางเรียน ==================== ?>
    <section class="acc is-open" id="timetable" data-acc="timetable">
      <button type="button" class="acc-head" aria-expanded="true" aria-controls="timetable-body">
        <span class="sec-icon teal"><?= icon('grid', '', 20) ?></span>
        <span class="acc-text">
          <span class="acc-title">ตารางเรียน</span><br>
          <span class="acc-sub">คาบเรียนต่อสัปดาห์ <?= count($classes) ?> คาบ · แสดงในปฏิทินมุมมองสัปดาห์/วัน และหน้าวันนี้</span>
        </span>
        <?= icon('chevron', 'acc-chev', 20) ?>
      </button>
      <div class="acc-body" id="timetable-body">
        <div class="acc-toolbar">
          <button type="button" class="btn btn-primary" data-open-dialog="class-dialog"
                  data-action="<?= e(url('class-save')) ?>" data-title="เพิ่มคาบเรียน" data-submit="เพิ่ม"
                  data-values="<?= e(json_encode(['subject_id' => '', 'name' => '', 'day' => '1', 'start_time' => '09:00', 'end_time' => '12:00', 'location' => '', 'teacher' => ''])) ?>">
            <?= icon('plus') ?> เพิ่มคาบเรียน
          </button>
        </div>

        <?php if (count($classes) == 0): ?>
          <div class="empty">
            <div class="empty-title">ยังไม่มีคาบเรียน</div>
            <div class="empty-sub">เพิ่มคาบเรียนแต่ละวิชา เลือกวันและเวลาที่เรียนทุกสัปดาห์</div>
          </div>
        <?php else: ?>
          <div class="rows">
            <?php foreach ($classes as $class): ?>
              <?php
              // ค่าเดิมสำหรับใส่ในฟอร์มตอนกดแก้ไข
              $values = [
                  'subject_id' => (string) $class['subject_id'], 'name' => (string) $class['name'], 'day' => (string) $class['day'],
                  'start_time' => $class['start'], 'end_time' => $class['end'],
                  'location' => (string) $class['location'], 'teacher' => (string) $class['teacher'],
              ];
              $dayName = DAYS_FULL[$class['day'] % 7];   // day 1-7 (จันทร์-อาทิตย์)  ->  ตำแหน่งใน DAYS_FULL (0 = อาทิตย์)
              ?>
              <div class="row-item">
                <span class="swatch-dot" style="background: <?= e($class['color']) ?>"></span>
                <div class="row-main">
                  <div class="row-title"><?= e($class['title']) ?></div>
                  <div class="row-meta">
                    วัน<?= $dayName ?> · <?= $class['start'] ?> – <?= $class['end'] ?>
                    <?php if ($class['location'] != ''): ?> · <?= e($class['location']) ?><?php endif; ?>
                    <?php if ($class['teacher'] != ''): ?> · <?= e($class['teacher']) ?><?php endif; ?>
                  </div>
                </div>
                <div class="row-actions">
                  <button type="button" class="icon-action" aria-label="แก้ไข <?= e($class['title']) ?>" data-open-dialog="class-dialog"
                          data-action="<?= e(url('class-save', ['id' => $class['id']])) ?>" data-title="แก้ไขคาบเรียน" data-submit="บันทึก"
                          data-values="<?= e(json_encode($values, JSON_UNESCAPED_UNICODE)) ?>">
                    <?= icon('pencil', '', 16) ?>
                  </button>
                  <form method="POST" action="<?= e(url('class-delete', ['id' => $class['id']])) ?>"
                        data-confirm="ลบ “<?= e($class['title']) ?>” ใช่ไหม?" data-confirm-text="คาบนี้จะไม่แสดงในตารางเรียนอีก">
                    <?= csrf_field() ?>
                    <button type="submit" class="icon-action danger" aria-label="ลบ <?= e($class['title']) ?>"><?= icon('trash', '', 16) ?></button>
                  </form>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>

    <?php // ==================== ช่วยเหลือ ==================== ?>
    <section class="acc" id="support">
      <div class="support-main">
        <span class="sec-icon red"><?= icon('lifebuoy', '', 20) ?></span>
        <div class="acc-text">
          <div class="acc-title">ช่วยเหลือ</div>
          <div class="acc-sub">ต้องการความช่วยเหลือหรือมีไอเดีย? บอกเราได้ว่าอะไรจะช่วยให้วางแผนง่ายขึ้น เราอ่านทุกความคิดเห็นและนำมาปรับปรุง</div>
        </div>
        <a class="support-email" href="mailto:<?= e($config['support_email']) ?>"><?= e($config['support_email']) ?></a>
      </div>
      <div class="support-foot">
        <a href="<?= e(url('privacy')) ?>">ความเป็นส่วนตัว</a>
        <a href="<?= e(url('terms')) ?>">ข้อตกลงการใช้งาน</a>
        <a href="<?= e(url('cookies')) ?>">คุกกี้</a>
        <button type="button" class="link-btn link-danger" data-open-dialog="delete-account-dialog">ลบบัญชี</button>
      </div>
    </section>
  </div>
</div>

<?php // ---------- กล่องเพิ่ม / แก้ไขวิชา (ส่งไปที่ subject-save.php) ---------- ?>
<dialog class="dlg dlg-wide" id="subject-dialog" <?= str_starts_with($reopen, 'subject-') ? 'data-autoshow' : '' ?>>
  <form method="POST" class="dlg-body" novalidate data-once
        action="<?= e($editingId ? url('subject-save', ['id' => $editingId]) : url('subject-save')) ?>">
    <?= csrf_field() ?>
    <label class="dlg-title" for="subject-name" data-dialog-title style="display:block"><?= $editingId ? 'แก้ไขวิชา' : 'วิชาใหม่' ?></label>
    <input id="subject-name" name="name" class="input input-rect <?= invalid('subject', 'name') ?>"
           placeholder="ชื่อวิชา" maxlength="80" value="<?= e(old('name')) ?>" required data-enable-submit>
    <?= show_error('subject', 'name') ?>

    <div style="margin-top:16px">
      <div class="label">สี</div>
      <div class="field-hint" style="font-size:14px;margin-top:4px">เลือกสีสำเร็จรูป หรือกำหนดสีเอง</div>
      <div class="swatches" role="radiogroup" aria-label="สีวิชา">
        <?php foreach (SUBJECT_COLORS as $color): ?>
          <button type="button" class="swatch" role="radio" style="background: <?= $color ?>" data-color="<?= $color ?>"
                  aria-checked="<?= strtolower($currentColor) == $color ? 'true' : 'false' ?>" aria-label="สี <?= $color ?>"></button>
        <?php endforeach; ?>
      </div>
      <label class="btn btn-outline btn-sm custom-colour">
        <span class="custom-preview" data-colour-preview style="background: <?= e($currentColor) ?>"></span>
        กำหนดสีเอง
        <input type="color" name="color" value="<?= e($currentColor) ?>" data-colour-input aria-label="กำหนดสีเอง">
      </label>
      <?= show_error('subject', 'color') ?>
    </div>

    <div class="form-buttons">
      <button type="submit" class="btn btn-primary" data-dialog-submit disabled><?= $editingId ? 'บันทึก' : 'เพิ่ม' ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </form>
</dialog>

<?php // ---------- กล่องเพิ่ม / แก้ไขคาบเรียน (ส่งไปที่ class-save.php) ---------- ?>
<dialog class="dlg dlg-wide" id="class-dialog" <?= str_starts_with($reopen, 'class-') ? 'data-autoshow' : '' ?>>
  <form method="POST" class="dlg-body" novalidate data-once
        action="<?= e($classEditId ? url('class-save', ['id' => $classEditId]) : url('class-save')) ?>">
    <?= csrf_field() ?>
    <div class="dlg-title" data-dialog-title><?= $classEditId ? 'แก้ไขคาบเรียน' : 'เพิ่มคาบเรียน' ?></div>
    <div class="grid-2" style="margin-top:16px">
      <div class="field">
        <label class="label" for="class-subject">วิชา</label>
        <select id="class-subject" name="subject_id" class="select <?= invalid('class', 'subject_id') ?>">
          <option value="">ไม่มีวิชา (ตั้งชื่อเอง)</option>
          <?php foreach (get_subjects($userId) as $s): ?>
            <option value="<?= $s['id'] ?>" <?= selected(old('subject_id') == $s['id']) ?>><?= e($s['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <?= show_error('class', 'subject_id') ?>
      </div>
      <div class="field">
        <label class="label" for="class-name">ชื่อคาบ (ไม่บังคับ)</label>
        <input id="class-name" name="name" class="input input-rect <?= invalid('class', 'name') ?>" maxlength="80"
               placeholder="เว้นว่าง = ใช้ชื่อวิชา" value="<?= e(old('name')) ?>">
        <?= show_error('class', 'name') ?>
      </div>
      <div class="field">
        <label class="label" for="class-day">วัน</label>
        <select id="class-day" name="day" class="select">
          <?php for ($day = 1; $day <= 7; $day++): ?>
            <option value="<?= $day ?>" <?= selected(old('day', '1') == $day) ?>><?= DAYS_FULL[$day % 7] ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="field">
        <label class="label" for="class-location">ห้องเรียน</label>
        <input id="class-location" name="location" class="input input-rect" maxlength="120" placeholder="เช่น ห้อง 501 อาคาร 19" value="<?= e(old('location')) ?>">
      </div>
      <div class="field">
        <label class="label" for="class-start">เวลาเริ่ม</label>
        <input id="class-start" name="start_time" type="time" class="input input-rect <?= invalid('class', 'start_time') ?>" value="<?= e(old('start_time', '09:00')) ?>" required>
        <?= show_error('class', 'start_time') ?>
      </div>
      <div class="field">
        <label class="label" for="class-end">เวลาเลิก</label>
        <input id="class-end" name="end_time" type="time" class="input input-rect <?= invalid('class', 'end_time') ?>" value="<?= e(old('end_time', '12:00')) ?>" required>
        <?= show_error('class', 'end_time') ?>
      </div>
      <div class="field">
        <label class="label" for="class-teacher">ผู้สอน</label>
        <input id="class-teacher" name="teacher" class="input input-rect" maxlength="80" placeholder="ไม่บังคับ" value="<?= e(old('teacher')) ?>">
      </div>
    </div>
    <div class="form-buttons">
      <button type="submit" class="btn btn-primary" data-dialog-submit><?= $classEditId ? 'บันทึก' : 'เพิ่ม' ?></button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </form>
</dialog>

<?php // ---------- กล่องลบบัญชี (ส่งไปที่ account-delete.php) ---------- ?>
<dialog class="dlg" id="delete-account-dialog" <?= error_of('delete', 'password') != '' ? 'data-autoshow' : '' ?>>
  <form method="POST" action="<?= e(url('account-delete')) ?>" class="dlg-body" novalidate data-once>
    <?= csrf_field() ?>
    <div class="dlg-title">ลบบัญชีของคุณใช่ไหม?</div>
    <p class="dlg-text">บัญชีและข้อมูลทั้งหมดของคุณจะถูกลบถาวร การลบนี้ย้อนกลับไม่ได้</p>
    <?php
    $pw_id = 'delete-password'; $pw_name = 'password'; $pw_label = 'กรอกรหัสผ่านเพื่อยืนยัน'; $pw_placeholder = 'รหัสผ่าน'; $pw_form = 'delete';
    include 'includes/password_field.php';
    ?>
    <div class="form-buttons">
      <button type="submit" class="btn btn-danger">ลบบัญชี</button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </form>
</dialog>

<?php // ---------- ยืนยันก่อนลบวิชา ---------- ?>
<dialog class="dlg" id="confirm-dialog">
  <div class="dlg-body">
    <div class="dlg-title" data-confirm-title>แน่ใจหรือไม่?</div>
    <p class="dlg-text" data-confirm-text></p>
    <div class="form-buttons" style="margin-top:0">
      <button type="button" class="btn btn-danger" data-confirm-ok>ลบ</button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </div>
</dialog>

<?php include 'includes/footer.php'; ?>
