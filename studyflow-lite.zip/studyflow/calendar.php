<?php
// =====================================================================
//  calendar.php : ปฏิทิน 3 มุมมอง
//    ?view=month  รายเดือน (ค่าเริ่มต้น)
//    ?view=week   รายสัปดาห์ (แสดงช่วงอ่านหนังสือตามชั่วโมง)
//    ?view=day    รายวัน
//    ?date=2026-11-25  วันที่ที่ต้องการดู
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();
$today = today();

// ---------- 1) อ่านค่าจาก URL ----------
$view = get('view');
if ($view != 'week' && $view != 'day') {
    $view = 'month';
}
$date = get('date');
if (! is_date($date)) {
    $date = $today;
}

// ---------- 2) หาวันแรก-วันสุดท้ายที่ต้องแสดง และลิงก์ ก่อนหน้า/ถัดไป ----------
if ($view == 'month') {
    $firstOfMonth = date('Y-m-01', strtotime($date));
    $lastOfMonth = date('Y-m-t', strtotime($date));
    $start = week_start($firstOfMonth);                 // เริ่มที่วันอาทิตย์
    $end = add_days(week_start($lastOfMonth), 6);       // จบที่วันเสาร์
    $prev = date('Y-m-d', strtotime($firstOfMonth . ' -1 month'));
    $next = date('Y-m-d', strtotime($firstOfMonth . ' +1 month'));
    $heading = thai_date($date, 'month');
} elseif ($view == 'week') {
    $start = week_start($date);
    $end = add_days($start, 6);
    $prev = add_days($date, -7);
    $next = add_days($date, 7);
    // หัวข้อ เช่น "22 – 28 พ.ย. 2569"
    if (date('n', strtotime($start)) == date('n', strtotime($end))) {
        $heading = date('j', strtotime($start)) . ' – ' . thai_date($end);
    } else {
        $heading = thai_date($start) . ' – ' . thai_date($end);
    }
} else {
    $start = $date;
    $end = $date;
    $prev = add_days($date, -1);
    $next = add_days($date, 1);
    $heading = thai_date($date, 'long');
}

// ---------- 3) เตรียมช่องของแต่ละวัน  $days['2026-11-25'] = ['allDay' => [...], 'timed' => [...]] ----------
//  allDay = งาน (แสดงด้านบนของวัน)   timed = ช่วงอ่านหนังสือ (แสดงตามชั่วโมง)
$days = [];
$d = $start;
while ($d <= $end) {
    $days[$d] = ['allDay' => [], 'timed' => []];
    $d = add_days($d, 1);
}

// ใส่งานลงในวันที่ต้องส่ง (การสอบขึ้นก่อน)
$tasks = get_tasks($userId, 't.due_date BETWEEN ? AND ?', [$start, $end],
    "t.due_time IS NULL, t.due_time, FIELD(t.type, 'exam', 'assignment', 'personal'), t.title");
foreach ($tasks as $task) {
    $days[$task->dueDate]['allDay'][] = $task->toArray();
}

// ใส่ช่วงอ่านหนังสือลงในวันที่อ่าน
$sessions = get_sessions($userId, 'ss.date BETWEEN ? AND ?', [$start, $end], 'ss.start_time');
foreach ($sessions as $session) {
    $days[$session['date']]['timed'][] = session_to_array($session);
}

// จัดคอลัมน์ให้รายการที่เวลาทับกัน แสดงเคียงข้างกัน (ใช้ในมุมมองสัปดาห์/วัน)
foreach ($days as $key => $day) {
    $days[$key]['timed'] = arrange_lanes($day['timed']);
}

// ---------- 4) ช่วงชั่วโมงที่แสดง : 07:00 - 21:00  ขยายเพิ่มถ้ามีรายการเช้ากว่า/ดึกกว่า ----------
$fromHour = 7;
$toHour = 21;
foreach ($days as $day) {
    foreach ($day['timed'] as $item) {
        $startHour = (int) substr($item['start'], 0, 2);
        $endHour = (int) ceil(to_minutes($item['end']) / 60);
        if ($startHour < $fromHour) {
            $fromHour = $startHour;
        }
        if ($endHour > $toHour) {
            $toHour = min(24, $endHour);
        }
    }
}

// ข้อมูลสำหรับกล่องเพิ่ม/แก้ไข
$subjects = get_subjects($userId);
$assessments = open_assessments($userId);

// ลิงก์ไปยังมุมมอง + วันที่
function calendar_link($view, $date)
{
    return url('calendar', ['view' => $view, 'date' => $date]);
}

// จัดรายการที่มีเวลาเป็นคอลัมน์ (lane) ไม่ให้ทับกัน
//   เช่น 09:00-10:00 กับ 09:30-11:00 ทับกัน -> อันแรกอยู่คอลัมน์ 0 อันที่สองคอลัมน์ 1
//   แต่ละรายการได้ค่า 'lane' (อยู่คอลัมน์ที่เท่าไร) และ 'lanes' (กลุ่มนี้มีทั้งหมดกี่คอลัมน์)
function arrange_lanes($items)
{
    $result = [];
    $group = [];          // รายการที่เวลาทับกันต่อเนื่อง
    $groupEnd = 0;        // เวลาจบช้าสุดของกลุ่ม (นาที)
    $laneEnds = [];       // เวลาจบของรายการสุดท้ายในแต่ละคอลัมน์

    foreach ($items as $item) {
        $itemStart = to_minutes($item['start']);
        $itemEnd = to_minutes($item['end']);

        // รายการนี้เริ่มหลังกลุ่มเดิมจบ -> ปิดกลุ่มเดิม เริ่มกลุ่มใหม่
        if (count($group) > 0 && $itemStart >= $groupEnd) {
            foreach ($group as $member) {
                $member['lanes'] = count($laneEnds);
                $result[] = $member;
            }
            $group = [];
            $laneEnds = [];
            $groupEnd = 0;
        }

        // หาคอลัมน์แรกที่ว่าง (รายการก่อนหน้าในคอลัมน์นั้นจบแล้ว)
        $lane = 0;
        while (isset($laneEnds[$lane]) && $laneEnds[$lane] > $itemStart) {
            $lane++;
        }
        $laneEnds[$lane] = $itemEnd;
        $item['lane'] = $lane;
        $group[] = $item;
        $groupEnd = max($groupEnd, $itemEnd);
    }

    // ปิดกลุ่มสุดท้าย
    foreach ($group as $member) {
        $member['lanes'] = count($laneEnds);
        $result[] = $member;
    }
    return $result;
}

// แสดงรายการ 1 ชิ้นเป็น "ชิป" เล็ก ๆ ในช่องวัน
function show_chip($item)
{
    $classes = 'chip';
    if ($item['done']) {
        $classes .= ' is-done';
    }
    if (($item['type'] ?? '') == 'exam') {
        $classes .= ' is-exam';
    }

    // ด้านหน้าชิป : เวลา หรือ ป้ายประเภท
    $front = '';
    if ($item['kind'] == 'session') {
        $front = '<span class="chip-time">' . $item['start'] . '</span>';
    } elseif ($item['due_time'] != '') {
        $front = '<span class="chip-time">' . $item['due_time'] . '</span>';
    } elseif ($item['type'] == 'assignment') {
        $front = '<span class="chip-tag">งาน</span>';
    } elseif ($item['type'] == 'exam') {
        $front = '<span class="chip-tag">สอบ</span>';
    }

    return '<button type="button" class="' . $classes . '" style="--c: ' . e($item['color']) . '" data-item="' . e(item_json($item)) . '">'
        . $front . '<span class="chip-text">' . e($item['title']) . '</span></button>';
}

$title = 'ปฏิทิน';
$page = 'calendar';
$scripts = ['js/calendar.js'];
include 'includes/header.php';
?>
<div class="page page-wide" id="calendar">
  <div class="cal-head">
    <div>
      <h1 class="page-title">ปฏิทิน</h1>
      <p class="page-sub">วางแผนช่วงอ่านหนังสือ งานที่มอบหมาย การสอบ และสิ่งที่ต้องทำ</p>
    </div>
    <?php // ปุ่มเพิ่มรายการ : ดูเดือนนี้อยู่ = เพิ่มวันนี้, ดูเดือนอื่น = เพิ่มวันที่ที่เลือก ?>
    <button type="button" class="btn btn-primary btn-lg" data-add-date="<?= $view == 'month' && substr($date, 0, 7) == substr($today, 0, 7) ? $today : $date ?>">
      <?= icon('plus') ?> เพิ่มรายการ
    </button>
  </div>

  <?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

  <div class="cal">
    <div class="cal-bar">
      <a class="cal-nav" href="<?= e(calendar_link($view, $prev)) ?>" aria-label="ก่อนหน้า"><?= icon('back') ?></a>
      <a class="cal-nav" href="<?= e(calendar_link($view, $next)) ?>" aria-label="ถัดไป"><?= icon('arrow') ?></a>
      <a class="cal-today" href="<?= e(calendar_link($view, $today)) ?>">วันนี้</a>
      <h2 class="cal-title"><?= $heading ?></h2>
      <nav class="seg cal-views" aria-label="มุมมองปฏิทิน">
        <?php foreach (['month' => 'เดือน', 'week' => 'สัปดาห์', 'day' => 'วัน'] as $v => $label): ?>
          <a class="seg-btn <?= $view == $v ? 'is-active' : '' ?>" href="<?= e(calendar_link($v, $date)) ?>" <?= $view == $v ? 'aria-current="page"' : '' ?>><?= $label ?></a>
        <?php endforeach; ?>
      </nav>
    </div>

    <?php if ($view == 'month'): ?>
      <?php // ==================== มุมมองรายเดือน ==================== ?>
      <div class="month" role="grid" aria-label="<?= $heading ?>">
        <?php foreach (DAYS_SHORT as $dayName): ?>
          <div class="month-dow" role="columnheader"><?= $dayName ?></div>
        <?php endforeach; ?>

        <?php foreach ($days as $d => $day): ?>
          <?php
          $items = array_merge($day['allDay'], $day['timed']);   // รวมงาน + การอ่าน
          $isOtherMonth = substr($d, 0, 7) != substr($date, 0, 7);
          ?>
          <div class="mcell <?= $isOtherMonth ? 'is-other' : '' ?> <?= $d == $today ? 'is-today' : '' ?>" role="gridcell" data-add-date="<?= $d ?>">
            <a class="mnum" href="<?= e(calendar_link('day', $d)) ?>" aria-label="<?= thai_date($d, 'long') ?>"><?= (int) substr($d, 8, 2) ?></a>
            <?php // แสดงได้ช่องละ 3 รายการ ที่เหลือเป็นลิงก์ "+อีก n รายการ" ?>
            <?php for ($i = 0; $i < count($items) && $i < 3; $i++): ?>
              <?= show_chip($items[$i]) ?>
            <?php endfor; ?>
            <?php if (count($items) > 3): ?>
              <a class="more-link" href="<?= e(calendar_link('day', $d)) ?>">+อีก <?= count($items) - 3 ?> รายการ</a>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>

    <?php else: ?>
      <?php
      // ==================== มุมมองรายสัปดาห์ / รายวัน ====================
      $hourHeight = 52;                   // ความสูงของ 1 ชั่วโมง (pixel)
      $pixelPerMinute = $hourHeight / 60;
      $baseMinute = $fromHour * 60;        // นาทีที่ด้านบนสุดของตาราง
      ?>
      <div class="tgrid-scroll">
        <div class="tgrid <?= $view == 'day' ? 'is-day' : '' ?>" style="--cols: <?= count($days) ?>; --hour-h: <?= $hourHeight ?>px"
             data-from-hour="<?= $fromHour ?>" data-hour-h="<?= $hourHeight ?>">

          <?php if ($view == 'week'): ?>
            <div class="trow">
              <div class="thead-cell"></div>
              <?php foreach ($days as $d => $day): ?>
                <div class="thead-cell <?= $d == $today ? 'is-today' : '' ?>">
                  <div class="th-dow"><?= DAYS_SHORT[(int) date('w', strtotime($d))] ?></div>
                  <a class="th-num" href="<?= e(calendar_link('day', $d)) ?>" aria-label="<?= thai_date($d, 'long') ?>"><?= (int) substr($d, 8, 2) ?></a>
                </div>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <div class="day-head">
              <span class="th-num" style="<?= $date == $today ? 'background:var(--primary);color:var(--on-primary)' : '' ?>"><?= (int) substr($date, 8, 2) ?></span>
              <div>
                <div class="th-dow"><?= DAYS_FULL[(int) date('w', strtotime($date))] ?></div>
                <div style="font-weight:600"><?= thai_date($date, 'month') ?></div>
              </div>
            </div>
          <?php endif; ?>

          <?php // แถว "ทั้งวัน" : งานที่ต้องส่ง ?>
          <div class="trow allday-row">
            <div class="allday-label">ทั้งวัน</div>
            <?php foreach ($days as $d => $day): ?>
              <div class="allday-cell" data-add-date="<?= $d ?>">
                <?php foreach ($day['allDay'] as $item): ?><?= show_chip($item) ?><?php endforeach; ?>
              </div>
            <?php endforeach; ?>
          </div>

          <?php // ตารางชั่วโมง : ช่วงอ่านหนังสือ ?>
          <div class="trow tbody">
            <div class="hour-gutter">
              <?php for ($h = $fromHour; $h < $toHour; $h++): ?>
                <div class="hour-label"><?= $h == $fromHour ? '' : sprintf('%02d:00', $h) ?></div>
              <?php endfor; ?>
            </div>
            <?php foreach ($days as $d => $day): ?>
              <div class="tcol <?= $d == $today ? 'is-today' : '' ?>" data-add-date="<?= $d ?>" data-timed>
                <?php for ($h = $fromHour; $h < $toHour; $h++): ?><div class="hour-line"></div><?php endfor; ?>

                <?php foreach ($day['timed'] as $item): ?>
                  <?php
                  // คำนวณตำแหน่ง : ระยะจากด้านบน = (นาทีที่เริ่ม - นาทีบนสุด) x pixel ต่อนาที
                  $top = (to_minutes($item['start']) - $baseMinute) * $pixelPerMinute;
                  $height = max(22, (to_minutes($item['end']) - to_minutes($item['start'])) * $pixelPerMinute - 2);
                  $width = 100 / $item['lanes'];
                  $left = $item['lane'] * $width;
                  ?>
                  <button type="button" class="ev is-session <?= $item['done'] ? 'is-done' : '' ?>"
                          style="--c: <?= e($item['color']) ?>; top: <?= $top ?>px; height: <?= $height ?>px; left: calc(<?= $left ?>% + 2px); width: calc(<?= $width ?>% - 4px)"
                          data-item="<?= e(item_json($item)) ?>">
                    <span class="ev-title"><?= e($item['title']) ?></span>
                    <span class="ev-meta"><?= $item['start'] ?> – <?= $item['end'] ?></span>
                  </button>
                <?php endforeach; ?>

                <?php // เส้นสีแดง = เวลาปัจจุบัน (เฉพาะวันนี้) ?>
                <?php $nowMinute = (int) date('G') * 60 + (int) date('i'); ?>
                <?php if ($d == $today && $nowMinute >= $baseMinute && $nowMinute <= $toHour * 60): ?>
                  <div class="now-line" style="top: <?= ($nowMinute - $baseMinute) * $pixelPerMinute ?>px" aria-hidden="true"></div>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php include 'includes/dialogs.php'; ?>
<?php include 'includes/footer.php'; ?>
