<?php
// =====================================================================
//  study.php : หน้าอ่านหนังสือ
//    - จับเวลาอ่านหนังสือ (กดเริ่ม / หยุดชั่วคราว / หยุดและบันทึก)
//    - การอ่านที่เสร็จแล้ว + ช่วงอ่านที่วางแผนไว้
//    ?subject=3  ดูเฉพาะวิชา id 3
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();

$subjects = get_subjects($userId);

// กรองตามวิชา (ถ้าเลือก)
$subjectFilter = null;
if (get('subject') != '') {
    $subjectFilter = find_subject($userId, get('subject'));
}
$where = '';
$params = [];
if ($subjectFilter != null) {
    $where = ' AND ss.subject_id = ?';
    $params[] = $subjectFilter['id'];
}

// การอ่านที่เสร็จแล้ว (ใหม่สุดขึ้นก่อน) และที่วางแผนไว้ (ใกล้สุดขึ้นก่อน)
$completed = get_sessions($userId, "ss.status = 'completed'" . $where, $params, 'ss.date DESC, ss.start_time DESC');
$planned = get_sessions($userId, "ss.status = 'planned'" . $where, $params, 'ss.date, ss.start_time');

// รวมเวลาที่อ่านไปทั้งหมด (บวกทีละรายการด้วย loop)
$completedMinutes = 0;
foreach ($completed as $session) {
    $completedMinutes += (int) $session['actual_minutes'];
}
list($weekCount, $weekMinutes) = week_study_totals($userId);

$assessments = open_assessments($userId);

$title = 'อ่านหนังสือ';
$page = 'study';
$scripts = ['js/calendar.js', 'js/study.js', 'js/timer.js'];
include 'includes/header.php';
?>
<div class="page" id="study-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">อ่านหนังสือ</h1>
      <p class="page-sub">จับเวลาอ่านหนังสือ วางแผนเตรียมตัว และเก็บบันทึกการอ่านที่ทำเสร็จ</p>
    </div>
  </div>

  <?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

  <div class="study-bar">
    <span class="study-stats">
      <strong>สัปดาห์นี้</strong>
      <span class="dot-sep">•</span> อ่านเสร็จ <?= $weekCount ?> ครั้ง
      <span class="dot-sep">•</span> <strong><?= duration_text($weekMinutes) ?></strong>
    </span>
  </div>

  <?php // ---------- จับเวลาอ่านหนังสือ (js/timer.js เป็นตัวนับเวลา) ---------- ?>
  <section class="card timer-card" id="timer" data-state="ready">
    <div class="timer-left">
      <div class="timer-title">
        <span>จับเวลาอ่านหนังสือ</span>
        <span class="state-badge" data-state-badge>พร้อม</span>
      </div>
      <p class="timer-sub">เลือกงานหรือวิชา แล้วจับเวลาที่อ่านจริง</p>

      <div class="timer-pick" data-when="ready">
        <label class="sr-only" for="timer-target">เลือกสิ่งที่จะอ่าน</label>
        <select id="timer-target" class="select timer-select">
          <option value="">เลือกสิ่งที่จะอ่าน</option>
          <?php if (count($assessments) > 0): ?>
            <optgroup label="งานประเมินผล">
              <?php foreach ($assessments as $t): ?>
                <option value="task:<?= $t->id ?>"><?= e($t->typeLabel() . ' · ' . $t->title) ?></option>
              <?php endforeach; ?>
            </optgroup>
          <?php endif; ?>
          <?php if (count($subjects) > 0): ?>
            <optgroup label="วิชา">
              <?php foreach ($subjects as $s): ?>
                <option value="subject:<?= $s['id'] ?>"><?= e($s['name']) ?></option>
              <?php endforeach; ?>
            </optgroup>
          <?php endif; ?>
        </select>
        <span class="field-error" data-timer-error hidden>เลือกสิ่งที่จะอ่านก่อน</span>
        <?php if (count($subjects) == 0): ?>
          <span class="field-hint"><a href="<?= e(url('settings')) ?>#subjects">เพิ่มวิชาในหน้าตั้งค่าก่อน</a></span>
        <?php endif; ?>
      </div>
      <div class="timer-now" data-when="running paused" hidden>
        <span class="timer-now-k">กำลังอ่าน</span>
        <span class="timer-now-v" data-timer-label></span>
      </div>
    </div>

    <div class="timer-right">
      <div class="timer-display" data-timer-display aria-live="off">00:00:00</div>
      <div class="timer-actions">
        <button type="button" class="btn btn-primary btn-lg" data-act="start" data-when="ready"><?= icon('play') ?> เริ่ม</button>
        <button type="button" class="btn btn-outline btn-lg" data-act="pause" data-when="running" hidden>หยุดชั่วคราว</button>
        <button type="button" class="btn btn-primary btn-lg" data-act="resume" data-when="paused" hidden><?= icon('play') ?> ทำต่อ</button>
        <button type="button" class="btn btn-primary btn-lg" data-act="stop" data-when="running paused" hidden>หยุดและบันทึก</button>
        <button type="button" class="btn btn-ghost" data-act="discard" data-when="paused" hidden>ทิ้ง</button>
      </div>
    </div>

    <?php // กด "หยุดและบันทึก" แล้ว JavaScript จะเติมค่าลงฟอร์มนี้และส่งไปที่ timer-save.php ?>
    <form method="POST" action="<?= e(url('timer-save')) ?>" id="timer-form" hidden>
      <?= csrf_field() ?>
      <input type="hidden" name="target">
      <input type="hidden" name="minutes">
      <input type="hidden" name="date">
      <input type="hidden" name="start_time">
    </form>
  </section>

  <div class="log-tools" style="margin-top:24px">
    <?php // ปุ่มกรองตามวิชา ?>
    <nav class="chip-filter" aria-label="วิชา">
      <a class="fchip <?= $subjectFilter == null ? 'is-active' : '' ?>" href="<?= e(url('study')) ?>">ทั้งหมด</a>
      <?php foreach ($subjects as $s): ?>
        <a class="fchip <?= $subjectFilter != null && $subjectFilter['id'] == $s['id'] ? 'is-active' : '' ?>" style="--c: <?= e($s['color']) ?>" href="<?= e(url('study', ['subject' => $s['id']])) ?>">
          <span class="swatch-dot" style="background: <?= e($s['color']) ?>"></span><?= e($s['name']) ?></a>
      <?php endforeach; ?>
    </nav>
    <button type="button" class="btn btn-primary" data-log-study data-subject="<?= $subjectFilter['id'] ?? '' ?>"><?= icon('plus') ?> บันทึกการอ่าน</button>
  </div>

  <?php // ---------- การอ่านที่เสร็จแล้ว ---------- ?>
  <section class="card log-card">
    <div class="log-head">
      <div>
        <h2 class="card-title">การอ่านที่เสร็จแล้ว</h2>
        <div class="log-sub"><?= count($completed) ?> ครั้ง · <?= duration_text($completedMinutes) ?></div>
      </div>
      <?php if (count($completed) > 0): ?>
        <button type="button" class="link-btn" data-toggle-history aria-expanded="false" aria-controls="history"
                data-show="ดูประวัติ" data-hide="ซ่อนประวัติ">ดูประวัติ</button>
      <?php endif; ?>
    </div>
    <div class="log-list" id="history" hidden>
      <?php foreach ($completed as $s): ?>
        <button type="button" class="log-row" style="--c: <?= e($s['color']) ?>" data-item="<?= e(item_json(session_to_array($s))) ?>">
          <span class="log-date"><?= thai_date($s['date']) ?><span><?= $s['start'] ?></span></span>
          <span class="log-main">
            <span class="log-title"><?= e($s['title']) ?></span>
            <span class="task-meta">
              <?php if ($s['subject_name'] != null): ?><span class="swatch-dot" style="background: <?= e($s['color']) ?>"></span><?= e($s['subject_name']) ?><?php endif; ?>
              <?php if ($s['task_title'] != null): ?> · <?= e($s['task_title']) ?><?php endif; ?>
            </span>
          </span>
          <span class="log-min"><?= duration_text((int) $s['actual_minutes']) ?></span>
        </button>
      <?php endforeach; ?>
    </div>
  </section>

  <?php // ---------- ช่วงอ่านที่วางแผนไว้ ---------- ?>
  <section class="card log-card">
    <div class="log-head">
      <div>
        <h2 class="card-title">ช่วงอ่านที่วางแผนไว้</h2>
        <div class="log-sub">แผนการเตรียมตัว จะนับเป็นเวลาอ่านเมื่อทำเสร็จแล้วเท่านั้น</div>
      </div>
      <span class="log-count">วางแผนไว้ <?= count($planned) ?> ครั้ง</span>
    </div>
    <?php if (count($planned) == 0): ?>
      <div class="empty upcoming-empty">
        <div class="empty-title">ยังไม่ได้วางแผน</div>
        <div class="empty-sub">กด “วางแผนอ่าน” ที่งานประเมินผล เพื่อวางแผนเตรียมตัวลงปฏิทิน</div>
      </div>
    <?php else: ?>
      <div class="log-list">
        <?php foreach ($planned as $s): ?>
          <div class="log-row is-static" style="--c: <?= e($s['color']) ?>">
            <span class="log-date"><?= thai_date($s['date']) ?><span><?= $s['start'] ?> – <?= $s['end'] ?></span></span>
            <button type="button" class="log-main log-open" data-item="<?= e(item_json(session_to_array($s))) ?>">
              <span class="log-title"><?= e($s['title']) ?>
                <?php if ($s['date'] < today()): ?><span class="due-badge tone-overdue">พลาดไป</span><?php endif; ?>
              </span>
              <span class="task-meta">
                <?php if ($s['subject_name'] != null): ?><span class="swatch-dot" style="background: <?= e($s['color']) ?>"></span><?= e($s['subject_name']) ?><?php endif; ?>
                <?php if ($s['task_title'] != null): ?> · <?= e($s['task_title']) ?><?php endif; ?>
                · <?= duration_text($s['duration_minutes']) ?>
              </span>
            </button>
            <form method="POST" action="<?= e(url('session-toggle', ['id' => $s['id']])) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="return" value="<?= e(current_page()) ?>">
              <button type="submit" class="btn btn-outline btn-sm">ทำเสร็จแล้ว</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
</div>

<?php include 'includes/dialogs.php'; ?>
<?php include 'includes/footer.php'; ?>
