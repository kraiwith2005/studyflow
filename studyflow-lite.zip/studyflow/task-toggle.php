<?php
// task-toggle.php : สลับสถานะงาน เสร็จแล้ว <-> ยังไม่เสร็จ
require 'includes/start.php';
require_post();

$task = find_task(user_id(), get('id'));
if ($task == null) {
    redirect('tasks');
}

if ($task->isDone()) {
    db_run('UPDATE tasks SET completed_at = NULL, updated_at = ? WHERE id = ? AND user_id = ?', [now(), $task->id, user_id()]);
    set_message('ทำเครื่องหมายว่ายังไม่เสร็จ');
} else {
    db_run('UPDATE tasks SET completed_at = ?, updated_at = ? WHERE id = ? AND user_id = ?', [now(), now(), $task->id, user_id()]);
    set_message('ทำเครื่องหมายว่าเสร็จแล้ว');
}
go_back();
