// =====================================================================
//  calendar.js : กล่องเพิ่ม / แก้ไข / ดูรายละเอียด  (ใช้ในหน้า วันนี้ ปฏิทิน งาน อ่านหนังสือ)
//  ข้อมูลของแต่ละรายการอยู่ใน data-item="{...JSON...}" ที่ PHP ใส่ไว้ในปุ่ม
// =====================================================================
(function () {
  var CAL = window.SF_CAL;

  function $(selector, scope) { return (scope || document).querySelector(selector); }
  function $all(selector, scope) { return Array.from((scope || document).querySelectorAll(selector)); }

  // วันที่ภาษาไทย (ปี พ.ศ.) เช่น "25 พ.ย. 2569"
  function shortDate(iso) {
    return new Intl.DateTimeFormat('th-TH-u-ca-buddhist', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(iso + 'T12:00:00'));
  }
  function longDate(iso) {
    return new Intl.DateTimeFormat('th-TH-u-ca-buddhist', { weekday: 'short', day: 'numeric', month: 'short' }).format(new Date(iso + 'T12:00:00'));
  }

  // ---------- ทุกกล่อง : ปุ่มปิด และคลิกพื้นหลังเพื่อปิด ----------
  $all('dialog').forEach(function (dialog) {
    $all('[data-dialog-close]', dialog).forEach(function (button) {
      button.addEventListener('click', function () { dialog.close(); });
    });
    dialog.addEventListener('click', function (event) {
      if (event.target === dialog) { dialog.close(); }
    });
  });

  // ลบข้อความ error เก่าในฟอร์ม
  function clearErrors(form) {
    $all('.field-error', form).forEach(function (el) { el.remove(); });
    $all('.is-invalid', form).forEach(function (el) { el.classList.remove('is-invalid'); });
  }

  // ---------- 1) คลิกที่ช่องวัน หรือปุ่ม "เพิ่มรายการ" -> เปิดกล่องเลือกประเภท ----------
  var addDialog = $('#add-dialog');
  var picked = { date: CAL.today, time: null };

  document.addEventListener('click', function (event) {
    var cell = event.target.closest('[data-add-date]');
    if (!cell || event.target.closest('.chip, .ev, a, .more-link')) { return; }

    // ถ้าคลิกในตารางชั่วโมง : คำนวณเวลาจากตำแหน่งที่คลิก (ปัดเป็นทุก 30 นาที)
    var time = null;
    if (cell.hasAttribute('data-timed')) {
      var grid = cell.closest('.tgrid');
      var fromHour = Number(grid.dataset.fromHour);
      var hourHeight = Number(grid.dataset.hourH);
      var y = event.clientY - cell.getBoundingClientRect().top;
      var minutes = Math.round((y / hourHeight) * 60 / 30) * 30 + fromHour * 60;
      var hour = Math.min(23, Math.floor(minutes / 60));
      time = String(hour).padStart(2, '0') + ':' + String(minutes % 60).padStart(2, '0');
    }
    picked = { date: cell.dataset.addDate, time: time };
    $('[data-add-date-label]', addDialog).textContent = longDate(picked.date);
    addDialog.showModal();
  });

  $all('[data-choose]', addDialog).forEach(function (button) {
    button.addEventListener('click', function () {
      addDialog.close();
      openForm(button.dataset.choose, null, { date: picked.date, start_time: picked.time });
    });
  });

  // ---------- 2) ฟอร์มการอ่าน และฟอร์มงาน ----------
  var sessionDialog = $('#session-dialog');
  var taskDialog = $('#task-dialog');
  var taskLabels = JSON.parse(taskDialog.dataset.labels);

  function showFormDate(dialog) {
    var input = dialog === sessionDialog ? $('#s-date') : $('#t-date');
    $('[data-form-date]', dialog).textContent = input.value ? shortDate(input.value) : '';
  }
  $('#s-date').addEventListener('change', function () { showFormDate(sessionDialog); });
  $('#t-date').addEventListener('change', function () { showFormDate(taskDialog); });

  // เปิดฟอร์ม
  //   type    = 'session' | 'assignment' | 'exam' | 'personal'
  //   item    = ข้อมูลเดิม (ตอนแก้ไข) หรือ null (ตอนเพิ่มใหม่)
  //   prefill = ค่าที่ใส่ให้ล่วงหน้า เช่น { date: '2026-11-25' }
  function openForm(type, item, prefill) {
    prefill = prefill || {};
    var dialog = type === 'session' ? sessionDialog : taskDialog;
    var form = $('form', dialog);
    var editing = item !== null;
    form.reset();
    clearErrors(form);
    // แก้ไข -> ส่งไปที่ ...-save?id=5   เพิ่มใหม่ -> ส่งไปที่ ...-save
    form.action = editing ? item.urls.update : form.dataset.store;

    if (type === 'session') {
      var logOnly = !editing && prefill.mark_done;      // ปุ่ม "บันทึกการอ่าน" = อ่านเสร็จแล้ว
      form.querySelector('[name="mark_done"]').value = logOnly ? '1' : '';
      $('[data-form-title]', dialog).textContent = editing ? CAL.titles.editSession : (logOnly ? CAL.titles.logStudy : CAL.titles.addSession);
      $('#s-title').value = editing ? item.title : (prefill.title || '');
      $('#s-subject').value = editing ? (item.subject_id || '') : (prefill.subject_id || '');
      $('#s-date').value = editing ? item.date : prefill.date;
      $('#s-start').value = editing ? item.start : (prefill.start_time || '16:00');
      $('#s-duration').value = editing ? String(item.duration) : '60';
      $('#s-task').value = editing ? (item.task_id || '') : (prefill.task_id || '');
    } else {
      var labels = taskLabels[type];
      form.querySelector('[name="type"]').value = type;
      $('[data-form-title]', dialog).textContent = editing ? labels.edit : labels.add;
      $('#t-title').placeholder = labels.placeholder;
      $('[data-date-label]', dialog).firstChild.textContent = labels.date;
      $('[data-time-label]', dialog).textContent = labels.time;
      $('[data-subject-field]', dialog).hidden = type === 'personal';   // งานส่วนตัวไม่ต้องเลือกวิชา
      $('#t-title').value = editing ? item.title : '';
      $('#t-subject').value = editing ? (item.subject_id || '') : '';
      $('#t-date').value = editing ? item.date : prefill.date;
      $('#t-time').value = editing ? (item.due_time || '') : '';
      $('#t-link').value = editing ? (item.link || '') : '';
      $('#t-notes').value = editing ? (item.notes || '') : '';
      var priority = editing ? item.priority : 'normal';
      $all('[name="priority"]', dialog).forEach(function (radio) { radio.checked = radio.value === priority; });
    }
    $('[data-form-submit]', dialog).textContent = editing ? 'บันทึก' : 'เพิ่ม';
    showFormDate(dialog);
    dialog.showModal();
    $('input[name="title"]', dialog).focus();
  }
  window.SFCal = { openForm: openForm };   // ให้ไฟล์อื่น (tasks.js, study.js) เรียกใช้ได้

  // กรอกผิด -> PHP ใส่ data-autoshow ไว้ ให้เปิดกล่องค้างไว้พร้อม error
  [sessionDialog, taskDialog].forEach(function (dialog) {
    if (dialog.hasAttribute('data-autoshow')) {
      showFormDate(dialog);
      dialog.showModal();
    }
  });

  // ---------- 3) คลิกที่รายการ -> กล่องรายละเอียด ----------
  var detail = $('#detail-dialog');
  var current = null;

  function setRow(key, value) {
    var row = $('[data-row="' + key + '"]', detail);
    var cell = $('[data-d="' + key + '"]', detail);
    if (cell) { cell.textContent = value || ''; }
    if (row) { row.hidden = !value; }       // ไม่มีค่า = ซ่อนแถวนั้น
  }

  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-item]');
    if (!button) { return; }
    var item = JSON.parse(button.dataset.item);
    current = item;

    $('[data-d="dot"]', detail).style.background = item.color;
    setRow('typeLabel', item.typeLabel);
    setRow('title', item.title);
    setRow('dateLabel', item.dateLabel);
    setRow('timeLabel', item.durationLabel ? item.timeLabel + ' (' + item.durationLabel + ')' : item.timeLabel);
    setRow('subject', item.subject);
    setRow('task', item.task);
    setRow('status', item.done ? CAL.strings.done : CAL.strings.notDone);
    setRow('priorityLabel', item.priority && item.priority !== 'normal' ? item.priorityLabel : '');
    setRow('notes', item.notes);

    var link = $('[data-d-link]', detail);
    $('[data-row="linkRow"]', detail).hidden = !item.link;
    if (item.link) {
      link.href = item.link;
      link.textContent = item.link.replace(/^https?:\/\//, '').slice(0, 60);
    }

    // ตั้งปลายทางของปุ่ม "ทำเสร็จแล้ว" และ "ลบ"
    $('[data-toggle-form]', detail).action = item.urls.toggle;
    $('[data-toggle-label]', detail).textContent = item.done ? CAL.strings.markNotDone : CAL.strings.markDone;
    var deleteForm = $('[data-delete-form]', detail);
    deleteForm.action = item.urls.destroy;
    deleteForm.dataset.confirm = CAL.strings.deleteQ.replace(':name', item.title);
    delete deleteForm.dataset.confirmed;
    detail.showModal();
  });

  $('[data-edit]', detail).addEventListener('click', function () {
    detail.close();
    openForm(current.kind === 'session' ? 'session' : current.type, current);
  });

  // ---------- 4) ถามยืนยันก่อนลบ ----------
  var confirmDialog = $('#confirm-dialog');
  var waitingForm = null;
  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!form.matches('form[data-confirm]') || form.dataset.confirmed) { return; }
    event.preventDefault();                 // หยุดไว้ก่อน รอผู้ใช้กดยืนยัน
    waitingForm = form;
    $('[data-confirm-title]', confirmDialog).textContent = form.dataset.confirm;
    $('[data-confirm-text]', confirmDialog).textContent = form.dataset.confirmText || '';
    detail.close();
    confirmDialog.showModal();
  });
  $('[data-confirm-ok]', confirmDialog).addEventListener('click', function () {
    waitingForm.dataset.confirmed = '1';
    this.disabled = true;
    waitingForm.requestSubmit();
  });
})();
