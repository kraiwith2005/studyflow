// =====================================================================
//  timer.js : จับเวลาอ่านหนังสือ (หน้าอ่านหนังสือ)
//  สถานะ 3 แบบ : ready (พร้อม) -> running (กำลังจับเวลา) <-> paused (หยุดชั่วคราว)
//  เก็บสถานะไว้ใน localStorage ของเบราว์เซอร์ ปิดหน้า/เปลี่ยนหน้าแล้วกลับมา เวลายังนับต่อ
//  กด "หยุดและบันทึก" -> ส่งจำนวนนาทีไปบันทึกที่ timer-save.php
// =====================================================================
(function () {
  var card = document.getElementById('timer');
  var display = card.querySelector('[data-timer-display]');
  var badge = card.querySelector('[data-state-badge]');
  var select = document.getElementById('timer-target');
  var error = card.querySelector('[data-timer-error]');
  var STORAGE_KEY = 'sf.timer';
  var badgeText = { ready: 'พร้อม', running: 'กำลังจับเวลา', paused: 'หยุดชั่วคราว' };

  // ข้อมูลของตัวจับเวลา (null = ยังไม่ได้เริ่ม)
  //   target    : สิ่งที่อ่าน เช่น "subject:3" หรือ "task:12"
  //   label     : ชื่อที่แสดง
  //   firstStart: เวลาที่กดเริ่มครั้งแรก (มิลลิวินาที)
  //   runStart  : เวลาที่เริ่มนับรอบนี้ (null = หยุดชั่วคราวอยู่)
  //   saved     : เวลาที่นับไว้แล้วจากรอบก่อน ๆ (มิลลิวินาที)
  var timer = load();

  function load() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch (e) { return null; }
  }
  function save() {
    try {
      if (timer) { localStorage.setItem(STORAGE_KEY, JSON.stringify(timer)); } else { localStorage.removeItem(STORAGE_KEY); }
    } catch (e) { /* ใช้ localStorage ไม่ได้ ก็ยังจับเวลาได้ตราบที่ไม่ปิดหน้า */ }
  }

  // เวลาที่อ่านไปทั้งหมด (มิลลิวินาที)
  function elapsed() {
    if (!timer) { return 0; }
    var total = timer.saved;
    if (timer.runStart) { total += Date.now() - timer.runStart; }
    return total;
  }

  // แปลงมิลลิวินาที -> "ชั่วโมง:นาที:วินาที"
  function format(ms) {
    var seconds = Math.floor(ms / 1000);
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = seconds % 60;
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }

  function state() {
    if (!timer) { return 'ready'; }
    return timer.runStart ? 'running' : 'paused';
  }

  // อัปเดตหน้าจอ : ตัวเลข, ป้ายสถานะ, ปุ่มที่แสดงตามสถานะ
  function render() {
    var now = state();
    card.dataset.state = now;
    badge.textContent = badgeText[now];
    display.textContent = format(elapsed());
    card.querySelector('[data-timer-label]').textContent = timer ? timer.label : '';
    card.querySelectorAll('[data-when]').forEach(function (el) {
      el.hidden = el.dataset.when.split(' ').indexOf(now) === -1;
    });
  }

  // ---------- ปุ่มต่าง ๆ ----------
  card.querySelector('[data-act="start"]').addEventListener('click', function () {
    if (select.value === '') {             // ยังไม่ได้เลือกว่าจะอ่านอะไร
      error.hidden = false;
      select.focus();
      return;
    }
    error.hidden = true;
    var label = select.options[select.selectedIndex].text;
    timer = { target: select.value, label: label, firstStart: Date.now(), runStart: Date.now(), saved: 0 };
    save();
    render();
  });

  card.querySelector('[data-act="pause"]').addEventListener('click', function () {
    timer.saved = elapsed();               // เก็บเวลาที่นับได้ไว้
    timer.runStart = null;
    save();
    render();
  });

  card.querySelector('[data-act="resume"]').addEventListener('click', function () {
    timer.runStart = Date.now();           // เริ่มนับรอบใหม่
    save();
    render();
  });

  card.querySelector('[data-act="discard"]').addEventListener('click', function () {
    if (!window.confirm('ทิ้งการจับเวลานี้ใช่ไหม? เวลาที่จับไว้จะไม่ถูกบันทึก')) { return; }
    timer = null;
    save();
    render();
  });

  card.querySelector('[data-act="stop"]').addEventListener('click', function () {
    var form = document.getElementById('timer-form');
    var start = new Date(timer.firstStart);
    form.elements.target.value = timer.target;
    form.elements.minutes.value = Math.round(elapsed() / 60000);    // มิลลิวินาที -> นาที
    form.elements.date.value = start.getFullYear() + '-' + String(start.getMonth() + 1).padStart(2, '0') + '-' + String(start.getDate()).padStart(2, '0');
    form.elements.start_time.value = String(start.getHours()).padStart(2, '0') + ':' + String(start.getMinutes()).padStart(2, '0');
    timer = null;
    save();
    form.submit();
  });

  render();
  setInterval(function () {               // อัปเดตตัวเลขบนหน้าจอ วินาทีละ 4 ครั้ง (ให้ตัวเลขเปลี่ยนตรงจังหวะ)
    if (state() === 'running') { display.textContent = format(elapsed()); }
  }, 250);
})();
