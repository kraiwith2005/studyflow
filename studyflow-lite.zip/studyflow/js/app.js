// =====================================================================
//  app.js : JavaScript ที่ใช้ทุกหน้า
//  ทำงานแบบ "event" : รอผู้ใช้คลิก แล้วค่อยทำงาน (คล้าย command ของปุ่มใน tkinter)
// =====================================================================

// ---------- ปุ่มรูปตา : แสดง / ซ่อนรหัสผ่าน ----------
document.querySelectorAll('[data-toggle-password]').forEach(function (button) {
  button.addEventListener('click', function () {
    var input = document.getElementById(button.dataset.togglePassword);
    if (input.type === 'password') {
      input.type = 'text';
      button.setAttribute('aria-label', 'ซ่อนรหัสผ่าน');
    } else {
      input.type = 'password';
      button.setAttribute('aria-label', 'แสดงรหัสผ่าน');
    }
  });
});

// ---------- กดส่งฟอร์มแล้ว ปิดปุ่มไว้ กันกดซ้ำ (จะได้ไม่บันทึกซ้ำ 2 ครั้ง) ----------
document.querySelectorAll('form[data-once]').forEach(function (form) {
  form.addEventListener('submit', function () {
    form.querySelectorAll('button[type="submit"]').forEach(function (b) { b.disabled = true; });
  });
});

// ---------- เมนูบัญชี (กดวงกลมชื่อมุมขวาบน) ----------
var menuButton = document.getElementById('avatar-btn');
var menu = document.getElementById('avatar-menu');
if (menuButton && menu) {
  menuButton.addEventListener('click', function (event) {
    event.stopPropagation();
    var isOpen = menu.classList.toggle('is-open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
  });
  // คลิกที่อื่น หรือกด Esc = ปิดเมนู
  document.addEventListener('click', function (event) {
    if (!menu.contains(event.target)) {
      menu.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded', 'false');
    }
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      menu.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded', 'false');
    }
  });
}

// ---------- ปุ่มสลับโหมดสว่าง / มืด ----------
// เปลี่ยนสีทันที แล้วส่งค่าไปบันทึกที่ theme-save.php เบื้องหลัง (ไม่ต้องโหลดหน้าใหม่)
var themeButton = document.getElementById('theme-toggle');
var saveStatus = document.getElementById('save-status');

function showSaveStatus(state) {
  var words = { saving: 'กำลังบันทึก…', saved: 'บันทึกแล้ว', error: 'บันทึกไม่สำเร็จ' };
  saveStatus.dataset.state = state;
  saveStatus.textContent = words[state];
}

if (themeButton) {
  themeButton.addEventListener('click', function () {
    var html = document.documentElement;
    var oldTheme = html.dataset.theme === 'dark' ? 'dark' : 'light';
    var newTheme = oldTheme === 'dark' ? 'light' : 'dark';
    html.dataset.theme = newTheme;
    themeButton.setAttribute('aria-label', newTheme === 'dark' ? 'เปลี่ยนเป็นโหมดสว่าง' : 'เปลี่ยนเป็นโหมดมืด');
    showSaveStatus('saving');

    fetch(themeButton.dataset.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
      },
      body: JSON.stringify({ theme: newTheme })
    }).then(function (response) {
      if (!response.ok) { throw new Error('save failed'); }
      showSaveStatus('saved');
    }).catch(function () {
      html.dataset.theme = oldTheme;     // บันทึกไม่ได้ -> เปลี่ยนกลับ
      showSaveStatus('error');
    });
  });
}
