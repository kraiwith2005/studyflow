// =====================================================================
//  tasks.js : หน้างาน  (ปุ่มตัวกรอง, ย่อ/ขยายกลุ่ม, ปุ่มเพิ่ม, ปุ่มวางแผนอ่าน)
// =====================================================================
(function () {
  var today = window.SF_CAL.today;

  // ปุ่ม "ตัวกรอง" : แสดง / ซ่อนแถบตัวกรอง
  var filterButton = document.querySelector('[data-toggle-filter]');
  filterButton.addEventListener('click', function () {
    var bar = document.getElementById('filter-bar');
    bar.hidden = !bar.hidden;
    filterButton.setAttribute('aria-expanded', String(!bar.hidden));
    filterButton.classList.toggle('is-on', !bar.hidden);
  });

  // ย่อ / ขยายกลุ่มงาน (จำไว้ในเบราว์เซอร์ด้วย localStorage)
  var saved = [];
  try { saved = JSON.parse(localStorage.getItem('sf.tasks.collapsed') || '[]'); } catch (e) { saved = []; }

  document.querySelectorAll('[data-group]').forEach(function (group) {
    var button = group.querySelector('.tgroup-toggle');
    var name = group.dataset.group;
    if (saved.indexOf(name) !== -1) {
      group.classList.add('is-collapsed');
      button.setAttribute('aria-expanded', 'false');
    }
    button.addEventListener('click', function () {
      var collapsed = group.classList.toggle('is-collapsed');
      button.setAttribute('aria-expanded', String(!collapsed));
      saved = saved.filter(function (x) { return x !== name; });
      if (collapsed) { saved.push(name); }
      try { localStorage.setItem('sf.tasks.collapsed', JSON.stringify(saved)); } catch (e) { /* ใช้ไม่ได้ก็ไม่เป็นไร */ }
    });
  });

  // ปุ่ม "เพิ่ม" ของแต่ละกลุ่ม
  document.querySelectorAll('[data-add-type]').forEach(function (button) {
    button.addEventListener('click', function () {
      window.SFCal.openForm(button.dataset.addType, null, { date: today });
    });
  });

  // ปุ่ม "วางแผนอ่าน" : เปิดฟอร์มการอ่าน โดยเลือกวิชาและงานไว้ให้
  document.querySelectorAll('[data-plan-task]').forEach(function (button) {
    button.addEventListener('click', function () {
      window.SFCal.openForm('session', null, {
        date: today,
        task_id: button.dataset.planTask,
        subject_id: button.dataset.planSubject,
        title: button.dataset.planTitle
      });
    });
  });
})();
