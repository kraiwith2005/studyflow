// =====================================================================
//  study.js : หน้าอ่านหนังสือ  (ปุ่มบันทึกการอ่าน, ปุ่มดู/ซ่อนประวัติ)
// =====================================================================
(function () {
  // ปุ่ม "บันทึกการอ่าน" : เปิดฟอร์มการอ่านแบบ "อ่านเสร็จแล้ว"
  var logButton = document.querySelector('[data-log-study]');
  logButton.addEventListener('click', function () {
    window.SFCal.openForm('session', null, {
      date: window.SF_CAL.today,
      mark_done: true,
      subject_id: logButton.dataset.subject
    });
  });

  // ปุ่ม "ดูประวัติ / ซ่อนประวัติ"
  var historyButton = document.querySelector('[data-toggle-history]');
  if (historyButton) {
    historyButton.addEventListener('click', function () {
      var list = document.getElementById('history');
      list.hidden = !list.hidden;
      historyButton.setAttribute('aria-expanded', String(!list.hidden));
      historyButton.textContent = list.hidden ? historyButton.dataset.show : historyButton.dataset.hide;
    });
  }
})();
