// =====================================================================
//  settings.js : หน้าตั้งค่า  (กล่องเพิ่ม/แก้ไขวิชา, เลือกสี, ยืนยันก่อนลบ)
// =====================================================================
(function () {
  function $(selector, scope) { return (scope || document).querySelector(selector); }
  function $all(selector, scope) { return Array.from((scope || document).querySelectorAll(selector)); }

  // ย่อ / ขยายหัวข้อ "วิชา"
  $all('.acc[data-acc] > .acc-head').forEach(function (head) {
    head.addEventListener('click', function () {
      var open = head.parentElement.classList.toggle('is-open');
      head.setAttribute('aria-expanded', String(open));
    });
  });

  // ---------- เลือกสีวิชา ----------
  function setColour(dialog, color) {
    color = color.toLowerCase();
    $('[data-colour-input]', dialog).value = color;
    $('[data-colour-preview]', dialog).style.background = color;
    $all('.swatch', dialog).forEach(function (swatch) {
      swatch.setAttribute('aria-checked', String(swatch.dataset.color === color));
    });
  }
  $all('.swatch').forEach(function (swatch) {
    swatch.addEventListener('click', function () { setColour(swatch.closest('dialog'), swatch.dataset.color); });
  });
  $all('[data-colour-input]').forEach(function (input) {
    input.addEventListener('input', function () { setColour(input.closest('dialog'), input.value); });
  });

  // ปุ่ม "เพิ่ม" กดได้เมื่อพิมพ์ชื่อวิชาแล้วเท่านั้น
  function updateSubmit(dialog) {
    var nameInput = $('[data-enable-submit]', dialog);
    var submit = $('[data-dialog-submit]', dialog);
    if (nameInput && submit) { submit.disabled = nameInput.value.trim() === ''; }
  }
  document.addEventListener('input', function (event) {
    var dialog = event.target.closest('dialog');
    if (dialog) { updateSubmit(dialog); }
  });

  // ---------- เปิดกล่อง ----------
  // ปุ่มเพิ่ม/แก้ไขวิชา มี data-action (ส่งไปไหน), data-name, data-color (ค่าเดิม)
  $all('[data-open-dialog]').forEach(function (button) {
    button.addEventListener('click', function () {
      var dialog = document.getElementById(button.dataset.openDialog);
      var form = $('form', dialog);
      form.querySelectorAll('.field-error').forEach(function (el) { el.remove(); });
      form.querySelectorAll('.is-invalid').forEach(function (el) { el.classList.remove('is-invalid'); });
      if (button.dataset.action) {
        form.action = button.dataset.action;
        $('#subject-name', dialog).value = button.dataset.name;
        setColour(dialog, button.dataset.color);
        $('[data-dialog-title]', dialog).textContent = button.dataset.title;
        $('[data-dialog-submit]', dialog).textContent = button.dataset.submit;
      } else {
        form.reset();
      }
      dialog.showModal();
      updateSubmit(dialog);
    });
  });

  $all('dialog').forEach(function (dialog) {
    $all('[data-dialog-close]', dialog).forEach(function (b) { b.addEventListener('click', function () { dialog.close(); }); });
    dialog.addEventListener('click', function (event) { if (event.target === dialog) { dialog.close(); } });
    // กรอกผิด -> เปิดกล่องค้างไว้
    if (dialog.hasAttribute('data-autoshow')) {
      dialog.showModal();
      updateSubmit(dialog);
    }
  });

  // ---------- ถามยืนยันก่อนลบวิชา ----------
  var confirmDialog = document.getElementById('confirm-dialog');
  var waitingForm = null;
  $all('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (form.dataset.confirmed) { return; }
      event.preventDefault();
      waitingForm = form;
      $('[data-confirm-title]', confirmDialog).textContent = form.dataset.confirm;
      $('[data-confirm-text]', confirmDialog).textContent = form.dataset.confirmText;
      confirmDialog.showModal();
    });
  });
  $('[data-confirm-ok]', confirmDialog).addEventListener('click', function () {
    waitingForm.dataset.confirmed = '1';
    waitingForm.requestSubmit();
  });
})();
