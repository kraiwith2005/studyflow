<?php
// =====================================================================
//  Task.php : class Task = งาน 1 ชิ้น (งานที่มอบหมาย / การสอบ / งานส่วนตัว)
//  เหมือน class Student ในบทที่ 6 : มี attribute (ข้อมูล) และ method (การทำงาน)
// =====================================================================

class Task
{
    // ----- attribute -----
    public $id;
    public $type;            // 'assignment' = งานที่มอบหมาย, 'exam' = การสอบ, 'personal' = งานส่วนตัว
    public $title;
    public $subjectId;
    public $subjectName;
    public $color;
    public $dueDate;         // วันส่ง เช่น '2026-11-30'
    public $dueTime;         // เวลาส่ง เช่น '23:59' (ไม่ใส่ = '')
    public $notes;
    public $link;
    public $priority;        // 'high' / 'normal' / 'low'
    public $completedAt;     // เวลาที่ทำเสร็จ (ยังไม่เสร็จ = null)
    public $plannedSessions; // วางแผนอ่านไว้กี่ครั้ง
    public $doneMinutes;     // อ่านไปแล้วกี่นาที

    // __construct ทำงานตอนสร้าง object : new Task($row)  (เหมือน __init__ ใน Python)
    // $row = 1 แถวจากฐานข้อมูล
    public function __construct($row)
    {
        $this->id = (int) $row['id'];
        $this->type = $row['type'];
        $this->title = $row['title'];
        $this->subjectId = $row['subject_id'] != null ? (int) $row['subject_id'] : null;
        $this->subjectName = $row['subject_name'] ?? null;
        $this->color = $row['subject_color'] ?? PERSONAL_COLOR;   // งานส่วนตัวไม่มีวิชา ใช้สีเทา
        $this->dueDate = $row['due_date'];
        $this->dueTime = show_time($row['due_time']);
        $this->notes = $row['notes'];
        $this->link = $row['link'];
        $this->priority = $row['priority'];
        $this->completedAt = $row['completed_at'];
        $this->plannedSessions = (int) ($row['planned_sessions'] ?? 0);
        $this->doneMinutes = (int) ($row['done_minutes'] ?? 0);
    }

    // ----- method -----

    // ทำเสร็จแล้วหรือยัง
    public function isDone()
    {
        return $this->completedAt != null;
    }

    // ชื่อประเภทงานภาษาไทย
    public function typeLabel()
    {
        if ($this->type == 'exam') {
            return 'การสอบ';
        } elseif ($this->type == 'personal') {
            return 'งานส่วนตัว';
        } else {
            return 'งานที่มอบหมาย';
        }
    }

    // ระดับความสำคัญภาษาไทย
    public function priorityLabel()
    {
        if ($this->priority == 'high') {
            return 'สำคัญมาก';
        } elseif ($this->priority == 'low') {
            return 'สำคัญน้อย';
        } else {
            return 'ปกติ';
        }
    }

    // ป้ายกำหนดส่ง เช่น "เลยกำหนด 2 วัน" (สีแดง) / "ส่งพรุ่งนี้" (สีเหลือง)
    // คืนค่า array 2 ช่อง : [ข้อความ, สีของป้าย]
    public function dueBadge()
    {
        if ($this->isDone()) {
            return ['เสร็จแล้ว', 'done'];
        }

        $days = days_between(today(), $this->dueDate);   // อีกกี่วันถึงวันส่ง
        $isExam = $this->type == 'exam';

        if ($days < 0) {
            return ['เลยกำหนด ' . (-$days) . ' วัน', 'overdue'];          // แดง
        } elseif ($days == 0) {
            return [$isExam ? 'สอบวันนี้' : 'ส่งวันนี้', 'soon'];          // เหลือง
        } elseif ($days == 1) {
            return [$isExam ? 'สอบพรุ่งนี้' : 'ส่งพรุ่งนี้', 'soon'];        // เหลือง
        } elseif ($days <= 7) {
            return [($isExam ? 'สอบในอีก ' : 'ส่งในอีก ') . $days . ' วัน', 'week'];
        } else {
            return [($isExam ? 'สอบในอีก ' : 'ส่งในอีก ') . $days . ' วัน', 'later'];
        }
    }

    // ข้อมูลของงานสำหรับส่งให้ JavaScript เปิดกล่องรายละเอียด / แก้ไข
    public function toArray()
    {
        return [
            'kind' => 'task',
            'id' => $this->id,
            'type' => $this->type,
            'typeLabel' => $this->typeLabel(),
            'title' => $this->title,
            'subject' => $this->subjectName,
            'subject_id' => $this->subjectId,
            'color' => $this->color,
            'done' => $this->isDone(),
            'date' => $this->dueDate,
            'due_time' => $this->dueTime,
            'notes' => $this->notes,
            'link' => $this->link,
            'priority' => $this->priority,
            'priorityLabel' => $this->priorityLabel(),
        ];
    }
}
