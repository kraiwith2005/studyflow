        <p class="auth-switch" style="text-align:left;margin-top:30px">
          <a href="<?= e($user != null ? url('settings') . '#support' : url('sign-in')) ?>">← กลับไปที่ StudyFlow</a>
        </p>
      </article>
    </main>
  </div>
</body>
</html>
