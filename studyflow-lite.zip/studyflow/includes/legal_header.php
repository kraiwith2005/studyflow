<?php
// legal_header.php : ส่วนบนของหน้านโยบาย (ความเป็นส่วนตัว / ข้อตกลง / คุกกี้)  ต้องมี $title และ $updated
$user = current_user();
?>
<!DOCTYPE html>
<html lang="th" <?= $user != null && $user['theme'] == 'dark' ? 'data-theme="dark"' : '' ?>>
<head>
  <?php include ROOT . '/includes/head.php'; ?>
</head>
<body>
  <div class="auth-page">
    <header class="auth-top"><?php include ROOT . '/includes/brand.php'; ?></header>
    <main class="auth-main">
      <article class="auth-card legal-card legal">
        <h1 class="auth-title"><?= e($title) ?></h1>
        <p class="auth-sub" style="margin-bottom:8px">ปรับปรุงล่าสุด <?= thai_date($updated) ?></p>
