<?php
// =====================================================================
//  header.php : ส่วนบนของทุกหน้าหลังเข้าสู่ระบบ (แถบเมนู, ปุ่มธีม, เมนูบัญชี)
//  ก่อน include ต้องมีตัวแปร $title (ชื่อหน้า) และ $page (ชื่อเมนูที่กำลังเปิด)
// =====================================================================
$user = current_user();

// เมนูหลัก : ชื่อไฟล์ => ชื่อที่แสดง  (array แบบ key => value เหมือน dictionary ใน Python)
$menu = [
    'today' => 'วันนี้',
    'calendar' => 'ปฏิทิน',
    'tasks' => 'งาน',
    'study' => 'อ่านหนังสือ',
    'stats' => 'สถิติ',
    'settings' => 'ตั้งค่า',
];
?>
<!DOCTYPE html>
<html lang="th" <?= $user['theme'] == 'dark' ? 'data-theme="dark"' : '' ?>>
<head>
  <?php include ROOT . '/includes/head.php'; ?>
</head>
<body>
  <header class="app-header">
    <div class="app-header-inner">
      <?php include ROOT . '/includes/brand.php'; ?>

      <nav class="app-nav" aria-label="เมนูหลัก">
        <?php foreach ($menu as $link => $label): ?>
          <a href="<?= e(url($link)) ?>" class="nav-link <?= $page == $link ? 'is-active' : '' ?>"
             <?= $page == $link ? 'aria-current="page"' : '' ?>><?= $label ?></a>
        <?php endforeach; ?>
      </nav>

      <div class="header-tools">
        <span id="save-status" class="save-status" data-state="saved" role="status" aria-live="polite">บันทึกแล้ว</span>

        <button type="button" id="theme-toggle" class="icon-btn" data-url="<?= e(url('theme-save')) ?>"
                aria-label="<?= $user['theme'] == 'dark' ? 'เปลี่ยนเป็นโหมดสว่าง' : 'เปลี่ยนเป็นโหมดมืด' ?>">
          <?= icon('moon', 'theme-icon-moon') ?>
          <?= icon('sun', 'theme-icon-sun') ?>
        </button>

        <div class="menu-wrap">
          <button type="button" id="avatar-btn" class="avatar" style="background: <?= e($user['avatar_color']) ?>"
                  aria-haspopup="menu" aria-expanded="false" aria-controls="avatar-menu"
                  aria-label="เมนูบัญชีของ <?= e($user['full_name']) ?>"><?= e($user['initial']) ?></button>
          <div id="avatar-menu" class="menu" role="menu">
            <div class="menu-head">
              <span class="avatar avatar-lg" style="background: <?= e($user['avatar_color']) ?>" aria-hidden="true"><?= e($user['initial']) ?></span>
              <div>
                <div class="menu-name"><?= e($user['full_name']) ?></div>
                <div class="menu-email"><?= e($user['email']) ?></div>
              </div>
            </div>
            <a href="<?= e(url('account')) ?>" class="menu-item" role="menuitem"><?= icon('gear') ?> จัดการบัญชี</a>
            <form method="POST" action="<?= e(url('sign-out')) ?>">
              <?= csrf_field() ?>
              <button type="submit" class="menu-item" role="menuitem"><?= icon('signout') ?> ออกจากระบบ</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </header>

  <?php // แถบเตือนให้เพิ่มรายวิชาก่อน (แสดงเมื่อยังไม่มีวิชาเลย และไม่ได้อยู่หน้าตั้งค่า) ?>
  <?php if ($page != 'settings' && $page != 'account' && count(get_subjects(user_id())) == 0): ?>
    <section class="setup" aria-label="เริ่มต้นใช้งาน">
      <div class="setup-head">
        <div>
          <div class="setup-title">เริ่มต้นด้วยการเพิ่มรายวิชา</div>
          <div class="setup-sub">เพิ่มรายวิชาที่ลงเรียนก่อน แล้วจึงเพิ่มงานและแผนการอ่านของแต่ละวิชาได้</div>
        </div>
      </div>
      <div class="setup-cards">
        <a href="<?= e(url('settings')) ?>#subjects" class="setup-card">
          <span class="setup-card-name">รายวิชา</span>
          <span class="setup-card-action">ตั้งค่าเลย</span>
        </a>
      </div>
    </section>
  <?php endif; ?>

  <main class="app-main">
