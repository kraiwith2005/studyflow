<?php
// =====================================================================
//  start.php : ทุกหน้าของเว็บจะเรียกไฟล์นี้เป็นอย่างแรก
//  หน้าที่ : ตั้งค่าเวลา, อ่านไฟล์ตั้งค่า, โหลดฟังก์ชันที่ใช้ร่วมกัน, เริ่ม session
//  (เทียบกับ Python = การ import module หลาย ๆ ตัวไว้ต้นไฟล์)
// =====================================================================

date_default_timezone_set('Asia/Bangkok');   // ใช้เวลาประเทศไทย

// ROOT = โฟลเดอร์หลักของโปรเจกต์ (โฟลเดอร์ที่อยู่เหนือ includes)
define('ROOT', dirname(__DIR__));

// BASE = ส่วนหน้าของ URL เช่น เปิดใน XAMPP ที่ http://localhost/studyflow  จะได้ "/studyflow"
define('BASE', rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/'));

// อ่านไฟล์ตั้งค่า
if (! file_exists(ROOT . '/config.php')) {
    die('ยังไม่มีไฟล์ config.php : ให้คัดลอก config.sample.php เป็น config.php ก่อน');
}
$config = require ROOT . '/config.php';

// แสดง error บนหน้าจอเฉพาะตอนพัฒนา
if ($config['debug']) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}

// โหลดไฟล์ฟังก์ชันต่าง ๆ (เหมือน import ใน Python)
require ROOT . '/includes/db.php';          // เชื่อมต่อฐานข้อมูล
require ROOT . '/includes/functions.php';   // ฟังก์ชันทั่วไป
require ROOT . '/includes/auth.php';        // ระบบสมาชิก (เข้าสู่ระบบ)
require ROOT . '/includes/Task.php';        // class Task (งาน 1 ชิ้น)
require ROOT . '/includes/data.php';        // ดึงข้อมูลงาน / การอ่าน / รายวิชา

// เริ่ม session (ที่เก็บข้อมูลของผู้ใช้ระหว่างเปลี่ยนหน้า เช่น ใครเข้าสู่ระบบอยู่)
session_name('studyflow_session');
session_set_cookie_params([
    'lifetime' => 60 * 60 * 24 * 30,   // จำการเข้าสู่ระบบไว้ 30 วัน
    'path' => BASE . '/',
    'httponly' => true,                // JavaScript อ่านคุกกี้นี้ไม่ได้
    'samesite' => 'Lax',
]);
ini_set('session.gc_maxlifetime', (string) (60 * 60 * 24 * 30));
session_start();

// ข้อความ / error ที่หน้าก่อนหน้าฝากไว้ (ใช้ได้ครั้งเดียวแล้วลบทิ้ง)
$flash = $_SESSION['flash'] ?? [];
unset($_SESSION['flash']);
