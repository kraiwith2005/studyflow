<?php
// =====================================================================
//  data.php : ดึงข้อมูลจากฐานข้อมูล (รายวิชา / งาน / การอ่านหนังสือ)
//  ทุกคำสั่ง SQL มี "user_id = ?" เสมอ  ผู้ใช้จึงเห็นเฉพาะข้อมูลของตัวเอง
// =====================================================================

const PERSONAL_COLOR = '#6b7a99';   // สีของงานส่วนตัว
const SESSION_COLOR = '#4E7894';    // สีของการอ่านที่ไม่มีวิชา

// ระยะเวลาอ่านที่เลือกได้ (นาที)
const DURATIONS = [15, 20, 30, 45, 60, 75, 90, 105, 120, 150, 180];

// สีสำเร็จรูปของรายวิชา
const SUBJECT_COLORS = ['#3b5fe0', '#cb3a31', '#4a9e52', '#7a3fe0', '#dc6428', '#48a0e0', '#c93b78', '#c48d31', '#3f9470', '#5045dd', '#ecaed5', '#f4f4f1'];

// ---------- รายวิชา ----------

// รายวิชาทั้งหมดของผู้ใช้
function get_subjects($userId)
{
    return db_select('SELECT * FROM subjects WHERE user_id = ? ORDER BY sort_order, name', [$userId]);
}

// รายวิชา 1 วิชา (ต้องเป็นของผู้ใช้คนนี้)  ไม่เจอ = null
function find_subject($userId, $id)
{
    return db_select_one('SELECT * FROM subjects WHERE id = ? AND user_id = ?', [(int) $id, $userId]);
}

// ---------- ตารางเรียน (คาบเรียนที่เรียนซ้ำทุกสัปดาห์) ----------

const CLASS_COLOR = '#8a948c';   // สีของคาบที่ไม่มีวิชา

// คาบเรียนทั้งหมดของผู้ใช้ เรียงตามวัน (จันทร์ -> อาทิตย์) และเวลา
//   day : 1 = จันทร์, 2 = อังคาร, ... 7 = อาทิตย์
function get_classes($userId)
{
    $classes = db_select('SELECT c.*, s.name AS subject_name, s.color AS subject_color
                          FROM recurring_classes c
                          LEFT JOIN subjects s ON s.id = c.subject_id
                          WHERE c.user_id = ?
                          ORDER BY c.day, c.start_time', [$userId]);
    foreach ($classes as $i => $c) {
        // ชื่อที่แสดง : ใช้ชื่อคาบถ้ามี ไม่มีก็ใช้ชื่อวิชา
        if ($c['name'] != null && $c['name'] != '') {
            $classes[$i]['title'] = $c['name'];
        } else {
            $classes[$i]['title'] = $c['subject_name'] ?? 'คาบเรียน';
        }
        $classes[$i]['color'] = $c['subject_color'] ?? CLASS_COLOR;
        $classes[$i]['start'] = show_time($c['start_time']);
        $classes[$i]['end'] = show_time($c['end_time']);
    }
    return $classes;
}

// คาบเรียน 1 คาบของผู้ใช้  ไม่เจอ = null
function find_class($userId, $id)
{
    return db_select_one('SELECT * FROM recurring_classes WHERE id = ? AND user_id = ?', [(int) $id, $userId]);
}

// เลือกเฉพาะคาบที่เรียนในวันที่ $date  (เทียบวันในสัปดาห์)
function classes_on($classes, $date)
{
    $weekday = (int) date('N', strtotime($date));   // 1 = จันทร์ ... 7 = อาทิตย์
    $result = [];
    foreach ($classes as $c) {
        if ((int) $c['day'] == $weekday) {
            $result[] = $c;
        }
    }
    return $result;
}

// ข้อมูลคาบเรียนสำหรับส่งให้ JavaScript (กล่องรายละเอียด)
function class_to_array($c, $date)
{
    return [
        'kind' => 'class',
        'id' => (int) $c['id'],
        'title' => $c['title'],
        'subject' => $c['subject_name'],
        'color' => $c['color'],
        'start' => $c['start'],
        'end' => $c['end'],
        'location' => $c['location'],
        'teacher' => $c['teacher'],
        'done' => false,
        'date' => $date,
    ];
}

// ---------- งาน ----------

// ดึงงานของผู้ใช้ แล้วแปลงแต่ละแถวเป็น object ของ class Task
//   $where  = เงื่อนไขเพิ่ม เช่น "t.type = 'exam'"
//   $params = ค่าที่ใส่แทน ? ใน $where
function get_tasks($userId, $where = '', $params = [], $order = 't.due_date, t.title')
{
    $sql = "SELECT t.*, s.name AS subject_name, s.color AS subject_color,
                (SELECT COUNT(*) FROM study_sessions ss WHERE ss.task_id = t.id AND ss.status = 'planned') AS planned_sessions,
                (SELECT SUM(ss.actual_minutes) FROM study_sessions ss WHERE ss.task_id = t.id AND ss.status = 'completed') AS done_minutes
            FROM tasks t
            LEFT JOIN subjects s ON s.id = t.subject_id
            WHERE t.user_id = ?";
    if ($where != '') {
        $sql .= " AND ($where)";
    }
    $sql .= " ORDER BY $order";

    $tasks = [];
    $rows = db_select($sql, array_merge([$userId], $params));
    foreach ($rows as $row) {
        $tasks[] = new Task($row);     // สร้าง object จาก 1 แถว
    }
    return $tasks;
}

// งาน 1 ชิ้นของผู้ใช้  ไม่เจอ = null
function find_task($userId, $id)
{
    $tasks = get_tasks($userId, 't.id = ?', [(int) $id]);
    if (count($tasks) == 0) {
        return null;
    }
    return $tasks[0];
}

// งานที่มอบหมาย + การสอบ ที่ยังไม่เสร็จ (ใช้ในช่อง "เชื่อมกับงาน" ตอนวางแผนอ่าน)
function open_assessments($userId)
{
    return get_tasks($userId, "t.type <> 'personal' AND t.completed_at IS NULL", [], 't.due_date, t.title');
}

// ---------- การอ่านหนังสือ (study_sessions) ----------

// ดึงรายการอ่านหนังสือ  แต่ละรายการเป็น array และเติมข้อมูลสำหรับแสดงผล
function get_sessions($userId, $where = '', $params = [], $order = 'ss.date, ss.start_time')
{
    $sql = "SELECT ss.*, s.name AS subject_name, s.color AS subject_color, t.title AS task_title
            FROM study_sessions ss
            LEFT JOIN subjects s ON s.id = ss.subject_id
            LEFT JOIN tasks t ON t.id = ss.task_id
            WHERE ss.user_id = ?";
    if ($where != '') {
        $sql .= " AND ($where)";
    }
    $sql .= " ORDER BY $order";

    $sessions = db_select($sql, array_merge([$userId], $params));
    foreach ($sessions as $i => $s) {
        $sessions[$i]['color'] = $s['subject_color'] ?? SESSION_COLOR;
        $sessions[$i]['done'] = $s['status'] == 'completed';
        $sessions[$i]['start'] = show_time($s['start_time']);
        // เวลาจบ = เวลาเริ่ม + ระยะเวลา
        $end = to_minutes($s['start_time']) + (int) $s['duration_minutes'];
        $sessions[$i]['end'] = $end >= 24 * 60 ? '24:00' : sprintf('%02d:%02d', intdiv($end, 60), $end % 60);
    }
    return $sessions;
}

// การอ่าน 1 รายการของผู้ใช้  ไม่เจอ = null
function find_session($userId, $id)
{
    $rows = get_sessions($userId, 'ss.id = ?', [(int) $id]);
    if (count($rows) == 0) {
        return null;
    }
    return $rows[0];
}

// ข้อมูลการอ่านสำหรับส่งให้ JavaScript
function session_to_array($s)
{
    return [
        'kind' => 'session',
        'id' => (int) $s['id'],
        'title' => $s['title'],
        'subject' => $s['subject_name'],
        'subject_id' => $s['subject_id'] != null ? (int) $s['subject_id'] : null,
        'color' => $s['color'],
        'start' => $s['start'],
        'end' => $s['end'],
        'duration' => (int) $s['duration_minutes'],
        'done' => $s['done'],
        'task_id' => $s['task_id'] != null ? (int) $s['task_id'] : null,
        'task' => $s['task_title'],
        'date' => $s['date'],
    ];
}

// สรุปการอ่านสัปดาห์นี้ (อาทิตย์ - เสาร์) : [จำนวนครั้ง, จำนวนนาที]
function week_study_totals($userId)
{
    $start = week_start(today());
    $row = db_select_one("SELECT COUNT(*) AS times, COALESCE(SUM(actual_minutes), 0) AS minutes
                          FROM study_sessions
                          WHERE user_id = ? AND status = 'completed' AND date BETWEEN ? AND ?",
        [$userId, $start, add_days($start, 6)]);
    return [(int) $row['times'], (int) $row['minutes']];
}

// ---------- ข้อมูลสำหรับกล่องรายละเอียด (JavaScript) ----------

// แปลงข้อมูลเป็นข้อความ JSON  ใส่ใน data-item="..." ของปุ่ม  เพิ่มป้ายวันที่ เวลา และลิงก์ที่ใช้แก้ไข/ลบ
function item_json($item)
{
    $item['dateLabel'] = thai_date($item['date'], 'long');

    if ($item['kind'] == 'task') {
        if ($item['due_time'] != '') {
            $item['timeLabel'] = $item['due_time'];
        }
        $item['urls'] = [
            'update' => url('task-save', ['id' => $item['id']]),
            'destroy' => url('task-delete', ['id' => $item['id']]),
            'toggle' => url('task-toggle', ['id' => $item['id']]),
        ];
    } elseif ($item['kind'] == 'class') {
        $item['typeLabel'] = 'คาบเรียน';
        $item['timeLabel'] = $item['start'] . ' – ' . $item['end'];
    } else {
        $item['typeLabel'] = 'การอ่านหนังสือ';
        $item['timeLabel'] = $item['start'] . ' – ' . $item['end'];
        $item['durationLabel'] = duration_text($item['duration']);
        $item['urls'] = [
            'update' => url('session-save', ['id' => $item['id']]),
            'destroy' => url('session-delete', ['id' => $item['id']]),
            'toggle' => url('session-toggle', ['id' => $item['id']]),
        ];
    }
    return json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
