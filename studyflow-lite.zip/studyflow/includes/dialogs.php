<?php
// =====================================================================
//  dialogs.php : กล่อง (dialog) ที่ใช้ร่วมกันในหน้า วันนี้ / ปฏิทิน / งาน / อ่านหนังสือ
//    - กล่องเลือกประเภทรายการที่จะเพิ่ม
//    - ฟอร์มเพิ่ม/แก้ไข การอ่านหนังสือ  และ  งาน
//    - กล่องรายละเอียด และกล่องยืนยันการลบ
//  JavaScript (js/calendar.js) เป็นตัวเปิด/ปิดกล่องและเติมข้อมูลลงฟอร์ม
//  ก่อน include ต้องมี : $subjects (รายวิชา), $assessments (งานที่ยังไม่เสร็จ)
// =====================================================================

$returnPage = current_page();   // หลังบันทึก จะกลับมาหน้านี้

// ถ้าเพิ่งกรอกผิด ให้เปิดฟอร์มเดิมค้างไว้  เช่น reopen = 'task-5' แปลว่าแก้งาน id 5 ไม่ผ่าน
$reopen = reopen();
$sessionOpen = ($reopen == 'new-session' || str_starts_with($reopen, 'session-'));
$sessionEditId = str_starts_with($reopen, 'session-') ? (int) substr($reopen, 8) : 0;
$taskOpen = (str_starts_with($reopen, 'new-') && $reopen != 'new-session') || str_starts_with($reopen, 'task-');
$taskEditId = str_starts_with($reopen, 'task-') ? (int) substr($reopen, 5) : 0;

$taskType = old('type', 'assignment');
if ($taskType != 'exam' && $taskType != 'personal') {
    $taskType = 'assignment';
}

// ข้อความบนฟอร์มงาน แยกตามประเภท (JavaScript ใช้เปลี่ยนหัวข้อตอนเปิดฟอร์ม)
$taskLabels = [
    'assignment' => ['add' => 'เพิ่มงานที่มอบหมาย', 'edit' => 'แก้ไขงานที่มอบหมาย', 'placeholder' => 'ชื่องานที่มอบหมาย', 'date' => 'วันกำหนดส่ง', 'time' => 'เวลาที่ต้องส่ง'],
    'exam' => ['add' => 'เพิ่มการสอบ', 'edit' => 'แก้ไขการสอบ', 'placeholder' => 'ชื่อการสอบ', 'date' => 'วันสอบ', 'time' => 'เวลาเริ่มสอบ'],
    'personal' => ['add' => 'เพิ่มงานส่วนตัว', 'edit' => 'แก้ไขงานส่วนตัว', 'placeholder' => 'ชื่องานส่วนตัว', 'date' => 'วันที่', 'time' => 'เวลา'],
];
$subjectsLink = url('settings') . '#subjects';
?>

<?php // ---------- 1) เลือกว่าจะเพิ่มอะไร ---------- ?>
<dialog class="dlg" id="add-dialog" aria-labelledby="add-title">
  <div class="dlg-head">
    <div>
      <div class="dlg-title" id="add-title" data-add-date-label></div>
      <div class="dlg-date">เพิ่มลงปฏิทิน</div>
    </div>
    <button type="button" class="dlg-x" data-dialog-close aria-label="ปิด"><?= icon('close') ?></button>
  </div>
  <div class="dlg-body">
    <div class="type-list">
      <button type="button" class="type-btn" data-choose="session">ช่วงอ่านหนังสือ <?= icon('plus') ?></button>
      <button type="button" class="type-btn" data-choose="personal">งานส่วนตัว <?= icon('plus') ?></button>
      <button type="button" class="type-btn" data-choose="assignment">งานที่มอบหมาย <?= icon('plus') ?></button>
      <button type="button" class="type-btn" data-choose="exam">สอบ <?= icon('plus') ?></button>
    </div>
  </div>
</dialog>

<?php // ---------- 2) ฟอร์มการอ่านหนังสือ (ส่งไปที่ session-save.php) ---------- ?>
<dialog class="dlg dlg-wide" id="session-dialog" <?= $sessionOpen ? 'data-autoshow' : '' ?>>
  <form method="POST" novalidate data-once data-store="<?= e(url('session-save')) ?>"
        action="<?= e($sessionEditId ? url('session-save', ['id' => $sessionEditId]) : url('session-save')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="return" value="<?= e($returnPage) ?>">
    <input type="hidden" name="mark_done" value="<?= e(old('mark_done')) ?>">
    <div class="dlg-head">
      <div>
        <div class="dlg-title" data-form-title><?= old('mark_done') ? 'บันทึกการอ่าน' : ($sessionEditId ? 'แก้ไขช่วงอ่านหนังสือ' : 'เพิ่มช่วงอ่านหนังสือ') ?></div>
        <div class="dlg-date" data-form-date></div>
      </div>
      <button type="button" class="dlg-x" data-dialog-close aria-label="ปิด"><?= icon('close') ?></button>
    </div>
    <div class="dlg-body dlg-scroll">
      <div class="field">
        <label class="label" for="s-title">ชื่อ<span class="req">*</span></label>
        <input id="s-title" name="title" class="input input-rect <?= invalid('session', 'title') ?>" maxlength="120"
               placeholder="ชื่อช่วงอ่านหนังสือ" value="<?= e(old('title')) ?>" required>
        <?= show_error('session', 'title') ?>
      </div>
      <div class="field">
        <label class="label" for="s-subject">วิชา<span class="req">*</span></label>
        <select id="s-subject" name="subject_id" class="select <?= invalid('session', 'subject_id') ?>" required>
          <option value="">เลือกวิชา</option>
          <?php foreach ($subjects as $s): ?>
            <option value="<?= $s['id'] ?>" <?= selected(old('subject_id') == $s['id']) ?>><?= e($s['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <?= show_error('session', 'subject_id') ?>
        <?php if (count($subjects) == 0): ?><span class="field-hint"><a href="<?= e($subjectsLink) ?>">เพิ่มวิชาในหน้าตั้งค่าก่อน</a></span><?php endif; ?>
      </div>
      <div class="time-box">
        <div class="time-box-title">เวลาในปฏิทิน</div>
        <div class="time-box-sub">รายการจะแสดงในปฏิทินรายชั่วโมงตามเวลานี้</div>
        <div class="field">
          <label class="label" for="s-date">วันที่<span class="req">*</span></label>
          <input id="s-date" name="date" type="date" class="input input-rect <?= invalid('session', 'date') ?>" value="<?= e(old('date')) ?>" required>
          <?= show_error('session', 'date') ?>
        </div>
        <div class="grid-2" style="margin-top:16px">
          <div class="field">
            <label class="label" for="s-start">เวลาเริ่ม<span class="req">*</span></label>
            <input id="s-start" name="start_time" type="time" class="input input-rect <?= invalid('session', 'start_time') ?>" value="<?= e(old('start_time', '16:00')) ?>" required>
            <?= show_error('session', 'start_time') ?>
          </div>
          <div class="field">
            <label class="label" for="s-duration">ระยะเวลา<span class="req">*</span></label>
            <select id="s-duration" name="duration_minutes" class="select" required>
              <?php foreach (DURATIONS as $minutes): ?>
                <option value="<?= $minutes ?>" <?= selected(old('duration_minutes', '60') == $minutes) ?>><?= duration_text($minutes) ?></option>
              <?php endforeach; ?>
            </select>
            <?= show_error('session', 'duration_minutes') ?>
          </div>
        </div>
      </div>
      <div class="field" style="margin-top:18px">
        <label class="label" for="s-task">เชื่อมกับงาน / การสอบ</label>
        <select id="s-task" name="task_id" class="select">
          <option value="">ไม่เชื่อม</option>
          <?php foreach ($assessments as $t): ?>
            <option value="<?= $t->id ?>" <?= selected(old('task_id') == $t->id) ?>><?= e($t->typeLabel() . ' · ' . $t->title . ' (' . thai_date($t->dueDate) . ')') ?></option>
          <?php endforeach; ?>
          <?php if (count($assessments) == 0): ?><option value="" disabled>ไม่มีงานประเมินผลที่ค้างอยู่</option><?php endif; ?>
        </select>
        <span class="field-hint">ไม่บังคับ ใช้เมื่อช่วงอ่านหนังสือนี้เป็นการเตรียมงานหรือการสอบเฉพาะเรื่อง</span>
      </div>
      <div class="form-buttons">
        <button type="submit" class="btn btn-primary" data-form-submit><?= $sessionEditId ? 'บันทึก' : 'เพิ่ม' ?></button>
        <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
      </div>
    </div>
  </form>
</dialog>

<?php // ---------- 3) ฟอร์มงาน (ส่งไปที่ task-save.php) ---------- ?>
<dialog class="dlg dlg-wide" id="task-dialog" data-labels="<?= e(json_encode($taskLabels, JSON_UNESCAPED_UNICODE)) ?>" <?= $taskOpen ? 'data-autoshow' : '' ?>>
  <form method="POST" novalidate data-once data-store="<?= e(url('task-save')) ?>"
        action="<?= e($taskEditId ? url('task-save', ['id' => $taskEditId]) : url('task-save')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="return" value="<?= e($returnPage) ?>">
    <input type="hidden" name="type" value="<?= e($taskType) ?>">
    <div class="dlg-head">
      <div>
        <div class="dlg-title" data-form-title><?= $taskLabels[$taskType][$taskEditId ? 'edit' : 'add'] ?></div>
        <div class="dlg-date" data-form-date></div>
      </div>
      <button type="button" class="dlg-x" data-dialog-close aria-label="ปิด"><?= icon('close') ?></button>
    </div>
    <div class="dlg-body">
      <div class="field">
        <label class="label" for="t-title">ชื่อ<span class="req">*</span></label>
        <input id="t-title" name="title" class="input input-rect <?= invalid('task', 'title') ?>" maxlength="120"
               placeholder="<?= $taskLabels[$taskType]['placeholder'] ?>" value="<?= e(old('title')) ?>" required>
        <?= show_error('task', 'title') ?>
      </div>
      <div class="field" data-subject-field <?= $taskType == 'personal' ? 'hidden' : '' ?>>
        <label class="label" for="t-subject">วิชา<span class="req">*</span></label>
        <select id="t-subject" name="subject_id" class="select <?= invalid('task', 'subject_id') ?>">
          <option value="">เลือกวิชา</option>
          <?php foreach ($subjects as $s): ?>
            <option value="<?= $s['id'] ?>" <?= selected(old('subject_id') == $s['id']) ?>><?= e($s['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <?= show_error('task', 'subject_id') ?>
        <?php if (count($subjects) == 0): ?><span class="field-hint"><a href="<?= e($subjectsLink) ?>">เพิ่มวิชาในหน้าตั้งค่าก่อน</a></span><?php endif; ?>
      </div>
      <div class="field-row">
        <div class="field">
          <label class="label" for="t-date" data-date-label><?= $taskLabels[$taskType]['date'] ?><span class="req">*</span></label>
          <input id="t-date" name="due_date" type="date" class="input input-rect <?= invalid('task', 'due_date') ?>" value="<?= e(old('due_date')) ?>" required>
          <?= show_error('task', 'due_date') ?>
        </div>
        <div class="field">
          <label class="label" for="t-time" data-time-label><?= $taskLabels[$taskType]['time'] ?></label>
          <input id="t-time" name="due_time" type="time" class="input input-rect <?= invalid('task', 'due_time') ?>" value="<?= e(old('due_time')) ?>">
          <?= show_error('task', 'due_time') ?>
          <span class="field-hint">ไม่บังคับ เว้นว่างได้ถ้าไม่มีเวลาที่แน่นอน</span>
        </div>
      </div>
      <div class="field">
        <span class="label">ความสำคัญ</span>
        <div class="seg seg-field" role="radiogroup" aria-label="ความสำคัญ">
          <?php foreach (['low' => 'ต่ำ', 'normal' => 'ปกติ', 'high' => 'สูง'] as $level => $levelName): ?>
            <label class="seg-btn seg-radio is-<?= $level ?>">
              <input type="radio" name="priority" value="<?= $level ?>" <?= checked(old('priority', 'normal') == $level) ?>>
              <span><?= $levelName ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="field">
        <label class="label" for="t-link">ลิงก์</label>
        <input id="t-link" name="link" type="url" inputmode="url" class="input input-rect <?= invalid('task', 'link') ?>"
               maxlength="500" placeholder="https://classroom.google.com/…" value="<?= e(old('link')) ?>">
        <?= show_error('task', 'link') ?>
        <span class="field-hint">ไม่บังคับ เช่น ลิงก์ส่งงานใน Google Classroom หรือไฟล์โจทย์ใน Drive</span>
      </div>
      <div class="field">
        <label class="label" for="t-notes">บันทึกย่อ</label>
        <textarea id="t-notes" name="notes" class="input input-rect textarea <?= invalid('task', 'notes') ?>"
                  rows="3" maxlength="2000" placeholder="เช่น ส่งเป็น PDF ไม่เกิน 10 หน้า"><?= e(old('notes')) ?></textarea>
        <?= show_error('task', 'notes') ?>
      </div>
      <div class="form-buttons">
        <button type="submit" class="btn btn-primary" data-form-submit><?= $taskEditId ? 'บันทึก' : 'เพิ่ม' ?></button>
        <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
      </div>
    </div>
  </form>
</dialog>

<?php // ---------- 4) กล่องรายละเอียด (กดที่รายการแล้วเปิด) ---------- ?>
<dialog class="dlg" id="detail-dialog" aria-labelledby="detail-title">
  <div class="dlg-head">
    <div style="min-width:0">
      <div class="detail-type"><span class="swatch-dot" data-d="dot"></span><span data-d="typeLabel"></span></div>
      <div class="dlg-title" id="detail-title" data-d="title" style="margin-top:4px"></div>
    </div>
    <button type="button" class="dlg-x" data-dialog-close aria-label="ปิด"><?= icon('close') ?></button>
  </div>
  <div class="dlg-body">
    <div class="detail-rows">
      <div class="detail-row" data-row="dateLabel"><span class="detail-k">วันที่</span><span class="detail-v" data-d="dateLabel"></span></div>
      <div class="detail-row" data-row="timeLabel"><span class="detail-k">เวลา</span><span class="detail-v" data-d="timeLabel"></span></div>
      <div class="detail-row" data-row="subject"><span class="detail-k">วิชา</span><span class="detail-v" data-d="subject"></span></div>
      <div class="detail-row" data-row="task"><span class="detail-k">สำหรับ</span><span class="detail-v" data-d="task"></span></div>
      <div class="detail-row" data-row="status"><span class="detail-k">สถานะ</span><span class="detail-v" data-d="status"></span></div>
      <div class="detail-row" data-row="priorityLabel"><span class="detail-k">ความสำคัญ</span><span class="detail-v" data-d="priorityLabel"></span></div>
      <div class="detail-row" data-row="notes"><span class="detail-k">บันทึกย่อ</span><span class="detail-v detail-notes" data-d="notes"></span></div>
      <div class="detail-row" data-row="linkRow"><span class="detail-k">ลิงก์</span><span class="detail-v"><a class="detail-link" data-d-link target="_blank" rel="noopener noreferrer"></a></span></div>
    </div>
    <div class="detail-actions" data-actions>
      <form method="POST" data-toggle-form>
        <?= csrf_field() ?>
        <input type="hidden" name="return" value="<?= e($returnPage) ?>">
        <button type="submit" class="btn btn-primary btn-sm" data-toggle-label></button>
      </form>
      <button type="button" class="btn btn-outline btn-sm" data-edit><?= icon('pencil', '', 15) ?> แก้ไข</button>
      <form method="POST" data-delete-form data-confirm="" data-confirm-text="การลบนี้ย้อนกลับไม่ได้">
        <?= csrf_field() ?>
        <input type="hidden" name="return" value="<?= e($returnPage) ?>">
        <button type="submit" class="btn btn-ghost btn-sm link-danger"><?= icon('trash', '', 15) ?> ลบ</button>
      </form>
    </div>
  </div>
</dialog>

<?php // ---------- 5) ยืนยันก่อนลบ ---------- ?>
<dialog class="dlg" id="confirm-dialog">
  <div class="dlg-body">
    <div class="dlg-title" data-confirm-title></div>
    <p class="dlg-text" data-confirm-text></p>
    <div class="form-buttons" style="margin-top:0">
      <button type="button" class="btn btn-danger" data-confirm-ok>ลบ</button>
      <button type="button" class="btn btn-outline" data-dialog-close>ยกเลิก</button>
    </div>
  </div>
</dialog>

<script>
  // ข้อมูลที่ js/calendar.js ใช้
  window.SF_CAL = {
    today: '<?= today() ?>',
    titles: { addSession: 'เพิ่มช่วงอ่านหนังสือ', editSession: 'แก้ไขช่วงอ่านหนังสือ', logStudy: 'บันทึกการอ่าน' },
    strings: { done: 'เสร็จแล้ว', notDone: 'ยังไม่เสร็จ', markDone: 'ทำเสร็จแล้ว', markNotDone: 'ยังไม่เสร็จ', deleteQ: 'ลบ “:name” ใช่ไหม?' }
  };
</script>
