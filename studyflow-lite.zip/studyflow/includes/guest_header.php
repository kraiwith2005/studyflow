<?php // guest_header.php : ส่วนบนของหน้าเข้าสู่ระบบ / สมัครสมาชิก (ยังไม่ได้เข้าสู่ระบบ) ?>
<!DOCTYPE html>
<html lang="th">
<head>
  <?php include ROOT . '/includes/head.php'; ?>
</head>
<body>
  <div class="auth-page">
    <aside class="auth-brand" aria-label="StudyFlow">
      <?php include ROOT . '/includes/brand.php'; ?>
      <div class="auth-hero">
        <p class="auth-hero-title">งานและเรียนทั้งหมด ในที่เดียว</p>
        <ul class="auth-points">
          <li>รวมงานทุกวิชาไว้ด้วยกัน</li>
          <li>ป้ายสีเตือนกำหนดส่ง ไม่พลาดงานไหน</li>
          <li>วางแผนและบันทึกการอ่านหนังสือ</li>
        </ul>
      </div>
    </aside>

    <div class="auth-side">
      <header class="auth-top"></header>
      <main class="auth-main">
        <div class="auth-card">
