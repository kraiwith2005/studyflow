<?php
// =====================================================================
//  auth.php : ระบบสมาชิก
//  - รู้ว่าใครเข้าสู่ระบบอยู่ (เก็บ id ผู้ใช้ไว้ใน $_SESSION)
//  - CSRF token : รหัสลับที่แนบไปกับทุกฟอร์ม กันเว็บอื่นแอบส่งฟอร์มแทนเรา
//  - จำกัดการใส่รหัสผ่านผิด 5 ครั้งต่อนาที
//  รหัสผ่านเก็บด้วย password_hash() (เข้ารหัสแบบ bcrypt ย้อนกลับไม่ได้)
//  และตรวจด้วย password_verify()
// =====================================================================

// ข้อมูลผู้ใช้ที่เข้าสู่ระบบอยู่ (array)  ยังไม่เข้าสู่ระบบ = null
function current_user()
{
    if (! isset($_SESSION['user_id'])) {
        return null;
    }
    $user = db_select_one('SELECT * FROM users WHERE id = ?', [$_SESSION['user_id']]);
    if ($user == null) {                 // บัญชีถูกลบไปแล้ว
        unset($_SESSION['user_id']);
        return null;
    }

    // ข้อมูลเพิ่มสำหรับแสดงผล
    $user['full_name'] = trim($user['first_name'] . ' ' . $user['last_name']);
    $user['initial'] = mb_strtoupper(mb_substr($user['first_name'] != '' ? $user['first_name'] : $user['email'], 0, 1));
    $colors = ['#9b4dca', '#3f7cc4', '#c2477a', '#2f8a6b', '#c27a2c', '#5b5bd6', '#b5483b'];
    $user['avatar_color'] = $colors[crc32(strtolower($user['email'])) % count($colors)];   // สีประจำตัว
    return $user;
}

// id ของผู้ใช้ที่เข้าสู่ระบบอยู่
function user_id()
{
    return (int) $_SESSION['user_id'];
}

// ใส่ไว้บนสุดของหน้าที่ต้องเข้าสู่ระบบก่อน  ถ้ายังไม่เข้า -> ไปหน้าเข้าสู่ระบบ
function require_login()
{
    if (current_user() == null) {
        redirect('sign-in');
    }
}

// ใส่ไว้ในหน้าเข้าสู่ระบบ / สมัครสมาชิก  ถ้าเข้าอยู่แล้ว -> ไปหน้าวันนี้
function require_guest()
{
    if (current_user() != null) {
        redirect('today');
    }
}

// จำว่าผู้ใช้คนนี้เข้าสู่ระบบแล้ว
function login_user($id)
{
    session_regenerate_id(true);    // เปลี่ยนรหัส session ใหม่ กันคนขโมย session เดิม
    $_SESSION['user_id'] = (int) $id;
}

// ออกจากระบบ : ล้างข้อมูลใน session ทั้งหมด
function logout_user()
{
    $_SESSION = [];
    session_regenerate_id(true);
}

// ---------- CSRF ----------

// รหัสลับประจำ session (สร้างครั้งแรกครั้งเดียว)
function csrf_token()
{
    if (! isset($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

// ช่องซ่อนที่ต้องใส่ในทุก <form method="POST">
function csrf_field()
{
    return '<input type="hidden" name="_token" value="' . csrf_token() . '">';
}

// ตรวจรหัสลับที่ส่งมากับฟอร์ม (หรือกับ JavaScript ผ่าน header X-CSRF-TOKEN)
function check_csrf()
{
    $sent = $_POST['_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (! is_string($sent) || ! hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        die('หน้านี้หมดอายุแล้ว กรุณากลับไปแล้วลองใหม่อีกครั้ง');
    }
}

// ไฟล์ที่รับฟอร์ม (POST) เรียกฟังก์ชันนี้บรรทัดแรก : ต้อง POST + ต้องเข้าสู่ระบบ + CSRF ถูกต้อง
function require_post()
{
    if ($_SERVER['REQUEST_METHOD'] != 'POST') {
        redirect('today');
    }
    check_csrf();
    require_login();
}

// ---------- จำกัดการใส่รหัสผ่านผิด ----------

// ลองไปแล้วกี่ครั้ง (ภายใน 1 นาทีล่าสุด)
function count_attempts($key)
{
    $row = db_select_one('SELECT attempts, reset_at FROM login_attempts WHERE `key` = ?', [$key]);
    if ($row == null || strtotime($row['reset_at']) <= time()) {
        return 0;   // ไม่เคยลอง หรือครบ 1 นาทีแล้ว นับใหม่
    }
    return (int) $row['attempts'];
}

// นับเพิ่ม 1 ครั้ง
function add_attempt($key)
{
    if (count_attempts($key) == 0) {
        db_run('REPLACE INTO login_attempts (`key`, attempts, reset_at) VALUES (?, 1, ?)', [$key, date('Y-m-d H:i:s', time() + 60)]);
    } else {
        db_run('UPDATE login_attempts SET attempts = attempts + 1 WHERE `key` = ?', [$key]);
    }
}

// เข้าสู่ระบบสำเร็จ -> ล้างตัวนับ
function clear_attempts($key)
{
    db_run('DELETE FROM login_attempts WHERE `key` = ?', [$key]);
}

// ตรวจรหัสผ่านใหม่ : อย่างน้อย 8 ตัว และต้องมีทั้งตัวอักษรและตัวเลข
// ผ่าน = คืนค่า ''   ไม่ผ่าน = คืนข้อความ error
function check_new_password($password)
{
    if ($password == '') {
        return 'กรุณากรอกรหัสผ่าน';
    } elseif (mb_strlen($password) < 8) {
        return 'รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร';
    } elseif (! preg_match('/[a-zA-Z]/', $password)) {
        return 'รหัสผ่านต้องมีตัวอักษรอย่างน้อย 1 ตัว';
    } elseif (! preg_match('/[0-9]/', $password)) {
        return 'รหัสผ่านต้องมีตัวเลขอย่างน้อย 1 ตัว';
    }
    return '';
}
