<?php
// ช่องรหัสผ่าน + ปุ่มรูปตา (แสดง/ซ่อนรหัส)
// ก่อน include ให้ตั้งตัวแปร : $pw_id, $pw_name, $pw_label, $pw_placeholder, $pw_form (ชื่อฟอร์มสำหรับ error)
//                       ไม่บังคับ : $pw_hint (คำแนะนำใต้ช่อง)
?>
<div class="field">
  <label class="label" for="<?= e($pw_id) ?>"><?= e($pw_label) ?></label>
  <div class="input-wrap">
    <input id="<?= e($pw_id) ?>" name="<?= e($pw_name) ?>" type="password" class="input <?= invalid($pw_form, $pw_name) ?>"
           placeholder="<?= e($pw_placeholder) ?>" autocomplete="<?= $pw_name == 'current_password' || $pw_form == 'sign-in' || $pw_form == 'delete' ? 'current-password' : 'new-password' ?>" required>
    <button type="button" class="input-action" data-toggle-password="<?= e($pw_id) ?>" aria-label="แสดงรหัสผ่าน" aria-pressed="false">
      <?= icon('eye') ?>
    </button>
  </div>
  <?php if (! empty($pw_hint) && error_of($pw_form, $pw_name) == ''): ?><span class="field-hint"><?= e($pw_hint) ?></span><?php endif; ?>
  <?= show_error($pw_form, $pw_name) ?>
</div>
<?php $pw_hint = ''; ?>
