<?php // footer.php : ส่วนท้ายของทุกหน้าหลังเข้าสู่ระบบ  ($scripts = ไฟล์ JavaScript เพิ่มเติมของหน้านั้น) ?>
  </main>

  <script src="<?= e(asset('js/app.js')) ?>"></script>
  <?php foreach ($scripts ?? [] as $script): ?>
    <script src="<?= e(asset($script)) ?>"></script>
  <?php endforeach; ?>
</body>
</html>
