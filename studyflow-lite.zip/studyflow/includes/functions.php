<?php
// =====================================================================
//  functions.php : ฟังก์ชันทั่วไปที่ทุกหน้าใช้ร่วมกัน
// =====================================================================

// ---------- การแสดงผล ----------

// แปลงข้อความให้ปลอดภัยก่อนแสดงบนหน้าเว็บ (กัน XSS : ผู้ใช้พิมพ์ <script> มาก็จะไม่ทำงาน)
function e($text)
{
    return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
}

// ใส่ค่าลงในข้อความ เช่น fill('ส่งในอีก :count วัน', ['count' => 3])  ได้ "ส่งในอีก 3 วัน"
function fill($text, $values)
{
    foreach ($values as $key => $value) {
        $text = str_replace(':' . $key, $value, $text);
    }
    return $text;
}

// สร้างลิงก์ภายในเว็บ เช่น url('tasks', ['q' => 'สอบ'])  ได้ "/tasks?q=สอบ"
function url($page, $query = [])
{
    $link = BASE . '/' . $page;
    // ตัดค่าที่ว่างออก จะได้ไม่มี ?a=&b= ใน URL
    $clean = [];
    foreach ($query as $key => $value) {
        if ($value !== null && $value !== '' && $value !== false) {
            $clean[$key] = $value;
        }
    }
    if (count($clean) > 0) {
        $link .= '?' . http_build_query($clean);
    }
    return $link;
}

// ลิงก์ไฟล์ css / js  (เติม ?v=เวลาแก้ไขไฟล์ เพื่อให้เบราว์เซอร์โหลดไฟล์ใหม่เมื่อมีการแก้)
function asset($file)
{
    return BASE . '/' . $file . '?v=' . filemtime(ROOT . '/' . $file);
}

// ไอคอน SVG เช่น icon('plus')
function icon($name, $class = '', $size = 18)
{
    static $shapes = null;
    if ($shapes === null) {
        $shapes = require ROOT . '/includes/icons.php';
    }
    $classAttr = $class != '' ? ' class="' . e($class) . '"' : '';
    return '<svg' . $classAttr . ' width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        . 'stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($shapes[$name] ?? '') . '</svg>';
}

// คืนค่า 'selected' / 'checked' เมื่อเงื่อนไขเป็นจริง (ใช้กับ <option> และ <input type="radio">)
function selected($condition)
{
    return $condition ? 'selected' : '';
}
function checked($condition)
{
    return $condition ? 'checked' : '';
}

// ---------- รับค่าจากฟอร์ม ----------

// อ่านค่าจากฟอร์ม (POST) แล้วตัดช่องว่างหัวท้าย  ไม่มีค่า = ''
function post($name)
{
    if (! isset($_POST[$name]) || ! is_string($_POST[$name])) {
        return '';
    }
    return trim($_POST[$name]);
}

// อ่านค่าจาก URL (GET) เช่น tasks?q=สอบ  get('q') ได้ 'สอบ'
function get($name)
{
    if (! isset($_GET[$name]) || ! is_string($_GET[$name])) {
        return '';
    }
    return trim($_GET[$name]);
}

// ---------- ย้ายหน้า + ฝากข้อความไว้ให้หน้าถัดไป ----------

// ไปหน้าอื่น แล้วจบการทำงานของไฟล์นี้ทันที   ($section = เลื่อนไปที่ส่วนนั้นของหน้า เช่น 'timetable')
function redirect($page, $query = [], $section = '')
{
    $link = url($page, $query);
    if ($section != '') {
        $link .= '#' . $section;
    }
    header('Location: ' . $link);
    exit;
}

// ฝากข้อความสำเร็จ (กล่องสีเขียว) ไว้แสดงที่หน้าถัดไป
function set_message($text)
{
    $_SESSION['flash']['message'] = $text;
}

// ฝาก error ของฟอร์ม + ค่าที่ผู้ใช้พิมพ์ไว้  $form = ชื่อฟอร์ม, $reopen = กล่องที่ต้องเปิดค้างไว้
function set_errors($form, $errors, $reopen = '')
{
    $_SESSION['flash']['form'] = $form;
    $_SESSION['flash']['errors'] = $errors;
    $_SESSION['flash']['old'] = $_POST;
    $_SESSION['flash']['reopen'] = $reopen;
}

// ข้อความสำเร็จที่ฝากไว้ (ไม่มี = '')
function message()
{
    global $flash;
    return $flash['message'] ?? '';
}

// ชื่อกล่อง (dialog) ที่ต้องเปิดค้างไว้หลังกรอกผิด
function reopen()
{
    global $flash;
    return $flash['reopen'] ?? '';
}

// ค่าที่ผู้ใช้พิมพ์ไว้ก่อนกรอกผิด (จะได้ไม่ต้องพิมพ์ใหม่)
function old($name, $default = '')
{
    global $flash;
    if (isset($flash['old'][$name]) && is_string($flash['old'][$name])) {
        return $flash['old'][$name];
    }
    return $default;
}

// ข้อความ error ของช่อง $field ในฟอร์ม $form (ไม่มี = '')
function error_of($form, $field)
{
    global $flash;
    if (($flash['form'] ?? '') != $form) {
        return '';
    }
    return $flash['errors'][$field] ?? '';
}

// HTML ของ error ใต้ช่องกรอก
function show_error($form, $field)
{
    $text = error_of($form, $field);
    if ($text == '') {
        return '';
    }
    return '<span class="field-error" role="alert">' . e($text) . '</span>';
}

// ใส่กรอบแดงให้ช่องที่กรอกผิด
function invalid($form, $field)
{
    return error_of($form, $field) != '' ? 'is-invalid' : '';
}

// กลับไปหน้าที่ส่งฟอร์มมา (Today / Calendar / Tasks / Study)
function go_back()
{
    $return = post('return');
    // ยอมให้กลับได้เฉพาะหน้าในเว็บเรา (กันคนส่งลิงก์เว็บอื่นมา)
    if (preg_match('/^(today|calendar|tasks|study)(\?.*)?$/', $return)) {
        header('Location: ' . BASE . '/' . $return);
        exit;
    }
    redirect('calendar');
}

// หน้าปัจจุบัน + query เช่น "tasks?q=สอบ"  (ใส่ในฟอร์ม เพื่อให้กลับมาหน้าเดิมได้)
function current_page()
{
    $page = basename($_SERVER['SCRIPT_NAME'], '.php');
    $query = $_SERVER['QUERY_STRING'] ?? '';
    if ($query != '') {
        return $page . '?' . $query;
    }
    return $page;
}

// ตอบกลับเป็น JSON (ใช้กับปุ่มสลับธีมที่ JavaScript ส่งมา)
function json_reply($data, $code = 200)
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// ---------- วันที่และเวลา (เก็บเป็นข้อความ 'ปี-เดือน-วัน' เช่น '2026-11-25') ----------

// วันนี้
function today()
{
    return date('Y-m-d');
}

// บวก/ลบวัน เช่น add_days('2026-11-25', 7) ได้ '2026-12-02'
function add_days($date, $days)
{
    return date('Y-m-d', strtotime($date . ' ' . ($days >= 0 ? '+' : '') . $days . ' days'));
}

// จำนวนวันจาก $from ถึง $to (ติดลบถ้า $to มาก่อน)
function days_between($from, $to)
{
    return (int) round((strtotime($to) - strtotime($from)) / 86400);
}

// วันอาทิตย์ที่เป็นวันแรกของสัปดาห์ที่มี $date
function week_start($date)
{
    $weekday = (int) date('w', strtotime($date));   // 0 = อาทิตย์ ... 6 = เสาร์
    return add_days($date, -$weekday);
}

// ตรวจว่าเป็นวันที่จริงไหม เช่น '2026-02-30' ไม่ใช่
function is_date($text)
{
    if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $text)) {
        return false;
    }
    $parts = explode('-', $text);
    return checkdate((int) $parts[1], (int) $parts[2], (int) $parts[0]);
}

// ตรวจว่าเป็นเวลา ชั่วโมง:นาที เช่น '23:59'
function is_time($text)
{
    return preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $text) == 1;
}

// '13:20:00' -> '13:20'
function show_time($time)
{
    if ($time == null || $time == '') {
        return '';
    }
    return substr($time, 0, 5);
}

// ชื่อเดือนและวันภาษาไทย
const MONTHS_SHORT = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
const MONTHS_FULL = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
const DAYS_FULL = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
const DAYS_SHORT = ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'];

// วันที่แบบไทย (ปี พ.ศ.)
//   'short' : 25 พ.ย. 2569
//   'long'  : วันพุธที่ 25 พฤศจิกายน 2569
//   'month' : พฤศจิกายน 2569
function thai_date($date, $style = 'short')
{
    if ($date == null || $date == '') {
        return '';
    }
    $time = strtotime(substr($date, 0, 10));
    $day = (int) date('j', $time);
    $month = (int) date('n', $time) - 1;          // array เริ่มที่ 0
    $year = (int) date('Y', $time) + 543;         // ค.ศ. -> พ.ศ.
    $weekday = (int) date('w', $time);

    if ($style == 'long') {
        return 'วัน' . DAYS_FULL[$weekday] . 'ที่ ' . $day . ' ' . MONTHS_FULL[$month] . ' ' . $year;
    } elseif ($style == 'month') {
        return MONTHS_FULL[$month] . ' ' . $year;
    } else {
        return $day . ' ' . MONTHS_SHORT[$month] . ' ' . $year;
    }
}

// ระยะเวลาเป็นคำ เช่น 45 -> "45 นาที", 90 -> "1 ชม. 30 นาที", 120 -> "2 ชม."
function duration_text($minutes)
{
    if ($minutes <= 60) {
        return $minutes . ' นาที';
    }
    $hours = intdiv($minutes, 60);
    $rest = $minutes % 60;
    if ($rest == 0) {
        return $hours . ' ชม.';
    }
    return $hours . ' ชม. ' . $rest . ' นาที';
}

// เวลา 'ชั่วโมง:นาที' -> จำนวนนาทีนับจากเที่ยงคืน เช่น '01:30' -> 90
function to_minutes($time)
{
    $parts = explode(':', $time);
    return (int) $parts[0] * 60 + (int) $parts[1];
}
