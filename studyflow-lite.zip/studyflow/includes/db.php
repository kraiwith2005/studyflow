<?php
// =====================================================================
//  db.php : เชื่อมต่อฐานข้อมูล MySQL และฟังก์ชันสั่งงานฐานข้อมูล
//  ใช้ PDO + prepared statement (ใส่ ? แทนค่า) เพื่อกัน SQL Injection
// =====================================================================

// คืนค่าการเชื่อมต่อฐานข้อมูล (เชื่อมครั้งแรกครั้งเดียว ครั้งต่อไปใช้ของเดิม)
function db()
{
    static $pdo = null;
    global $config;

    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4';
            $pdo = new PDO($dsn, $config['db_user'], $config['db_pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);          // มีปัญหาให้แจ้ง error
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);     // ได้ผลเป็น array แบบมีชื่อคอลัมน์
        } catch (PDOException $error) {
            // เหมือน try / except ใน Python : ถ้าเชื่อมไม่ได้ ให้แสดงข้อความแทนการพัง
            error_log($error->getMessage());
            die('เชื่อมต่อฐานข้อมูลไม่ได้ กรุณาตรวจสอบค่าใน config.php');
        }
    }
    return $pdo;
}

// ดึงข้อมูลหลายแถว  ผลลัพธ์ = array ของแถว  เช่น [ ['id'=>1,'name'=>'คณิต'], ['id'=>2,'name'=>'ฟิสิกส์'] ]
function db_select($sql, $params = [])
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// ดึงข้อมูลแถวเดียว  ไม่เจอ = null
function db_select_one($sql, $params = [])
{
    $rows = db_select($sql, $params);
    if (count($rows) == 0) {
        return null;
    }
    return $rows[0];
}

// สั่ง INSERT / UPDATE / DELETE
function db_run($sql, $params = [])
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
}

// id ของแถวที่เพิ่ง INSERT
function db_last_id()
{
    return (int) db()->lastInsertId();
}

// วันเวลาปัจจุบันในรูปแบบที่ MySQL ใช้ เช่น 2026-11-25 18:30:00
function now()
{
    return date('Y-m-d H:i:s');
}
