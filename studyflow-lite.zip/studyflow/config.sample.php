<?php
// ===== ตั้งค่าระบบ =====
// คัดลอกไฟล์นี้เป็น config.php แล้วแก้ค่าให้ตรงกับเครื่องของตัวเอง
// (config.php ไม่อัปขึ้น GitHub เพราะมีรหัสผ่านฐานข้อมูล)
return [
    // ฐานข้อมูล (ค่าเริ่มต้นของ XAMPP: ผู้ใช้ root ไม่มีรหัสผ่าน)
    'db_host' => '127.0.0.1',
    'db_name' => 'studyflow',
    'db_user' => 'root',
    'db_pass' => '',

    // true = แสดง error ของ PHP บนหน้าเว็บ (ใช้ตอนพัฒนาในเครื่องตัวเอง)
    // บนเว็บจริงให้เป็น false
    'debug' => false,

    // อีเมลติดต่อที่แสดงในหน้าตั้งค่า
    'support_email' => 'mystudyplanner.studio@gmail.com',
];
