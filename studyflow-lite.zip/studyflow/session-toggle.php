<?php
// session-toggle.php : สลับสถานะการอ่าน อ่านแล้ว <-> ยังไม่ได้อ่าน
require 'includes/start.php';
require_post();

$session = find_session(user_id(), get('id'));
if ($session == null) {
    redirect('study');
}

if ($session['done']) {
    db_run("UPDATE study_sessions SET status = 'planned', actual_minutes = NULL, updated_at = ? WHERE id = ? AND user_id = ?",
        [now(), $session['id'], user_id()]);
    set_message('ทำเครื่องหมายว่ายังไม่เสร็จ');
} else {
    // อ่านเสร็จ : นับเวลาตามที่วางแผนไว้
    db_run("UPDATE study_sessions SET status = 'completed', actual_minutes = duration_minutes, updated_at = ? WHERE id = ? AND user_id = ?",
        [now(), $session['id'], user_id()]);
    set_message('ทำเครื่องหมายว่าเสร็จแล้ว');
}
go_back();
