<?php
// หน้าแรก : เข้าสู่ระบบแล้วไปหน้า "วันนี้"  ยังไม่เข้า ไปหน้าเข้าสู่ระบบ
require 'includes/start.php';

if (current_user() != null) {
    redirect('today');
} else {
    redirect('sign-in');
}
