<?php
// =====================================================================
//  today.php : หน้า "วันนี้" สรุปงานที่ต้องส่ง และแผนการอ่านของวันนี้
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();
$today = today();

// งานที่ยังไม่เสร็จ ที่ต้องส่งภายใน 7 วัน (รวมงานที่เลยกำหนดแล้ว)
// เรียง : วันส่ง -> ความสำคัญ (สูงก่อน) -> เวลาส่ง
$openTasks = get_tasks($userId, 't.completed_at IS NULL AND t.due_date <= ?', [add_days($today, 7)],
    "t.due_date, FIELD(t.priority, 'high', 'normal', 'low'), t.due_time IS NULL, t.due_time");

// แบ่งงานเป็น 3 กลุ่มด้วย loop + if
$overdue = [];    // เลยกำหนด
$dueToday = [];   // ส่งวันนี้
$dueSoon = [];    // 7 วันข้างหน้า
foreach ($openTasks as $task) {
    if ($task->dueDate < $today) {
        $overdue[] = $task;
    } elseif ($task->dueDate == $today) {
        $dueToday[] = $task;
    } else {
        $dueSoon[] = $task;
    }
}
$groups = [
    ['tone' => 'overdue', 'heading' => 'เลยกำหนด', 'tasks' => $overdue],
    ['tone' => 'today', 'heading' => 'ส่งวันนี้', 'tasks' => $dueToday],
    ['tone' => 'soon', 'heading' => '7 วันข้างหน้า', 'tasks' => $dueSoon],
];

// การอ่านหนังสือของวันนี้ แยกเป็น "วางแผนไว้" กับ "อ่านเสร็จแล้ว"
$plannedToday = [];
$doneToday = [];
foreach (get_sessions($userId, 'ss.date = ?', [$today], 'ss.start_time') as $session) {
    if ($session['done']) {
        $doneToday[] = $session;
    } else {
        $plannedToday[] = $session;
    }
}
list($weekCount, $weekMinutes) = week_study_totals($userId);

// ข้อมูลสำหรับกล่องเพิ่ม/แก้ไข
$subjects = get_subjects($userId);
$assessments = open_assessments($userId);

$title = 'วันนี้';
$page = 'today';
$scripts = ['js/calendar.js'];
include 'includes/header.php';
?>
<div class="page" id="today-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">วันนี้</h1>
      <p class="page-sub"><?= thai_date($today, 'long') ?></p>
    </div>
    <button type="button" class="btn btn-primary btn-lg" data-add-date="<?= $today ?>">
      <?= icon('plus') ?> เพิ่มรายการ
    </button>
  </div>

  <?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

  <div class="today-grid">
    <?php // ---------- การ์ด "ต้องส่ง" ---------- ?>
    <section class="card today-card">
      <div class="card-title">ต้องส่ง</div>
      <?php if (count($openTasks) == 0): ?>
        <p class="today-empty">ไม่มีงานต้องส่งใน 7 วันข้างหน้า</p>
      <?php endif; ?>

      <?php foreach ($groups as $group): ?>
        <?php if (count($group['tasks']) > 0): ?>
          <p class="today-subhead tone-<?= $group['tone'] ?>"><?= $group['heading'] ?> · <?= count($group['tasks']) ?></p>
          <ul class="today-list">
            <?php foreach ($group['tasks'] as $task): ?>
              <?php $badge = $task->dueBadge(); ?>
              <li class="today-row is-task" style="--c: <?= e($task->color) ?>">
                <form method="POST" action="<?= e(url('task-toggle', ['id' => $task->id])) ?>" class="task-check-form">
                  <?= csrf_field() ?>
                  <input type="hidden" name="return" value="today">
                  <button type="submit" class="task-check" aria-label="ทำเครื่องหมายว่า “<?= e($task->title) ?>” เสร็จแล้ว">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                  </button>
                </form>
                <button type="button" class="today-main today-btn" data-item="<?= e(item_json($task->toArray())) ?>">
                  <span class="today-name">
                    <?php if ($task->priority == 'high'): ?><span class="prio-flag" aria-label="สำคัญมาก">!</span><?php endif; ?>
                    <?= e($task->title) ?>
                  </span>
                  <span class="today-meta">
                    <?php if ($task->subjectName != null): ?><span class="swatch-dot" style="background: <?= e($task->color) ?>"></span><?= e($task->subjectName) ?> · <?php endif; ?>
                    <?= thai_date($task->dueDate) ?><?php if ($task->dueTime != ''): ?> เวลา <?= $task->dueTime ?><?php endif; ?>
                  </span>
                </button>
                <span class="due-badge tone-<?= $badge[1] ?>"><?= $badge[0] ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      <?php endforeach; ?>
    </section>

    <?php // ---------- การ์ด "แผนการอ่าน" ---------- ?>
    <section class="card today-card">
      <div class="card-title">แผนการอ่าน</div>
      <p class="today-stat">
        สัปดาห์นี้: <strong><?= $weekCount ?> ครั้ง</strong>
        · <strong><?= duration_text($weekMinutes) ?></strong>
      </p>
      <?php if (count($plannedToday) == 0 && count($doneToday) == 0): ?>
        <p class="today-empty">วันนี้ยังไม่มีแผนอ่านหนังสือ</p>
        <a class="btn btn-outline btn-sm" href="<?= e(url('study')) ?>">ไปที่อ่านหนังสือ</a>
      <?php else: ?>
        <ul class="today-list">
          <?php foreach ($plannedToday as $session): ?>
            <li class="today-row" style="--c: <?= e($session['color']) ?>">
              <span class="today-time"><?= $session['start'] ?></span>
              <button type="button" class="today-main today-btn" data-item="<?= e(item_json(session_to_array($session))) ?>">
                <span class="today-name"><?= e($session['title']) ?></span>
                <span class="today-meta"><?= duration_text($session['duration_minutes']) ?><?php if ($session['subject_name'] != null): ?> · <?= e($session['subject_name']) ?><?php endif; ?></span>
              </button>
              <form method="POST" action="<?= e(url('session-toggle', ['id' => $session['id']])) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="return" value="today">
                <button type="submit" class="btn btn-primary btn-sm">ทำเสร็จแล้ว</button>
              </form>
            </li>
          <?php endforeach; ?>
          <?php foreach ($doneToday as $session): ?>
            <li class="today-row is-done" style="--c: <?= e($session['color']) ?>">
              <span class="today-time"><?= $session['start'] ?></span>
              <span class="today-main">
                <span class="today-name"><?= e($session['title']) ?></span>
                <span class="today-meta">เสร็จแล้ว · <?= duration_text($session['actual_minutes'] ?: $session['duration_minutes']) ?></span>
              </span>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>
  </div>
</div>

<?php include 'includes/dialogs.php'; ?>
<?php include 'includes/footer.php'; ?>
