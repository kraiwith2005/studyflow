<?php
// =====================================================================
//  sign-in.php : เข้าสู่ระบบ
// =====================================================================
require 'includes/start.php';
require_guest();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    check_csrf();
    $email = strtolower(post('email'));
    $password = $_POST['password'] ?? '';

    // ตรวจว่ากรอกครบไหม
    $errors = [];
    if ($email == '') {
        $errors['email'] = 'กรุณากรอกอีเมล';
    } elseif (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'รูปแบบอีเมลไม่ถูกต้อง';
    }
    if ($password == '') {
        $errors['password'] = 'กรุณากรอกรหัสผ่าน';
    }

    // กันการเดารหัสผ่าน : ผิดได้ไม่เกิน 5 ครั้งต่อนาที (นับแยกตามอีเมล + เครื่องที่ใช้)
    $key = 'login|' . $email . '|' . ($_SERVER['REMOTE_ADDR'] ?? '');
    if (count($errors) == 0 && count_attempts($key) >= 5) {
        $errors['email'] = 'พยายามเข้าสู่ระบบหลายครั้งเกินไป กรุณารอ 1 นาทีแล้วลองใหม่';
    }

    // หาผู้ใช้จากอีเมล แล้วเทียบรหัสผ่านด้วย password_verify
    if (count($errors) == 0) {
        $user = db_select_one('SELECT id, password FROM users WHERE email = ?', [$email]);
        if ($user == null || $user['password'] == null || ! password_verify($password, $user['password'])) {
            add_attempt($key);
            $errors['email'] = 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
        }
    }

    if (count($errors) > 0) {
        set_errors('sign-in', $errors);
        redirect('sign-in');
    }

    clear_attempts($key);
    login_user($user['id']);
    redirect('today');
}

// ---------- แสดงฟอร์ม ----------
$title = 'เข้าสู่ระบบ';
include 'includes/guest_header.php';
?>
<h1 class="auth-title">ยินดีต้อนรับกลับ</h1>
<p class="auth-sub">เข้าสู่ระบบเพื่อทำต่อจากที่ค้างไว้</p>

<?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

<form method="POST" action="<?= e(url('sign-in')) ?>" novalidate data-once>
  <?= csrf_field() ?>
  <div class="field">
    <label class="label" for="email">อีเมล</label>
    <input id="email" name="email" type="email" class="input <?= invalid('sign-in', 'email') ?>"
           value="<?= e(old('email')) ?>" placeholder="กรอกอีเมลของคุณ" autocomplete="email" required autofocus>
    <?= show_error('sign-in', 'email') ?>
  </div>

  <?php
  $pw_id = 'password'; $pw_name = 'password'; $pw_label = 'รหัสผ่าน'; $pw_placeholder = 'กรอกรหัสผ่าน'; $pw_form = 'sign-in';
  include 'includes/password_field.php';
  ?>

  <div class="auth-actions">
    <button type="submit" class="btn btn-primary btn-block btn-lg">เข้าสู่ระบบ <?= icon('arrow', '', 16) ?></button>
  </div>
</form>

<p class="auth-switch">เพิ่งเคยใช้? <a href="<?= e(url('sign-up')) ?>">สร้างบัญชี</a></p>
<?php include 'includes/guest_footer.php'; ?>
