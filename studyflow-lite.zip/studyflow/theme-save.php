<?php
// =====================================================================
//  theme-save.php : บันทึกโหมดสว่าง / โหมดมืด
//  JavaScript (js/app.js) ส่งข้อมูลมาเป็น JSON เช่น {"theme": "dark"} แล้วรอคำตอบเป็น JSON
// =====================================================================
require 'includes/start.php';
require_post();

$body = json_decode(file_get_contents('php://input'), true);   // อ่าน JSON ที่ส่งมา -> array
$theme = $body['theme'] ?? '';

if ($theme != 'light' && $theme != 'dark') {
    json_reply(['message' => 'ค่าธีมไม่ถูกต้อง'], 422);
}
db_run('UPDATE users SET theme = ?, updated_at = ? WHERE id = ?', [$theme, now(), user_id()]);
json_reply(['saved' => true, 'theme' => $theme]);
