<?php
// =====================================================================
//  sign-up.php : สมัครสมาชิก
//  เปิดหน้า (GET) = แสดงฟอร์ม   กดสมัคร (POST) = ตรวจข้อมูลแล้วบันทึกผู้ใช้ใหม่
// =====================================================================
require 'includes/start.php';
require_guest();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    check_csrf();

    // 1) รับค่าจากฟอร์ม
    $firstName = post('first_name');
    $lastName = post('last_name');
    $email = strtolower(post('email'));
    $password = $_POST['password'] ?? '';

    // 2) ตรวจข้อมูล  เก็บ error ไว้ใน array  (key = ชื่อช่อง, value = ข้อความ)
    $errors = [];
    if ($firstName == '') {
        $errors['first_name'] = 'กรุณากรอกชื่อ';
    } elseif (mb_strlen($firstName) > 60) {
        $errors['first_name'] = 'ชื่อยาวเกิน 60 ตัวอักษร';
    }
    if ($lastName == '') {
        $errors['last_name'] = 'กรุณากรอกนามสกุล';
    } elseif (mb_strlen($lastName) > 60) {
        $errors['last_name'] = 'นามสกุลยาวเกิน 60 ตัวอักษร';
    }
    if ($email == '') {
        $errors['email'] = 'กรุณากรอกอีเมล';
    } elseif (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'รูปแบบอีเมลไม่ถูกต้อง';
    } elseif (db_select_one('SELECT id FROM users WHERE email = ?', [$email]) != null) {
        $errors['email'] = 'อีเมลนี้มีบัญชีอยู่แล้ว กรุณาเข้าสู่ระบบแทน';
    }
    $passwordError = check_new_password($password);
    if ($passwordError != '') {
        $errors['password'] = $passwordError;
    }

    // 3) มี error -> กลับไปหน้าฟอร์ม พร้อมข้อความ
    if (count($errors) > 0) {
        set_errors('sign-up', $errors);
        redirect('sign-up');
    }

    // 4) ผ่านทุกข้อ -> บันทึกผู้ใช้ (รหัสผ่านเข้ารหัสด้วย password_hash ก่อนเก็บ)
    db_run('INSERT INTO users (first_name, last_name, email, password, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
        [$firstName, $lastName, $email, password_hash($password, PASSWORD_BCRYPT), now(), now()]);
    login_user(db_last_id());
    redirect('today');
}

// ---------- แสดงฟอร์ม ----------
$title = 'สมัครสมาชิก';
include 'includes/guest_header.php';
?>
<h1 class="auth-title">สร้างบัญชีของคุณ</h1>
<p class="auth-sub">บันทึกงานเรียนครั้งเดียว StudyFlow เชื่อมทุกอย่างให้เอง</p>

<form method="POST" action="<?= e(url('sign-up')) ?>" novalidate data-once>
  <?= csrf_field() ?>
  <div class="field-row">
    <div class="field">
      <label class="label" for="first_name">ชื่อ</label>
      <input id="first_name" name="first_name" class="input <?= invalid('sign-up', 'first_name') ?>"
             value="<?= e(old('first_name')) ?>" placeholder="ชื่อ" autocomplete="given-name" required autofocus>
      <?= show_error('sign-up', 'first_name') ?>
    </div>
    <div class="field">
      <label class="label" for="last_name">นามสกุล</label>
      <input id="last_name" name="last_name" class="input <?= invalid('sign-up', 'last_name') ?>"
             value="<?= e(old('last_name')) ?>" placeholder="นามสกุล" autocomplete="family-name" required>
      <?= show_error('sign-up', 'last_name') ?>
    </div>
  </div>

  <div class="field">
    <label class="label" for="email">อีเมล</label>
    <input id="email" name="email" type="email" class="input <?= invalid('sign-up', 'email') ?>"
           value="<?= e(old('email')) ?>" placeholder="กรอกอีเมลของคุณ" autocomplete="email" required>
    <?= show_error('sign-up', 'email') ?>
  </div>

  <?php
  $pw_id = 'password'; $pw_name = 'password'; $pw_label = 'รหัสผ่าน'; $pw_placeholder = 'กรอกรหัสผ่าน'; $pw_form = 'sign-up';
  $pw_hint = 'อย่างน้อย 8 ตัวอักษร มีทั้งตัวอักษรและตัวเลข';
  include 'includes/password_field.php';
  ?>

  <div class="auth-actions">
    <button type="submit" class="btn btn-primary btn-block btn-lg">ดำเนินการต่อ <?= icon('arrow', '', 16) ?></button>
  </div>
</form>

<p class="auth-switch">มีบัญชีอยู่แล้ว? <a href="<?= e(url('sign-in')) ?>">เข้าสู่ระบบ</a></p>
<p class="auth-legal">
  เมื่อสร้างบัญชี ถือว่าคุณยอมรับ<a href="<?= e(url('terms')) ?>">ข้อตกลงการใช้งาน</a> และรับทราบ<a href="<?= e(url('privacy')) ?>">นโยบายความเป็นส่วนตัว</a> ทั้งนี้คุณจะไม่ได้รับข้อความโฆษณาใด ๆ
</p>
<?php include 'includes/guest_footer.php'; ?>
