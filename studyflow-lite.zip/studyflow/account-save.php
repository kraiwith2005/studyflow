<?php
// =====================================================================
//  account-save.php : บันทึกจากหน้าจัดการบัญชี
//    action = profile  -> แก้ชื่อ นามสกุล อีเมล
//    action = password -> เปลี่ยนรหัสผ่าน
// =====================================================================
require 'includes/start.php';
require_post();
$user = current_user();
$action = post('action');

if ($action == 'profile') {
    $firstName = post('first_name');
    $lastName = post('last_name');
    $email = strtolower(post('email'));

    $errors = [];
    if ($firstName == '') {
        $errors['first_name'] = 'กรุณากรอกชื่อ';
    } elseif (mb_strlen($firstName) > 60) {
        $errors['first_name'] = 'ชื่อยาวเกิน 60 ตัวอักษร';
    }
    if ($lastName == '') {
        $errors['last_name'] = 'กรุณากรอกนามสกุล';
    } elseif (mb_strlen($lastName) > 60) {
        $errors['last_name'] = 'นามสกุลยาวเกิน 60 ตัวอักษร';
    }
    if ($email == '') {
        $errors['email'] = 'กรุณากรอกอีเมล';
    } elseif (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'รูปแบบอีเมลไม่ถูกต้อง';
    } elseif (db_select_one('SELECT id FROM users WHERE email = ? AND id <> ?', [$email, $user['id']]) != null) {
        $errors['email'] = 'อีเมลนี้ถูกใช้แล้ว';   // คนอื่นใช้อีเมลนี้อยู่
    }

    if (count($errors) > 0) {
        set_errors('profile', $errors);
        redirect('account');
    }
    db_run('UPDATE users SET first_name = ?, last_name = ?, email = ?, updated_at = ? WHERE id = ?',
        [$firstName, $lastName, $email, now(), $user['id']]);
    set_message('บันทึกข้อมูลส่วนตัวแล้ว');

} elseif ($action == 'password') {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirmation'] ?? '';

    $errors = [];
    if ($current == '') {
        $errors['current_password'] = 'กรุณากรอกรหัสผ่านปัจจุบัน';
    } elseif (! password_verify($current, (string) $user['password'])) {
        $errors['current_password'] = 'รหัสผ่านปัจจุบันไม่ถูกต้อง';
    }
    $passwordError = check_new_password($new);
    if ($passwordError != '') {
        $errors['password'] = $passwordError;
    } elseif ($new !== $confirm) {
        $errors['password'] = 'การยืนยันรหัสผ่านไม่ตรงกัน';
    }

    if (count($errors) > 0) {
        set_errors('password', $errors);
        redirect('account');
    }
    db_run('UPDATE users SET password = ?, updated_at = ? WHERE id = ?', [password_hash($new, PASSWORD_BCRYPT), now(), $user['id']]);
    set_message('เปลี่ยนรหัสผ่านแล้ว');
}

redirect('account');
