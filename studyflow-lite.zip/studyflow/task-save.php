<?php
// =====================================================================
//  task-save.php : บันทึกงาน (เพิ่มใหม่ หรือ แก้ไข)
//  ไม่มี ?id= ใน URL  = เพิ่มงานใหม่
//  มี   ?id=5        = แก้ไขงาน id 5
// =====================================================================
require 'includes/start.php';
require_post();
$userId = user_id();

// ถ้าเป็นการแก้ไข : ต้องเป็นงานของผู้ใช้คนนี้เท่านั้น
$task = null;
if (get('id') != '') {
    $task = find_task($userId, get('id'));
    if ($task == null) {
        redirect('tasks');
    }
}

// 1) รับค่าจากฟอร์ม
$type = $task != null ? $task->type : post('type');   // ประเภทงานเปลี่ยนไม่ได้หลังสร้าง
$title = post('title');
$subjectId = post('subject_id');
$dueDate = post('due_date');
$dueTime = post('due_time');
$priority = post('priority');
$link = post('link');
$notes = post('notes');

// 2) ตรวจข้อมูล
$errors = [];
if ($type != 'assignment' && $type != 'exam' && $type != 'personal') {
    $type = 'assignment';
}
if ($title == '') {
    $errors['title'] = 'กรุณากรอกชื่อ';
} elseif (mb_strlen($title) > 120) {
    $errors['title'] = 'ชื่อยาวเกิน 120 ตัวอักษร';
}
// งานที่มอบหมายและการสอบต้องเลือกวิชา  งานส่วนตัวไม่ต้อง
if ($type != 'personal') {
    if ($subjectId == '') {
        $errors['subject_id'] = 'กรุณาเลือกวิชา';
    } elseif (find_subject($userId, $subjectId) == null) {
        $errors['subject_id'] = 'ไม่พบวิชานี้';
    }
}
if (! is_date($dueDate)) {
    $errors['due_date'] = 'กรุณาเลือกวันที่';
}
if ($dueTime != '' && ! is_time($dueTime)) {
    $errors['due_time'] = 'รูปแบบเวลาไม่ถูกต้อง';
}
if ($priority != 'high' && $priority != 'low') {
    $priority = 'normal';
}
if ($link != '' && ! preg_match('#^https?://#i', $link)) {
    $errors['link'] = 'ใส่ลิงก์ให้ครบ โดยขึ้นต้นด้วย http:// หรือ https://';
} elseif (mb_strlen($link) > 500) {
    $errors['link'] = 'ลิงก์ยาวเกิน 500 ตัวอักษร';
}
if (mb_strlen($notes) > 2000) {
    $errors['notes'] = 'บันทึกย่อยาวเกิน 2000 ตัวอักษร';
}

// 3) กรอกผิด -> กลับไปหน้าเดิม เปิดฟอร์มค้างไว้พร้อม error
if (count($errors) > 0) {
    set_errors('task', $errors, $task != null ? 'task-' . $task->id : 'new-' . $type);
    go_back();
}

// 4) เตรียมค่าที่จะบันทึก (ช่องที่เว้นว่างเก็บเป็น NULL)
if ($type == 'personal') {
    $subjectId = null;
}
if ($dueTime == '') {
    $dueTime = null;
}
if ($link == '') {
    $link = null;
}
if ($notes == '') {
    $notes = null;
}

// 5) บันทึกลงฐานข้อมูล
if ($task == null) {
    db_run('INSERT INTO tasks (user_id, subject_id, type, title, due_date, due_time, priority, link, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [$userId, $subjectId, $type, $title, $dueDate, $dueTime, $priority, $link, $notes, now(), now()]);
    $typeNames = ['assignment' => 'งานที่มอบหมาย', 'exam' => 'การสอบ', 'personal' => 'งานส่วนตัว'];
    set_message('เพิ่ม' . $typeNames[$type] . ' “' . $title . '” แล้ว');
} else {
    db_run('UPDATE tasks SET subject_id = ?, title = ?, due_date = ?, due_time = ?, priority = ?, link = ?, notes = ?, updated_at = ?
            WHERE id = ? AND user_id = ?',
        [$subjectId, $title, $dueDate, $dueTime, $priority, $link, $notes, now(), $task->id, $userId]);
    set_message('บันทึกการแก้ไขแล้ว');
}
go_back();
