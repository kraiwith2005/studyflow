<?php
// =====================================================================
//  export.php : ดาวน์โหลดข้อมูลของตัวเองเป็นไฟล์ CSV
//    ?type=study  ->  study.csv  (การอ่านที่เสร็จแล้ว)
//    ?type=tasks  ->  tasks.csv  (งานทั้งหมด)
//  ไฟล์ CSV = ตารางข้อมูลแบบข้อความ คั่นแต่ละช่องด้วย , (comma)
//  เปิดใน Excel ได้ และอ่านใน Python ได้ด้วย pandas.read_csv()  (ดู analysis/analysis.py)
// =====================================================================
require 'includes/start.php';
require_login();
$userId = user_id();
$type = get('type') == 'tasks' ? 'tasks' : 'study';

// บอกเบราว์เซอร์ว่านี่คือไฟล์ให้ดาวน์โหลด
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $type . '.csv"');

// เขียน 1 แถวลงไฟล์ CSV
function csv_row($file, $values)
{
    fputcsv($file, $values, ',', '"', '');
}

$file = fopen('php://output', 'w');   // เขียนไฟล์ออกไปที่เบราว์เซอร์โดยตรง
fwrite($file, "\xEF\xBB\xBF");         // BOM : ให้ Excel อ่านภาษาไทยถูก

if ($type == 'study') {
    csv_row($file, ['date', 'start_time', 'subject', 'task', 'title', 'minutes']);   // แถวหัวตาราง
    foreach (get_sessions($userId, "ss.status = 'completed'", [], 'ss.date, ss.start_time') as $s) {
        csv_row($file, [$s['date'], $s['start'], $s['subject_name'] ?? '', $s['task_title'] ?? '', $s['title'], (int) $s['actual_minutes']]);
    }
} else {
    csv_row($file, ['type', 'title', 'subject', 'due_date', 'due_time', 'status', 'completed_date']);
    foreach (get_tasks($userId) as $task) {
        // สถานะ : done = เสร็จแล้ว, overdue = เลยกำหนด, open = ยังไม่เสร็จ
        if ($task->isDone()) {
            $status = 'done';
        } elseif ($task->dueDate < today()) {
            $status = 'overdue';
        } else {
            $status = 'open';
        }
        csv_row($file, [$task->type, $task->title, $task->subjectName ?? '', $task->dueDate, $task->dueTime, $status,
            $task->completedAt != null ? substr($task->completedAt, 0, 10) : '']);
    }
}
fclose($file);
