# =====================================================================
#  analysis.py : วิเคราะห์ข้อมูลจาก StudyFlow ด้วย Python
#  (ใช้ความรู้จากบทที่ 8 NumPy, บทที่ 11 Pandas, บทที่ 12 Matplotlib)
#
#  วิธีใช้
#    1) บนเว็บ StudyFlow ไปที่หน้า "สถิติ" กดดาวน์โหลด study.csv
#    2) วางไฟล์ไว้ในโฟลเดอร์เดียวกับไฟล์นี้
#    3) ติดตั้งไลบรารี (ครั้งแรกครั้งเดียว) :  pip install pandas numpy matplotlib
#    4) รัน :  python analysis.py
#  ผลลัพธ์ : สรุปตัวเลขบนหน้าจอ + กราฟ 2 รูป (บันทึกเป็นไฟล์ studyflow_report.png ด้วย)
# =====================================================================

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from matplotlib import font_manager

# ---------- ตั้งฟอนต์ภาษาไทยให้กราฟ (ไม่ตั้ง ภาษาไทยจะเป็นสี่เหลี่ยม) ----------
# วนดูทีละชื่อ ตัวไหนมีในเครื่องก็ใช้ตัวนั้น  (Mac = Thonburi, Windows = Tahoma / Leelawadee UI)
installed = [f.name for f in font_manager.fontManager.ttflist]
for name in ['Thonburi', 'Tahoma', 'Leelawadee UI', 'Noto Sans Thai', 'Sarabun', 'Garuda', 'Loma']:
    if name in installed:
        plt.rcParams['font.family'] = name
        break
plt.rcParams['axes.unicode_minus'] = False

# โฟลเดอร์ที่ไฟล์นี้อยู่ (จะได้หา study.csv เจอ ไม่ว่ารันจากที่ไหน)
folder = os.path.dirname(os.path.abspath(__file__))

# ---------- 1) อ่านไฟล์ CSV เป็น DataFrame (บทที่ 11) ----------
study = pd.read_csv(os.path.join(folder, 'study.csv'), encoding='utf-8-sig')

print('===== ข้อมูลการอ่านหนังสือ =====')
print(study.head())                      # ดู 5 แถวแรก
print('จำนวนครั้งที่อ่าน :', len(study))

if len(study) == 0:
    print('ยังไม่มีข้อมูลการอ่าน ลองบันทึกการอ่านบนเว็บก่อน')
    raise SystemExit

# ช่องที่ว่างให้เป็นข้อความ "ไม่มีวิชา"
study['subject'] = study['subject'].fillna('ไม่มีวิชา')

# แปลงข้อความวันที่ -> ชนิดวันที่ (กราฟเส้นจะเรียงวันได้ถูก)
study['date'] = pd.to_datetime(study['date'])

# ---------- 2) สถิติพื้นฐานด้วย NumPy (บทที่ 8) ----------
minutes = np.array(study['minutes'])     # แปลงคอลัมน์เป็น array ของ NumPy
print('\n===== สถิติเวลาอ่าน (นาที) =====')
print('รวม     :', np.sum(minutes))
print('เฉลี่ย   :', round(np.mean(minutes), 1))
print('มากสุด  :', np.max(minutes))
print('น้อยสุด  :', np.min(minutes))

# ---------- 3) จัดกลุ่มข้อมูลด้วย groupby (บทที่ 11) ----------
# 3.1 เวลาอ่านรวมของแต่ละวิชา (เรียงจากมากไปน้อย)
by_subject = study.groupby('subject')['minutes'].sum().sort_values(ascending=False)
print('\n===== เวลาอ่านแยกตามวิชา =====')
print(by_subject)
print('วิชาที่อ่านมากที่สุด :', by_subject.index[0], '(', by_subject.iloc[0], 'นาที )')

# 3.2 เวลาอ่านรวมแต่ละวัน (ไว้ดูแนวโน้ม)
by_date = study.groupby('date')['minutes'].sum()

# ---------- 4) วาดกราฟด้วย Matplotlib (บทที่ 12) ----------
fig, axes = plt.subplots(1, 2, figsize=(13, 5))     # 1 แถว 2 กราฟ
fig.suptitle('รายงานการอ่านหนังสือจาก StudyFlow', fontsize=16)

# กราฟ 1 : กราฟแท่ง เวลาอ่านแยกตามวิชา
axes[0].bar(by_subject.index, by_subject.values, color='#036D9A')
axes[0].set_title('เวลาอ่านแยกตามวิชา')
axes[0].set_ylabel('นาที')
axes[0].tick_params(axis='x', rotation=20)

# กราฟ 2 : กราฟเส้น เวลาอ่านแต่ละวัน
axes[1].plot(by_date.index, by_date.values, marker='o', color='#036D9A')
axes[1].set_title('เวลาอ่านแต่ละวัน')
axes[1].set_ylabel('นาที')
axes[1].tick_params(axis='x', rotation=30)

plt.tight_layout()
output = os.path.join(folder, 'studyflow_report.png')
plt.savefig(output, dpi=120)               # บันทึกกราฟเป็นรูป
print('\nบันทึกกราฟไว้ที่', output)
plt.show()                                 # แสดงกราฟบนหน้าจอ
