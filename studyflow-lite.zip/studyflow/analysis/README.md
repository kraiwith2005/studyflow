# วิเคราะห์ข้อมูล StudyFlow ด้วย Python

1. บนเว็บ ไปที่เมนู **สถิติ** แล้วกดดาวน์โหลด `study.csv`
2. วางไฟล์ไว้ในโฟลเดอร์นี้ (ข้างไฟล์ `analysis.py`)
3. ติดตั้งไลบรารีครั้งแรก : `pip install pandas numpy matplotlib`
4. รัน : `python analysis.py`

จะได้สรุปตัวเลขบนหน้าจอ และกราฟ 2 รูป (กราฟแท่งเวลาอ่านแยกตามวิชา + กราฟเส้นเวลาอ่านแต่ละวัน) (บันทึกเป็น `studyflow_report.png` ด้วย)

| ในไฟล์ | บทที่เรียน |
|---|---|
| `np.array`, `np.mean`, `np.max` | บทที่ 8 NumPy |
| `pd.read_csv`, `groupby`, `sum`, `sort_values`, `fillna` | บทที่ 11 Pandas |
| `plt.bar`, `plt.plot`, `plt.savefig`, `plt.show` | บทที่ 12 Matplotlib |
