<?php
// =====================================================================
//  session-save.php : บันทึกการอ่านหนังสือ (วางแผนใหม่ / แก้ไข / บันทึกว่าอ่านแล้ว)
// =====================================================================
require 'includes/start.php';
require_post();
$userId = user_id();

$session = null;
if (get('id') != '') {
    $session = find_session($userId, get('id'));
    if ($session == null) {
        redirect('study');
    }
}

// 1) รับค่า
$title = post('title');
$subjectId = post('subject_id');
$date = post('date');
$startTime = post('start_time');
$duration = (int) post('duration_minutes');
$taskId = post('task_id');
$alreadyDone = post('mark_done') == '1';    // มาจากปุ่ม "บันทึกการอ่าน" = อ่านเสร็จไปแล้ว

// 2) ตรวจข้อมูล
$errors = [];
if ($title == '') {
    $errors['title'] = 'กรุณากรอกชื่อ';
} elseif (mb_strlen($title) > 120) {
    $errors['title'] = 'ชื่อยาวเกิน 120 ตัวอักษร';
}
if ($subjectId == '') {
    $errors['subject_id'] = 'กรุณาเลือกวิชา';
} elseif (find_subject($userId, $subjectId) == null) {
    $errors['subject_id'] = 'ไม่พบวิชานี้';
}
if (! is_date($date)) {
    $errors['date'] = 'กรุณาเลือกวันที่';
}
if (! is_time($startTime)) {
    $errors['start_time'] = 'กรุณาเลือกเวลาเริ่ม';
} elseif (to_minutes($startTime) + $duration > 24 * 60) {
    $errors['start_time'] = 'ช่วงอ่านหนังสือต้องสิ้นสุดภายในเที่ยงคืน';
}
if ($duration < 1 || $duration > 600) {
    $errors['duration_minutes'] = 'กรุณาเลือกระยะเวลา';
}
// งานที่เชื่อมต้องเป็นงานของเรา และไม่ใช่งานส่วนตัว
if ($taskId != '') {
    $task = find_task($userId, $taskId);
    if ($task == null || $task->type == 'personal') {
        $taskId = '';
    }
}

if (count($errors) > 0) {
    set_errors('session', $errors, $session != null ? 'session-' . $session['id'] : 'new-session');
    go_back();
}
if ($taskId == '') {
    $taskId = null;
}

// 3) บันทึก
if ($session == null) {
    $status = $alreadyDone ? 'completed' : 'planned';
    $actual = $alreadyDone ? $duration : null;   // อ่านไปจริงกี่นาที
    db_run('INSERT INTO study_sessions (user_id, subject_id, task_id, title, date, start_time, duration_minutes, status, actual_minutes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [$userId, $subjectId, $taskId, $title, $date, $startTime, $duration, $status, $actual, now(), now()]);
    set_message($alreadyDone ? 'บันทึกการอ่านแล้ว: ' . $title : 'เพิ่มช่วงอ่านหนังสือ “' . $title . '” แล้ว');
} else {
    db_run('UPDATE study_sessions SET subject_id = ?, task_id = ?, title = ?, date = ?, start_time = ?, duration_minutes = ?, updated_at = ?
            WHERE id = ? AND user_id = ?',
        [$subjectId, $taskId, $title, $date, $startTime, $duration, now(), $session['id'], $userId]);
    set_message('บันทึกการแก้ไขแล้ว');
}
go_back();
