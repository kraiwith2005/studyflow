<?php
// =====================================================================
//  timer-save.php : บันทึกเวลาจากตัวจับเวลา (js/timer.js ส่งมาตอนกด "หยุดและบันทึก")
//  รับค่า : target (เช่น subject:3 หรือ task:12), minutes, date, start_time
//  บันทึกเป็นการอ่านที่ "เสร็จแล้ว" 1 รายการ
// =====================================================================
require 'includes/start.php';
require_post();
$userId = user_id();

$target = post('target');
$minutes = (int) post('minutes');
$date = post('date');
$startTime = post('start_time');

// น้อยกว่า 1 นาที ไม่บันทึก
if ($minutes < 1) {
    set_message('อ่านไม่ถึง 1 นาที จึงไม่ได้บันทึก');
    redirect('study');
}
// อ่านนานสุดได้ 10 ชั่วโมงต่อครั้ง
if ($minutes > 600) {
    $minutes = 600;
}
if (! is_date($date) || ! is_time($startTime)) {
    $date = today();
    $startTime = date('H:i', time() - $minutes * 60);
}
// อ่านข้ามเที่ยงคืน : เลื่อนเวลาเริ่มให้จบภายในวันเดียวกัน
if (to_minutes($startTime) + $minutes > 24 * 60) {
    $start = 24 * 60 - $minutes;
    $startTime = sprintf('%02d:%02d', intdiv($start, 60), $start % 60);
}

// แยก target  "task:12" -> ['task', '12']
$parts = explode(':', $target);
$kind = $parts[0];
$id = $parts[1] ?? '';

$subjectId = null;
$taskId = null;
$title = '';
if ($kind == 'task') {
    $task = find_task($userId, $id);
    if ($task != null && $task->type != 'personal') {
        $subjectId = $task->subjectId;
        $taskId = $task->id;
        $title = 'เตรียม ' . $task->title;
    }
} elseif ($kind == 'subject') {
    $subject = find_subject($userId, $id);
    if ($subject != null) {
        $subjectId = $subject['id'];
        $title = $subject['name'];
    }
}
if ($title == '') {
    set_message('ไม่พบงานหรือวิชาที่เลือก จึงไม่ได้บันทึก');
    redirect('study');
}

db_run("INSERT INTO study_sessions (user_id, subject_id, task_id, title, date, start_time, duration_minutes, status, actual_minutes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?, ?)",
    [$userId, $subjectId, $taskId, $title, $date, $startTime, $minutes, $minutes, now(), now()]);
set_message('บันทึกเวลาอ่าน ' . duration_text($minutes) . ' แล้ว');
redirect('study');
