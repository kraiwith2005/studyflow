<?php
// =====================================================================
//  account.php : จัดการบัญชี (แก้ชื่อ-อีเมล / เปลี่ยนรหัสผ่าน)
//  ฟอร์มทั้งสองส่งไปที่ account-save.php
// =====================================================================
require 'includes/start.php';
require_login();
$user = current_user();

$title = 'จัดการบัญชี';
$page = 'account';
include 'includes/header.php';
?>
<div class="page page-narrow">
  <div class="page-head">
    <div>
      <h1 class="page-title">จัดการบัญชี</h1>
      <p class="page-sub">แก้ไขชื่อ อีเมล และรหัสผ่าน</p>
    </div>
  </div>

  <?php if (message() != ''): ?><div class="alert alert-success" role="status"><?= e(message()) ?></div><?php endif; ?>

  <?php // ---------- ข้อมูลส่วนตัว ---------- ?>
  <section class="card">
    <h2 class="card-title">ข้อมูลส่วนตัว</h2>
    <p class="card-sub">ชื่อของคุณจะแสดงในเมนูบัญชี</p>
    <form method="POST" action="<?= e(url('account-save')) ?>" novalidate data-once>
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="profile">
      <div class="field-row">
        <div class="field">
          <label class="label" for="first_name">ชื่อ</label>
          <input id="first_name" name="first_name" class="input <?= invalid('profile', 'first_name') ?>"
                 value="<?= e(old('first_name', $user['first_name'])) ?>" autocomplete="given-name" required>
          <?= show_error('profile', 'first_name') ?>
        </div>
        <div class="field">
          <label class="label" for="last_name">นามสกุล</label>
          <input id="last_name" name="last_name" class="input <?= invalid('profile', 'last_name') ?>"
                 value="<?= e(old('last_name', $user['last_name'])) ?>" autocomplete="family-name" required>
          <?= show_error('profile', 'last_name') ?>
        </div>
      </div>
      <div class="field">
        <label class="label" for="email">อีเมล</label>
        <input id="email" name="email" type="email" class="input <?= invalid('profile', 'email') ?>"
               value="<?= e(old('email', $user['email'])) ?>" autocomplete="email" required>
        <?= show_error('profile', 'email') ?>
      </div>
      <div class="form-actions"><button type="submit" class="btn btn-primary">บันทึกข้อมูลส่วนตัว</button></div>
    </form>
  </section>

  <?php // ---------- เปลี่ยนรหัสผ่าน ---------- ?>
  <section class="card">
    <h2 class="card-title">เปลี่ยนรหัสผ่าน</h2>
    <p class="card-sub">กรอกรหัสผ่านปัจจุบัน แล้วตั้งรหัสผ่านใหม่</p>
    <form method="POST" action="<?= e(url('account-save')) ?>" novalidate data-once>
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="password">
      <?php
      $pw_form = 'password';
      $pw_id = 'current_password'; $pw_name = 'current_password'; $pw_label = 'รหัสผ่านปัจจุบัน'; $pw_placeholder = 'รหัสผ่านปัจจุบัน';
      include 'includes/password_field.php';
      $pw_id = 'new_password'; $pw_name = 'password'; $pw_label = 'รหัสผ่านใหม่'; $pw_placeholder = 'อย่างน้อย 8 ตัวอักษร';
      include 'includes/password_field.php';
      $pw_id = 'password_confirmation'; $pw_name = 'password_confirmation'; $pw_label = 'ยืนยันรหัสผ่านใหม่'; $pw_placeholder = 'พิมพ์อีกครั้ง';
      include 'includes/password_field.php';
      ?>
      <div class="form-actions"><button type="submit" class="btn btn-primary">เปลี่ยนรหัสผ่าน</button></div>
    </form>
  </section>
</div>
<?php include 'includes/footer.php'; ?>
