# StudyFlow

เว็บแอปช่วยนิสิตจัดการงานและกำหนดส่งจากหลายรายวิชา
เขียนด้วย **PHP (ไม่ใช้เฟรมเวิร์ก) + MySQL + HTML + CSS + JavaScript** รันบน XAMPP ได้ทันที

ฟังก์ชันของระบบ
1. สมัครสมาชิก / เข้าสู่ระบบ / ออกจากระบบ / จัดการบัญชี
2. จัดการรายวิชา (เพิ่ม แก้ไข ลบ เลือกสี)
3. จัดการงาน : งานที่มอบหมาย การสอบ งานส่วนตัว (วันส่ง เวลาส่ง ลิงก์ บันทึกย่อ ทำเสร็จ)
4. ป้ายเตือนกำหนดส่ง (เลยกำหนด / ส่งวันนี้ / ส่งพรุ่งนี้ / ส่งในอีก n วัน)
5. ค้นหาและกรองงาน
6. ปฏิทิน 3 มุมมอง : เดือน / สัปดาห์ / วัน
7. หน้า "วันนี้" สรุปงานที่ต้องส่งและแผนการอ่าน
8. วางแผนและบันทึกการอ่านหนังสือ
9. จับเวลาอ่านหนังสือ (เริ่ม / หยุดชั่วคราว / หยุดและบันทึก)
10. ตารางเรียน (คาบเรียนรายสัปดาห์ แสดงในปฏิทินและหน้าวันนี้)
11. โหมดสว่าง / มืด

---

## ติดตั้งบน XAMPP

1. คัดลอกโฟลเดอร์ `studyflow` ไปไว้ที่ `C:\xampp\htdocs\studyflow`
2. เปิด XAMPP Control Panel กด Start ที่ **Apache** และ **MySQL**
3. เข้า http://localhost/phpmyadmin สร้างฐานข้อมูลชื่อ `studyflow` แล้ว Import ไฟล์ `database/schema.sql`
4. คัดลอก `config.sample.php` เป็น `config.php` (ค่าเริ่มต้นใช้กับ XAMPP ได้เลย)
5. เปิด http://localhost/studyflow

---

## โครงสร้างไฟล์

**1 หน้าเว็บ = 1 ไฟล์ PHP** เช่น เปิด `/tasks` คือไฟล์ `tasks.php`

| ไฟล์ | หน้าที่ |
|---|---|
| `sign-up.php` `sign-in.php` `sign-out.php` | สมัครสมาชิก / เข้าสู่ระบบ / ออกจากระบบ |
| `today.php` | หน้าวันนี้ |
| `calendar.php` | ปฏิทิน เดือน / สัปดาห์ / วัน |
| `tasks.php` | รายการงาน ค้นหา ตัวกรอง |
| `study.php` | การอ่านหนังสือ + ตัวจับเวลา |
| `settings.php` | รายวิชา ตารางเรียน และลบบัญชี |
| `account.php` | แก้ชื่อ อีเมล รหัสผ่าน |
| `task-save.php` `task-toggle.php` `task-delete.php` | รับฟอร์ม : บันทึก / ติ๊กเสร็จ / ลบ **งาน** |
| `session-save.php` `session-toggle.php` `session-delete.php` | รับฟอร์ม : บันทึก / ติ๊กเสร็จ / ลบ **การอ่าน** |
| `subject-save.php` `subject-delete.php` | รับฟอร์ม : บันทึก / ลบ **รายวิชา** |
| `class-save.php` `class-delete.php` | รับฟอร์ม : บันทึก / ลบ **คาบเรียน** (ตารางเรียน) |
| `timer-save.php` | รับเวลาจากตัวจับเวลา แล้วบันทึกเป็นการอ่าน |
| `account-save.php` `account-delete.php` `theme-save.php` | รับฟอร์ม : บัญชี / ลบบัญชี / ธีม |
| `includes/start.php` | ทุกหน้าเรียกไฟล์นี้ก่อน : โหลดไฟล์อื่น เริ่ม session |
| `includes/db.php` | เชื่อมฐานข้อมูล + ฟังก์ชัน `db_select` `db_run` |
| `includes/functions.php` | ฟังก์ชันทั่วไป : แสดงผล วันที่ไทย ฟอร์ม |
| `includes/auth.php` | ระบบสมาชิก รหัสผ่าน CSRF |
| `includes/Task.php` | **class Task** (งาน 1 ชิ้น) |
| `includes/data.php` | ดึงข้อมูลงาน / การอ่าน / รายวิชา |
| `includes/header.php` `footer.php` `dialogs.php` | ส่วนหน้าตาที่ใช้ร่วมกัน |
| `js/*.js` | การทำงานฝั่งเบราว์เซอร์ (เปิดกล่อง กดปุ่ม) |
| `css/app.css` | หน้าตาเว็บ สี 3 สี |
| `js/timer.js` | ตัวจับเวลาอ่านหนังสือ |
| `database/schema.sql` | สร้างตาราง 6 ตาราง |

### ขั้นตอนของไฟล์รับฟอร์มทุกไฟล์ (รูปแบบเดียวกันหมด)

```
1) รับค่าจากฟอร์ม        $title = post('title');
2) ตรวจข้อมูล ด้วย if    if ($title == '') { $errors['title'] = 'กรุณากรอกชื่อ'; }
3) ผิด -> กลับไปหน้าเดิม  if (count($errors) > 0) { set_errors(...); go_back(); }
4) ถูก -> บันทึก SQL      db_run('INSERT INTO tasks ... VALUES (?, ?, ...)', [...]);
5) กลับไปหน้าเดิม          set_message('เพิ่ม... แล้ว'); go_back();
```

---

## เทียบกับเนื้อหาที่เรียน (ETC311-312)

ภาษาต่างกัน (เรียน Python, โปรเจกต์ใช้ PHP) แต่หลักการเดียวกัน

| สัปดาห์ | หัวข้อ | Python ที่เรียน | ในโปรเจกต์ (PHP) | ดูตัวอย่างที่ |
|---|---|---|---|---|
| W2 | ตัวแปร ชนิดข้อมูล ตัวดำเนินการ | `name = "Ann"` `score = 80` | `$title = post('title');` | `task-save.php` บรรทัด 21–28 |
| W2 | list / dictionary | `["a","b"]` `{"id": 1}` | array : `['ม.ค.', 'ก.พ.']` / `['id' => 1]` | `functions.php` `MONTHS_SHORT`, แถวข้อมูลจาก `db_select()` |
| W3 | if / elif / else, and / or | `if x: ... elif: ... else:` | `if (...) {} elseif (...) {} else {}` , `&&` `\|\|` | `Task.php` `dueBadge()` (ป้ายกำหนดส่ง) |
| W4 | for / while | `for t in tasks:` / `while ...:` | `foreach ($tasks as $task)` / `while (...)` / `for ($i = 0; ...)` | `today.php` แบ่งงาน 3 กลุ่ม, `calendar.php` สร้างช่องวัน (while) และ `arrange_lanes()` |
| W5 | ฟังก์ชัน (คืนค่า / ไม่คืนค่า), module | `def check_pass(score): return ...` , `import` | `function check_new_password($p) { return ...; }` , `require` | `auth.php` `check_new_password()`, `start.php` (require = import) |
| W6 | class, object, `__init__`, method | `class Student:` `def __init__(self, ...)` `def is_pass(self)` | `class Task` `__construct($row)` `isDone()` `dueBadge()` | `includes/Task.php` |
| W6 | try / except | `try: ... except:` | `try { ... } catch (PDOException $error) { ... }` | `db.php` ฟังก์ชัน `db()` |
| W7 | GUI, event (กดปุ่มแล้วทำงาน) | `Button(command=...)`, `after()` ทำงานซ้ำทุก ๆ ช่วงเวลา | `button.addEventListener('click', ...)`, `setInterval(..., 250)` | `js/timer.js` (ตัวจับเวลา), `js/app.js` |
| W8, W11 | array / ตาราง (DataFrame) | `df['col']`, `df[df.score > 50]` | ตาราง MySQL + `SELECT ... WHERE` | `data.php` `get_tasks()` |
| W12 | สรุปผลข้อมูล | `sum()`, `groupby` | บวกด้วย loop / `COUNT()` `SUM()` ใน SQL | `study.php` (รวมนาที), `data.php` `week_study_totals()` |

### ตัวอย่างที่เทียบได้ตรง ๆ

**W6 class** — Python ในชีท
```python
class Student:
    def __init__(self, name, score):
        self.name = name
        self.score = score
    def is_pass(self):
        return self.score >= 50
```
**ในโปรเจกต์** (`includes/Task.php`)
```php
class Task {
    public function __construct($row) {      // = __init__
        $this->title = $row['title'];         // = self.title = ...
        $this->completedAt = $row['completed_at'];
    }
    public function isDone() {                // = def is_done(self)
        return $this->completedAt != null;
    }
}
$task = new Task($row);                        // = task = Task(row)
```

**W3 if/elif** — ป้ายกำหนดส่ง (`Task.php` → `dueBadge()`)
```php
if ($days < 0) {            return ['เลยกำหนด ' . (-$days) . ' วัน', 'overdue'];
} elseif ($days == 0) {     return ['ส่งวันนี้', 'soon'];
} elseif ($days == 1) {     return ['ส่งพรุ่งนี้', 'soon'];
} else {                    return ['ส่งในอีก ' . $days . ' วัน', 'later'];
}
```

---

## คำถามที่กรรมการน่าจะถาม

**ถาม : รหัสผ่านเก็บอย่างไร**
ตอบ : ไม่เก็บตัวจริง ใช้ `password_hash()` เข้ารหัสแบบ bcrypt ก่อนเก็บ (ย้อนกลับไม่ได้) ตอนเข้าสู่ระบบใช้ `password_verify()` เทียบ — ดู `sign-up.php` และ `sign-in.php`

**ถาม : กัน SQL Injection อย่างไร**
ตอบ : ไม่เอาค่าที่ผู้ใช้พิมพ์ไปต่อในคำสั่ง SQL ตรง ๆ แต่ใส่ `?` แล้วส่งค่าแยก (prepared statement) — ดู `includes/db.php`

**ถาม : ทำไมผู้ใช้คนหนึ่งเห็นข้อมูลของคนอื่นไม่ได้**
ตอบ : ทุกคำสั่ง SQL มีเงื่อนไข `user_id = ?` โดยใช้ id ของคนที่เข้าสู่ระบบอยู่ (เก็บใน `$_SESSION`)

**ถาม : กัน XSS (พิมพ์ `<script>` มา) อย่างไร**
ตอบ : ข้อความที่ผู้ใช้พิมพ์ผ่านฟังก์ชัน `e()` ก่อนแสดงทุกครั้ง (`htmlspecialchars`) — ดู `includes/functions.php`

**ถาม : CSRF token คืออะไร**
ตอบ : รหัสลับที่แนบไปกับทุกฟอร์ม เซิร์ฟเวอร์ตรวจก่อนบันทึก กันเว็บอื่นแอบส่งฟอร์มแทนผู้ใช้ — ดู `includes/auth.php`

**ถาม : ป้ายสีกำหนดส่งคำนวณอย่างไร**
ตอบ : หาจำนวนวันจากวันนี้ถึงวันส่ง (`days_between`) แล้วใช้ if/elseif เลือกข้อความและสี — `Task.php` → `dueBadge()`

**ถาม : ปฏิทินรายเดือนสร้างอย่างไร**
ตอบ : หาวันอาทิตย์ก่อนวันที่ 1 และวันเสาร์หลังวันสุดท้ายของเดือน ใช้ `while` วนสร้างช่องทีละวัน แล้ววนใส่งาน (`foreach`) ลงช่องวันที่ตรงกับวันส่ง — `calendar.php` ข้อ 2–3

**ถาม : ถ้าช่วงอ่านหนังสือเวลาทับกัน แสดงอย่างไร**
ตอบ : ฟังก์ชัน `arrange_lanes()` ใน `calendar.php` วนทีละรายการ หาคอลัมน์แรกที่ว่างด้วย `while` แล้วแบ่งความกว้างเท่า ๆ กัน

**ถาม : ฐานข้อมูลมีกี่ตาราง เชื่อมกันอย่างไร**
ตอบ : 6 ตาราง (users, subjects, recurring_classes, tasks, study_sessions, login_attempts) ทุกตารางมี `user_id` ชี้ไปที่ users ลบผู้ใช้แล้วข้อมูลถูกลบตาม (ON DELETE CASCADE) ลบวิชาแล้วงานยังอยู่ (ON DELETE SET NULL) — ดู `database/schema.sql`

**ถาม : JavaScript ทำอะไรบ้าง**
ตอบ : เฉพาะส่วนหน้าตา เช่น เปิด/ปิดกล่อง เติมข้อมูลลงฟอร์มตอนแก้ไข แสดง/ซ่อนรหัสผ่าน การบันทึกข้อมูลทั้งหมดทำที่ PHP

**ถาม : ตัวจับเวลาทำงานอย่างไร**
ตอบ : `js/timer.js` จำเวลาที่กดเริ่มไว้ (เก็บใน localStorage ของเบราว์เซอร์ เปลี่ยนหน้าแล้วยังนับต่อ) ใช้ `setInterval` อัปเดตตัวเลขบนหน้าจอซ้ำ ๆ (วินาทีละ 4 ครั้ง) กด "หยุดและบันทึก" จะคำนวณเป็นนาทีแล้วส่งฟอร์มไปที่ `timer-save.php` ซึ่งบันทึกลงตาราง `study_sessions` เป็นการอ่านที่เสร็จแล้ว (ไม่ถึง 1 นาทีไม่บันทึก)

**ถาม : ตารางเรียนแสดงในปฏิทินอย่างไร**
ตอบ : คาบเรียน 1 แถวเก็บแค่ "วัน" (1 = จันทร์ ... 7 = อาทิตย์) กับเวลา ตอนสร้างปฏิทิน `classes_on()` ใน `data.php` จะวนดูทุกคาบ เลือกคาบที่วันตรงกับวันในสัปดาห์ของวันนั้น (`date('N')`) แล้วใส่ลงช่องวัน — จึงแสดงซ้ำทุกสัปดาห์โดยไม่ต้องบันทึกทุกวัน
