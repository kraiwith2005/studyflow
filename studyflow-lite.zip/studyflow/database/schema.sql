-- =====================================================================
--  ฐานข้อมูล StudyFlow (MySQL / MariaDB)
--  วิธีใช้ : เปิด phpMyAdmin (XAMPP : http://localhost/phpmyadmin)
--           สร้างฐานข้อมูลชื่อ studyflow แล้ว Import ไฟล์นี้
--
--  มี 5 ตาราง
--    users           ผู้ใช้
--    subjects        รายวิชา        (ของผู้ใช้แต่ละคน)
--    tasks           งาน            (งานที่มอบหมาย / การสอบ / งานส่วนตัว)
--    study_sessions  การอ่านหนังสือ  (วางแผนไว้ / อ่านเสร็จแล้ว)
--    login_attempts  นับการใส่รหัสผ่านผิด
--
--  FOREIGN KEY ... ON DELETE CASCADE  = ลบผู้ใช้ แล้วข้อมูลของผู้ใช้ถูกลบตามไปด้วย
--  FOREIGN KEY ... ON DELETE SET NULL = ลบวิชา แล้วงานยังอยู่ แต่ช่องวิชากลายเป็นค่าว่าง
-- =====================================================================

SET NAMES utf8mb4;

-- ผู้ใช้
CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  email VARCHAR(255) NOT NULL,
  password VARCHAR(255) NULL DEFAULT NULL,               -- รหัสผ่านที่เข้ารหัสแล้ว (password_hash)
  theme ENUM('light','dark') NULL DEFAULT NULL,          -- โหมดสว่าง / มืด
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY users_email_unique (email)                  -- อีเมลห้ามซ้ำ
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- รายวิชา
CREATE TABLE IF NOT EXISTS subjects (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(80) NOT NULL,
  color CHAR(7) NOT NULL,                                -- สี เช่น #3b5fe0
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY subjects_user_id_name_unique (user_id, name),
  CONSTRAINT subjects_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- งาน
CREATE TABLE IF NOT EXISTS tasks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  subject_id BIGINT UNSIGNED NULL DEFAULT NULL,          -- งานส่วนตัวไม่มีวิชา
  type ENUM('assignment','exam','personal') NOT NULL,    -- งานที่มอบหมาย / การสอบ / งานส่วนตัว
  title VARCHAR(120) NOT NULL,
  due_date DATE NOT NULL,                                -- วันส่ง
  due_time TIME NULL DEFAULT NULL,                       -- เวลาส่ง (ไม่บังคับ)
  notes TEXT NULL,                                       -- บันทึกย่อ
  link VARCHAR(500) NULL DEFAULT NULL,                   -- ลิงก์ส่งงาน
  priority ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
  completed_at TIMESTAMP NULL DEFAULT NULL,              -- ว่าง = ยังไม่เสร็จ
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY tasks_user_id_due_date_index (user_id, due_date),
  CONSTRAINT tasks_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT tasks_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- การอ่านหนังสือ
CREATE TABLE IF NOT EXISTS study_sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  subject_id BIGINT UNSIGNED NULL DEFAULT NULL,
  task_id BIGINT UNSIGNED NULL DEFAULT NULL,             -- อ่านเพื่อเตรียมงานไหน (ไม่บังคับ)
  title VARCHAR(120) NOT NULL,
  date DATE NOT NULL,
  start_time TIME NOT NULL,
  duration_minutes SMALLINT UNSIGNED NOT NULL,           -- ระยะเวลาที่วางแผน (นาที)
  status ENUM('planned','completed') NOT NULL DEFAULT 'planned',
  actual_minutes SMALLINT UNSIGNED NULL DEFAULT NULL,    -- อ่านจริงกี่นาที
  created_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY study_sessions_user_id_date_index (user_id, date),
  CONSTRAINT study_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT study_sessions_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES subjects (id) ON DELETE SET NULL,
  CONSTRAINT study_sessions_task_id_foreign FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- นับการใส่รหัสผ่านผิด (ไม่เกิน 5 ครั้งต่อนาที)
CREATE TABLE IF NOT EXISTS login_attempts (
  `key` VARCHAR(255) NOT NULL PRIMARY KEY,
  attempts INT UNSIGNED NOT NULL DEFAULT 0,
  reset_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
