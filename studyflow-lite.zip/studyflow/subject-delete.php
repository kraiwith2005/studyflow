<?php
// subject-delete.php : ลบรายวิชา  (งานของวิชานี้ยังอยู่ แต่ช่องวิชาจะว่าง : ฐานข้อมูลตั้งไว้ ON DELETE SET NULL)
require 'includes/start.php';
require_post();

$subject = find_subject(user_id(), get('id'));
if ($subject == null) {
    redirect('settings');
}

db_run('DELETE FROM subjects WHERE id = ? AND user_id = ?', [$subject['id'], user_id()]);
set_message('ลบวิชา “' . $subject['name'] . '” แล้ว');
redirect('settings');
