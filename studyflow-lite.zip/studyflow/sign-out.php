<?php
// sign-out.php : ออกจากระบบ แล้วกลับไปหน้าเข้าสู่ระบบ
require 'includes/start.php';
require_post();
logout_user();
redirect('sign-in');
