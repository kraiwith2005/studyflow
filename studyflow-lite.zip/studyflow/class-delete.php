<?php
// class-delete.php : ลบคาบเรียนออกจากตารางเรียน
require 'includes/start.php';
require_post();

$class = find_class(user_id(), get('id'));
if ($class == null) {
    redirect('settings');
}

db_run('DELETE FROM recurring_classes WHERE id = ? AND user_id = ?', [$class['id'], user_id()]);
set_message('ลบคาบเรียนแล้ว');
redirect('settings', [], 'timetable');
