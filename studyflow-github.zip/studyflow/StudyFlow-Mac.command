#!/bin/bash
# StudyFlow — install (first time) and start on macOS. Double-click to run.
cd "$(dirname "$0")" || exit 1
echo ""
echo "=============================="
echo "  StudyFlow"
echo "=============================="

load_brew() {
  if [ -x /opt/homebrew/bin/brew ]; then eval "$(/opt/homebrew/bin/brew shellenv)";
  elif [ -x /usr/local/bin/brew ]; then eval "$(/usr/local/bin/brew shellenv)"; fi
}

load_brew
if ! command -v brew >/dev/null 2>&1; then
  echo "→ Installing Homebrew (you may be asked for your Mac password)…"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || { echo "Homebrew install failed."; read -r -p "Press Enter to close"; exit 1; }
  load_brew
fi

for pkg in php composer mysql; do
  if ! brew list "$pkg" >/dev/null 2>&1; then
    echo "→ Installing $pkg (first time only)…"
    brew install "$pkg" || { echo "Could not install $pkg."; read -r -p "Press Enter to close"; exit 1; }
  fi
done

echo "→ Starting MySQL…"
brew services start mysql >/dev/null 2>&1
for i in $(seq 1 40); do mysqladmin -uroot ping >/dev/null 2>&1 && break; sleep 1; done
if ! mysqladmin -uroot ping >/dev/null 2>&1; then echo "MySQL did not start."; read -r -p "Press Enter to close"; exit 1; fi

if [ ! -d vendor ]; then
  echo "→ Installing StudyFlow components (first time only)…"
  composer install --no-interaction --no-progress || { echo "composer install failed."; read -r -p "Press Enter to close"; exit 1; }
fi

if [ ! -f .env ]; then
  cp .env.example .env
  php artisan key:generate --force
fi

mysql -uroot -e "CREATE DATABASE IF NOT EXISTS studyflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci" \
  || { echo "Could not create the database. Check DB_USERNAME / DB_PASSWORD in .env"; read -r -p "Press Enter to close"; exit 1; }
php artisan migrate --force || { echo "Database setup failed."; read -r -p "Press Enter to close"; exit 1; }

echo ""
echo "✓ StudyFlow is running:  http://localhost:8000"
echo "  Keep this window open while you use it. Close it (or press Ctrl+C) to stop."
echo ""
(sleep 2; open "http://localhost:8000") &
php artisan serve --port=8000
