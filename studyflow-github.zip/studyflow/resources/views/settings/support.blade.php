@php($dErr = $errors->getBag('delete'))
<section class="acc" id="support">
  <div class="support-main">
    <span class="sec-icon red"><x-icon name="lifebuoy" size="20" /></span>
    <div class="acc-text">
      <div class="acc-title">{{ __('Support') }}</div>
      <div class="acc-sub">{{ __('Need help or have an idea? Tell us what would make planning easier. We read feedback and use it to guide improvements.') }}</div>
    </div>
    <a class="support-email" href="mailto:{{ config('studyflow.support_email') }}">{{ config('studyflow.support_email') }}</a>
  </div>
  <div class="support-foot">
    <a href="{{ route('privacy') }}">{{ __('Privacy') }}</a>
    <a href="{{ route('terms') }}">{{ __('Terms of Use') }}</a>
    <a href="{{ route('cookies') }}">{{ __('Cookies') }}</a>
    <button type="button" class="link-btn link-danger" data-open-dialog="delete-account-dialog">{{ __('Delete account') }}</button>
  </div>
</section>

<dialog class="dlg" id="delete-account-dialog" @if($dErr->any()) data-autoshow @endif>
  <form method="POST" action="{{ route('account.destroy') }}" class="dlg-body" novalidate data-once>
    @csrf @method('DELETE')
    <div class="dlg-title">{{ __('Delete your account?') }}</div>
    <p class="dlg-text">{{ __('Your account and all of its planner data will be permanently deleted. This can’t be undone.') }}</p>
    @if ($user->hasPassword())
      @include('partials.password-field', ['id' => 'delete-password', 'name' => 'password', 'bag' => 'delete',
        'label' => __('Enter your password to confirm'), 'placeholder' => __('Password'), 'autocomplete' => 'current-password'])
    @else
      <div class="field">
        <label class="label" for="confirm-email">{!! __('Type :word to confirm', ['word' => '<strong>'.e($user->email).'</strong>']) !!}</label>
        <input id="confirm-email" name="confirm_email" class="input input-rect" autocomplete="off">
        @if($dErr->has('confirm_email'))<span class="field-error">{{ $dErr->first('confirm_email') }}</span>@endif
      </div>
    @endif
    <div class="form-buttons">
      <button type="submit" class="btn btn-danger">{{ __('Delete account') }}</button>
      <button type="button" class="btn btn-outline" data-dialog-close>{{ __('Cancel') }}</button>
    </div>
  </form>
</dialog>
