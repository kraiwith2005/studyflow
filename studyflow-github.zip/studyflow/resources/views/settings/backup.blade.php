@php($bErr = $errors->getBag('backup'))
<section class="acc {{ $isOpen('backup') ? 'is-open' : '' }}" id="backup" data-acc="backup">
  <button type="button" class="acc-head" aria-expanded="{{ $isOpen('backup') ? 'true' : 'false' }}" aria-controls="backup-body">
    <span class="sec-icon purple"><x-icon name="database" size="20" /></span>
    <span class="acc-text">
      <span class="acc-title">{{ __('Backup & data') }}</span><br>
      <span class="acc-sub">{{ __('Export, import or clear your planner data.') }}</span>
    </span>
    <x-icon name="chevron" size="20" class="acc-chev" />
  </button>
  <div class="acc-body" id="backup-body">
    @if ($bErr->any())<div class="form-error-box" role="alert">{{ $bErr->first() }}</div>@endif
    <div class="backup-list">
      <div class="backup-row">
        <div>
          <div class="row-title">{{ __('Export backup') }}</div>
          <div class="row-meta">{{ __('Download your subjects, terms, timetable, tasks and study sessions as a JSON file.') }}</div>
        </div>
        <a href="{{ route('settings.backup.export') }}" class="btn btn-outline"><x-icon name="download" size="16" /> {{ __('Export') }}</a>
      </div>
      <div class="backup-row">
        <div>
          <div class="row-title">{{ __('Import backup') }}</div>
          <div class="row-meta">{{ __('Restore from a StudyFlow backup file. This replaces your current planner data.') }}</div>
        </div>
        <form method="POST" action="{{ route('settings.backup.import') }}" enctype="multipart/form-data" id="import-form"
              data-confirm="{{ __('Replace your planner with this backup?') }}" data-confirm-text="{{ __('Your current planner data will be replaced by the file’s contents.') }}" data-confirm-label="{{ __('Import') }}">
          @csrf
          <label class="btn btn-outline" style="position:relative">
            <x-icon name="upload" size="16" /> {{ __('Import') }}
            <input type="file" name="backup" accept=".json,application/json" data-auto-submit
                   style="position:absolute;inset:0;opacity:0;cursor:pointer" aria-label="{{ __('Choose backup file') }}">
          </label>
        </form>
      </div>
      <div class="backup-row danger">
        <div>
          <div class="row-title">{{ __('Clear all data') }}</div>
          <div class="row-meta">{{ __('Remove all subjects, terms, timetable, tasks and study sessions. Your account stays.') }}</div>
        </div>
        <button type="button" class="btn btn-outline link-danger" data-open-dialog="clear-dialog">{{ __('Clear all data') }}</button>
      </div>
    </div>
  </div>
</section>

<dialog class="dlg" id="clear-dialog">
  <form method="POST" action="{{ route('settings.backup.clear') }}" class="dlg-body" data-once>
    @csrf @method('DELETE')
    <div class="dlg-title">{{ __('Clear all planner data?') }}</div>
    <p class="dlg-text">{{ __('Subjects, terms, period times, classes, tasks and study sessions will be deleted. Export a backup first if you might need it. This can’t be undone.') }}</p>
    <div class="field">
      <label class="label" for="clear-confirm">{!! __('Type :word to confirm', ['word' => '<strong>CLEAR</strong>']) !!}</label>
      <input id="clear-confirm" name="confirm" class="input input-rect" autocomplete="off" data-match="CLEAR">
    </div>
    <div class="form-buttons">
      <button type="submit" class="btn btn-danger" data-match-submit disabled>{{ __('Clear all data') }}</button>
      <button type="button" class="btn btn-outline" data-dialog-close>{{ __('Cancel') }}</button>
    </div>
  </form>
</dialog>
