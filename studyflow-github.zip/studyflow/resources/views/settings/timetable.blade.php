@php
  $typeHelp = [
    'school' => __('School mode uses a grid so you can fill your periods × 5 days quickly. Week and day calendar views show classes. Month view stays clean.'),
    'university' => __('University mode skips the grid. Add each lecture, tutorial or lab with its own day and time below. Week and day calendar views show classes.'),
    'custom' => __('Custom mode uses a grid with your own periods across all 7 days, including weekends. Week and day calendar views show classes.'),
  ];
  $pErr = $errors->getBag('periods');
  $cErr = $errors->getBag('klass');
  $classOpen = str_starts_with((string) $reopen, 'class-');
  $classEditing = $classOpen && $reopen !== 'class-new' ? (int) substr($reopen, 6) : null;
  $ab = $planner->repeat_cycle === 'ab';
  $classPeriods = $periods->where('kind', 'class');
  $editPeriods = old('periods', $periods->map(fn ($p) => ['id' => $p->id, 'name' => $p->name, 'kind' => $p->kind,
      'start_time' => substr($p->start_time, 0, 5), 'end_time' => substr($p->end_time, 0, 5)])->all());
@endphp
<section class="acc {{ $isOpen('timetable') ? 'is-open' : '' }}" id="timetable" data-acc="timetable">
  <button type="button" class="acc-head" aria-expanded="{{ $isOpen('timetable') ? 'true' : 'false' }}" aria-controls="timetable-body">
    <span class="sec-icon teal"><x-icon name="grid" size="20" /></span>
    <span class="acc-text">
      <span class="acc-title">{{ __('Timetable') }}</span><br>
      <span class="acc-sub">{{ $ab ? __('Week A / Week B timetable') : __('Weekly timetable') }} · <span data-class-count>{{ trans_choice(':count class|:count classes', $classCount) }}</span></span>
    </span>
    <x-icon name="chevron" size="20" class="acc-chev" />
  </button>
  <div class="acc-body" id="timetable-body">

    {{-- Type & cycle (saved automatically) --}}
    <div class="subcard" id="tt-settings" data-url="{{ route('settings.timetable.settings') }}">
      <div class="grid-2">
        <div class="field">
          <label class="label label-muted" for="tt-type">{{ __('Timetable type') }}</label>
          <select id="tt-type" class="select" data-tt-setting="timetable_type">
            <option value="school" @selected($planner->timetable_type === 'school')>{{ __('School grid') }}</option>
            <option value="university" @selected($planner->timetable_type === 'university')>{{ __('University') }}</option>
            <option value="custom" @selected($planner->timetable_type === 'custom')>{{ __('Custom') }}</option>
          </select>
        </div>
        <div class="field">
          <label class="label label-muted" for="tt-cycle">{{ __('Repeat cycle') }}</label>
          <select id="tt-cycle" class="select" data-tt-setting="repeat_cycle">
            <option value="weekly" @selected(! $ab)>{{ __('Every week') }}</option>
            <option value="ab" @selected($ab)>{{ __('Week A / Week B') }}</option>
          </select>
        </div>
        @if ($ab)
          <div class="field">
            <label class="label label-muted" for="tt-anchor">{{ __('Week A starts on') }}</label>
            <input id="tt-anchor" type="date" class="input input-rect" data-tt-setting="cycle_anchor"
                   value="{{ $planner->cycle_anchor?->toDateString() }}">
            <span class="field-hint">{{ __('Pick any day in a Week A. The weeks then alternate A, B, A, B…') }}</span>
          </div>
        @endif
      </div>
      <p class="hint-text">{{ $typeHelp[$planner->timetable_type] }}</p>
    </div>

    @if ($planner->usesGrid())
      {{-- Period times --}}
      <div class="subcard">
        <div class="subcard-head">
          <div>
            <div class="subcard-title">{{ __('Period times') }}</div>
            <div class="subcard-sub">{{ __('Set these once, then fill the timetable grid below.') }}</div>
          </div>
          <button type="button" class="btn btn-outline" data-toggle-periods @if($pErr->any()) hidden @endif>{{ __('Edit period times') }}</button>
        </div>

        <div class="period-list" id="period-view" @if($pErr->any()) hidden @endif>
          @foreach ($periods as $period)
            <div class="period-item">
              <div>
                <div class="period-name">{{ $period->name }}</div>
                <div class="period-kind">{{ $period->isBreak() ? __('Break') : __('Class period') }}</div>
              </div>
              <div class="period-time">{{ $period->time_range }}</div>
            </div>
          @endforeach
        </div>

        <form method="POST" action="{{ route('settings.timetable.periods') }}" id="period-editor" novalidate data-once @unless($pErr->any()) hidden @endunless>
          @csrf @method('PUT')
          @if ($pErr->any())<div class="form-error-box" role="alert">{{ $pErr->first() }}</div>@endif
          <div class="period-edit-row period-edit-head" aria-hidden="true">
            <span>{{ __('Name') }}</span><span>{{ __('Type') }}</span><span>{{ __('Start') }}</span><span>{{ __('End') }}</span><span style="width:34px"></span>
          </div>
          <div id="period-rows">
            @foreach ($editPeriods as $i => $p)
              <div class="period-edit-row" data-period-row>
                <input type="hidden" name="periods[{{ $i }}][id]" value="{{ $p['id'] ?? '' }}">
                <input class="input input-rect" name="periods[{{ $i }}][name]" value="{{ $p['name'] }}" maxlength="40" aria-label="{{ __('Period name') }}" required>
                <select class="select" name="periods[{{ $i }}][kind]" aria-label="{{ __('Period type') }}">
                  <option value="class" @selected($p['kind'] === 'class')>{{ __('Class') }}</option>
                  <option value="break" @selected($p['kind'] === 'break')>{{ __('Break') }}</option>
                </select>
                <input class="input input-rect" type="time" name="periods[{{ $i }}][start_time]" value="{{ $p['start_time'] }}" aria-label="{{ __('Start time') }}" required>
                <input class="input input-rect" type="time" name="periods[{{ $i }}][end_time]" value="{{ $p['end_time'] }}" aria-label="{{ __('End time') }}" required>
                <button type="button" class="icon-action danger" data-remove-period aria-label="{{ __('Remove period') }}"><x-icon name="trash" size="16" /></button>
              </div>
            @endforeach
          </div>
          <button type="button" class="btn btn-outline btn-sm" style="margin-top:14px" data-add-period><x-icon name="plus" size="16" /> {{ __('Add period') }}</button>
          <p class="hint-text">{{ __('Periods are sorted by start time when you save. Removing a period also clears its cells in the grid.') }}</p>
          <div class="form-buttons">
            <button type="submit" class="btn btn-primary">{{ __('Save period times') }}</button>
            <a href="{{ route('settings', ['open' => 'timetable']) }}#timetable" class="btn btn-outline" data-cancel-periods>{{ __('Cancel') }}</a>
          </div>
        </form>
      </div>

      {{-- Grid --}}
      <div class="subcard" id="tt-grid" data-url="{{ route('settings.timetable.slot') }}">
        <div class="subcard-head">
          <div>
            <div class="subcard-title">{{ __('Timetable grid') }}</div>
            <div class="subcard-sub">{{ __('Pick a subject in each cell. Empty means no class. Changes save automatically.') }}</div>
          </div>
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            @if ($ab)
              <div class="week-tabs" role="tablist" aria-label="{{ __('Week') }}">
                <button type="button" class="week-tab is-active" role="tab" aria-selected="true" data-week-tab="A">{{ __('Week A') }}</button>
                <button type="button" class="week-tab" role="tab" aria-selected="false" data-week-tab="B">{{ __('Week B') }}</button>
              </div>
            @endif
            <form method="POST" action="{{ route('settings.timetable.clear') }}"
                  data-confirm="{{ __('Clear the whole grid?') }}" data-confirm-text="{{ $ab ? __('Every cell in Week A and Week B will be emptied. Your subjects and period times stay.') : __('Every cell will be emptied. Your subjects and period times stay.') }}" data-confirm-label="{{ __('Clear grid') }}">
              @csrf @method('DELETE')
              <button type="submit" class="btn btn-outline">{{ __('Clear grid') }}</button>
            </form>
          </div>
        </div>

        @foreach ($planner->weeks() as $week)
          <div class="week-pane" data-week-pane="{{ $week }}" @if($week !== 'A') hidden @endif>
            <div class="tt-wrap">
              <table class="tt">
                <thead>
                  <tr>
                    <th scope="col">{{ __('PERIOD') }}</th>
                    @foreach ($planner->gridDays() as $d)<th scope="col">{{ day_name($d, true) }}</th>@endforeach
                  </tr>
                </thead>
                <tbody>
                  @foreach ($periods as $period)
                    @if ($period->isBreak())
                      <tr class="tt-break">
                        <td><div class="tt-pname">{{ $period->name }}</div><div class="tt-ptime">{{ $period->time_range }}</div></td>
                        <td colspan="{{ count($planner->gridDays()) }}" class="tt-break-label">{{ __('Break') }}</td>
                      </tr>
                    @else
                      <tr>
                        <td><div class="tt-pname">{{ $period->name }}</div><div class="tt-ptime">{{ $period->time_range }}</div></td>
                        @foreach ($planner->gridDays() as $d)
                          @php $sid = $grid["{$period->id}-{$d}-{$week}"] ?? null; @endphp
                          @php $sub = $sid ? $subjects->firstWhere('id', $sid) : null; @endphp
                          <td>
                            <select class="select cell {{ $sub ? 'has-subject' : '' }}" @if($sub) style="--c: {{ $sub->color }}" @endif
                                    data-period="{{ $period->id }}" data-day="{{ $d }}" data-week="{{ $week }}"
                                    aria-label="{{ $period->name }}, {{ day_name($d) }}{{ $ab ? ', '.__('Week '.$week) : '' }}"
                                    @if($subjects->isEmpty()) disabled @endif>
                              <option value="">{{ __('Empty') }}</option>
                              @foreach ($subjects as $s)
                                <option value="{{ $s->id }}" data-color="{{ $s->color }}" @selected($sid === $s->id)>{{ $s->name }}</option>
                              @endforeach
                            </select>
                          </td>
                        @endforeach
                      </tr>
                    @endif
                  @endforeach
                </tbody>
              </table>
            </div>
          </div>
        @endforeach
        @if ($subjects->isEmpty())
          <div class="notice">{{ __('Add subjects first, then you can fill the timetable grid.') }}
            <a href="{{ route('settings', ['open' => 'subjects']) }}#subjects">{{ __('Go to Subjects') }}</a></div>
        @endif
      </div>
    @endif

    {{-- Recurring classes --}}
    <div class="subcard">
      <div class="subcard-head">
        <div>
          <div class="subcard-title">{{ $planner->usesGrid() ? __('Other recurring commitments') : __('Weekly classes') }}</div>
          <div class="subcard-sub">{{ $planner->usesGrid()
              ? __('Mentor periods, training, sport, work and other repeating commitments that don’t belong in the grid.')
              : __('Lectures, tutorials, labs and anything else that repeats each week.') }}</div>
        </div>
        <button type="button" class="btn btn-primary" data-open-panel="class-panel"
                data-action="{{ route('settings.classes.store') }}" data-method="POST" data-title="{{ __('Add one class') }}" data-submit="{{ __('Add') }}"
                data-values="{{ json_encode(['name' => '', 'subject_id' => '', 'day' => '1', 'start_time' => '09:00', 'end_time' => '10:00', 'week' => 'every', 'location' => '', 'teacher' => '']) }}">
          <x-icon name="plus" /> {{ __('Add class') }}
        </button>
      </div>

      <div class="panel {{ $classOpen ? 'is-open' : '' }}" id="class-panel" style="background:var(--surface-2)">
        <form method="POST" novalidate data-once
              action="{{ $classEditing ? route('settings.classes.update', $classEditing) : route('settings.classes.store') }}">
          @csrf
          <input type="hidden" name="_method" value="{{ $classEditing ? 'PUT' : 'POST' }}">
          <div class="panel-title" data-panel-title>{{ $classEditing ? __('Edit class') : __('Add one class') }}</div>
          <p class="panel-sub">{{ __('Pick the subject, day and time. That’s all you need. Name, room and teacher are optional.') }}</p>
          <div class="grid-2">
            <div class="field">
              <label class="label label-muted" for="class-name">{{ __('Class name') }} <span style="opacity:.7">({{ __('optional') }})</span></label>
              <input id="class-name" name="name" class="input input-rect @if($cErr->has('name')) is-invalid @endif" maxlength="80"
                     placeholder="{{ __('Leave blank to use the subject name') }}" value="{{ old('name') }}">
              @if($cErr->has('name'))<span class="field-error">{{ $cErr->first('name') }}</span>@endif
            </div>
            <div class="field">
              <label class="label label-muted" for="class-subject">{{ __('Subject') }}</label>
              <select id="class-subject" name="subject_id" class="select">
                <option value="">{{ __('No subject / custom') }}</option>
                @foreach ($subjects as $s)<option value="{{ $s->id }}" @selected((string) old('subject_id') === (string) $s->id)>{{ $s->name }}</option>@endforeach
              </select>
            </div>
            <div class="field">
              <label class="label label-muted" for="class-day">{{ __('Day') }}</label>
              <select id="class-day" name="day" class="select">
                @foreach (range(1, 7) as $n)<option value="{{ $n }}" @selected((string) old('day', '1') === (string) $n)>{{ day_name($n) }}</option>@endforeach
              </select>
            </div>
            @if ($ab)
              <div class="field">
                <label class="label label-muted" for="class-week">{{ __('Repeats') }}</label>
                <select id="class-week" name="week" class="select">
                  <option value="every" @selected(old('week', 'every') === 'every')>{{ __('Every week') }}</option>
                  <option value="A" @selected(old('week') === 'A')>{{ __('Week A only') }}</option>
                  <option value="B" @selected(old('week') === 'B')>{{ __('Week B only') }}</option>
                </select>
              </div>
            @else
              <input type="hidden" name="week" value="every">
            @endif
            <div class="field">
              <label class="label label-muted" for="class-start">{{ __('Start time') }}</label>
              <input id="class-start" name="start_time" type="time" class="input input-rect @if($cErr->has('start_time')) is-invalid @endif" value="{{ old('start_time', '09:00') }}" required>
              @if($cErr->has('start_time'))<span class="field-error">{{ $cErr->first('start_time') }}</span>@endif
            </div>
            <div class="field">
              <label class="label label-muted" for="class-end">{{ __('End time') }}</label>
              <input id="class-end" name="end_time" type="time" class="input input-rect @if($cErr->has('end_time')) is-invalid @endif" value="{{ old('end_time', '10:00') }}" required>
              @if($cErr->has('end_time'))<span class="field-error">{{ $cErr->first('end_time') }}</span>@endif
            </div>
            <div class="field">
              <label class="label label-muted" for="class-location">{{ __('Location') }}</label>
              <input id="class-location" name="location" class="input input-rect" maxlength="120" placeholder="{{ __('Room, campus, building') }}" value="{{ old('location') }}">
            </div>
            <div class="field">
              <label class="label label-muted" for="class-teacher">{{ __('Teacher / tutor') }}</label>
              <input id="class-teacher" name="teacher" class="input input-rect" maxlength="80" placeholder="{{ __('Optional') }}" value="{{ old('teacher') }}">
            </div>
          </div>
          <div class="form-buttons">
            <button type="submit" class="btn btn-primary" data-panel-submit>{{ $classEditing ? __('Save') : __('Add') }}</button>
            <button type="button" class="btn btn-outline" data-panel-close>{{ __('Cancel') }}</button>
          </div>
        </form>
      </div>

      @if ($recurring->isEmpty())
        <div class="empty">
          <div class="empty-title">{{ __('No classes added yet') }}</div>
          <div class="empty-sub">{{ __('Add lectures, tutorials, labs, sport, work or other weekly commitments.') }}</div>
        </div>
      @else
        <div class="rows">
          @foreach ($recurring as $c)
            @php $cVals = ['name' => $c->name ?? '', 'subject_id' => (string) ($c->subject_id ?? ''), 'day' => (string) $c->day, 'start_time' => substr($c->start_time, 0, 5), 'end_time' => substr($c->end_time, 0, 5), 'week' => $c->week, 'location' => $c->location ?? '', 'teacher' => $c->teacher ?? '']; @endphp
            <div class="row-item">
              <span class="swatch-dot" style="background: {{ $c->color }}"></span>
              <div class="row-main">
                <div class="row-title">{{ $c->display_name }}
                  @if ($ab && $c->week !== 'every')<span class="badge">{{ __('Week '.$c->week) }}</span>@endif</div>
                <div class="row-meta">{{ day_name($c->day) }} · {{ fmt_time($c->start_time) }} – {{ fmt_time($c->end_time) }}{{ $c->location ? ' · '.$c->location : '' }}{{ $c->teacher ? ' · '.$c->teacher : '' }}</div>
              </div>
              <div class="row-actions">
                <button type="button" class="icon-action" aria-label="{{ __('Edit :name', ['name' => $c->display_name]) }}" data-open-panel="class-panel"
                        data-action="{{ route('settings.classes.update', $c) }}" data-method="PUT" data-title="{{ __('Edit class') }}" data-submit="{{ __('Save') }}"
                        data-values="{{ json_encode($cVals) }}">
                  <x-icon name="pencil" size="16" />
                </button>
                <form method="POST" action="{{ route('settings.classes.destroy', $c) }}"
                      data-confirm="{{ __('Delete “:name”?', ['name' => $c->display_name]) }}" data-confirm-text="{{ __('It will no longer appear in your timetable.') }}">
                  @csrf @method('DELETE')
                  <button type="submit" class="icon-action danger" aria-label="{{ __('Delete :name', ['name' => $c->display_name]) }}"><x-icon name="trash" size="16" /></button>
                </form>
              </div>
            </div>
          @endforeach
        </div>
      @endif
    </div>
  </div>
</section>

<template id="period-row-template">
  <div class="period-edit-row" data-period-row>
    <input type="hidden" data-f="id" value="">
    <input class="input input-rect" data-f="name" maxlength="40" aria-label="{{ __('Period name') }}" required>
    <select class="select" data-f="kind" aria-label="{{ __('Period type') }}"><option value="class">{{ __('Class') }}</option><option value="break">{{ __('Break') }}</option></select>
    <input class="input input-rect" type="time" data-f="start_time" aria-label="{{ __('Start time') }}" required>
    <input class="input input-rect" type="time" data-f="end_time" aria-label="{{ __('End time') }}" required>
    <button type="button" class="icon-action danger" data-remove-period aria-label="{{ __('Remove period') }}"><x-icon name="trash" size="16" /></button>
  </div>
</template>
