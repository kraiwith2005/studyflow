@extends('layouts.app', ['title' => __('Settings')])

@php
  $reopen = session('reopen');
  $isOpen = fn ($key) => in_array($key, $open, true);
@endphp

@section('content')
<div class="page" id="settings" data-reopen="{{ $reopen }}">
  <div class="page-head">
    <div>
      <h1 class="page-title">{{ __('Settings') }}</h1>
      <p class="page-sub">{{ __('Manage your subjects, terms, timetable, data and support.') }}</p>
    </div>
  </div>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  <div class="acc-stack">
    @include('settings.subjects')
    @include('settings.terms')
    @include('settings.timetable')
    @include('settings.backup')
    @include('settings.support')
  </div>
</div>

{{-- Shared confirm dialog for delete buttons --}}
<dialog class="dlg" id="confirm-dialog">
  <div class="dlg-body">
    <div class="dlg-title" data-confirm-title>{{ __('Are you sure?') }}</div>
    <p class="dlg-text" data-confirm-text></p>
    <div class="form-buttons" style="margin-top:0">
      <button type="button" class="btn btn-danger" data-confirm-ok>{{ __('Delete') }}</button>
      <button type="button" class="btn btn-outline" data-dialog-close>{{ __('Cancel') }}</button>
    </div>
  </div>
</dialog>
@endsection

@push('scripts')
<script src="{{ asset('js/settings.js') }}?v={{ filemtime(public_path('js/settings.js')) }}"></script>
@endpush
