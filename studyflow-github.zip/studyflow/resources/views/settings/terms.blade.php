@php
  $tErr = $errors->getBag('term');
  $termOpen = str_starts_with((string) $reopen, 'term-');
  $termEditing = $termOpen && $reopen !== 'term-new' ? (int) substr($reopen, 5) : null;
  $today = now()->toDateString();
@endphp
<section class="acc {{ $isOpen('terms') ? 'is-open' : '' }}" id="terms" data-acc="terms">
  <button type="button" class="acc-head" aria-expanded="{{ $isOpen('terms') ? 'true' : 'false' }}" aria-controls="terms-body">
    <span class="sec-icon orange"><x-icon name="calendar" size="20" /></span>
    <span class="acc-text">
      <span class="acc-title">{{ __('Terms') }}</span><br>
      <span class="acc-sub">{{ trans_choice(':count term configured.|:count terms configured.', $terms->count()) }}</span>
    </span>
    <x-icon name="chevron" size="20" class="acc-chev" />
  </button>
  <div class="acc-body" id="terms-body">
    <div class="acc-toolbar">
      <button type="button" class="btn btn-primary" data-open-panel="term-panel"
              data-action="{{ route('settings.terms.store') }}" data-method="POST" data-title="{{ __('New term') }}" data-submit="{{ __('Add') }}"
              data-values="{{ json_encode(['name' => '', 'start_date' => $today, 'end_date' => $today]) }}">
        <x-icon name="plus" /> {{ __('Add term') }}
      </button>
    </div>

    <div class="panel {{ $termOpen ? 'is-open' : '' }}" id="term-panel">
      <form method="POST" novalidate data-once
            action="{{ $termEditing ? route('settings.terms.update', $termEditing) : route('settings.terms.store') }}">
        @csrf
        <input type="hidden" name="_method" value="{{ $termEditing ? 'PUT' : 'POST' }}">
        <div class="panel-title" data-panel-title>{{ $termEditing ? __('Edit term') : __('New term') }}</div>
        <div class="grid-3" style="margin-top:16px">
          <div class="field">
            <label class="label label-muted" for="term-name">{{ __('Name') }}</label>
            <input id="term-name" name="name" class="input input-rect @if($tErr->has('name')) is-invalid @endif"
                   placeholder="{{ __('e.g. Term 1') }}" maxlength="60" value="{{ old('name') }}" required>
            @if($tErr->has('name'))<span class="field-error">{{ $tErr->first('name') }}</span>@endif
          </div>
          <div class="field">
            <label class="label label-muted" for="term-start">{{ __('Start date') }}</label>
            <input id="term-start" name="start_date" type="date" class="input input-rect @if($tErr->has('start_date')) is-invalid @endif"
                   value="{{ old('start_date', $today) }}" required>
            @if($tErr->has('start_date'))<span class="field-error">{{ $tErr->first('start_date') }}</span>@endif
          </div>
          <div class="field">
            <label class="label label-muted" for="term-end">{{ __('End date') }}</label>
            <input id="term-end" name="end_date" type="date" class="input input-rect @if($tErr->has('end_date')) is-invalid @endif"
                   value="{{ old('end_date', $today) }}" required>
            @if($tErr->has('end_date'))<span class="field-error">{{ $tErr->first('end_date') }}</span>@endif
          </div>
        </div>
        <div class="form-buttons">
          <button type="submit" class="btn btn-primary" data-panel-submit>{{ $termEditing ? __('Save') : __('Add') }}</button>
          <button type="button" class="btn btn-outline" data-panel-close>{{ __('Cancel') }}</button>
        </div>
      </form>
    </div>

    @if ($terms->isEmpty())
      <div class="empty">
        <div class="empty-title">{{ __('No terms yet') }}</div>
        <div class="empty-sub">{{ __('Add term dates so tasks can be grouped automatically.') }}</div>
      </div>
    @else
      <div class="rows">
        @foreach ($terms as $term)
          <div class="row-item">
            <div class="row-main">
              <div class="row-title">{{ $term->name }} @if($term->isCurrent())<span class="badge">{{ __('Current') }}</span>@endif</div>
              <div class="row-meta">{{ fmt_date($term->start_date) }} – {{ fmt_date($term->end_date) }}
                · {{ $term->length_label }}</div>
            </div>
            <div class="row-actions">
              <button type="button" class="icon-action" aria-label="{{ __('Edit :name', ['name' => $term->name]) }}" data-open-panel="term-panel"
                      data-action="{{ route('settings.terms.update', $term) }}" data-method="PUT" data-title="{{ __('Edit term') }}" data-submit="{{ __('Save') }}"
                      data-values="{{ json_encode(['name' => $term->name, 'start_date' => $term->start_date->toDateString(), 'end_date' => $term->end_date->toDateString()]) }}">
                <x-icon name="pencil" size="16" />
              </button>
              <form method="POST" action="{{ route('settings.terms.destroy', $term) }}"
                    data-confirm="{{ __('Delete “:name”?', ['name' => $term->name]) }}" data-confirm-text="{{ __('The term dates will be removed. This can’t be undone.') }}">
                @csrf @method('DELETE')
                <button type="submit" class="icon-action danger" aria-label="{{ __('Delete :name', ['name' => $term->name]) }}"><x-icon name="trash" size="16" /></button>
              </form>
            </div>
          </div>
        @endforeach
      </div>
    @endif
  </div>
</section>
