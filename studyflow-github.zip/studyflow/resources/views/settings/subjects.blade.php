@php
  $sErr = $errors->getBag('subject');
  $editing = str_starts_with((string) $reopen, 'subject-') && $reopen !== 'subject-new' ? (int) substr($reopen, 8) : null;
@endphp
<section class="acc {{ $isOpen('subjects') ? 'is-open' : '' }}" id="subjects" data-acc="subjects">
  <button type="button" class="acc-head" aria-expanded="{{ $isOpen('subjects') ? 'true' : 'false' }}" aria-controls="subjects-body">
    <span class="sec-icon blue"><x-icon name="book" size="20" /></span>
    <span class="acc-text">
      <span class="acc-title">{{ __('Subjects') }}</span><br>
      <span class="acc-sub">{{ trans_choice(':count subject configured.|:count subjects configured.', $subjects->count()) }}</span>
    </span>
    <x-icon name="chevron" size="20" class="acc-chev" />
  </button>
  <div class="acc-body" id="subjects-body">
    <div class="acc-toolbar">
      <button type="button" class="btn btn-primary" data-open-dialog="subject-dialog"
              data-action="{{ route('settings.subjects.store') }}" data-method="POST"
              data-title="{{ __('New subject') }}" data-submit="{{ __('Add') }}" data-values='{"name":"","color":"{{ $presets[0] }}"}'>
        <x-icon name="plus" /> {{ __('Add subject') }}
      </button>
    </div>

    @if ($subjects->isEmpty())
      <div class="empty">
        <div class="empty-title">{{ __('No subjects yet') }}</div>
        <div class="empty-sub">{{ __('Add subjects before filling your timetable grid.') }}</div>
      </div>
    @else
      <div class="rows">
        @foreach ($subjects as $subject)
          <div class="row-item">
            <span class="swatch-dot" style="background: {{ $subject->color }}"></span>
            <div class="row-main">
              <div class="row-title">{{ $subject->name }}</div>
              <div class="row-meta">{{ trans_choice(':count timetable cell|:count timetable cells', $subject->slots_count) }}</div>
            </div>
            <div class="row-actions">
              <button type="button" class="icon-action" aria-label="{{ __('Edit :name', ['name' => $subject->name]) }}" data-open-dialog="subject-dialog"
                      data-action="{{ route('settings.subjects.update', $subject) }}" data-method="PUT"
                      data-title="{{ __('Edit subject') }}" data-submit="{{ __('Save') }}"
                      data-values="{{ json_encode(['name' => $subject->name, 'color' => $subject->color]) }}">
                <x-icon name="pencil" size="16" />
              </button>
              <form method="POST" action="{{ route('settings.subjects.destroy', $subject) }}"
                    data-confirm="{{ __('Delete “:name”?', ['name' => $subject->name]) }}"
                    data-confirm-text="{{ $subject->slots_count ? trans_choice('It will also be removed from :count timetable cell.|It will also be removed from :count timetable cells.', $subject->slots_count).' ' : '' }}{{ __('This can’t be undone.') }}">
                @csrf @method('DELETE')
                <button type="submit" class="icon-action danger" aria-label="{{ __('Delete :name', ['name' => $subject->name]) }}"><x-icon name="trash" size="16" /></button>
              </form>
            </div>
          </div>
        @endforeach
      </div>
    @endif
  </div>
</section>

<dialog class="dlg dlg-wide" id="subject-dialog" @if(str_starts_with((string) $reopen, 'subject-')) data-autoshow @endif>
  <form method="POST" class="dlg-body" novalidate data-once
        action="{{ $editing ? route('settings.subjects.update', $editing) : route('settings.subjects.store') }}">
    @csrf
    <input type="hidden" name="_method" value="{{ $editing ? 'PUT' : 'POST' }}">
    <label class="dlg-title" for="subject-name" data-dialog-title style="display:block">{{ $editing ? __('Edit subject') : __('New subject') }}</label>
    <input id="subject-name" name="name" class="input input-rect @if($sErr->has('name')) is-invalid @endif"
           placeholder="{{ __('Subject name') }}" maxlength="80" value="{{ old('name') }}" required data-enable-submit>
    @if($sErr->has('name'))<span class="field-error">{{ $sErr->first('name') }}</span>@endif

    <div style="margin-top:16px">
      <div class="label">{{ __('Colour') }}</div>
      <div class="field-hint" style="font-size:14px;margin-top:4px">{{ __('Choose a preset or use any custom shade.') }}</div>
      @php $current = old('color', $presets[0]); @endphp
      <div class="swatches" role="radiogroup" aria-label="{{ __('Subject colour') }}">
        @foreach ($presets as $hex)
          <button type="button" class="swatch" role="radio" style="background: {{ $hex }}" data-color="{{ $hex }}"
                  aria-checked="{{ strtolower($current) === $hex ? 'true' : 'false' }}" aria-label="{{ __('Colour :hex', ['hex' => $hex]) }}"></button>
        @endforeach
      </div>
      <label class="btn btn-outline btn-sm custom-colour">
        <span class="custom-preview" data-colour-preview style="background: {{ $current }}"></span>
        {{ __('Custom colour') }}
        <input type="color" name="color" value="{{ $current }}" data-colour-input aria-label="{{ __('Custom colour') }}">
      </label>
      @if($sErr->has('color'))<span class="field-error">{{ $sErr->first('color') }}</span>@endif
    </div>

    <div class="form-buttons">
      <button type="submit" class="btn btn-primary" data-dialog-submit disabled>{{ $editing ? __('Save') : __('Add') }}</button>
      <button type="button" class="btn btn-outline" data-dialog-close>{{ __('Cancel') }}</button>
    </div>
  </form>
</dialog>
