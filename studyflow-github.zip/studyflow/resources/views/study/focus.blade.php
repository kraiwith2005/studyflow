@php
  $state = $timer?->status ?? 'ready';
  $vis = fn (string $when) => in_array($state, explode(' ', $when), true) ? '' : 'hidden';
  $timerJs = [
    'timer' => $timer?->toClient(),
    'serverNow' => now()->getTimestampMs(),
    'urls' => ['start' => route('timer.start'), 'pause' => route('timer.pause'), 'resume' => route('timer.resume'), 'stop' => route('timer.stop'), 'discard' => route('timer.discard')],
    'strings' => [
      'ready' => __('READY'), 'running' => __('RUNNING'), 'paused' => __('PAUSED'),
      'choose' => __('Choose what you’re studying first.'),
      'discardQ' => __('Discard this timer?'), 'discardText' => __('The time on the timer won’t be saved.'), 'discard' => __('Discard'),
    ],
  ];
@endphp
<section class="card timer-card" id="timer" data-state="{{ $state }}">
  <div class="timer-left">
    <div class="timer-title">
      <span>{{ __('Study timer') }}</span>
      <span class="state-badge" data-state-badge>{{ ['ready' => __('READY'), 'running' => __('RUNNING'), 'paused' => __('PAUSED')][$state] }}</span>
    </div>
    <p class="timer-sub">{{ __('Choose an assessment or subject, then record the time you actually study.') }}</p>

    <div class="timer-pick" data-when="ready" {{ $vis('ready') }}>
      <label class="sr-only" for="timer-target">{{ __('Choose what you’re studying') }}</label>
      <select id="timer-target" class="select timer-select">
        <option value="">{{ __('Choose what you’re studying') }}</option>
        @if ($todayPlanned->isNotEmpty())
          <optgroup label="{{ __('Planned for today') }}">
            @foreach ($todayPlanned as $s)<option value="session:{{ $s->id }}">{{ fmt_time($s->start_time) }} · {{ $s->title }}</option>@endforeach
          </optgroup>
        @endif
        @if ($assessments->isNotEmpty() || $homework->isNotEmpty())
          <optgroup label="{{ __('Homework & assessments') }}">
            @foreach ($assessments->concat($homework)->sortBy('due_date') as $t)
              <option value="task:{{ $t->id }}">{{ \App\Models\Task::typeLabel($t->type) }} · {{ $t->title }}</option>
            @endforeach
          </optgroup>
        @endif
        @if ($subjects->isNotEmpty())
          <optgroup label="{{ __('Subjects') }}">
            @foreach ($subjects as $s)<option value="subject:{{ $s->id }}">{{ $s->name }}</option>@endforeach
          </optgroup>
        @endif
      </select>
      <span class="field-error" data-timer-error hidden></span>
      @if ($subjects->isEmpty())
        <span class="field-hint"><a href="{{ route('settings', ['open' => 'subjects']) }}#subjects">{{ __('Add a subject in Settings first.') }}</a></span>
      @endif
    </div>
    <div class="timer-now" data-when="running paused" {{ $vis('running paused') }}>
      <span class="timer-now-k">{{ __('Studying') }}</span>
      <span class="timer-now-v" data-timer-label>{{ $timer?->label }}</span>
    </div>
  </div>

  <div class="timer-right">
    <div class="timer-display" data-timer-display aria-live="off">00:00:00</div>
    <div class="timer-actions">
      <button type="button" class="btn btn-primary btn-lg" data-act="start" data-when="ready" {{ $vis('ready') }}><x-icon name="play" /> {{ __('Start') }}</button>
      <button type="button" class="btn btn-outline btn-lg" data-act="pause" data-when="running" {{ $vis('running') }}>{{ __('Pause') }}</button>
      <button type="button" class="btn btn-primary btn-lg" data-act="resume" data-when="paused" {{ $vis('paused') }}><x-icon name="play" /> {{ __('Resume') }}</button>
      <button type="button" class="btn btn-primary btn-lg" data-act="stop" data-when="running paused" {{ $vis('running paused') }}>{{ __('Stop & save') }}</button>
      <button type="button" class="btn btn-ghost" data-act="discard" data-when="paused" {{ $vis('paused') }}>{{ __('Discard') }}</button>
    </div>
  </div>
</section>
<script>window.SF_TIMER = {!! json_encode($timerJs, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) !!};</script>

<section class="card upcoming-card">
  <div class="upcoming-head">
    <h2 class="card-title">{{ __('Other upcoming assessments') }}</h2>
    <p class="card-sub" style="margin-bottom:0">{{ __('Plan, study or review another assessment.') }}</p>
  </div>
  @if ($assessments->isEmpty())
    <div class="empty upcoming-empty">
      <div class="empty-title">{{ __('No active assessments') }}</div>
      <div class="empty-sub">{{ __('Assignments and exams will appear here automatically.') }}</div>
    </div>
  @else
    <div class="upcoming-list">
      @foreach ($assessments as $t)
        @php [$dueText, $dueTone] = \App\Http\Controllers\TaskController::dueLabel($t); @endphp
        <div class="up-row" style="--c: {{ $t->color }}">
          <div class="up-main">
            <div class="up-title">{{ $t->title }}</div>
            <div class="task-meta">
              <span class="swatch-dot" style="background: {{ $t->color }}"></span>{{ \App\Models\Task::typeLabel($t->type) }} · {{ $t->subject?->name }} · {{ fmt_date($t->due_date) }}
              @if ($t->planned_sessions) · {{ trans_choice(':count session planned|:count sessions planned', $t->planned_sessions) }} @endif
              @if ($t->done_minutes) · {{ __(':time studied', ['time' => \App\Models\StudySession::durationLabel((int) $t->done_minutes)]) }} @endif
            </div>
          </div>
          <span class="due-badge tone-{{ $dueTone }}">{{ $dueText }}</span>
          <div class="up-actions">
            <button type="button" class="btn btn-outline btn-sm" data-plan-task="{{ $t->id }}" data-plan-subject="{{ $t->subject_id }}"
                    data-plan-title="{{ __('Study for :title', ['title' => $t->title]) }}">{{ __('Plan study') }}</button>
            <button type="button" class="btn btn-primary btn-sm" data-study-now="task:{{ $t->id }}" @if($timer) disabled @endif>{{ __('Study now') }}</button>
          </div>
        </div>
      @endforeach
    </div>
  @endif
</section>
