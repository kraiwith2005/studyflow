<div class="log-tools">
  <nav class="chip-filter" aria-label="{{ __('Subject') }}">
    <a class="fchip {{ $subjectFilter ? '' : 'is-active' }}" href="{{ route('study', ['tab' => 'log']) }}">{{ __('All') }}</a>
    @foreach ($subjects as $s)
      <a class="fchip {{ $subjectFilter?->id === $s->id ? 'is-active' : '' }}" style="--c: {{ $s->color }}" href="{{ route('study', ['tab' => 'log', 'subject' => $s->id]) }}">
        <span class="swatch-dot" style="background: {{ $s->color }}"></span>{{ $s->name }}</a>
    @endforeach
  </nav>
  <button type="button" class="btn btn-primary" data-log-study data-subject="{{ $subjectFilter?->id }}"><x-icon name="plus" /> {{ __('Log study') }}</button>
</div>

<section class="card log-card">
  <div class="log-head">
    <div>
      <h2 class="card-title">{{ __('Completed study') }}</h2>
      <div class="log-sub">{{ trans_choice(':count session|:count sessions', $completed->count()) }} · {{ $fmtMinutes($completedMinutes) }}</div>
    </div>
    @if ($completed->isNotEmpty())
      <button type="button" class="link-btn" data-toggle-history aria-expanded="false" aria-controls="history"
              data-show="{{ __('Show history') }}" data-hide="{{ __('Hide history') }}">{{ __('Show history') }}</button>
    @endif
  </div>
  <div class="log-list" id="history" hidden>
    @foreach ($completed as $s)
      <button type="button" class="log-row" style="--c: {{ $s->color }}" data-item="{{ \App\Support\ItemPayload::json(\App\Support\ItemPayload::session($s)) }}">
        <span class="log-date">{{ fmt_date($s->date) }}<span>{{ fmt_time($s->start_time) }}</span></span>
        <span class="log-main">
          <span class="log-title">{{ $s->title }}</span>
          <span class="task-meta">@if($s->subject)<span class="swatch-dot" style="background: {{ $s->color }}"></span>{{ $s->subject->name }}@endif @if($s->task) · {{ $s->task->title }} @endif</span>
        </span>
        <span class="log-min">{{ $fmtMinutes((int) $s->actual_minutes) }}</span>
      </button>
    @endforeach
  </div>
</section>

<section class="card log-card">
  <div class="log-head">
    <div>
      <h2 class="card-title">{{ __('Planned sessions') }}</h2>
      <div class="log-sub">{{ __('Scheduled preparation. These don’t count as study until completed.') }}</div>
    </div>
    <span class="log-count">{{ trans_choice(':count planned|:count planned', $planned->count()) }}</span>
  </div>
  @if ($planned->isEmpty())
    <div class="empty upcoming-empty">
      <div class="empty-title">{{ __('Nothing planned') }}</div>
      <div class="empty-sub">{{ __('Use “Plan study” on an assessment to schedule preparation on the Calendar.') }}</div>
    </div>
  @else
    <div class="log-list">
      @foreach ($planned as $s)
        @php $late = $s->date->lt(now()->startOfDay()); @endphp
        <div class="log-row is-static" style="--c: {{ $s->color }}">
          <span class="log-date">{{ fmt_date($s->date) }}<span>{{ fmt_time($s->start_time) }} – {{ fmt_time($s->end_time) }}</span></span>
          <button type="button" class="log-main log-open" data-item="{{ \App\Support\ItemPayload::json(\App\Support\ItemPayload::session($s)) }}">
            <span class="log-title">{{ $s->title }} @if($late)<span class="due-badge tone-overdue">{{ __('Missed') }}</span>@endif</span>
            <span class="task-meta">@if($s->subject)<span class="swatch-dot" style="background: {{ $s->color }}"></span>{{ $s->subject->name }}@endif @if($s->task) · {{ $s->task->title }} @endif · {{ \App\Models\StudySession::durationLabel($s->duration_minutes) }}</span>
          </button>
          <a class="btn btn-outline btn-sm" href="{{ route('study') }}?start=session:{{ $s->id }}" @if($timer) aria-disabled="true" tabindex="-1" style="pointer-events:none;opacity:.5" @endif>{{ __('Start') }}</a>
        </div>
      @endforeach
    </div>
  @endif
</section>
