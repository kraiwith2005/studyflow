@extends('layouts.app', ['title' => __('Study')])

@php
  $fmtMinutes = function (int $m) {
      if ($m < 60) return __(':mm', ['m' => $m]);
      return $m % 60 ? __(':hh :mm', ['h' => intdiv($m, 60), 'm' => $m % 60]) : __(':hh', ['h' => intdiv($m, 60)]);
  };
  $tabUrl = fn ($t) => route('study', array_filter(['tab' => $t === 'focus' ? null : $t]));
@endphp

@section('banner')
  @include('partials.setup-banner')
@endsection

@section('content')
<div class="page" id="study-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">{{ __('Study') }}</h1>
      <p class="page-sub">{{ __('Plan preparation, focus on the work, and keep a clear record of what you completed.') }}</p>
    </div>
  </div>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  <div class="study-bar">
    <nav class="seg" aria-label="{{ __('Study') }}">
      <a class="seg-btn {{ $tab === 'focus' ? 'is-active' : '' }}" href="{{ $tabUrl('focus') }}" @if($tab === 'focus') aria-current="page" @endif>{{ __('Focus') }}</a>
      <a class="seg-btn {{ $tab === 'log' ? 'is-active' : '' }}" href="{{ $tabUrl('log') }}" @if($tab === 'log') aria-current="page" @endif>{{ __('Plan & Log') }}</a>
    </nav>
    <span class="study-stats">
      <strong>{{ __('This week') }}</strong>
      <span class="dot-sep">•</span> {{ trans_choice(':count completed session|:count completed sessions', $weekCount) }}
      <span class="dot-sep">•</span> <strong>{{ $fmtMinutes($weekMinutes) }}</strong>
    </span>
  </div>

  @if ($tab === 'focus')
    @include('study.focus')
  @else
    @include('study.log')
  @endif
</div>

@include('calendar.dialogs')
@endsection

@push('scripts')
<script src="{{ asset('js/calendar.js') }}?v={{ filemtime(public_path('js/calendar.js')) }}"></script>
<script src="{{ asset('js/study.js') }}?v={{ filemtime(public_path('js/study.js')) }}"></script>
@endpush
