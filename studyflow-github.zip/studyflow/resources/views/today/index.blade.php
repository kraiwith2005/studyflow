@extends('layouts.app', ['title' => __('Today')])

@php
  $payload = fn ($t) => \App\Support\ItemPayload::json(\App\Support\ItemPayload::task($t));
  $sessionPayload = fn ($s) => \App\Support\ItemPayload::json(\App\Support\ItemPayload::session($s));
  $todayStr = $todayDate->toDateString();
@endphp

@section('banner')
  @include('partials.setup-banner')
@endsection

@section('content')
<div class="page" id="today-page" data-reopen="{{ session('reopen') }}">
  <div class="page-head">
    <div>
      <h1 class="page-title">{{ __('Today') }}</h1>
      <p class="page-sub">{{ fmt_date($todayDate, 'long') }}</p>
    </div>
    <button type="button" class="btn btn-primary btn-lg" data-add-date="{{ $todayStr }}">
      <x-icon name="plus" /> {{ __('Add item') }}
    </button>
  </div>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  <div class="today-grid">
    {{-- Classes --}}
    <section class="card today-card">
      <div class="card-title">{{ __('Classes today') }}</div>
      @if (empty($classes))
        <p class="today-empty">{{ __('No classes today.') }}</p>
      @else
        <ul class="today-list">
          @foreach ($classes as $c)
            <li class="today-row" style="--c: {{ $c['color'] }}">
              <span class="today-time">{{ fmt_time($c['start']) }}</span>
              <span class="today-main">
                <span class="today-name">{{ $c['title'] }}</span>
                <span class="today-meta">
                  {{ fmt_time($c['start']) }}–{{ fmt_time($c['end']) }}@if (!empty($c['location'])) · {{ $c['location'] }} @endif
                </span>
              </span>
            </li>
          @endforeach
        </ul>
      @endif
    </section>

    {{-- Due --}}
    <section class="card today-card">
      <div class="card-title">{{ __('Due') }}</div>
      @if ($overdue->isEmpty() && $dueToday->isEmpty() && $dueSoon->isEmpty())
        <p class="today-empty">{{ __('Nothing due in the next 7 days.') }}</p>
      @else
        @foreach ([['overdue', __('Overdue'), $overdue], ['today', __('Due today'), $dueToday], ['soon', __('Next 7 days'), $dueSoon]] as [$tone, $heading, $items])
          @if ($items->isNotEmpty())
            <p class="today-subhead tone-{{ $tone }}">{{ $heading }} · {{ $items->count() }}</p>
            <ul class="today-list">
              @foreach ($items as $t)
                @php [$dueText, $dueTone] = \App\Http\Controllers\TaskController::dueLabel($t); @endphp
                <li class="today-row is-task" style="--c: {{ $t->color }}">
                  <form method="POST" action="{{ route('tasks.toggle', $t) }}" class="task-check-form">
                    @csrf @method('PATCH')
                    <input type="hidden" name="return" value="{{ $returnUrl }}">
                    <button type="submit" class="task-check" aria-label="{{ __('Mark “:name” as done', ['name' => $t->title]) }}">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                    </button>
                  </form>
                  <button type="button" class="today-main today-btn" data-item="{{ $payload($t) }}">
                    <span class="today-name">
                      @if ($t->priority === 'high')<span class="prio-flag" aria-label="{{ __('High priority') }}">!</span>@endif
                      {{ $t->title }}
                    </span>
                    <span class="today-meta">
                      @if ($t->subject)<span class="swatch-dot" style="background: {{ $t->color }}"></span>{{ $t->subject->name }} · @endif
                      {{ fmt_date($t->due_date) }}@if ($t->dueTime()) {{ __('at :time', ['time' => fmt_time($t->dueTime())]) }}@endif
                    </span>
                  </button>
                  <span class="due-badge tone-{{ $dueTone }}">{{ $dueText }}</span>
                </li>
              @endforeach
            </ul>
          @endif
        @endforeach
      @endif
    </section>

    {{-- Study plan --}}
    <section class="card today-card">
      <div class="card-title">{{ __('Study plan') }}</div>
      <p class="today-stat">
        {{ __('This week') }}: <strong>{{ trans_choice(':count session|:count sessions', $weekCount) }}</strong>
        · <strong>{{ \App\Models\StudySession::durationLabel($weekMinutes) }}</strong>
      </p>
      @if ($plannedToday->isEmpty() && $doneToday->isEmpty())
        <p class="today-empty">{{ __('No study blocks planned for today.') }}</p>
        <a class="btn btn-outline btn-sm" href="{{ route('study') }}">{{ __('Go to Study') }}</a>
      @else
        <ul class="today-list">
          @foreach ($plannedToday as $s)
            <li class="today-row" style="--c: {{ $s->color }}">
              <span class="today-time">{{ fmt_time($s->start_time) }}</span>
              <button type="button" class="today-main today-btn" data-item="{{ $sessionPayload($s) }}">
                <span class="today-name">{{ $s->title }}</span>
                <span class="today-meta">{{ \App\Models\StudySession::durationLabel($s->duration_minutes) }}@if ($s->subject) · {{ $s->subject->name }} @endif</span>
              </button>
              <a class="btn btn-primary btn-sm" href="{{ route('study') }}">{{ __('Start') }}</a>
            </li>
          @endforeach
          @foreach ($doneToday as $s)
            <li class="today-row is-done" style="--c: {{ $s->color }}">
              <span class="today-time">{{ fmt_time($s->start_time) }}</span>
              <span class="today-main">
                <span class="today-name">{{ $s->title }}</span>
                <span class="today-meta">{{ __('Done') }} · {{ \App\Models\StudySession::durationLabel($s->actual_minutes ?: $s->duration_minutes) }}</span>
              </span>
            </li>
          @endforeach
        </ul>
      @endif
    </section>
  </div>
</div>

@include('calendar.dialogs')
@endsection

@push('scripts')
<script src="{{ asset('js/calendar.js') }}?v={{ filemtime(public_path('js/calendar.js')) }}"></script>
@endpush
