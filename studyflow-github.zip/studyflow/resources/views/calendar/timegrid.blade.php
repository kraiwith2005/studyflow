@php
  $hourH = 52;
  $cols = count($days);
  $toMin = fn ($t) => (int) substr($t, 0, 2) * 60 + (int) substr($t, 3, 2);
  $base = $fromHour * 60;
  $pxPerMin = $hourH / 60;
@endphp
<div class="tgrid-scroll">
  <div class="tgrid {{ $view === 'day' ? 'is-day' : '' }}" style="--cols: {{ $cols }}; --hour-h: {{ $hourH }}px"
       data-from-hour="{{ $fromHour }}" data-hour-h="{{ $hourH }}">

    @if ($view === 'week')
      <div class="trow">
        <div class="thead-cell"></div>
        @foreach ($days as $d => $day)
          @php $c = \Carbon\Carbon::parse($d); @endphp
          <div class="thead-cell {{ $d === $todayStr ? 'is-today' : '' }}">
            <div class="th-dow">{{ day_name($c->dayOfWeekIso, true) }}</div>
            <a class="th-num" href="{{ $viewUrl('day', $d) }}" aria-label="{{ fmt_date($c, 'long') }}">{{ $c->day }}</a>
          </div>
        @endforeach
      </div>
    @else
      <div class="day-head">
        <span class="th-num" style="{{ $date->toDateString() === $todayStr ? 'background:var(--primary);color:var(--on-primary)' : '' }}">{{ $date->day }}</span>
        <div>
          <div class="th-dow">{{ day_name($date->dayOfWeekIso) }}</div>
          <div style="font-weight:600">{{ fmt_date($date, 'month') }}</div>
        </div>
      </div>
    @endif

    {{-- All-day row: assignments, exams, personal tasks --}}
    <div class="trow allday-row">
      <div class="allday-label">{{ __('ALL DAY') }}</div>
      @foreach ($days as $d => $day)
        <div class="allday-cell" data-add-date="{{ $d }}">
          @foreach ($day['allDay'] as $item) @include('calendar.chip') @endforeach
        </div>
      @endforeach
    </div>

    {{-- Hourly grid --}}
    <div class="trow tbody">
      <div class="hour-gutter">
        @for ($h = $fromHour; $h < $toHour; $h++)
          <div class="hour-label">{{ $h === $fromHour ? '' : fmt_time(sprintf('%02d:00', $h)) }}</div>
        @endfor
      </div>
      @foreach ($days as $d => $day)
        <div class="tcol {{ $d === $todayStr ? 'is-today' : '' }}" data-add-date="{{ $d }}" data-timed>
          @for ($h = $fromHour; $h < $toHour; $h++)<div class="hour-line"></div>@endfor
          @foreach ($day['timed'] as $item)
            @php
              $top = ($toMin($item['start']) - $base) * $pxPerMin;
              $height = max(22, ($toMin($item['end']) - $toMin($item['start'])) * $pxPerMin - 2);
              $w = 100 / $item['lanes'];
            @endphp
            <button type="button" class="ev is-{{ $item['kind'] }} {{ $item['done'] ? 'is-done' : '' }}"
                    style="--c: {{ $item['color'] }}; top: {{ $top }}px; height: {{ $height }}px; left: calc({{ $item['lane'] * $w }}% + 2px); width: calc({{ $w }}% - 4px)"
                    data-item="{{ $payload($item) }}">
              <span class="ev-title">{{ $item['title'] }}</span>
              <span class="ev-meta">{{ fmt_time($item['start']) }} – {{ fmt_time($item['end']) }}{{ !empty($item['location']) ? ' · '.$item['location'] : '' }}</span>
            </button>
          @endforeach
          @if ($d === $todayStr)
            @php $nowMin = now()->hour * 60 + now()->minute; @endphp
            @if ($nowMin >= $base && $nowMin <= $toHour * 60)
              <div class="now-line" style="top: {{ ($nowMin - $base) * $pxPerMin }}px" aria-hidden="true"></div>
            @endif
          @endif
        </div>
      @endforeach
    </div>
  </div>
</div>
