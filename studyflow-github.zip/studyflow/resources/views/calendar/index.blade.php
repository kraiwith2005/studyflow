@extends('layouts.app', ['title' => __('Calendar')])

@php
  $todayStr = now()->toDateString();
  $payload = fn (array $i) => \App\Support\ItemPayload::json($i);
  $viewUrl = fn ($v, $d) => route('calendar', ['view' => $v, 'date' => $d instanceof \Carbon\Carbon ? $d->toDateString() : $d]);
@endphp

@section('banner')
  @include('partials.setup-banner')
@endsection

@section('content')
<div class="page page-wide" id="calendar" data-reopen="{{ session('reopen') }}">
  <div class="cal-head">
    <div>
      <h1 class="page-title">{{ __('Calendar') }}</h1>
      <p class="page-sub">{{ __('Plan study blocks, homework, assignments, exams, reminders and timetable classes.') }}</p>
    </div>
    <button type="button" class="btn btn-primary btn-lg" data-add-date="{{ $view === 'month' && $date->isSameMonth(now()) ? $todayStr : $date->toDateString() }}">
      <x-icon name="plus" /> {{ __('Add item') }}
    </button>
  </div>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  <div class="cal">
    <div class="cal-bar">
      <a class="cal-nav" href="{{ $viewUrl($view, $prev) }}" aria-label="{{ __('Previous') }}"><x-icon name="back" /></a>
      <a class="cal-nav" href="{{ $viewUrl($view, $next) }}" aria-label="{{ __('Next') }}"><x-icon name="arrow" /></a>
      <a class="cal-today" href="{{ $viewUrl($view, $todayStr) }}">{{ __('Today') }}</a>
      <h2 class="cal-title">{{ $title }}</h2>
      @if ($weekLetter && $view !== 'month')<span class="cal-week-letter">{{ __('Week '.$weekLetter) }}</span>@endif
      <nav class="seg cal-views" aria-label="{{ __('Calendar view') }}">
        @foreach (['month' => __('Month'), 'week' => __('Week'), 'day' => __('Day')] as $v => $label)
          <a class="seg-btn {{ $view === $v ? 'is-active' : '' }}" href="{{ $viewUrl($v, $date) }}" @if($view === $v) aria-current="page" @endif>{{ $label }}</a>
        @endforeach
      </nav>
    </div>

    @if ($view === 'month')
      @include('calendar.month')
    @else
      @include('calendar.timegrid')
    @endif
  </div>
</div>

@include('calendar.dialogs')
@endsection

@push('scripts')
<script src="{{ asset('js/calendar.js') }}?v={{ filemtime(public_path('js/calendar.js')) }}"></script>
@endpush
