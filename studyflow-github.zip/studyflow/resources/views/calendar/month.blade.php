<div class="month" role="grid" aria-label="{{ $title }}">
  @foreach ([7, 1, 2, 3, 4, 5, 6] as $iso)
    <div class="month-dow" role="columnheader">{{ day_name($iso, true) }}</div>
  @endforeach
  @foreach ($days as $d => $day)
    @php
      $c = \Carbon\Carbon::parse($d);
      $items = array_merge($day['allDay'], $day['timed']);
      $shown = array_slice($items, 0, 3);
    @endphp
    <div class="mcell {{ $c->month !== $date->month ? 'is-other' : '' }} {{ $d === $todayStr ? 'is-today' : '' }}"
         role="gridcell" data-add-date="{{ $d }}">
      <a class="mnum" href="{{ $viewUrl('day', $d) }}" aria-label="{{ fmt_date($c, 'long') }}">{{ $c->day }}</a>
      @foreach ($shown as $item) @include('calendar.chip') @endforeach
      @if (count($items) > 3)
        <a class="more-link" href="{{ $viewUrl('day', $d) }}">{{ __('+:n more', ['n' => count($items) - 3]) }}</a>
      @endif
    </div>
  @endforeach
</div>
