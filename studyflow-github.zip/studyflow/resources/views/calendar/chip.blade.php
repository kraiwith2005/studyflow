{{-- One all-day task or a session shown as a chip --}}
<button type="button" class="chip {{ $item['done'] ? 'is-done' : '' }} {{ ($item['type'] ?? '') === 'exam' ? 'is-exam' : '' }}"
        style="--c: {{ $item['color'] }}" data-item="{{ $payload($item) }}">
  @if ($item['kind'] === 'session')
    <span class="chip-time">{{ fmt_time($item['start']) }}</span>
  @elseif ($item['type'] !== 'personal')
    <span class="chip-tag">{{ ['homework' => __('HW'), 'assignment' => __('Assign.'), 'exam' => __('Exam')][$item['type']] }}</span>
  @endif
  <span class="chip-text">{{ $item['title'] }}</span>
</button>
