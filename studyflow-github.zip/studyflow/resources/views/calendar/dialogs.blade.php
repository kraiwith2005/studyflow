@php
  $reopen = (string) session('reopen');
  $sErr = $errors->getBag('session');
  $tErr = $errors->getBag('task');
  $sessionOpen = str_starts_with($reopen, 'new-session') || str_starts_with($reopen, 'session-');
  $sessionEdit = str_starts_with($reopen, 'session-') ? (int) substr($reopen, 8) : null;
  $taskOpen = (str_starts_with($reopen, 'new-') && $reopen !== 'new-session') || str_starts_with($reopen, 'task-');
  $taskEdit = str_starts_with($reopen, 'task-') ? (int) substr($reopen, 5) : null;
  $taskType = old('type', 'assignment');
  $taskLabels = [
    'assignment' => ['add' => __('Add assignment'), 'edit' => __('Edit assignment'), 'placeholder' => __('Assignment title'), 'date' => __('Due date'), 'time' => __('Due time')],
    'exam' => ['add' => __('Add exam'), 'edit' => __('Edit exam'), 'placeholder' => __('Exam title'), 'date' => __('Exam date'), 'time' => __('Start time')],
    'personal' => ['add' => __('Add personal task'), 'edit' => __('Edit personal task'), 'placeholder' => __('Personal task title'), 'date' => __('Date'), 'time' => __('Time')],
  ];
  $err = fn ($bag, $f) => $bag->has($f) ? '<span class="field-error">'.e($bag->first($f)).'</span>' : '';
@endphp

{{-- 1. What to add --}}
<dialog class="dlg" id="add-dialog" aria-labelledby="add-title">
  <div class="dlg-head">
    <div>
      <div class="dlg-title" id="add-title" data-add-date-label></div>
      <div class="dlg-date">{{ __('Add to calendar') }}</div>
    </div>
    <button type="button" class="dlg-x" data-dialog-close aria-label="{{ __('Close') }}"><x-icon name="close" /></button>
  </div>
  <div class="dlg-body">
    <div class="type-list">
      <button type="button" class="type-btn" data-choose="session">{{ __('Study session') }} <x-icon name="plus" /></button>
      <button type="button" class="type-btn" data-choose="personal">{{ __('Personal task') }} <x-icon name="plus" /></button>
      <button type="button" class="type-btn" data-choose="assignment">{{ __('Assignment') }} <x-icon name="plus" /></button>
      <button type="button" class="type-btn" data-choose="exam">{{ __('Exam') }} <x-icon name="plus" /></button>
    </div>
    <div class="note-box">{!! __('Timetable classes are added from :link.', ['link' => '<a href="'.route('settings', ['open' => 'timetable']).'#timetable">'.e(__('Settings').' → '.__('Timetable')).'</a>']) !!}</div>
  </div>
</dialog>

{{-- 2. Study session --}}
<dialog class="dlg dlg-wide" id="session-dialog" @if($sessionOpen) data-autoshow @endif>
  <form method="POST" novalidate data-once action="{{ $sessionEdit ? route('sessions.update', $sessionEdit) : route('sessions.store') }}">
    @csrf
    <input type="hidden" name="_method" value="{{ $sessionEdit ? 'PUT' : 'POST' }}">
    <input type="hidden" name="return" value="{{ $returnUrl }}">
    <input type="hidden" name="mark_done" value="{{ old('mark_done') }}">
    <div class="dlg-head">
      <div>
        <div class="dlg-title" data-form-title>{{ old('mark_done') ? __('Log study') : ($sessionEdit ? __('Edit study session') : __('Add study session')) }}</div>
        <div class="dlg-date" data-form-date></div>
      </div>
      <button type="button" class="dlg-x" data-dialog-close aria-label="{{ __('Close') }}"><x-icon name="close" /></button>
    </div>
    <div class="dlg-body dlg-scroll">
      <div class="field">
        <label class="label" for="s-title">{{ __('Title') }}<span class="req">*</span></label>
        <input id="s-title" name="title" class="input input-rect @if($sErr->has('title')) is-invalid @endif" maxlength="120"
               placeholder="{{ __('Study session title') }}" value="{{ old('title') }}" required>
        {!! $err($sErr, 'title') !!}
      </div>
      <div class="field">
        <label class="label" for="s-subject">{{ __('Subject') }}<span class="req">*</span></label>
        <select id="s-subject" name="subject_id" class="select @if($sErr->has('subject_id')) is-invalid @endif" required>
          <option value="">{{ __('Select subject') }}</option>
          @foreach ($subjects as $s)<option value="{{ $s->id }}" @selected((string) old('subject_id') === (string) $s->id)>{{ $s->name }}</option>@endforeach
        </select>
        {!! $err($sErr, 'subject_id') !!}
        @if ($subjects->isEmpty())<span class="field-hint"><a href="{{ route('settings', ['open' => 'subjects']) }}#subjects">{{ __('Add a subject in Settings first.') }}</a></span>@endif
      </div>
      <div class="time-box">
        <div class="time-box-title">{{ __('Calendar time') }}</div>
        <div class="time-box-sub">{{ __('This is where the item appears in the hourly calendar.') }}</div>
        <div class="field">
          <label class="label" for="s-date">{{ __('Date') }}<span class="req">*</span></label>
          <input id="s-date" name="date" type="date" class="input input-rect @if($sErr->has('date')) is-invalid @endif" value="{{ old('date') }}" required>
          {!! $err($sErr, 'date') !!}
        </div>
        <div class="grid-2" style="margin-top:16px">
          <div class="field">
            <label class="label" for="s-start">{{ __('Start time') }}<span class="req">*</span></label>
            <input id="s-start" name="start_time" type="time" class="input input-rect @if($sErr->has('start_time')) is-invalid @endif" value="{{ old('start_time', '16:00') }}" required>
            {!! $err($sErr, 'start_time') !!}
          </div>
          <div class="field">
            <label class="label" for="s-duration">{{ __('Duration') }}<span class="req">*</span></label>
            <select id="s-duration" name="duration_minutes" class="select" required>
              @foreach ($durations as $m)<option value="{{ $m }}" @selected((string) old('duration_minutes', '60') === (string) $m)>{{ \App\Models\StudySession::durationLabel($m) }}</option>@endforeach
            </select>
            {!! $err($sErr, 'duration_minutes') !!}
          </div>
        </div>
      </div>
      <div class="field" style="margin-top:18px">
        <label class="label" for="s-task">{{ __('Link to assessment') }}</label>
        <select id="s-task" name="task_id" class="select">
          <option value="">{{ __('Not linked') }}</option>
          @forelse ($linkable as $t)
            <option value="{{ $t->id }}" @selected((string) old('task_id') === (string) $t->id)>{{ \App\Models\Task::typeLabel($t->type) }} · {{ $t->title }} ({{ fmt_date($t->due_date) }})</option>
          @empty
            <option value="" disabled>{{ __('No active assessments') }}</option>
          @endforelse
        </select>
        <span class="field-hint">{{ __('Optional. Useful when this study block is for a specific assignment or exam.') }}</span>
      </div>
      <div class="form-buttons">
        <button type="submit" class="btn btn-primary" data-form-submit>{{ $sessionEdit ? __('Save') : __('Add') }}</button>
        <button type="button" class="btn btn-outline" data-dialog-close>{{ __('Cancel') }}</button>
      </div>
    </div>
  </form>
</dialog>

{{-- 3. Assignment / exam / personal task --}}
<dialog class="dlg dlg-wide" id="task-dialog" data-labels="{{ json_encode($taskLabels, JSON_UNESCAPED_UNICODE) }}" @if($taskOpen) data-autoshow @endif>
  <form method="POST" novalidate data-once action="{{ $taskEdit ? route('tasks.update', $taskEdit) : route('tasks.store') }}">
    @csrf
    <input type="hidden" name="_method" value="{{ $taskEdit ? 'PUT' : 'POST' }}">
    <input type="hidden" name="return" value="{{ $returnUrl }}">
    <input type="hidden" name="type" value="{{ $taskType }}">
    <div class="dlg-head">
      <div>
        <div class="dlg-title" data-form-title>{{ $taskLabels[$taskType][$taskEdit ? 'edit' : 'add'] }}</div>
        <div class="dlg-date" data-form-date></div>
      </div>
      <button type="button" class="dlg-x" data-dialog-close aria-label="{{ __('Close') }}"><x-icon name="close" /></button>
    </div>
    <div class="dlg-body">
      <div class="field">
        <label class="label" for="t-title">{{ __('Title') }}<span class="req">*</span></label>
        <input id="t-title" name="title" class="input input-rect @if($tErr->has('title')) is-invalid @endif" maxlength="120"
               placeholder="{{ $taskLabels[$taskType]['placeholder'] }}" value="{{ old('title') }}" required>
        {!! $err($tErr, 'title') !!}
      </div>
      <div class="field" data-subject-field @if($taskType === 'personal') hidden @endif>
        <label class="label" for="t-subject">{{ __('Subject') }}<span class="req">*</span></label>
        <select id="t-subject" name="subject_id" class="select @if($tErr->has('subject_id')) is-invalid @endif">
          <option value="">{{ __('Select subject') }}</option>
          @foreach ($subjects as $s)<option value="{{ $s->id }}" @selected((string) old('subject_id') === (string) $s->id)>{{ $s->name }}</option>@endforeach
        </select>
        {!! $err($tErr, 'subject_id') !!}
        @if ($subjects->isEmpty())<span class="field-hint"><a href="{{ route('settings', ['open' => 'subjects']) }}#subjects">{{ __('Add a subject in Settings first.') }}</a></span>@endif
      </div>
      <div class="field-row">
        <div class="field">
          <label class="label" for="t-date" data-date-label>{{ $taskLabels[$taskType]['date'] }}<span class="req">*</span></label>
          <input id="t-date" name="due_date" type="date" class="input input-rect @if($tErr->has('due_date')) is-invalid @endif" value="{{ old('due_date') }}" required>
          {!! $err($tErr, 'due_date') !!}
        </div>
        <div class="field">
          <label class="label" for="t-time" data-time-label>{{ $taskLabels[$taskType]['time'] }}</label>
          <input id="t-time" name="due_time" type="time" class="input input-rect @if($tErr->has('due_time')) is-invalid @endif" value="{{ old('due_time') }}">
          {!! $err($tErr, 'due_time') !!}
          <span class="field-hint">{{ __('Optional. Leave empty if there is no set time.') }}</span>
        </div>
      </div>
      <div class="form-buttons">
        <button type="submit" class="btn btn-primary" data-form-submit>{{ $taskEdit ? __('Save') : __('Add') }}</button>
        <button type="button" class="btn btn-outline" data-dialog-close>{{ __('Cancel') }}</button>
      </div>
    </div>
  </form>
</dialog>

{{-- 4. Item details --}}
<dialog class="dlg" id="detail-dialog" aria-labelledby="detail-title">
  <div class="dlg-head">
    <div style="min-width:0">
      <div class="detail-type"><span class="swatch-dot" data-d="dot"></span><span data-d="typeLabel"></span></div>
      <div class="dlg-title" id="detail-title" data-d="title" style="margin-top:4px"></div>
    </div>
    <button type="button" class="dlg-x" data-dialog-close aria-label="{{ __('Close') }}"><x-icon name="close" /></button>
  </div>
  <div class="dlg-body">
    <div class="detail-rows">
      <div class="detail-row" data-row="dateLabel"><span class="detail-k">{{ __('Date') }}</span><span class="detail-v" data-d="dateLabel"></span></div>
      <div class="detail-row" data-row="timeLabel"><span class="detail-k">{{ __('Time') }}</span><span class="detail-v" data-d="timeLabel"></span></div>
      <div class="detail-row" data-row="subject"><span class="detail-k">{{ __('Subject') }}</span><span class="detail-v" data-d="subject"></span></div>
      <div class="detail-row" data-row="task"><span class="detail-k">{{ __('For') }}</span><span class="detail-v" data-d="task"></span></div>
      <div class="detail-row" data-row="period"><span class="detail-k">{{ __('Period') }}</span><span class="detail-v" data-d="period"></span></div>
      <div class="detail-row" data-row="location"><span class="detail-k">{{ __('Location') }}</span><span class="detail-v" data-d="location"></span></div>
      <div class="detail-row" data-row="teacher"><span class="detail-k">{{ __('Teacher / tutor') }}</span><span class="detail-v" data-d="teacher"></span></div>
      <div class="detail-row" data-row="status"><span class="detail-k">{{ __('Status') }}</span><span class="detail-v" data-d="status"></span></div>
    </div>
    <div class="detail-actions" data-actions>
      <form method="POST" data-toggle-form>
        @csrf @method('PATCH')
        <input type="hidden" name="return" value="{{ $returnUrl }}">
        <button type="submit" class="btn btn-primary btn-sm" data-toggle-label></button>
      </form>
      <button type="button" class="btn btn-outline btn-sm" data-edit><x-icon name="pencil" size="15" /> {{ __('Edit') }}</button>
      <form method="POST" data-delete-form data-confirm="" data-confirm-text="{{ __('This can’t be undone.') }}">
        @csrf @method('DELETE')
        <input type="hidden" name="return" value="{{ $returnUrl }}">
        <button type="submit" class="btn btn-ghost btn-sm link-danger"><x-icon name="trash" size="15" /> {{ __('Delete') }}</button>
      </form>
    </div>
    <p class="note-box" data-class-note hidden>{!! __('Timetable classes are added from :link.', ['link' => '<a href="'.route('settings', ['open' => 'timetable']).'#timetable">'.e(__('Settings').' → '.__('Timetable')).'</a>']) !!}</p>
  </div>
</dialog>

{{-- 5. Confirm --}}
<dialog class="dlg" id="confirm-dialog">
  <div class="dlg-body">
    <div class="dlg-title" data-confirm-title></div>
    <p class="dlg-text" data-confirm-text></p>
    <div class="form-buttons" style="margin-top:0">
      <button type="button" class="btn btn-danger" data-confirm-ok>{{ __('Delete') }}</button>
      <button type="button" class="btn btn-outline" data-dialog-close>{{ __('Cancel') }}</button>
    </div>
  </div>
</dialog>

@php
  $calJs = [
    'today' => now()->toDateString(),
    'titles' => ['addSession' => __('Add study session'), 'editSession' => __('Edit study session'), 'logStudy' => __('Log study')],
    'strings' => [
      'done' => __('Done'), 'notDone' => __('Not done yet'),
      'markDone' => __('Mark as done'), 'markNotDone' => __('Mark as not done'),
      'deleteQ' => __('Delete “:name”?'),
    ],
  ];
@endphp
<script>
  window.SF_CAL = {!! json_encode($calJs, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) !!};
</script>
