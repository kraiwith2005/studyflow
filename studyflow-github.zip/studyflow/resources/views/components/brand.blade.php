<a href="{{ auth()->check() ? route('calendar') : route('sign-in') }}" class="brand">
  <x-brand-mark />
  <span>
    <span class="brand-name">StudyFlow</span><br>
    <span class="brand-tag">{{ __(config('studyflow.tagline')) }}</span>
  </span>
</a>
