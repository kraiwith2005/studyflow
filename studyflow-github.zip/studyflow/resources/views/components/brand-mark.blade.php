{{-- StudyFlow mark: two flowing lines inside a blue tile, top line in maize --}}
<svg {{ $attributes->merge(['class' => 'brand-mark']) }} viewBox="0 0 40 40" aria-hidden="true">
  <defs>
    <linearGradient id="sfg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#0A86BC"/>
      <stop offset="1" stop-color="#036D9A"/>
    </linearGradient>
  </defs>
  <rect width="40" height="40" rx="11" fill="url(#sfg)"/>
  <path d="M9 16.5c3.6-4.4 7.4-4.4 10.4-.9 3 3.5 7.4 3.5 11.6-1.4" fill="none" stroke="#FDEA6F" stroke-width="3" stroke-linecap="round"/>
  <path d="M9 25.5c3.6-4.4 7.4-4.4 10.4-.9 3 3.5 7.4 3.5 11.6-1.4" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
</svg>
