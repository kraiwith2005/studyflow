{{-- ไทย / EN segmented switch (posts to /locale/{code}) --}}
<form method="POST" class="lang-switch" aria-label="{{ __('Language') }}">
  @csrf
  @foreach (['th' => 'ไทย', 'en' => 'EN'] as $code => $label)
    <button type="submit" formaction="{{ route('locale', $code) }}" class="lang-btn {{ app()->getLocale() === $code ? 'is-active' : '' }}"
            lang="{{ $code }}" @if(app()->getLocale() === $code) aria-current="true" @endif>{{ $label }}</button>
  @endforeach
</form>
