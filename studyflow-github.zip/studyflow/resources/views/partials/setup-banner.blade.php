@php($progress = auth()->user()->setupProgress())
@if ($progress['done'] < $progress['total'])
<section class="setup" aria-label="{{ __('Planner setup') }}">
  <div class="setup-head">
    <div>
      <div class="setup-title">{{ __('Complete your planner setup') }}</div>
      <div class="setup-sub">{{ __('Add these once so your calendar, tasks, study plans and timetable work properly.') }}</div>
    </div>
    <span class="setup-count">{{ __(':done of :total complete', ['done' => $progress['done'], 'total' => $progress['total']]) }}</span>
  </div>
  <div class="setup-cards">
    @foreach (['subjects' => __('Subjects'), 'terms' => __('Terms'), 'timetable' => __('Timetable')] as $key => $label)
      @php($done = $progress['steps'][$key])
      <a href="{{ route('settings', ['open' => $key]) }}#{{ $key }}" class="setup-card {{ $done ? 'is-done' : '' }}">
        <span class="setup-card-name">{{ $label }}</span>
        <span class="setup-card-action">{{ $done ? __('Complete') : __('Set up now') }}</span>
      </a>
    @endforeach
  </div>
</section>
@endif
