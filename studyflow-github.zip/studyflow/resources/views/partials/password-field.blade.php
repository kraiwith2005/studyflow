{{-- $id, $name, $label, $placeholder, $autocomplete, optional $forgot --}}
<div class="field">
  @if (!empty($forgot))
    <div class="label-row">
      <label class="label" for="{{ $id }}">{{ $label }}</label>
      <a class="forgot-link" href="{{ route('password.request') }}">{{ __('Forgot password?') }}</a>
    </div>
  @else
    <label class="label" for="{{ $id }}">{{ $label }}</label>
  @endif
  <div class="input-wrap">
    <input id="{{ $id }}" name="{{ $name }}" type="password" class="input @error($name, $bag ?? 'default') is-invalid @enderror"
           placeholder="{{ $placeholder }}" autocomplete="{{ $autocomplete }}" required>
    <button type="button" class="input-action" data-toggle-password="{{ $id }}" aria-label="{{ __('Show password') }}" aria-pressed="false">
      <x-icon name="eye" />
    </button>
  </div>
  @if (!empty($hint))<span class="field-hint">{{ $hint }}</span>@endif
  @error($name, $bag ?? 'default')<span class="field-error">{{ $message }}</span>@enderror
</div>
