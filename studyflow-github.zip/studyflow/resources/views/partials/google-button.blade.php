@if (\App\Http\Controllers\Auth\GoogleController::enabled())
  <a href="{{ route('google.redirect') }}" class="btn btn-outline btn-block btn-lg">
    <x-google-icon /> {{ __('Continue with Google') }}
  </a>
  <div class="divider">{{ __('or') }}</div>
@endif
