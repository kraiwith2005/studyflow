@extends('layouts.legal', ['title' => __('Terms of Use'), 'updated' => '2026-11-08'])
@section('content')
<p>By creating a StudyFlow account you agree to these terms.</p>
<h2>Your account</h2>
<p>Keep your password private. You’re responsible for activity on your account. Provide a real email address so you can reset your password.</p>
<h2>Your content</h2>
<p>The planner data you add belongs to you. You can export or delete it at any time.</p>
<h2>Acceptable use</h2>
<p>Don’t attempt to access other people’s accounts, disrupt the service, or use StudyFlow for anything unlawful.</p>
<h2>No guarantee</h2>
<p>StudyFlow is provided as is. We work to keep it available and your data safe, but please keep your own backups of anything important using Settings › Backup &amp; data.</p>
<h2>Changes</h2>
<p>We may update these terms. The date at the top shows the latest version.</p>
@endsection
