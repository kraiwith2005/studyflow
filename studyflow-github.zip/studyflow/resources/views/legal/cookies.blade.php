@extends('layouts.legal', ['title' => __('Cookies'), 'updated' => '2026-11-08'])
@section('content')
<p>StudyFlow uses only the cookies it needs to work. There are no advertising or tracking cookies.</p>
<h2>Cookies we set</h2>
<ul>
  <li><strong>Session cookie</strong> keeps you signed in while you use StudyFlow.</li>
  <li><strong>Remember-me cookie</strong> keeps you signed in between visits until you sign out.</li>
  <li><strong>XSRF-TOKEN</strong> protects your forms from being submitted by other websites.</li>
  <li><strong>locale</strong> remembers your language (Thai or English).</li>
</ul>
<p>Because these cookies are essential, they can’t be switched off without stopping StudyFlow from working.</p>
@endsection
