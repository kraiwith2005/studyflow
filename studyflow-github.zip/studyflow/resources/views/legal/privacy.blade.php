@extends('layouts.legal', ['title' => __('Privacy Policy'), 'updated' => '2026-11-08'])
@section('content')
<p>This policy explains what StudyFlow stores about you and why.</p>
<h2>What we store</h2>
<ul>
  <li>Your account details: first name, last name, email address and a securely hashed password (or your Google account ID if you sign in with Google).</li>
  <li>The planner data you add: subjects, terms, timetable, classes, tasks and study sessions.</li>
  <li>Your display preference (light or dark mode).</li>
</ul>
<h2>How we use it</h2>
<p>Only to run StudyFlow for you: to sign you in, show your planner and save your changes. We don’t sell your data, show ads or send marketing emails.</p>
<h2>Your control</h2>
<p>You can export your planner data, clear it, or delete your account at any time in Settings. Deleting your account permanently removes your account and all planner data.</p>
<h2>Contact</h2>
<p>Questions about privacy: <a href="mailto:{{ config('studyflow.support_email') }}">{{ config('studyflow.support_email') }}</a></p>
@endsection
