<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" @if(auth()->user()?->theme) data-theme="{{ auth()->user()->theme }}" @endif>
<head>
  @include('partials.head')
</head>
<body>
  <div class="auth-page">
    <header class="auth-top"><x-brand /><x-lang-switch /></header>
    <main class="auth-main">
      <article class="auth-card legal-card legal">
        <h1 class="auth-title">{{ $title }}</h1>
        <p class="auth-sub" style="margin-bottom:8px">{{ __('Last updated :date', ['date' => fmt_date($updated)]) }}</p>
        @yield('content')
        <p class="auth-switch" style="text-align:left;margin-top:30px">
          <a href="{{ auth()->check() ? route('settings').'#support' : route('sign-in') }}">← {{ __('Back to StudyFlow') }}</a>
        </p>
      </article>
    </main>
  </div>
</body>
</html>
