@php $user = auth()->user(); @endphp
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" @if($user->theme) data-theme="{{ $user->theme }}" @endif>
<head>
  @include('partials.head')
</head>
<body>
  <header class="app-header">
    <div class="app-header-inner">
      <x-brand />

      <nav class="app-nav" aria-label="{{ __('Main') }}">
        @foreach (['calendar' => __('Calendar'), 'tasks' => __('Tasks'), 'study' => __('Study'), 'settings' => __('Settings')] as $route => $label)
          <a href="{{ route($route) }}" class="nav-link {{ request()->routeIs($route.'*') ? 'is-active' : '' }}"
             @if(request()->routeIs($route.'*')) aria-current="page" @endif>{{ $label }}</a>
        @endforeach
      </nav>

      <div class="header-tools">
        @php $activeTimer = request()->routeIs('study') ? null : $user->studyTimer; @endphp
        @if ($activeTimer)
          <a href="{{ route('study') }}" class="timer-pill is-{{ $activeTimer->status }}" data-timer-pill
             data-accum="{{ $activeTimer->accumulated_seconds }}" data-started="{{ $activeTimer->started_at?->getTimestampMs() }}"
             data-server-now="{{ now()->getTimestampMs() }}" data-status="{{ $activeTimer->status }}"
             title="{{ $activeTimer->label }}" aria-label="{{ __('Study timer: :label', ['label' => $activeTimer->label]) }}">
            <span class="timer-pill-dot" aria-hidden="true"></span><span data-pill-time>{{ gmdate('H:i:s', $activeTimer->elapsedSeconds()) }}</span>
          </a>
        @endif
        <x-lang-switch />
        <span id="save-status" class="save-status" data-state="saved" role="status" aria-live="polite">{{ __('Saved') }}</span>

        <button type="button" id="theme-toggle" class="icon-btn" data-url="{{ route('preferences.theme') }}"
                aria-label="{{ $user->theme === 'dark' ? __('Switch to light mode') : __('Switch to dark mode') }}">

          <x-icon name="moon" class="theme-icon-moon" />
          <x-icon name="sun" class="theme-icon-sun" />
        </button>

        <div class="menu-wrap">
          <button type="button" id="avatar-btn" class="avatar" style="background: {{ $user->avatar_color }}"
                  aria-haspopup="menu" aria-expanded="false" aria-controls="avatar-menu"
                  aria-label="{{ __('Account menu for :name', ['name' => $user->full_name]) }}">{{ $user->initial }}</button>
          <div id="avatar-menu" class="menu" role="menu">
            <div class="menu-head">
              <span class="avatar avatar-lg" style="background: {{ $user->avatar_color }}" aria-hidden="true">{{ $user->initial }}</span>
              <div>
                <div class="menu-name">{{ $user->full_name }}</div>
                <div class="menu-email">{{ $user->email }}</div>
              </div>
            </div>
            <a href="{{ route('account') }}" class="menu-item" role="menuitem"><x-icon name="gear" /> {{ __('Manage account') }}</a>
            <form method="POST" action="{{ route('sign-out') }}">
              @csrf
              <button type="submit" class="menu-item" role="menuitem"><x-icon name="signout" /> {{ __('Sign out') }}</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </header>

  @yield('banner')

  <main class="app-main">
    @yield('content')
  </main>

  <script>window.SF_I18N = @json(\App\Support\JsStrings::all());</script>
  <script src="{{ asset('js/app.js') }}?v={{ filemtime(public_path('js/app.js')) }}"></script>
  @stack('scripts')
</body>
</html>
