@php $user = auth()->user(); @endphp
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" @if($user->theme) data-theme="{{ $user->theme }}" @endif>
<head>
  @include('partials.head')
</head>
<body>
  <header class="app-header">
    <div class="app-header-inner">
      <x-brand />

      <nav class="app-nav" aria-label="{{ __('Main') }}">
        @foreach (['today' => __('Today'), 'calendar' => __('Calendar'), 'tasks' => __('Tasks'), 'study' => __('Study'), 'settings' => __('Settings')] as $route => $label)
          <a href="{{ route($route) }}" class="nav-link {{ request()->routeIs($route.'*') ? 'is-active' : '' }}"
             @if(request()->routeIs($route.'*')) aria-current="page" @endif>{{ $label }}</a>
        @endforeach
      </nav>

      <div class="header-tools">
        @php $activeTimer = request()->routeIs('study') ? null : $user->studyTimer; @endphp
        @if ($activeTimer)
          <a href="{{ route('study') }}" class="timer-pill is-{{ $activeTimer->status }}" data-timer-pill
             data-accum="{{ $activeTimer->accumulated_seconds }}" data-started="{{ $activeTimer->started_at?->getTimestampMs() }}"
             data-server-now="{{ now()->getTimestampMs() }}" data-status="{{ $activeTimer->status }}"
             title="{{ $activeTimer->label }}" aria-label="{{ __('Study timer: :label', ['label' => $activeTimer->label]) }}">
            <span class="timer-pill-dot" aria-hidden="true"></span><span data-pill-time>{{ gmdate('H:i:s', $activeTimer->elapsedSeconds()) }}</span>
          </a>
        @endif
        <x-lang-switch />
        <span id="save-status" class="save-status" data-state="saved" role="status" aria-live="polite">{{ __('Saved') }}</span>

        <button type="button" id="theme-toggle" class="icon-btn" data-url="{{ route('preferences.theme') }}"
                aria-label="{{ $user->theme === 'dark' ? __('Switch to light mode') : __('Switch to dark mode') }}">

          <x-icon name="moon" class="theme-icon-moon" />
          <x-icon name="sun" class="theme-icon-sun" />
        </button>

        <div class="menu-wrap">
          <button type="button" id="avatar-btn" class="avatar" style="background: {{ $user->avatar_color }}"
                  aria-haspopup="menu" aria-expanded="false" aria-controls="avatar-menu"
                  aria-label="{{ __('Account menu for :name', ['name' => $user->full_name]) }}">{{ $user->initial }}</button>
          <div id="avatar-menu" class="menu" role="menu">
            <div class="menu-head">
              <span class="avatar avatar-lg" style="background: {{ $user->avatar_color }}" aria-hidden="true">{{ $user->initial }}</span>
              <div>
                <div class="menu-name">{{ $user->full_name }}</div>
                <div class="menu-email">{{ $user->email }}</div>
              </div>
            </div>
            <a href="{{ route('account') }}" class="menu-item" role="menuitem"><x-icon name="gear" /> {{ __('Manage account') }}</a>
            <a href="{{ route('today', ['tour' => 1]) }}" class="menu-item" role="menuitem" data-replay-tour><x-icon name="calendar" /> {{ __('Show the tour again') }}</a>
            <form method="POST" action="{{ route('sign-out') }}">
              @csrf
              <button type="submit" class="menu-item" role="menuitem"><x-icon name="signout" /> {{ __('Sign out') }}</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </header>

  @yield('banner')

  <main class="app-main">
    @yield('content')
  </main>

  <script>window.SF_I18N = @json(\App\Support\JsStrings::all());</script>
  <script src="{{ asset('js/app.js') }}?v={{ filemtime(public_path('js/app.js')) }}"></script>
  @stack('scripts')
  @if (request()->routeIs('today') && (! $user->tour_completed_at || request()->boolean('tour')))
    @php
      $tour = [
        'doneUrl' => route('tour.done'),
        'labels' => ['next' => __('Next'), 'back' => __('Back'), 'skip' => __('Skip tour'), 'finish' => __('Start using StudyFlow'), 'step' => __('Step :n of :total')],
        'steps' => [
          ['target' => null, 'title' => __('Welcome to StudyFlow'), 'text' => __('All your schoolwork in one place. This quick tour shows where everything is. It takes under a minute.')],
          ['target' => '.app-nav a[href$="/today"]', 'title' => __('Today'), 'text' => __('Open StudyFlow to see today’s classes, what’s due and your study plan at a glance.')],
          ['target' => '.app-nav a[href$="/calendar"]', 'title' => __('Calendar'), 'text' => __('Every deadline, exam and class by month, week or day. Tap a day to add something to it.')],
          ['target' => '.app-nav a[href$="/tasks"]', 'title' => __('Tasks'), 'text' => __('All your work in one list, sorted by due date. Search, mark priority and tick things off.')],
          ['target' => '.app-nav a[href$="/study"]', 'title' => __('Study'), 'text' => __('Time your study sessions and see how much you studied this week.')],
          ['target' => '.app-nav a[href$="/settings"]', 'title' => __('Start here: Settings'), 'text' => __('Add your subjects, term dates and timetable first. Everything else uses them.')],
          ['target' => '#today-page [data-add-date]', 'title' => __('Add your first item'), 'text' => __('Add an assignment, exam, personal task or study block. Only the title, subject and date are required.')],
        ],
      ];
    @endphp
    <script>window.SF_TOUR = {!! json_encode($tour, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) !!};</script>
    <script src="{{ asset('js/tour.js') }}?v={{ filemtime(public_path('js/tour.js')) }}"></script>
  @endif
</body>
</html>
