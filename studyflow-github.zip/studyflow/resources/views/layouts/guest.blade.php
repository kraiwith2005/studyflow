<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
  @include('partials.head')
</head>
<body>
  <div class="auth-page">
    {{-- Brand panel: what StudyFlow does --}}
    <aside class="auth-brand" aria-label="StudyFlow">
      <x-brand />
      <div class="auth-hero">
        <p class="auth-hero-title">{{ __(config('studyflow.tagline')) }}</p>
        <ul class="auth-points">
          <li>{{ __('All your subjects’ work in one place') }}</li>
          <li>{{ __('Colour-coded deadlines so nothing slips') }}</li>
          <li>{{ __('A study timer that keeps going between pages') }}</li>
        </ul>
      </div>
    </aside>

    <div class="auth-side">
      <header class="auth-top"><x-lang-switch /></header>
      <main class="auth-main">
        <div class="auth-card">
          @yield('content')
        </div>
      </main>
    </div>
  </div>
  <script src="{{ asset('js/app.js') }}?v={{ filemtime(public_path('js/app.js')) }}"></script>
</body>
</html>
