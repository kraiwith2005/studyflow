<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
  @include('partials.head')
</head>
<body>
  <div class="auth-page">
    <header class="auth-top"><x-brand /><x-lang-switch /></header>
    <main class="auth-main">
      <div class="auth-card">
        @yield('content')
      </div>
    </main>
  </div>
  <script src="{{ asset('js/app.js') }}?v={{ filemtime(public_path('js/app.js')) }}"></script>
</body>
</html>
