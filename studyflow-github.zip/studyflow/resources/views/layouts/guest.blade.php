<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
  @include('partials.head')
</head>
<body>
  <div class="auth-page">
    {{-- Brand panel: what StudyFlow does, and what its three colours mean --}}
    <aside class="auth-brand" aria-label="StudyFlow">
      <x-brand />
      <div class="auth-hero">
        <p class="auth-hero-title">{{ __(config('studyflow.tagline')) }}</p>
        <ul class="auth-points">
          <li>{{ __('All your subjects’ work in one place') }}</li>
          <li>{{ __('Colour-coded deadlines so nothing slips') }}</li>
          <li>{{ __('A study timer that keeps going between pages') }}</li>
        </ul>
      </div>
      <div class="auth-legend">
        <p class="auth-legend-title">{{ __('What the colours mean') }}</p>
        <ul>
          <li><span class="auth-swatch is-blue" aria-hidden="true"></span>{{ __('Buttons and links you can tap') }}</li>
          <li><span class="auth-swatch is-maize" aria-hidden="true"></span>{{ __('Today and due soon') }}</li>
          <li><span class="auth-swatch is-red" aria-hidden="true"></span>{{ __('Overdue and exams') }}</li>
        </ul>
      </div>
    </aside>

    <div class="auth-side">
      <header class="auth-top"><x-lang-switch /></header>
      <main class="auth-main">
        <div class="auth-card">
          @yield('content')
        </div>
      </main>
    </div>
  </div>
  <script src="{{ asset('js/app.js') }}?v={{ filemtime(public_path('js/app.js')) }}"></script>
</body>
</html>
