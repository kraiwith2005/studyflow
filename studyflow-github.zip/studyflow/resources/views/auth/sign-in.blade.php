@extends('layouts.guest', ['title' => __('Sign in')])

@section('content')
  <h1 class="auth-title">{{ __('Welcome back') }}</h1>
  <p class="auth-sub">{{ __('Sign in to pick up where you left off.') }}</p>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  @include('partials.google-button')

  <form method="POST" action="{{ route('sign-in') }}" novalidate data-once>
    @csrf
    <div class="field">
      <label class="label" for="email">{{ __('Email address') }}</label>
      <input id="email" name="email" type="email" class="input @error('email') is-invalid @enderror"
             value="{{ old('email') }}" placeholder="{{ __('Enter your email address') }}" autocomplete="email" required autofocus>
      @error('email')<span class="field-error">{{ $message }}</span>@enderror
    </div>

    @include('partials.password-field', [
      'id' => 'password', 'name' => 'password', 'label' => __('Password'),
      'placeholder' => __('Enter your password'), 'autocomplete' => 'current-password', 'forgot' => true,
    ])

    <div class="auth-actions">
      <button type="submit" class="btn btn-primary btn-block btn-lg">{{ __('Sign in') }} <x-icon name="arrow" size="16" /></button>
    </div>
  </form>

  <p class="auth-switch">{{ __('New here?') }} <a href="{{ route('sign-up') }}">{{ __('Create an account') }}</a></p>
@endsection
