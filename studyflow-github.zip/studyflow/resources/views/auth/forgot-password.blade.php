@extends('layouts.guest', ['title' => __('Reset your password')])

@section('content')
  <h1 class="auth-title">{{ __('Reset your password') }}</h1>
  <p class="auth-sub">{{ __('Enter the email you signed up with and we’ll send you a link to choose a new password.') }}</p>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  <form method="POST" action="{{ route('password.email') }}" novalidate data-once>
    @csrf
    <div class="field">
      <label class="label" for="email">{{ __('Email address') }}</label>
      <input id="email" name="email" type="email" class="input @error('email') is-invalid @enderror"
             value="{{ old('email') }}" placeholder="{{ __('Enter your email address') }}" autocomplete="email" required autofocus>
      @error('email')<span class="field-error">{{ $message }}</span>@enderror
    </div>
    <div class="auth-actions">
      <button type="submit" class="btn btn-primary btn-block btn-lg">{{ __('Send reset link') }}</button>
    </div>
  </form>

  <p class="auth-switch"><a href="{{ route('sign-in') }}">{{ __('Back to sign in') }}</a></p>
@endsection
