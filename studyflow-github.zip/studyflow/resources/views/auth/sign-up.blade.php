@extends('layouts.guest', ['title' => __('Create your account')])

@section('content')
  <h1 class="auth-title">{{ __('Create your account') }}</h1>
  <p class="auth-sub">{{ __('Add your schoolwork once. StudyFlow keeps the rest connected.') }}</p>

  @include('partials.google-button')

  <form method="POST" action="{{ route('sign-up') }}" novalidate data-once>
    @csrf
    <div class="field-row">
      <div class="field">
        <label class="label" for="first_name">{{ __('First name') }}</label>
        <input id="first_name" name="first_name" class="input @error('first_name') is-invalid @enderror"
               value="{{ old('first_name') }}" placeholder="{{ __('First name') }}" autocomplete="given-name" required autofocus>
        @error('first_name')<span class="field-error">{{ $message }}</span>@enderror
      </div>
      <div class="field">
        <label class="label" for="last_name">{{ __('Last name') }}</label>
        <input id="last_name" name="last_name" class="input @error('last_name') is-invalid @enderror"
               value="{{ old('last_name') }}" placeholder="{{ __('Last name') }}" autocomplete="family-name" required>
        @error('last_name')<span class="field-error">{{ $message }}</span>@enderror
      </div>
    </div>

    <div class="field">
      <label class="label" for="email">{{ __('Email address') }}</label>
      <input id="email" name="email" type="email" class="input @error('email') is-invalid @enderror"
             value="{{ old('email') }}" placeholder="{{ __('Enter your email address') }}" autocomplete="email" required>
      @error('email')<span class="field-error">{{ $message }}</span>@enderror
    </div>

    @include('partials.password-field', [
      'id' => 'password', 'name' => 'password', 'label' => __('Password'),
      'placeholder' => __('Enter your password'), 'autocomplete' => 'new-password',
      'hint' => $errors->has('password') ? null : __('At least 8 characters, with letters and numbers.'),
    ])

    <div class="auth-actions">
      <button type="submit" class="btn btn-primary btn-block btn-lg">{{ __('Continue') }} <x-icon name="arrow" size="16" /></button>
    </div>
  </form>

  <p class="auth-switch">{{ __('Already have an account?') }} <a href="{{ route('sign-in') }}">{{ __('Sign in') }}</a></p>
  <p class="auth-legal">
    {!! __('By creating an account, you agree to the :terms and acknowledge the :privacy. This does not opt you into marketing messages.', [
      'terms' => '<a href="'.route('terms').'">'.e(__('Terms of Use')).'</a>',
      'privacy' => '<a href="'.route('privacy').'">'.e(__('Privacy Policy')).'</a>',
    ]) !!}
  </p>
@endsection
