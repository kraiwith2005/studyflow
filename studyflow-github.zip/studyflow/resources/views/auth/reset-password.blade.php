@extends('layouts.guest', ['title' => __('Choose a new password')])

@section('content')
  <h1 class="auth-title">{{ __('Choose a new password') }}</h1>
  <p class="auth-sub">{{ __('At least 8 characters, with letters and numbers.') }}</p>

  <form method="POST" action="{{ route('password.update') }}" novalidate data-once>
    @csrf
    <input type="hidden" name="token" value="{{ $token }}">
    <div class="field">
      <label class="label" for="email">{{ __('Email address') }}</label>
      <input id="email" name="email" type="email" class="input @error('email') is-invalid @enderror"
             value="{{ old('email', $email) }}" autocomplete="email" required>
      @error('email')<span class="field-error">{{ $message }}</span>@enderror
    </div>
    @include('partials.password-field', ['id' => 'password', 'name' => 'password', 'label' => __('New password'),
      'placeholder' => __('New password'), 'autocomplete' => 'new-password'])
    @include('partials.password-field', ['id' => 'password_confirmation', 'name' => 'password_confirmation',
      'label' => __('Confirm new password'), 'placeholder' => __('Type it again'), 'autocomplete' => 'new-password'])
    <div class="auth-actions">
      <button type="submit" class="btn btn-primary btn-block btn-lg">{{ __('Reset password') }}</button>
    </div>
  </form>
@endsection
