@extends('layouts.app', ['title' => __('Manage account')])

@section('content')
  <div class="page page-narrow">
    <div class="page-head">
      <div>
        <h1 class="page-title">{{ __('Manage account') }}</h1>
        <p class="page-sub">{{ __('Update your name, email and password.') }}</p>
      </div>
    </div>

    @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

    <section class="card">
      <h2 class="card-title">{{ __('Profile') }}</h2>
      <p class="card-sub">{{ __('Your name appears in the account menu.') }}</p>
      <form method="POST" action="{{ route('account.profile') }}" novalidate data-once>
        @csrf @method('PUT')
        <div class="field-row">
          <div class="field">
            <label class="label" for="first_name">{{ __('First name') }}</label>
            <input id="first_name" name="first_name" class="input @error('first_name') is-invalid @enderror"
                   value="{{ old('first_name', $user->first_name) }}" autocomplete="given-name" required>
            @error('first_name')<span class="field-error">{{ $message }}</span>@enderror
          </div>
          <div class="field">
            <label class="label" for="last_name">{{ __('Last name') }}</label>
            <input id="last_name" name="last_name" class="input @error('last_name') is-invalid @enderror"
                   value="{{ old('last_name', $user->last_name) }}" autocomplete="family-name" required>
            @error('last_name')<span class="field-error">{{ $message }}</span>@enderror
          </div>
        </div>
        <div class="field">
          <label class="label" for="email">{{ __('Email address') }}</label>
          <input id="email" name="email" type="email" class="input @error('email') is-invalid @enderror"
                 value="{{ old('email', $user->email) }}" autocomplete="email" required>
          @error('email')<span class="field-error">{{ $message }}</span>@enderror
        </div>
        <div class="form-actions"><button type="submit" class="btn btn-primary">{{ __('Save profile') }}</button></div>
      </form>
    </section>

    <section class="card">
      <h2 class="card-title">{{ $user->hasPassword() ? __('Change password') : __('Set a password') }}</h2>
      <p class="card-sub">
        {{ $user->hasPassword() ? __('Enter your current password, then choose a new one.') : __('You signed up with Google. Add a password to also sign in with your email.') }}
      </p>
      <form method="POST" action="{{ route('account.password') }}" novalidate data-once>
        @csrf @method('PUT')
        @if ($user->hasPassword())
          @include('partials.password-field', ['id' => 'current_password', 'name' => 'current_password', 'bag' => 'password',
            'label' => __('Current password'), 'placeholder' => __('Current password'), 'autocomplete' => 'current-password'])
        @endif
        @include('partials.password-field', ['id' => 'new_password', 'name' => 'password', 'bag' => 'password',
          'label' => __('New password'), 'placeholder' => __('At least 8 characters'), 'autocomplete' => 'new-password'])
        @include('partials.password-field', ['id' => 'password_confirmation', 'name' => 'password_confirmation', 'bag' => 'password',
          'label' => __('Confirm new password'), 'placeholder' => __('Type it again'), 'autocomplete' => 'new-password'])
        <div class="form-actions"><button type="submit" class="btn btn-primary">{{ __('Update password') }}</button></div>
      </form>
    </section>
  </div>
@endsection
