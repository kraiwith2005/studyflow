@php
  [$dueText, $dueTone] = \App\Http\Controllers\TaskController::dueLabel($task);
  $minutes = (int) $task->done_minutes;
  $prep = [];
  if ($task->planned_sessions) $prep[] = trans_choice(':count session planned|:count sessions planned', $task->planned_sessions);
  if ($task->done_sessions) $prep[] = __(':time studied', ['time' => \App\Models\StudySession::durationLabel($minutes ?: 0)]);
  $canPlan = $task->type !== 'personal' && ! $task->isDone();
@endphp
<div class="task-row {{ $task->isDone() ? 'is-done' : '' }}" style="--c: {{ $task->color }}">
  <form method="POST" action="{{ route('tasks.toggle', $task) }}" class="task-check-form">
    @csrf @method('PATCH')
    <input type="hidden" name="return" value="{{ $returnUrl }}">
    <button type="submit" class="task-check" aria-pressed="{{ $task->isDone() ? 'true' : 'false' }}"
            aria-label="{{ $task->isDone() ? __('Mark “:name” as not done', ['name' => $task->title]) : __('Mark “:name” as done', ['name' => $task->title]) }}">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
    </button>
  </form>
  <button type="button" class="task-main" data-item="{{ \App\Support\ItemPayload::json(\App\Support\ItemPayload::task($task)) }}">
    <span class="task-title">{{ $task->title }}</span>
    <span class="task-meta">
      @if ($task->subject)<span class="swatch-dot" style="background: {{ $task->color }}"></span>{{ $task->subject->name }} · @endif
      {{ fmt_date($task->due_date) }}@if ($task->dueTime()) {{ __('at :time', ['time' => fmt_time($task->dueTime())]) }}@endif
      @if ($prep) · {{ implode(' · ', $prep) }} @endif
    </span>
  </button>
  <span class="due-badge tone-{{ $dueTone }}">{{ $dueText }}</span>
  @if ($canPlan)
    <button type="button" class="btn btn-outline btn-sm task-plan" data-plan-task="{{ $task->id }}" data-plan-subject="{{ $task->subject_id }}" data-plan-title="{{ __('Study for :title', ['title' => $task->title]) }}">{{ __('Plan study') }}</button>
  @endif
</div>
