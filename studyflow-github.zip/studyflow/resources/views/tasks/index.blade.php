@extends('layouts.app', ['title' => __('Tasks')])

@php
  $url = fn (array $over) => route('tasks', array_filter(array_merge([
      'filter' => $filter === 'all' ? null : $filter,
      'completed' => $showCompleted ? 1 : null,
      'term' => $term?->id,
      'q' => $search !== '' ? $search : null,
      'high' => $highOnly ? 1 : null,
  ], $over), fn ($v) => $v !== null));
  $groupMeta = [
    'assignment' => [__('Assignments'), __('No assignments yet')],
    'exam' => [__('Exams'), __('No exams yet')],
    'personal' => [__('Personal tasks'), __('No personal tasks yet')],
  ];
  $filterOpen = $filter !== 'all' || $term || $highOnly;
@endphp

@section('banner')
  @include('partials.setup-banner')
@endsection

@section('content')
<div class="page" id="tasks-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">{{ __('Tasks') }}</h1>
      <p class="page-sub">{{ __('Add schoolwork once, then follow each assessment from preparation to deadline.') }}</p>
    </div>
  </div>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  <div class="task-tools">
    <form method="GET" action="{{ route('tasks') }}" class="task-search" role="search">
      @if ($filter !== 'all')<input type="hidden" name="filter" value="{{ $filter }}">@endif
      @if ($showCompleted)<input type="hidden" name="completed" value="1">@endif
      @if ($term)<input type="hidden" name="term" value="{{ $term->id }}">@endif
      @if ($highOnly)<input type="hidden" name="high" value="1">@endif
      <label class="sr-only" for="task-search">{{ __('Search tasks') }}</label>
      <svg class="task-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      <input id="task-search" type="search" name="q" value="{{ $search }}" class="input input-rect task-search-input" placeholder="{{ __('Search tasks') }}" maxlength="80">
      @if ($search !== '')<a class="task-search-clear" href="{{ $url(['q' => null]) }}" aria-label="{{ __('Clear search') }}">&times;</a>@endif
    </form>
    <button type="button" class="pill-btn {{ $filterOpen ? 'is-on' : '' }}" data-toggle-filter aria-expanded="{{ $filterOpen ? 'true' : 'false' }}" aria-controls="filter-bar">{{ __('Filter') }}</button>
    <a class="pill-btn {{ $showCompleted ? 'is-on' : '' }}" href="{{ $url(['completed' => $showCompleted ? null : 1]) }}" aria-pressed="{{ $showCompleted ? 'true' : 'false' }}">
      {{ $showCompleted ? __('Hide completed') : __('Show completed') }}
    </a>
  </div>

  <div class="filter-bar" id="filter-bar" @unless($filterOpen) hidden @endunless>
    <nav class="seg" aria-label="{{ __('Filter') }}">
      @foreach (['all' => __('All'), 'school' => __('School'), 'personal' => __('Personal')] as $f => $label)
        <a class="seg-btn {{ $filter === $f ? 'is-active' : '' }}" href="{{ $url(['filter' => $f === 'all' ? null : $f]) }}" @if($filter === $f) aria-current="true" @endif>{{ $label }}</a>
      @endforeach
    </nav>
    <a class="pill-btn pill-urgent {{ $highOnly ? 'is-on' : '' }}" href="{{ $url(['high' => $highOnly ? null : 1]) }}" aria-pressed="{{ $highOnly ? 'true' : 'false' }}">{{ __('High priority only') }}</a>
    @if ($terms->isNotEmpty())
      <label class="sr-only" for="term-filter">{{ __('Term') }}</label>
      <select id="term-filter" class="select select-sm" data-term-filter data-base="{{ $url(['term' => null]) }}">
        <option value="">{{ __('All terms') }}</option>
        @foreach ($terms as $t)<option value="{{ $t->id }}" @selected($term?->id === $t->id)>{{ $t->name }}</option>@endforeach
      </select>
    @endif
  </div>

  <p class="task-count">
    {{ trans_choice(':count task showing|:count tasks showing', $count) }}
    @if ($search !== '') · {{ __('matching “:q”', ['q' => $search]) }}@endif
  </p>
  @if ($count === 0 && ($search !== '' || $highOnly))
    <div class="empty">{{ __('No tasks match. Try another word or clear the filters.') }}
      <a href="{{ route('tasks') }}">{{ __('Clear all') }}</a>
    </div>
  @endif

  <section class="task-section" aria-labelledby="sec-assess" @if($filter === 'personal') hidden @endif>
    <h2 class="eyebrow" id="sec-assess">{{ __('ASSESSMENTS') }}</h2>
    <p class="section-sub">{{ __('Assignments and exams move from preparation to their due date. Plan study sessions for each one.') }}</p>
    @foreach ($groups['assessments'] as $type => $items) @include('tasks.group') @endforeach
  </section>

  <section class="task-section" aria-labelledby="sec-other">
    <h2 class="eyebrow" id="sec-other">{{ __('OTHER WORK') }}</h2>
    <p class="section-sub">{{ __('Personal tasks stay lightweight and easy to clear.') }}</p>
    @foreach ($groups['other'] as $type => $items)
      @if (! ($filter === 'school' && $type === 'personal') && ! ($filter === 'personal' && $type !== 'personal'))
        @include('tasks.group')
      @endif
    @endforeach
  </section>
</div>

@include('calendar.dialogs')
@endsection

@push('scripts')
<script src="{{ asset('js/calendar.js') }}?v={{ filemtime(public_path('js/calendar.js')) }}"></script>
<script src="{{ asset('js/tasks.js') }}?v={{ filemtime(public_path('js/tasks.js')) }}"></script>
@endpush
