@extends('layouts.app', ['title' => __('Tasks')])

@php
  $url = fn (array $over) => route('tasks', array_filter(array_merge([
      'filter' => $filter === 'all' ? null : $filter,
      'completed' => $showCompleted ? 1 : null,
      'term' => $term?->id,
  ], $over), fn ($v) => $v !== null));
  $groupMeta = [
    'assignment' => [__('Assignments'), __('No assignments yet')],
    'exam' => [__('Exams'), __('No exams yet')],
    'homework' => [__('Homework'), __('No homework yet')],
    'personal' => [__('Personal tasks'), __('No personal tasks yet')],
  ];
  $filterOpen = $filter !== 'all' || $term;
@endphp

@section('banner')
  @include('partials.setup-banner')
@endsection

@section('content')
<div class="page" id="tasks-page">
  <div class="page-head">
    <div>
      <h1 class="page-title">{{ __('Tasks') }}</h1>
      <p class="page-sub">{{ __('Add schoolwork once, then follow each assessment from preparation to deadline.') }}</p>
    </div>
  </div>

  @if (session('status'))<div class="alert alert-success" role="status">{{ session('status') }}</div>@endif

  <div class="task-tools">
    <button type="button" class="pill-btn {{ $filterOpen ? 'is-on' : '' }}" data-toggle-filter aria-expanded="{{ $filterOpen ? 'true' : 'false' }}" aria-controls="filter-bar">{{ __('Filter') }}</button>
    <a class="pill-btn {{ $showCompleted ? 'is-on' : '' }}" href="{{ $url(['completed' => $showCompleted ? null : 1]) }}" aria-pressed="{{ $showCompleted ? 'true' : 'false' }}">
      {{ $showCompleted ? __('Hide completed') : __('Show completed') }}
    </a>
  </div>

  <div class="filter-bar" id="filter-bar" @unless($filterOpen) hidden @endunless>
    <nav class="seg" aria-label="{{ __('Filter') }}">
      @foreach (['all' => __('All'), 'school' => __('School'), 'personal' => __('Personal')] as $f => $label)
        <a class="seg-btn {{ $filter === $f ? 'is-active' : '' }}" href="{{ $url(['filter' => $f === 'all' ? null : $f]) }}" @if($filter === $f) aria-current="true" @endif>{{ $label }}</a>
      @endforeach
    </nav>
    @if ($terms->isNotEmpty())
      <label class="sr-only" for="term-filter">{{ __('Term') }}</label>
      <select id="term-filter" class="select select-sm" data-term-filter data-base="{{ $url(['term' => null]) }}">
        <option value="">{{ __('All terms') }}</option>
        @foreach ($terms as $t)<option value="{{ $t->id }}" @selected($term?->id === $t->id)>{{ $t->name }}</option>@endforeach
      </select>
    @endif
  </div>

  <p class="task-count">{{ trans_choice(':count task showing|:count tasks showing', $count) }}</p>

  <section class="task-section" aria-labelledby="sec-assess" @if($filter === 'personal') hidden @endif>
    <h2 class="eyebrow" id="sec-assess">{{ __('ASSESSMENTS') }}</h2>
    <p class="section-sub">{{ __('Assignments and exams move from preparation to their due date. Plan study sessions for each one.') }}</p>
    @foreach ($groups['assessments'] as $type => $items) @include('tasks.group') @endforeach
  </section>

  <section class="task-section" aria-labelledby="sec-other">
    <h2 class="eyebrow" id="sec-other">{{ __('OTHER WORK') }}</h2>
    <p class="section-sub">{{ __('Homework and personal tasks stay lightweight and easy to clear.') }}</p>
    @foreach ($groups['other'] as $type => $items)
      @if (! ($filter === 'school' && $type === 'personal') && ! ($filter === 'personal' && $type !== 'personal'))
        @include('tasks.group')
      @endif
    @endforeach
  </section>
</div>

@include('calendar.dialogs')
@endsection

@push('scripts')
<script src="{{ asset('js/calendar.js') }}?v={{ filemtime(public_path('js/calendar.js')) }}"></script>
<script src="{{ asset('js/tasks.js') }}?v={{ filemtime(public_path('js/tasks.js')) }}"></script>
@endpush
