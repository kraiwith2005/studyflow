<div class="tgroup {{ $type === 'personal' ? 'is-personal' : '' }}" data-group="{{ $type }}">
  <div class="tgroup-head">
    <button type="button" class="tgroup-toggle" aria-expanded="true" aria-controls="group-{{ $type }}" aria-label="{{ __('Show or hide :name', ['name' => $groupMeta[$type][0]]) }}">
      <x-icon name="chevron" size="18" />
    </button>
    <div class="tgroup-text">
      <div class="tgroup-name">{{ $groupMeta[$type][0] }}</div>
      <div class="tgroup-count">{{ trans_choice(':count item|:count items', $items->count()) }}</div>
    </div>
    <button type="button" class="btn btn-primary" data-add-type="{{ $type }}"><x-icon name="plus" /> {{ __('Add') }}</button>
  </div>
  <div class="tgroup-body" id="group-{{ $type }}">
    @forelse ($items as $task)
      @include('tasks.item')
    @empty
      <div class="empty">
        <div class="empty-title">{{ $groupMeta[$type][1] }}</div>
        <div class="empty-sub">{{ __('Click “Add” to create one.') }}</div>
      </div>
    @endforelse
  </div>
</div>
