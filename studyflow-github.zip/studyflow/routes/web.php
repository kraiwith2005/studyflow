<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\StudyController;
use App\Http\Controllers\StudySessionController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\PasswordResetController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\LocaleController;
use App\Http\Controllers\PreferenceController;
use App\Http\Controllers\Settings\BackupController;
use App\Http\Controllers\Settings\RecurringClassController;
use App\Http\Controllers\Settings\SettingsController;
use App\Http\Controllers\Settings\SubjectController;
use App\Http\Controllers\Settings\TermController;
use App\Http\Controllers\Settings\TimetableController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route(auth()->check() ? 'calendar' : 'sign-in'));

Route::post('/locale/{locale}', [LocaleController::class, 'update'])->name('locale');

// Public information pages (linked from sign-up and Settings).
foreach (['privacy', 'terms', 'cookies'] as $page) {
    Route::get("/{$page}", fn () => view(app()->getLocale() === 'th' ? "legal.th.{$page}" : "legal.{$page}"))->name($page);
}

Route::middleware('guest')->group(function () {
    Route::get('/sign-up', [RegisterController::class, 'create'])->name('sign-up');
    Route::post('/sign-up', [RegisterController::class, 'store']);

    Route::get('/sign-in', [LoginController::class, 'create'])->name('sign-in');
    Route::post('/sign-in', [LoginController::class, 'store']);

    Route::get('/forgot-password', [PasswordResetController::class, 'request'])->name('password.request');
    Route::post('/forgot-password', [PasswordResetController::class, 'email'])
        ->middleware('throttle:5,1')->name('password.email');
    Route::get('/reset-password/{token}', [PasswordResetController::class, 'edit'])->name('password.reset');
    Route::post('/reset-password', [PasswordResetController::class, 'update'])->name('password.update');

    Route::get('/auth/google', [GoogleController::class, 'redirect'])->name('google.redirect');
    Route::get('/auth/google/callback', [GoogleController::class, 'callback'])->name('google.callback');
});

Route::middleware('auth')->group(function () {
    Route::post('/sign-out', [LoginController::class, 'destroy'])->name('sign-out');

    // Main sections — each is built in its own stage.
    Route::get('/calendar', [CalendarController::class, 'index'])->name('calendar');

    Route::post('/tasks', [TaskController::class, 'store'])->name('tasks.store');
    Route::put('/tasks/{task}', [TaskController::class, 'update'])->name('tasks.update');
    Route::delete('/tasks/{task}', [TaskController::class, 'destroy'])->name('tasks.destroy');
    Route::patch('/tasks/{task}/toggle', [TaskController::class, 'toggle'])->name('tasks.toggle');

    Route::post('/sessions', [StudySessionController::class, 'store'])->name('sessions.store');
    Route::put('/sessions/{session}', [StudySessionController::class, 'update'])->name('sessions.update');
    Route::delete('/sessions/{session}', [StudySessionController::class, 'destroy'])->name('sessions.destroy');
    Route::patch('/sessions/{session}/toggle', [StudySessionController::class, 'toggle'])->name('sessions.toggle');
    Route::get('/tasks', [TaskController::class, 'index'])->name('tasks');
    Route::get('/study', [StudyController::class, 'index'])->name('study');
    Route::post('/study/timer', [StudyController::class, 'start'])->name('timer.start');
    Route::post('/study/timer/pause', [StudyController::class, 'pause'])->name('timer.pause');
    Route::post('/study/timer/resume', [StudyController::class, 'resume'])->name('timer.resume');
    Route::post('/study/timer/stop', [StudyController::class, 'stop'])->name('timer.stop');
    Route::delete('/study/timer', [StudyController::class, 'discard'])->name('timer.discard');

    Route::get('/settings', [SettingsController::class, 'index'])->name('settings');
    Route::prefix('settings')->name('settings.')->group(function () {
        Route::post('/subjects', [SubjectController::class, 'store'])->name('subjects.store');
        Route::put('/subjects/{subject}', [SubjectController::class, 'update'])->name('subjects.update');
        Route::delete('/subjects/{subject}', [SubjectController::class, 'destroy'])->name('subjects.destroy');

        Route::post('/terms', [TermController::class, 'store'])->name('terms.store');
        Route::put('/terms/{term}', [TermController::class, 'update'])->name('terms.update');
        Route::delete('/terms/{term}', [TermController::class, 'destroy'])->name('terms.destroy');

        Route::put('/timetable', [TimetableController::class, 'updateSettings'])->name('timetable.settings');
        Route::put('/timetable/periods', [TimetableController::class, 'updatePeriods'])->name('timetable.periods');
        Route::put('/timetable/slot', [TimetableController::class, 'setSlot'])->name('timetable.slot');
        Route::delete('/timetable/grid', [TimetableController::class, 'clearGrid'])->name('timetable.clear');

        Route::post('/classes', [RecurringClassController::class, 'store'])->name('classes.store');
        Route::put('/classes/{class}', [RecurringClassController::class, 'update'])->name('classes.update');
        Route::delete('/classes/{class}', [RecurringClassController::class, 'destroy'])->name('classes.destroy');

        Route::get('/backup/export', [BackupController::class, 'export'])->name('backup.export');
        Route::post('/backup/import', [BackupController::class, 'import'])->name('backup.import');
        Route::delete('/backup/clear', [BackupController::class, 'clear'])->name('backup.clear');
    });

    Route::get('/account', [AccountController::class, 'edit'])->name('account');
    Route::put('/account/profile', [AccountController::class, 'updateProfile'])->name('account.profile');
    Route::put('/account/password', [AccountController::class, 'updatePassword'])->name('account.password');
    Route::delete('/account', [AccountController::class, 'destroy'])->name('account.destroy');

    Route::post('/preferences/theme', [PreferenceController::class, 'theme'])->name('preferences.theme');
});
