<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** The "homework" type is removed. Existing homework is kept as assignments so no one loses data. */
    public function up(): void
    {
        DB::table('tasks')->where('type', 'homework')->update(['type' => 'assignment']);

        Schema::table('tasks', function (Blueprint $table) {
            $table->enum('type', ['assignment', 'exam', 'personal'])->change();
        });
    }

    public function down(): void
    {
        Schema::table('tasks', function (Blueprint $table) {
            $table->enum('type', ['homework', 'assignment', 'exam', 'personal'])->change();
        });
    }
};
