<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // The study timer currently running or paused (at most one per user).
        Schema::create('study_timers', function (Blueprint $table) {
            $table->foreignId('user_id')->primary()->constrained()->cascadeOnDelete();
            $table->foreignId('subject_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('task_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('study_session_id')->nullable()->constrained()->nullOnDelete(); // a planned session being studied
            $table->string('label', 150);
            $table->enum('status', ['running', 'paused']);
            $table->timestamp('first_started_at');
            $table->timestamp('started_at')->nullable(); // start of the current running stretch
            $table->unsignedInteger('accumulated_seconds')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('study_timers');
    }
};
