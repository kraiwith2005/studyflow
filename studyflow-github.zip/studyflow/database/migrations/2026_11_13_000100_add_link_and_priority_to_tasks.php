<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** A link to where the work lives, and how important the task is. */
    public function up(): void
    {
        Schema::table('tasks', function (Blueprint $table) {
            $table->string('link', 500)->nullable()->after('notes');
            $table->enum('priority', ['low', 'normal', 'high'])->default('normal')->after('link');
        });
    }

    public function down(): void
    {
        Schema::table('tasks', function (Blueprint $table) {
            $table->dropColumn(['link', 'priority']);
        });
    }
};
