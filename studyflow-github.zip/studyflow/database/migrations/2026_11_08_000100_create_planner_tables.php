<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // One row per user: how their timetable works.
        Schema::create('planner_settings', function (Blueprint $table) {
            $table->foreignId('user_id')->primary()->constrained()->cascadeOnDelete();
            $table->enum('timetable_type', ['school', 'university', 'custom'])->default('school');
            $table->enum('repeat_cycle', ['weekly', 'ab'])->default('weekly');
            $table->date('cycle_anchor')->nullable(); // Monday of a "Week A" when repeat_cycle = ab
            $table->boolean('periods_initialized')->default(false);
            $table->timestamps();
        });

        Schema::create('subjects', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name', 80);
            $table->char('color', 7);
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
            $table->unique(['user_id', 'name']);
        });

        Schema::create('terms', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name', 60);
            $table->date('start_date');
            $table->date('end_date');
            $table->timestamps();
            $table->index(['user_id', 'start_date']);
        });

        Schema::create('periods', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name', 40);
            $table->enum('kind', ['class', 'break'])->default('class');
            $table->time('start_time');
            $table->time('end_time');
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        // One cell of the timetable grid.
        Schema::create('timetable_slots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('period_id')->constrained()->cascadeOnDelete();
            $table->unsignedTinyInteger('day'); // 1 = Monday … 7 = Sunday
            $table->enum('week', ['A', 'B'])->default('A');
            $table->foreignId('subject_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['period_id', 'day', 'week']);
        });

        // Classes and commitments outside the grid.
        Schema::create('recurring_classes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('subject_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name', 80)->nullable();
            $table->unsignedTinyInteger('day');
            $table->time('start_time');
            $table->time('end_time');
            $table->enum('week', ['every', 'A', 'B'])->default('every');
            $table->string('location', 120)->nullable();
            $table->string('teacher', 80)->nullable();
            $table->timestamps();
            $table->index(['user_id', 'day']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('recurring_classes');
        Schema::dropIfExists('timetable_slots');
        Schema::dropIfExists('periods');
        Schema::dropIfExists('terms');
        Schema::dropIfExists('subjects');
        Schema::dropIfExists('planner_settings');
    }
};
