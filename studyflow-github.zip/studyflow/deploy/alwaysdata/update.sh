#!/bin/bash
# StudyFlow — pull the latest code from GitHub and apply it.
#   bash deploy/alwaysdata/update.sh
set -e
cd "$(dirname "$0")/../.."
# Git does not keep empty folders; Laravel needs these to exist.
mkdir -p storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs bootstrap/cache
if [ -d .git ]; then
  echo "→ Getting the latest code from GitHub…"
  git pull --ff-only
fi
[ -f public/.htaccess ] || cp deploy/alwaysdata/public-htaccess public/.htaccess
echo "→ Updating components…"
composer install --no-dev --optimize-autoloader --no-interaction --no-progress
echo "→ Updating the database (if needed)…"
php artisan migrate --force --no-interaction
php artisan optimize:clear --no-interaction >/dev/null
php artisan optimize --no-interaction >/dev/null
echo "✓ StudyFlow is up to date."
