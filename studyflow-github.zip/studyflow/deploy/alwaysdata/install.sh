#!/bin/bash
# StudyFlow — first-time setup on Alwaysdata (run over SSH inside the project folder).
#   bash deploy/alwaysdata/install.sh
set -e
cd "$(dirname "$0")/../.."
# Hidden files can be skipped by a browser upload; restore them from visible copies.
[ -f .env.example ] || cp deploy/alwaysdata/env.example .env.example
[ -f public/.htaccess ] || cp deploy/alwaysdata/public-htaccess public/.htaccess
# Git does not keep empty folders; Laravel needs these to exist.
mkdir -p storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs bootstrap/cache
echo "== StudyFlow setup =="

php -r 'exit(version_compare(PHP_VERSION, "8.3.0", ">=") ? 0 : 1);' \
  || { echo "✗ PHP $(php -r 'echo PHP_VERSION;') is too old. In the Alwaysdata admin: Environment › PHP › choose 8.3 or newer, then run this again."; exit 1; }

echo "→ Installing components (1–3 minutes)…"
composer install --no-dev --optimize-autoloader --no-interaction --no-progress

if [ ! -f .env ]; then
  echo ""
  echo "Answer 5 questions (from the Alwaysdata admin › Databases › MySQL):"
  read -r -p "  Site address, e.g. https://studyflow.alwaysdata.net : " SF_URL
  read -r -p "  MySQL host,    e.g. mysql-studyflow.alwaysdata.net : " SF_DBH
  read -r -p "  Database name, e.g. studyflow_app                  : " SF_DBN
  read -r -p "  MySQL user,    e.g. studyflow                      : " SF_DBU
  read -r -s -p "  MySQL password (hidden while typing)               : " SF_DBP; echo
  export SF_URL SF_DBH SF_DBN SF_DBU SF_DBP
  php -r '
    $s = file_get_contents(".env.example");
    $set = function ($k, $v) use (&$s) {
        $line = $k . "=" . $v;
        $s = preg_match("/^" . $k . "=.*$/m", $s)
            ? preg_replace_callback("/^" . $k . "=.*$/m", fn () => $line, $s)
            : $s . "\n" . $line;
    };
    $quote = fn ($v) => "\"" . str_replace(["\\", "\"", "\$"], ["\\\\", "\\\"", "\\\$"], $v) . "\"";
    $set("APP_ENV", "production"); $set("APP_DEBUG", "false"); $set("LOG_LEVEL", "error");
    $set("APP_URL", rtrim(getenv("SF_URL"), "/"));
    $set("DB_CONNECTION", "mysql"); $set("DB_HOST", getenv("SF_DBH")); $set("DB_PORT", "3306");
    $set("DB_DATABASE", getenv("SF_DBN")); $set("DB_USERNAME", getenv("SF_DBU")); $set("DB_PASSWORD", $quote(getenv("SF_DBP")));
    file_put_contents(".env", $s);
  '
  unset SF_DBP
  chmod 600 .env
  php artisan key:generate --force --no-interaction
  echo "✓ Settings saved to .env"
else
  echo "→ .env already exists — keeping your settings"
fi

echo "→ Setting up the database…"
php artisan migrate --force --no-interaction

chmod -R u+rwX storage bootstrap/cache
php artisan optimize --no-interaction >/dev/null
echo ""
echo "✓ StudyFlow is installed. Open your site address in the browser."
