#!/bin/bash
# Builds an upload-ready StudyFlow package for InfinityFree (no SSH needed on the host).
# Output: deploy/infinityfree/dist/studyflow-infinityfree.zip
#   htdocs/        -> upload the CONTENTS of this folder into InfinityFree's htdocs
#   database.sql   -> import in phpMyAdmin
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/deploy/infinityfree/dist"
BUILD="$OUT/build"
rm -rf "$OUT" && mkdir -p "$BUILD/htdocs"

echo "→ Copying app"
rsync -a "$ROOT/" "$BUILD/htdocs/" \
  --exclude .git --exclude node_modules --exclude vendor --exclude tests --exclude deploy \
  --exclude .env --exclude '.env.*' --exclude phpunit.xml --exclude 'StudyFlow-Mac.command' \
  --exclude AGENTS.md --exclude CLAUDE.md --exclude '.phpunit*' --exclude 'database/database.sqlite' \
  --exclude 'storage/logs/*.log' --exclude 'storage/framework/sessions/*' \
  --exclude 'storage/framework/views/*' --exclude 'storage/framework/cache/data/*' \
  --exclude 'bootstrap/cache/*.php'
cp "$ROOT/deploy/infinityfree/htaccess-root" "$BUILD/htdocs/.htaccess"

echo "→ Installing production components (no dev tools)"
( cd "$BUILD/htdocs" && COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader --no-interaction --no-progress -q )

echo "→ Writing production .env (fill in the CHANGE-ME values on the host)"
KEY="base64:$(php -r 'echo base64_encode(random_bytes(32));')"
python3 - "$ROOT/.env.example" "$BUILD/htdocs/.env" "$KEY" <<'PY'
import re, sys
src, dst, key = sys.argv[1:4]
s = open(src).read()
def put(k, v):
    global s
    if re.search(rf'^{k}=.*$', s, flags=re.M): s = re.sub(rf'^{k}=.*$', f'{k}={v}', s, flags=re.M)
    else: s += f'\n{k}={v}'
put('APP_ENV', 'production'); put('APP_KEY', key); put('APP_DEBUG', 'false')
put('APP_URL', 'https://CHANGE-ME.infinityfreeapp.com'); put('APP_TIMEZONE', 'Asia/Bangkok')
put('LOG_LEVEL', 'error')
put('DB_CONNECTION', 'mysql'); put('DB_HOST', 'CHANGE-ME.infinityfree.com'); put('DB_PORT', '3306')
put('DB_DATABASE', 'CHANGE-ME'); put('DB_USERNAME', 'CHANGE-ME'); put('DB_PASSWORD', 'CHANGE-ME')
s = "# StudyFlow — live settings. Change every CHANGE-ME value (see the install guide).\n" + s
open(dst, 'w').write(s)
PY

echo "→ Building database.sql from the migrations"
TMPDB="sf_build_$$"
mysql -uroot -e "CREATE DATABASE $TMPDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
( cd "$BUILD/htdocs" && DB_DATABASE=$TMPDB DB_USERNAME=root DB_PASSWORD= DB_HOST=localhost DB_SOCKET=/run/mysqld/mysqld.sock php artisan migrate --force -q )
{
  echo "-- StudyFlow database — import this once in phpMyAdmin (database must be empty)."
  echo "SET NAMES utf8mb4;"
  echo "SET FOREIGN_KEY_CHECKS=0;"
  mysqldump -uroot --no-data --skip-comments --skip-add-drop-table --skip-set-charset --compact "$TMPDB"
  mysqldump -uroot --no-create-info --skip-comments --compact "$TMPDB" migrations
  echo "SET FOREIGN_KEY_CHECKS=1;"
} | sed -E -e 's/ DEFINER=`[^`]+`@`[^`]+`//g' -e '/^\/\*M!999999/d' > "$BUILD/database.sql"
mysql -uroot -e "DROP DATABASE $TMPDB"

# Only keep caches that contain no machine-specific paths.
rm -f "$BUILD/htdocs/bootstrap/cache/config.php" "$BUILD/htdocs/bootstrap/cache/routes"*.php
: > "$BUILD/htdocs/storage/logs/.gitkeep"

echo "→ Zipping"
( cd "$BUILD" && zip -qr "$OUT/studyflow-infinityfree.zip" htdocs database.sql )
FILES=$(find "$BUILD/htdocs" -type f | wc -l)
echo "✓ Done: $OUT/studyflow-infinityfree.zip  ($FILES files in htdocs)"
