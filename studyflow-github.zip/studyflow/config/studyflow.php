<?php

return [
    'tagline' => 'Your schoolwork, in one flow',
    'support_email' => env('STUDYFLOW_SUPPORT_EMAIL', 'mystudyplanner.studio@gmail.com'),
];
