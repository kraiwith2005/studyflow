/* StudyFlow — Study page: timer, history, Plan study / Log study */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const today = (window.SF_CAL && window.SF_CAL.today) || new Date().toISOString().slice(0, 10);

  /* ---------- Plan study / Log study (dialogs from calendar.js) ---------- */
  $$('[data-plan-task]').forEach((b) => b.addEventListener('click', () => {
    window.SFCal.openForm('session', null, { date: today, task_id: b.dataset.planTask, subject_id: b.dataset.planSubject, title: b.dataset.planTitle });
  }));
  $('[data-log-study]')?.addEventListener('click', (e) => {
    window.SFCal.openForm('session', null, { date: today, mark_done: true, subject_id: e.currentTarget.dataset.subject });
  });

  /* ---------- History toggle ---------- */
  const hb = $('[data-toggle-history]');
  hb?.addEventListener('click', () => {
    const list = $('#history');
    list.hidden = !list.hidden;
    hb.setAttribute('aria-expanded', String(!list.hidden));
    hb.textContent = list.hidden ? hb.dataset.show : hb.dataset.hide;
  });

  /* ---------- Timer ---------- */
  const card = $('#timer');
  const cfg = window.SF_TIMER;
  if (!card || !cfg) return;
  const S = cfg.strings;
  const display = $('[data-timer-display]', card);
  const select = $('#timer-target');
  const errorEl = $('[data-timer-error]', card);
  const offset = cfg.serverNow - Date.now(); // server clock minus device clock
  let timer = cfg.timer;          // null when ready
  let ticker = null;
  let busy = false;

  const pad = (n) => String(n).padStart(2, '0');
  const fmt = (s) => `${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}`;
  const elapsed = () => {
    if (!timer) return 0;
    if (timer.status !== 'running') return timer.accumulated;
    return timer.accumulated + Math.max(0, Math.floor((Date.now() + offset - timer.startedAt) / 1000));
  };
  const baseTitle = document.title;

  function render() {
    const state = timer ? timer.status : 'ready';
    card.dataset.state = state;
    $('[data-state-badge]', card).textContent = S[state];
    $$('[data-when]', card).forEach((el) => { el.hidden = !el.dataset.when.split(' ').includes(state); });
    if (timer) $('[data-timer-label]', card).textContent = timer.label;
    $$('[data-study-now]').forEach((b) => { b.disabled = !!timer; });
    const tick = () => {
      const t = fmt(elapsed());
      display.textContent = t;
      document.title = state === 'running' ? `${t} · ${baseTitle}` : baseTitle;
    };
    tick();
    clearInterval(ticker);
    if (state === 'running') ticker = setInterval(tick, 1000);
  }

  async function act(name, body) {
    if (busy) return;
    busy = true;
    $$('[data-act]', card).forEach((b) => { b.disabled = true; });
    try {
      const method = name === 'discard' ? 'DELETE' : 'POST';
      const res = await SF.request(cfg.urls[name], { method, body });
      if (name === 'stop' || name === 'discard') {
        location.href = location.pathname; // fresh page: flash message + updated stats
        return;
      }
      timer = res.timer;
      render();
    } catch (err) {
      if (err.status === 409 || err.status === 404) { location.reload(); return; }
      errorEl.textContent = err.data?.message || err.message;
      errorEl.hidden = false;
    } finally {
      busy = false;
      $$('[data-act]', card).forEach((b) => { b.disabled = false; });
    }
  }

  function start(target) {
    errorEl.hidden = true;
    if (!target) { errorEl.textContent = S.choose; errorEl.hidden = false; select.focus(); return; }
    act('start', { target });
  }

  $('[data-act="start"]', card).addEventListener('click', () => start(select.value));
  $('[data-act="pause"]', card).addEventListener('click', () => act('pause'));
  $('[data-act="resume"]', card).addEventListener('click', () => act('resume'));
  $('[data-act="stop"]', card).addEventListener('click', () => act('stop'));
  select.addEventListener('change', () => { errorEl.hidden = true; });

  // Discard asks first (uses the shared confirm dialog).
  const confirmDlg = $('#confirm-dialog');
  let discarding = false;
  $('[data-act="discard"]', card).addEventListener('click', () => {
    discarding = true;
    $('[data-confirm-title]', confirmDlg).textContent = S.discardQ;
    $('[data-confirm-text]', confirmDlg).textContent = S.discardText;
    $('[data-confirm-ok]', confirmDlg).textContent = S.discard;
    confirmDlg.showModal();
  });
  $('[data-confirm-ok]', confirmDlg).addEventListener('click', () => {
    if (!discarding) return;
    discarding = false;
    confirmDlg.close();
    act('discard');
  });
  confirmDlg.addEventListener('close', () => { discarding = false; });

  // "Study now" on an assessment, or "Start" on a planned session (?start=session:ID).
  $$('[data-study-now]').forEach((b) => b.addEventListener('click', () => {
    select.value = b.dataset.studyNow;
    window.scrollTo({ top: card.offsetTop - 90, behavior: 'smooth' });
    start(b.dataset.studyNow);
  }));
  const wanted = new URLSearchParams(location.search).get('start');
  if (wanted && !timer && [...select.options].some((o) => o.value === wanted)) {
    select.value = wanted;
    start(wanted);
  }

  // Keep the display honest after the tab sleeps (e.g. phone screen off).
  document.addEventListener('visibilitychange', () => { if (!document.hidden) render(); });
  render();
})();
