/* StudyFlow — Settings page */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  /* ---------- Accordion (open sections kept in the URL) ---------- */
  function syncUrl() {
    const open = $$('.acc.is-open[data-acc]').map((a) => a.dataset.acc);
    const url = new URL(location.href);
    if (open.length) url.searchParams.set('open', open.join(',')); else url.searchParams.delete('open');
    history.replaceState(null, '', url.pathname + url.search + url.hash);
  }
  $$('.acc[data-acc] > .acc-head').forEach((head) => {
    head.addEventListener('click', () => {
      const acc = head.parentElement;
      const open = acc.classList.toggle('is-open');
      head.setAttribute('aria-expanded', String(open));
      syncUrl();
    });
  });

  /* ---------- Filling forms from data-values ---------- */
  function clearErrors(scope) {
    $$('.field-error, .form-error-box', scope).forEach((e) => e.remove());
    $$('.is-invalid', scope).forEach((e) => e.classList.remove('is-invalid'));
  }
  function prepareForm(form, trigger) {
    form.action = trigger.dataset.action;
    form.querySelector('input[name="_method"]').value = trigger.dataset.method || 'POST';
    const values = JSON.parse(trigger.dataset.values || '{}');
    Object.entries(values).forEach(([name, value]) => {
      const el = form.elements[name];
      if (el && el.type !== 'color') el.value = value;
    });
    clearErrors(form);
    return values;
  }

  /* ---------- Dialogs ---------- */
  $$('[data-open-dialog]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const dlg = document.getElementById(btn.dataset.openDialog);
      const form = dlg.querySelector('form');
      if (btn.dataset.action && form) {
        const values = prepareForm(form, btn);
        const title = dlg.querySelector('[data-dialog-title]');
        if (title) title.textContent = btn.dataset.title;
        const submit = dlg.querySelector('[data-dialog-submit]');
        if (submit) submit.textContent = btn.dataset.submit;
        if (values.color) setColour(dlg, values.color);
      } else if (form) {
        form.reset();
      }
      dlg.showModal();
      dlg.dispatchEvent(new Event('input', { bubbles: true }));
      dlg.querySelector('input:not([type=hidden]):not([type=color])')?.focus();
    });
  });
  $$('dialog').forEach((dlg) => {
    $$('[data-dialog-close]', dlg).forEach((b) => b.addEventListener('click', () => dlg.close()));
    dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); }); // click backdrop
    if (dlg.hasAttribute('data-autoshow')) {
      dlg.showModal();
      dlg.dispatchEvent(new Event('input', { bubbles: true }));
    }
  });

  /* Subject dialog: "Add" only when a name is typed */
  document.addEventListener('input', (e) => {
    const dlg = e.target.closest ? e.target.closest('dialog') : null;
    if (!dlg) return;
    const name = $('[data-enable-submit]', dlg);
    const submit = $('[data-dialog-submit]', dlg);
    if (name && submit) submit.disabled = name.value.trim() === '';
    const match = $('[data-match]', dlg);
    const matchBtn = $('[data-match-submit]', dlg);
    if (match && matchBtn) matchBtn.disabled = match.value.trim() !== match.dataset.match;
  });

  /* Colour swatches + custom colour */
  function setColour(scope, hex) {
    hex = hex.toLowerCase();
    $('[data-colour-input]', scope).value = hex;
    $('[data-colour-preview]', scope).style.background = hex;
    $$('.swatch', scope).forEach((s) => s.setAttribute('aria-checked', String(s.dataset.color === hex)));
  }
  $$('.swatch').forEach((sw) => sw.addEventListener('click', () => setColour(sw.closest('dialog'), sw.dataset.color)));
  $$('[data-colour-input]').forEach((input) => {
    input.addEventListener('input', () => setColour(input.closest('dialog'), input.value));
  });

  /* ---------- Inline panels (Terms, classes) ---------- */
  $$('[data-open-panel]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const panel = document.getElementById(btn.dataset.openPanel);
      const form = panel.querySelector('form');
      prepareForm(form, btn);
      $('[data-panel-title]', panel).textContent = btn.dataset.title;
      $('[data-panel-submit]', panel).textContent = btn.dataset.submit;
      panel.classList.add('is-open');
      panel.scrollIntoView({ behavior: 'smooth', block: 'center' });
      form.querySelector('input:not([type=hidden])')?.focus({ preventScroll: true });
    });
  });
  $$('[data-panel-close]').forEach((b) => b.addEventListener('click', () => b.closest('.panel').classList.remove('is-open')));
  const reopen = $('#settings')?.dataset.reopen;
  if (reopen) $('.panel.is-open')?.scrollIntoView({ block: 'center' });

  /* ---------- Confirm before destructive submits ---------- */
  const confirmDlg = $('#confirm-dialog');
  let pendingForm = null;
  $$('form[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (e) => {
      if (form.dataset.confirmed) return;
      e.preventDefault();
      pendingForm = form;
      $('[data-confirm-title]', confirmDlg).textContent = form.dataset.confirm;
      $('[data-confirm-text]', confirmDlg).textContent = form.dataset.confirmText || '';
      $('[data-confirm-ok]', confirmDlg).textContent = form.dataset.confirmLabel || window.SF_I18N?.delete || 'Delete';
      confirmDlg.showModal();
    });
  });
  confirmDlg?.addEventListener('close', () => {
    // Cancelling an import must clear the chosen file so choosing it again re-triggers.
    if (pendingForm && !pendingForm.dataset.confirmed) pendingForm.querySelector('input[type=file]')?.value && (pendingForm.querySelector('input[type=file]').value = '');
  });
  $('[data-confirm-ok]', confirmDlg)?.addEventListener('click', () => {
    if (!pendingForm) return;
    pendingForm.dataset.confirmed = '1';
    $('[data-confirm-ok]', confirmDlg).disabled = true;
    pendingForm.requestSubmit ? pendingForm.requestSubmit() : pendingForm.submit();
  });
  $$('[data-auto-submit]').forEach((input) => {
    input.addEventListener('change', () => { if (input.files.length) input.form.requestSubmit(); });
  });

  /* ---------- Timetable settings (autosave, then reload the section) ---------- */
  const ttSettings = $('#tt-settings');
  if (ttSettings) {
    $$('[data-tt-setting]', ttSettings).forEach((el) => {
      el.addEventListener('change', async () => {
        const body = {};
        $$('[data-tt-setting]', ttSettings).forEach((f) => { body[f.dataset.ttSetting] = f.value || null; });
        try {
          await SF.request(ttSettings.dataset.url, { method: 'PUT', body });
          location.reload();
        } catch (_) { /* status shows "Not saved" */ }
      });
    });
  }

  /* ---------- Timetable grid cells (autosave) ---------- */
  const grid = $('#tt-grid');
  if (grid) {
    $$('select.cell', grid).forEach((sel) => {
      let previous = sel.value;
      sel.addEventListener('change', async () => {
        const opt = sel.selectedOptions[0];
        const paint = (o) => {
          sel.classList.toggle('has-subject', !!o.value);
          if (o.value) sel.style.setProperty('--c', o.dataset.color); else sel.style.removeProperty('--c');
        };
        paint(opt);
        try {
          const res = await SF.request(grid.dataset.url, {
            method: 'PUT',
            body: { period_id: +sel.dataset.period, day: +sel.dataset.day, week: sel.dataset.week, subject_id: sel.value ? +sel.value : null },
          });
          previous = sel.value;
          $$('[data-class-count]').forEach((c) => { const t = window.SF_I18N || {}; c.textContent = (res.class_count === 1 ? t.class : t.classes).replace(':count', res.class_count); });
        } catch (_) {
          sel.value = previous; // roll back on failure
          paint(sel.selectedOptions[0]);
        }
      });
    });
    $$('[data-week-tab]', grid).forEach((tab) => {
      tab.addEventListener('click', () => {
        $$('[data-week-tab]', grid).forEach((t) => { t.classList.toggle('is-active', t === tab); t.setAttribute('aria-selected', String(t === tab)); });
        $$('[data-week-pane]', grid).forEach((p) => { p.hidden = p.dataset.weekPane !== tab.dataset.weekTab; });
      });
    });
  }

  /* ---------- Period editor ---------- */
  const editor = $('#period-editor');
  if (editor) {
    const rows = $('#period-rows');
    const renumber = () => {
      $$('[data-period-row]', rows).forEach((row, i) => {
        $$('input, select', row).forEach((el) => {
          const f = el.dataset.f || el.name.match(/\[(\w+)\]$/)?.[1];
          el.dataset.f = f;
          el.name = `periods[${i}][${f}]`;
        });
      });
    };
    $('[data-toggle-periods]')?.addEventListener('click', (e) => {
      e.currentTarget.hidden = true;
      $('#period-view').hidden = true;
      editor.hidden = false;
      rows.querySelector('input:not([type=hidden])')?.focus();
    });
    $('[data-add-period]', editor).addEventListener('click', () => {
      const last = $$('[data-period-row]', rows).pop();
      const row = $('#period-row-template').content.firstElementChild.cloneNode(true);
      const lastEnd = last ? last.querySelector('[data-f="end_time"], input[name$="[end_time]"]').value : '08:00';
      const [h, m] = (lastEnd || '08:00').split(':').map(Number);
      const end = new Date(0, 0, 0, h, m + 50);
      row.querySelector('[data-f="name"]').value = (window.SF_I18N?.period || 'Period :n').replace(':n', $$('[data-period-row]', rows).length + 1);
      row.querySelector('[data-f="start_time"]').value = lastEnd || '08:00';
      row.querySelector('[data-f="end_time"]').value = `${String(end.getHours()).padStart(2, '0')}:${String(end.getMinutes()).padStart(2, '0')}`;
      rows.appendChild(row);
      renumber();
      row.querySelector('[data-f="name"]').select();
    });
    rows.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-remove-period]');
      if (!btn) return;
      if ($$('[data-period-row]', rows).length === 1) return; // keep at least one
      btn.closest('[data-period-row]').remove();
      renumber();
    });
    renumber();
  }
})();
