/* StudyFlow — Tasks page (dialogs come from calendar.js) */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const today = (window.SF_CAL && window.SF_CAL.today) || new Date().toISOString().slice(0, 10);

  /* Filter bar */
  const fbtn = $('[data-toggle-filter]');
  fbtn?.addEventListener('click', () => {
    const bar = $('#filter-bar');
    bar.hidden = !bar.hidden;
    fbtn.setAttribute('aria-expanded', String(!bar.hidden));
    fbtn.classList.toggle('is-on', !bar.hidden);
  });
  $('[data-term-filter]')?.addEventListener('change', (e) => {
    const url = new URL(e.target.dataset.base, location.origin);
    if (e.target.value) url.searchParams.set('term', e.target.value);
    location.href = url.pathname + url.search;
  });

  /* Collapsible groups (remembered on this device) */
  const KEY = 'sf.tasks.collapsed';
  let collapsed = [];
  try { collapsed = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (_) { collapsed = []; }
  $$('[data-group]').forEach((g) => {
    const btn = $('.tgroup-toggle', g);
    const apply = (isCollapsed) => {
      g.classList.toggle('is-collapsed', isCollapsed);
      btn.setAttribute('aria-expanded', String(!isCollapsed));
    };
    apply(collapsed.includes(g.dataset.group));
    btn.addEventListener('click', () => {
      const now = !g.classList.contains('is-collapsed');
      apply(now);
      collapsed = now ? [...new Set([...collapsed, g.dataset.group])] : collapsed.filter((x) => x !== g.dataset.group);
      try { localStorage.setItem(KEY, JSON.stringify(collapsed)); } catch (_) { /* storage unavailable */ }
    });
  });

  /* Add buttons + Plan study */
  $$('[data-add-type]').forEach((b) => b.addEventListener('click', () => {
    window.SFCal.openForm(b.dataset.addType, null, { date: today });
  }));
  $$('[data-plan-task]').forEach((b) => b.addEventListener('click', () => {
    window.SFCal.openForm('session', null, { date: today, task_id: b.dataset.planTask, subject_id: b.dataset.planSubject, title: b.dataset.planTitle });
  }));
})();
