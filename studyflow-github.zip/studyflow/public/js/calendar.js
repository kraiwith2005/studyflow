/* StudyFlow — Calendar page */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const CAL = window.SF_CAL || { strings: {} };
  const T = CAL.strings;
  const lang = document.documentElement.lang === 'th' ? 'th-TH-u-ca-buddhist' : 'en-GB';

  const fmt = (iso, opts) => new Intl.DateTimeFormat(lang, opts).format(new Date(iso + 'T12:00:00'));
  const shortDate = (iso) => fmt(iso, { day: 'numeric', month: 'short', year: 'numeric' });
  const longDate = (iso) => fmt(iso, { weekday: 'short', day: 'numeric', month: 'short' });

  /* ---------- Generic dialog behaviour ---------- */
  $$('dialog').forEach((dlg) => {
    $$('[data-dialog-close]', dlg).forEach((b) => b.addEventListener('click', () => dlg.close()));
    dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  });
  function clearErrors(scope) {
    $$('.field-error', scope).forEach((e) => e.remove());
    $$('.is-invalid', scope).forEach((e) => e.classList.remove('is-invalid'));
  }

  /* ---------- Add: choose a type ---------- */
  const addDlg = $('#add-dialog');
  let pick = { date: CAL.today, time: null };

  function openChooser(date, time) {
    pick = { date, time };
    $('[data-add-date-label]', addDlg).textContent = longDate(date);
    addDlg.showModal();
  }

  document.addEventListener('click', (e) => {
    const host = e.target.closest('[data-add-date]');
    if (!host || e.target.closest('.chip, .ev, a, .more-link')) return;
    let time = null;
    if (host.hasAttribute('data-timed')) {
      const grid = host.closest('.tgrid');
      const from = +grid.dataset.fromHour, hourH = +grid.dataset.hourH;
      const y = e.clientY - host.getBoundingClientRect().top;
      const mins = Math.max(0, Math.round((y / hourH) * 60 / 30) * 30) + from * 60;
      time = `${String(Math.min(23, Math.floor(mins / 60))).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}`;
    }
    openChooser(host.dataset.addDate, time);
  });

  $$('[data-choose]', addDlg).forEach((btn) => {
    btn.addEventListener('click', () => {
      addDlg.close();
      openForm(btn.dataset.choose, null, { date: pick.date, start_time: pick.time });
    });
  });

  /* ---------- Session + task forms ---------- */
  const sessionDlg = $('#session-dialog');
  const taskDlg = $('#task-dialog');
  const labels = JSON.parse(taskDlg.dataset.labels);

  function setDateLabel(dlg) {
    const input = $(dlg === sessionDlg ? '#s-date' : '#t-date');
    $('[data-form-date]', dlg).textContent = input.value ? shortDate(input.value) : '';
  }
  $('#s-date').addEventListener('change', () => setDateLabel(sessionDlg));
  $('#t-date').addEventListener('change', () => setDateLabel(taskDlg));

  /**
   * type: session | assignment | exam | personal
   * item: payload when editing, null when adding
   * prefill: { date, start_time }
   */
  function openForm(type, item, prefill = {}) {
    const dlg = type === 'session' ? sessionDlg : taskDlg;
    const form = $('form', dlg);
    form.reset();
    clearErrors(form);
    const editing = !!item;
    form.action = editing ? item.urls.update : form.dataset.storeUrl || form.action;
    form.querySelector('[name="_method"]').value = editing ? 'PUT' : 'POST';

    if (type === 'session') {
      form.querySelector('[name="mark_done"]').value = !editing && prefill.mark_done ? '1' : '';
      $('[data-form-title]', dlg).textContent = editing ? dlg.dataset.editTitle : (prefill.mark_done ? CAL.titles.logStudy : dlg.dataset.addTitle);
      $('#s-title').value = editing ? item.title : (prefill.title || '');
      $('#s-subject').value = editing ? (item.subject_id ?? '') : (prefill.subject_id ? String(prefill.subject_id) : '');
      $('#s-date').value = editing ? item.date : prefill.date;
      $('#s-start').value = editing ? item.start : (prefill.start_time || '16:00');
      const dur = $('#s-duration');
      $$('option[data-custom]', dur).forEach((o) => o.remove());
      if (editing && !$$('option', dur).some((o) => o.value === String(item.duration))) {
        // Timer sessions can have any length; keep theirs selectable.
        const o = new Option(item.durationLabel || `${item.duration}`, String(item.duration)); o.dataset.custom = '1'; dur.add(o);
      }
      dur.value = editing ? String(item.duration) : '60';
      const link = $('#s-task');
      link.value = editing && item.task_id ? String(item.task_id) : (prefill.task_id ? String(prefill.task_id) : '');
      if (editing && item.task_id && link.value !== String(item.task_id)) {
        // Linked to a task that's now completed: keep it selectable.
        link.add(new Option(item.task, item.task_id, true, true));
      }
    } else {
      const l = labels[type];
      form.querySelector('[name="type"]').value = type;
      $('[data-form-title]', dlg).textContent = editing ? l.edit : l.add;
      $('#t-title').placeholder = l.placeholder;
      $('[data-date-label]', dlg).firstChild.textContent = l.date;
      $('[data-subject-field]', dlg).hidden = type === 'personal';
      $('#t-title').value = editing ? item.title : '';
      $('#t-subject').value = editing ? (item.subject_id ?? '') : '';
      $('#t-date').value = editing ? item.date : prefill.date;
      $('#t-time').value = editing ? (item.due_time || '') : '';
      $('#t-link').value = editing ? (item.link || '') : '';
      $('#t-notes').value = editing ? (item.notes || '') : '';
      const pr = editing ? (item.priority || 'normal') : 'normal';
      dlg.querySelectorAll('[name="priority"]').forEach((r) => { r.checked = r.value === pr; });
      $('[data-time-label]', dlg).textContent = l.time;
    }
    $('[data-form-submit]', dlg).textContent = editing ? dlg.dataset.saveLabel : dlg.dataset.addLabel;
    setDateLabel(dlg);
    dlg.showModal();
    $('input[name="title"]', dlg).focus();
  }

  // Remember the "add" URLs and labels so forms can switch between add and edit.
  [sessionDlg, taskDlg].forEach((dlg) => {
    const form = $('form', dlg);
    const isEdit = form.querySelector('[name="_method"]').value === 'PUT';
    form.dataset.storeUrl = dlg === sessionDlg ? form.action.replace(/\/sessions\/\d+$/, '/sessions') : form.action.replace(/\/tasks\/\d+$/, '/tasks');
    const submit = $('[data-form-submit]', dlg).textContent;
    dlg.dataset.addLabel = isEdit ? (window.SF_I18N?.add || 'Add') : submit;
    dlg.dataset.saveLabel = isEdit ? submit : (window.SF_I18N?.save || 'Save');
    if (dlg === sessionDlg) {
      dlg.dataset.addTitle = CAL.titles?.addSession || $('[data-form-title]', dlg).textContent;
      dlg.dataset.editTitle = CAL.titles?.editSession || $('[data-form-title]', dlg).textContent;
    }
    if (dlg.hasAttribute('data-autoshow')) { setDateLabel(dlg); dlg.showModal(); }
  });

  /* ---------- Item details ---------- */
  const detail = $('#detail-dialog');
  let current = null;

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-item]');
    if (!el) return;
    current = JSON.parse(el.dataset.item);
    const i = current;
    $('[data-d="dot"]', detail).style.background = i.color;
    const set = (k, v) => {
      const row = $(`[data-row="${k}"]`, detail);
      const val = $(`[data-d="${k}"]`, detail);
      if (val) val.textContent = v || '';
      if (row) row.hidden = !v;
    };
    set('typeLabel', i.typeLabel);
    set('title', i.title);
    set('dateLabel', i.dateLabel);
    set('timeLabel', i.timeLabel ? (i.durationLabel ? `${i.timeLabel} (${i.durationLabel})` : i.timeLabel) : '');
    set('subject', i.subject);
    set('task', i.task);
    set('period', i.period);
    set('location', i.location);
    set('teacher', i.teacher);
    set('status', i.kind === 'class' ? '' : (i.done ? T.done : T.notDone));
    set('priorityLabel', i.priority && i.priority !== 'normal' ? i.priorityLabel : '');
    set('notes', i.notes);
    const linkRow = $('[data-row="linkRow"]', detail);
    const linkEl = $('[data-d-link]', detail);
    if (linkRow && linkEl) {
      linkRow.hidden = !i.link;
      if (i.link) { linkEl.href = i.link; linkEl.textContent = i.link.replace(/^https?:\/\//, '').slice(0, 60); }
    }

    const isClass = i.kind === 'class';
    $('[data-actions]', detail).hidden = isClass;
    $('[data-class-note]', detail).hidden = !isClass;
    if (!isClass) {
      $('[data-toggle-form]', detail).action = i.urls.toggle;
      $('[data-toggle-label]', detail).textContent = i.done ? T.markNotDone : T.markDone;
      const del = $('[data-delete-form]', detail);
      del.action = i.urls.destroy;
      del.dataset.confirm = T.deleteQ.replace(':name', i.title);
      delete del.dataset.confirmed;
    }
    detail.showModal();
  });

  window.SFCal = { openForm };

  $('[data-edit]', detail).addEventListener('click', () => {
    detail.close();
    openForm(current.kind === 'session' ? 'session' : current.type, current);
  });

  /* ---------- Confirm before delete ---------- */
  const confirmDlg = $('#confirm-dialog');
  let pending = null;
  document.addEventListener('submit', (e) => {
    const form = e.target;
    if (!form.matches('form[data-confirm]') || form.dataset.confirmed) return;
    e.preventDefault();
    pending = form;
    $('[data-confirm-title]', confirmDlg).textContent = form.dataset.confirm;
    $('[data-confirm-text]', confirmDlg).textContent = form.dataset.confirmText || '';
    detail.close();
    confirmDlg.showModal();
  });
  $('[data-confirm-ok]', confirmDlg).addEventListener('click', () => {
    if (!pending) return;
    pending.dataset.confirmed = '1';
    $('[data-confirm-ok]', confirmDlg).disabled = true;
    pending.requestSubmit();
  });
})();
