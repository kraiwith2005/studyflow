/* StudyFlow — shared front-end helpers */
(function () {
  'use strict';

  const csrf = () => document.querySelector('meta[name="csrf-token"]')?.content || '';

  /* ---- Save indicator + JSON requests (used by every page) ---- */
  const status = document.getElementById('save-status');
  let statusTimer;
  function setStatus(state) {
    if (!status) return;
    clearTimeout(statusTimer);
    status.dataset.state = state;
    const t = window.SF_I18N || {};
    status.textContent = { saving: t.saving || 'Saving…', saved: t.saved || 'Saved', error: t.notSaved || 'Not saved' }[state];
  }

  async function request(url, { method = 'POST', body } = {}) {
    setStatus('saving');
    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-CSRF-TOKEN': csrf(),
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: body ? JSON.stringify(body) : undefined,
        credentials: 'same-origin',
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw Object.assign(new Error(data.message || 'Request failed'), { status: res.status, data });
      setStatus('saved');
      return data;
    } catch (err) {
      setStatus('error');
      statusTimer = setTimeout(() => setStatus('saved'), 4000);
      throw err;
    }
  }
  window.SF = { request, setStatus };

  /* ---- Password show / hide ---- */
  document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.togglePassword);
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      const t = window.SF_I18N || {};
      btn.setAttribute('aria-label', show ? (t.hidePassword || 'Hide password') : (t.showPassword || 'Show password'));
      btn.setAttribute('aria-pressed', String(show));
    });
  });

  /* ---- Disable submit buttons while a form is sending (prevents double posts) ---- */
  document.querySelectorAll('form[data-once]').forEach((form) => {
    form.addEventListener('submit', () => {
      form.querySelectorAll('button[type="submit"]').forEach((b) => { b.disabled = true; });
    });
  });

  /* ---- Avatar menu ---- */
  const menuBtn = document.getElementById('avatar-btn');
  const menu = document.getElementById('avatar-menu');
  if (menuBtn && menu) {
    const close = () => { menu.classList.remove('is-open'); menuBtn.setAttribute('aria-expanded', 'false'); };
    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = !menu.classList.contains('is-open');
      menu.classList.toggle('is-open', open);
      menuBtn.setAttribute('aria-expanded', String(open));
      if (open) menu.querySelector('a, button')?.focus();
    });
    document.addEventListener('click', (e) => { if (!menu.contains(e.target)) close(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { close(); menuBtn.focus(); } });
  }

  /* ---- Header timer pill (when a study timer runs on another page) ---- */
  const pill = document.querySelector('[data-timer-pill]');
  if (pill && pill.dataset.status === 'running') {
    const offset = Number(pill.dataset.serverNow) - Date.now();
    const accum = Number(pill.dataset.accum), started = Number(pill.dataset.started);
    const out = pill.querySelector('[data-pill-time]');
    const pad = (n) => String(n).padStart(2, '0');
    const tick = () => {
      const s = accum + Math.max(0, Math.floor((Date.now() + offset - started) / 1000));
      out.textContent = `${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}`;
    };
    tick(); setInterval(tick, 1000);
  }

  /* ---- Theme toggle (saved to the account) ---- */
  const themeBtn = document.getElementById('theme-toggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', async () => {
      const root = document.documentElement;
      const current = root.dataset.theme === 'dark' ? 'dark' : 'light'; // light unless chosen
      const next = current === 'dark' ? 'light' : 'dark';
      root.dataset.theme = next;
      const t = window.SF_I18N || {};
      themeBtn.setAttribute('aria-label', next === 'dark' ? (t.toLight || 'Switch to light mode') : (t.toDark || 'Switch to dark mode'));
      try {
        await request(themeBtn.dataset.url, { body: { theme: next } });
      } catch (_) {
        root.dataset.theme = current; // roll back if the server didn't save it
      }
    });
  }
})();
