/* StudyFlow — first-run tour: a spotlight on each part of the app, one step at a time. */
(function () {
  const cfg = window.SF_TOUR;
  if (!cfg || !cfg.steps || !cfg.steps.length) return;

  const csrf = () => document.querySelector('meta[name="csrf-token"]')?.content || '';
  const steps = cfg.steps.filter((s) => !s.target || document.querySelector(s.target));
  const L = cfg.labels;
  let i = 0;
  let lastFocus = document.activeElement;

  const shade = document.createElement('div');
  shade.className = 'tour-shade';
  const spot = document.createElement('div');
  spot.className = 'tour-spot';
  const card = document.createElement('div');
  card.className = 'tour-card';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-modal', 'true');
  card.setAttribute('aria-labelledby', 'tour-title');
  card.innerHTML = `
    <div class="tour-step" data-step></div>
    <h2 class="tour-title" id="tour-title" data-title></h2>
    <p class="tour-text" data-text></p>
    <div class="tour-dots" data-dots aria-hidden="true"></div>
    <div class="tour-actions">
      <button type="button" class="tour-skip" data-skip></button>
      <span class="tour-gap"></span>
      <button type="button" class="btn btn-outline btn-sm" data-back></button>
      <button type="button" class="btn btn-primary btn-sm" data-next></button>
    </div>`;
  document.body.append(shade, spot, card);
  document.documentElement.classList.add('tour-open');

  const $ = (s) => card.querySelector(s);
  $('[data-skip]').textContent = L.skip;
  $('[data-back]').textContent = L.back;
  $('[data-dots]').innerHTML = steps.map(() => '<span></span>').join('');

  function place() {
    const step = steps[i];
    const el = step.target ? document.querySelector(step.target) : null;
    const pad = 6;
    card.classList.toggle('is-center', !el);
    spot.hidden = !el;
    shade.classList.toggle('is-solid', !el);

    if (!el) {
      card.style.left = ''; card.style.top = '';
      return;
    }
    el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    const r = el.getBoundingClientRect();
    spot.style.left = `${r.left - pad}px`;
    spot.style.top = `${r.top - pad}px`;
    spot.style.width = `${r.width + pad * 2}px`;
    spot.style.height = `${r.height + pad * 2}px`;

    const cw = card.offsetWidth, ch = card.offsetHeight;
    const vw = window.innerWidth, vh = window.innerHeight;
    let top = r.bottom + 16;
    if (top + ch > vh - 12) top = Math.max(12, r.top - ch - 16);
    let left = r.left + r.width / 2 - cw / 2;
    left = Math.min(Math.max(12, left), vw - cw - 12);
    card.style.left = `${left}px`;
    card.style.top = `${top}px`;
  }

  function render() {
    const step = steps[i];
    $('[data-step]').textContent = L.step.replace(':n', i + 1).replace(':total', steps.length);
    $('[data-title]').textContent = step.title;
    $('[data-text]').textContent = step.text;
    $('[data-back]').hidden = i === 0;
    $('[data-next]').textContent = i === steps.length - 1 ? L.finish : L.next;
    card.querySelectorAll('[data-dots] span').forEach((d, k) => d.classList.toggle('is-on', k === i));
    place();
    $('[data-next]').focus();
  }

  function finish() {
    fetch(cfg.doneUrl, { method: 'POST', headers: { 'X-CSRF-TOKEN': csrf(), Accept: 'application/json' } }).catch(() => {});
    shade.remove(); spot.remove(); card.remove();
    document.removeEventListener('keydown', onKey);
    window.removeEventListener('resize', place);
    document.documentElement.classList.remove('tour-open');
    // Drop ?tour=1 so a reload doesn't start it again.
    if (new URLSearchParams(location.search).has('tour')) history.replaceState(null, '', location.pathname);
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); finish(); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); next(); }
    else if (e.key === 'ArrowLeft' && i > 0) { e.preventDefault(); i--; render(); }
    else if (e.key === 'Tab') {
      // keep keyboard focus inside the tour card
      const f = [...card.querySelectorAll('button:not([hidden])')];
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }

  function next() {
    if (i < steps.length - 1) { i++; render(); } else { finish(); }
  }

  $('[data-next]').addEventListener('click', next);
  $('[data-back]').addEventListener('click', () => { if (i > 0) { i--; render(); } });
  $('[data-skip]').addEventListener('click', finish);
  shade.addEventListener('click', () => {}); // clicks on the dimmed page do nothing
  document.addEventListener('keydown', onKey);
  window.addEventListener('resize', place);
  render();
})();
