<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    public const PRESETS = [
        '#3b5fe0', '#cb3a31', '#4a9e52', '#7a3fe0', '#dc6428', '#48a0e0',
        '#c93b78', '#c48d31', '#3f9470', '#5045dd', '#ecaed5', '#f4f4f1',
    ];

    protected $fillable = ['user_id', 'name', 'color', 'sort_order'];

    public function slots() { return $this->hasMany(TimetableSlot::class); }
}
