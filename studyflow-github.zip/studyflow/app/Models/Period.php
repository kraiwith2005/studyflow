<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Period extends Model
{
    public const DEFAULTS = [
        ['Period 1', 'class', '08:40', '09:35'],
        ['Period 2', 'class', '09:35', '10:30'],
        ['Recess', 'break', '10:30', '10:50'],
        ['Period 3', 'class', '10:50', '11:45'],
        ['Period 4', 'class', '11:45', '12:40'],
        ['Lunch', 'break', '12:40', '13:20'],
        ['Period 5', 'class', '13:20', '14:15'],
        ['Period 6', 'class', '14:15', '15:10'],
    ];

    /** Default periods with names in the current language. */
    public static function localizedDefaults(): array
    {
        $n = 0;

        return array_map(function ($row) use (&$n) {
            [$name, $kind, $start, $end] = $row;
            $label = match ($name) {
                'Recess' => __('Recess'),
                'Lunch' => __('Lunch'),
                default => __('Period :n', ['n' => ++$n]),
            };

            return [$label, $kind, $start, $end];
        }, self::DEFAULTS);
    }

    protected $fillable = ['user_id', 'name', 'kind', 'start_time', 'end_time', 'sort_order'];

    public function isBreak(): bool { return $this->kind === 'break'; }

    public function getTimeRangeAttribute(): string
    {
        return fmt_time($this->start_time).' – '.fmt_time($this->end_time);
    }

    public function slots() { return $this->hasMany(TimetableSlot::class); }
}
