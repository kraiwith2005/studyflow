<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Term extends Model
{
    protected $fillable = ['user_id', 'name', 'start_date', 'end_date'];

    protected function casts(): array
    {
        return ['start_date' => 'date', 'end_date' => 'date'];
    }

    public function getLengthLabelAttribute(): string
    {
        $days = (int) $this->start_date->diffInDays($this->end_date) + 1;

        return $days >= 14 ? trans_choice(':count week|:count weeks', (int) ceil($days / 7)) : trans_choice(':count day|:count days', $days);
    }

    public function isCurrent(): bool
    {
        return now()->startOfDay()->betweenIncluded($this->start_date, $this->end_date);
    }
}
