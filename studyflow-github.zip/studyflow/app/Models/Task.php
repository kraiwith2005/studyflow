<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    public const TYPES = ['homework', 'assignment', 'exam', 'personal'];
    public const PERSONAL_COLOR = '#6b7a99';

    protected $fillable = ['user_id', 'subject_id', 'type', 'title', 'due_date', 'notes', 'completed_at'];

    protected function casts(): array
    {
        return ['due_date' => 'date', 'completed_at' => 'datetime'];
    }

    public function subject() { return $this->belongsTo(Subject::class); }
    public function studySessions() { return $this->hasMany(StudySession::class); }

    public function isDone(): bool { return $this->completed_at !== null; }
    public function needsSubject(): bool { return $this->type !== 'personal'; }

    public function getColorAttribute(): string
    {
        return $this->subject?->color ?? self::PERSONAL_COLOR;
    }

    public static function typeLabel(string $type): string
    {
        return [
            'homework' => __('Homework'),
            'assignment' => __('Assignment'),
            'exam' => __('Exam'),
            'personal' => __('Personal task'),
        ][$type];
    }
}
