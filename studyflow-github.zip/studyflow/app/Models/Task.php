<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    public const TYPES = ['assignment', 'exam', 'personal'];
    public const PERSONAL_COLOR = '#6b7a99';

    protected $fillable = ['user_id', 'subject_id', 'type', 'title', 'due_date', 'due_time', 'notes', 'link', 'priority', 'completed_at'];

    public const PRIORITIES = ['high', 'normal', 'low'];

    public static function priorityLabel(string $p): string
    {
        return match ($p) {
            'high' => __('High priority'),
            'low' => __('Low priority'),
            default => __('Normal priority'),
        };
    }

    /** due_time as H:i, or null when the task has no time set. */
    public function dueTime(): ?string
    {
        return $this->due_time ? substr($this->due_time, 0, 5) : null;
    }

    protected function casts(): array
    {
        return ['due_date' => 'date', 'completed_at' => 'datetime'];
    }

    public function subject() { return $this->belongsTo(Subject::class); }
    public function studySessions() { return $this->hasMany(StudySession::class); }

    public function isDone(): bool { return $this->completed_at !== null; }
    public function needsSubject(): bool { return $this->type !== 'personal'; }

    public function getColorAttribute(): string
    {
        return $this->subject?->color ?? self::PERSONAL_COLOR;
    }

    public static function typeLabel(string $type): string
    {
        return [
            'assignment' => __('Assignment'),
            'exam' => __('Exam'),
            'personal' => __('Personal task'),
        ][$type];
    }
}
