<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PlannerSetting extends Model
{
    protected $primaryKey = 'user_id';
    public $incrementing = false;
    protected $fillable = ['user_id', 'timetable_type', 'repeat_cycle', 'cycle_anchor', 'periods_initialized'];
    protected $attributes = ['timetable_type' => 'school', 'repeat_cycle' => 'weekly', 'periods_initialized' => false];

    protected function casts(): array
    {
        return ['cycle_anchor' => 'date', 'periods_initialized' => 'boolean'];
    }

    public function usesGrid(): bool
    {
        return $this->timetable_type !== 'university';
    }

    /** Days shown in the grid: Mon–Fri for school, Mon–Sun for custom. */
    public function gridDays(): array
    {
        return $this->timetable_type === 'custom' ? [1, 2, 3, 4, 5, 6, 7] : [1, 2, 3, 4, 5];
    }

    public function weeks(): array
    {
        return $this->repeat_cycle === 'ab' ? ['A', 'B'] : ['A'];
    }
}
