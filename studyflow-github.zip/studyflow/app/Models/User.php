<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

#[Fillable(['first_name', 'last_name', 'email', 'password', 'google_id', 'theme'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function getFullNameAttribute(): string
    {
        return trim($this->first_name.' '.$this->last_name);
    }

    public function getInitialAttribute(): string
    {
        return mb_strtoupper(mb_substr($this->first_name ?: $this->email, 0, 1));
    }

    /** A stable avatar colour derived from the email. */
    public function getAvatarColorAttribute(): string
    {
        $palette = ['#9b4dca', '#3f7cc4', '#c2477a', '#2f8a6b', '#c27a2c', '#5b5bd6', '#b5483b'];

        return $palette[crc32(strtolower($this->email)) % count($palette)];
    }

    public function plannerSetting() { return $this->hasOne(PlannerSetting::class); }
    public function subjects() { return $this->hasMany(Subject::class)->orderBy('sort_order')->orderBy('name'); }
    public function terms() { return $this->hasMany(Term::class)->orderBy('start_date'); }
    public function periods() { return $this->hasMany(Period::class)->orderBy('start_time'); }
    public function timetableSlots() { return $this->hasMany(TimetableSlot::class); }
    public function tasks() { return $this->hasMany(Task::class); }
    public function studySessions() { return $this->hasMany(StudySession::class); }
    public function studyTimer() { return $this->hasOne(StudyTimer::class); }
    public function recurringClasses() { return $this->hasMany(RecurringClass::class)->orderBy('day')->orderBy('start_time'); }

    /** Settings row, created with defaults (and default periods) on first use. */
    public function planner(): PlannerSetting
    {
        $setting = $this->plannerSetting()->firstOrCreate(['user_id' => $this->id]);
        if (! $setting->periods_initialized) {
            foreach (Period::localizedDefaults() as $i => [$name, $kind, $start, $end]) {
                $this->periods()->create(['name' => $name, 'kind' => $kind, 'start_time' => $start, 'end_time' => $end, 'sort_order' => $i]);
            }
            $setting->update(['periods_initialized' => true]);
        }

        return $setting->refresh();
    }

    /** Setup progress used by the banner on Calendar, Tasks and Study. */
    public function setupProgress(): array
    {
        $steps = [
            'subjects' => $this->subjects()->exists(),
            'terms' => $this->terms()->exists(),
            'timetable' => $this->timetableSlots()->exists() || $this->recurringClasses()->exists(),
        ];

        return ['steps' => $steps, 'done' => count(array_filter($steps)), 'total' => count($steps)];
    }

    public function hasPassword(): bool
    {
        return ! empty($this->password);
    }
}
