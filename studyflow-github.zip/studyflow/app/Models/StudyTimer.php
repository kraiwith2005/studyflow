<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudyTimer extends Model
{
    protected $primaryKey = 'user_id';
    public $incrementing = false;
    protected $fillable = ['user_id', 'subject_id', 'task_id', 'study_session_id', 'label', 'status', 'first_started_at', 'started_at', 'accumulated_seconds'];

    protected function casts(): array
    {
        return ['first_started_at' => 'datetime', 'started_at' => 'datetime'];
    }

    public function subject() { return $this->belongsTo(Subject::class); }
    public function task() { return $this->belongsTo(Task::class); }

    public function elapsedSeconds(): int
    {
        $running = $this->status === 'running' && $this->started_at ? (int) $this->started_at->diffInSeconds(now()) : 0;

        return $this->accumulated_seconds + max(0, $running);
    }

    /** What the browser needs to show and tick the timer. */
    public function toClient(): array
    {
        return [
            'status' => $this->status,
            'label' => $this->label,
            'accumulated' => $this->accumulated_seconds,
            'startedAt' => $this->started_at?->getTimestampMs(),
            'elapsed' => $this->elapsedSeconds(),
        ];
    }
}
