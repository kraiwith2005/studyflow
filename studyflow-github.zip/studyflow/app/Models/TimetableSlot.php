<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TimetableSlot extends Model
{
    protected $fillable = ['user_id', 'period_id', 'day', 'week', 'subject_id'];

    public function period() { return $this->belongsTo(Period::class); }
    public function subject() { return $this->belongsTo(Subject::class); }
}
