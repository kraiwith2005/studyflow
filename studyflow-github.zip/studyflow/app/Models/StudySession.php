<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class StudySession extends Model
{
    public const DURATIONS = [15, 20, 30, 45, 60, 75, 90, 105, 120, 150, 180];

    protected $fillable = ['user_id', 'subject_id', 'task_id', 'title', 'date', 'start_time', 'duration_minutes', 'status', 'actual_minutes'];

    protected function casts(): array
    {
        return ['date' => 'date'];
    }

    public function subject() { return $this->belongsTo(Subject::class); }
    public function task() { return $this->belongsTo(Task::class); }

    public function isDone(): bool { return $this->status === 'completed'; }

    public function getEndTimeAttribute(): string
    {
        return Carbon::createFromFormat('H:i:s', strlen($this->start_time) === 5 ? $this->start_time.':00' : $this->start_time)
            ->addMinutes($this->duration_minutes)->format('H:i:s');
    }

    public function getColorAttribute(): string
    {
        return $this->subject?->color ?? '#4E7894';
    }

    public static function durationLabel(int $minutes): string
    {
        if ($minutes <= 60) return __(':m min', ['m' => $minutes]);
        $h = intdiv($minutes, 60); $m = $minutes % 60;

        return $m ? __(':hh :mm', ['h' => $h, 'm' => $m]) : __(':hh', ['h' => $h]);
    }
}
