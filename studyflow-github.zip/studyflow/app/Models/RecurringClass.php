<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RecurringClass extends Model
{
    public const DAYS = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];

    protected $fillable = ['user_id', 'subject_id', 'name', 'day', 'start_time', 'end_time', 'week', 'location', 'teacher'];

    public function subject() { return $this->belongsTo(Subject::class); }

    public function getDisplayNameAttribute(): string
    {
        return $this->name ?: ($this->subject?->name ?? __('Untitled class'));
    }

    public function getColorAttribute(): string
    {
        return $this->subject?->color ?? '#8a948c';
    }
}
