<?php

namespace App\Services;

use App\Models\Period;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

/**
 * Export, import and clear everything a user has planned.
 * Later stages (tasks, study sessions) add their tables here.
 */
class PlannerData
{
    public const VERSION = 2; // v2 adds tasks and study sessions (v1 files still import)

    public function export(User $user): array
    {
        $planner = $user->planner();
        $subjects = $user->subjects()->get();
        $periods = $user->periods()->get();
        $subjectRef = $subjects->pluck('id')->flip();   // db id => index
        $tasks = $user->tasks()->orderBy('id')->get();
        $taskRef = $tasks->pluck('id')->flip();
        $periodRef = $periods->pluck('id')->flip();

        return [
            'app' => 'StudyFlow',
            'version' => self::VERSION,
            'exported_at' => now()->toIso8601String(),
            'settings' => [
                'timetable_type' => $planner->timetable_type,
                'repeat_cycle' => $planner->repeat_cycle,
                'cycle_anchor' => $planner->cycle_anchor?->toDateString(),
            ],
            'subjects' => $subjects->map(fn ($s) => ['name' => $s->name, 'color' => $s->color])->values(),
            'terms' => $user->terms()->get()->map(fn ($t) => [
                'name' => $t->name, 'start_date' => $t->start_date->toDateString(), 'end_date' => $t->end_date->toDateString(),
            ])->values(),
            'periods' => $periods->map(fn ($p) => [
                'name' => $p->name, 'kind' => $p->kind, 'start_time' => substr($p->start_time, 0, 5), 'end_time' => substr($p->end_time, 0, 5),
            ])->values(),
            'timetable_slots' => $user->timetableSlots()->get()->map(fn ($s) => [
                'period' => $periodRef[$s->period_id], 'day' => $s->day, 'week' => $s->week, 'subject' => $subjectRef[$s->subject_id],
            ])->values(),
            'recurring_classes' => $user->recurringClasses()->get()->map(fn ($c) => [
                'subject' => $c->subject_id !== null ? $subjectRef[$c->subject_id] : null,
                'name' => $c->name, 'day' => $c->day, 'start_time' => substr($c->start_time, 0, 5), 'end_time' => substr($c->end_time, 0, 5),
                'week' => $c->week, 'location' => $c->location, 'teacher' => $c->teacher,
            ])->values(),
            'tasks' => $tasks->map(fn ($t) => [
                'subject' => $t->subject_id !== null ? $subjectRef[$t->subject_id] : null,
                'type' => $t->type, 'title' => $t->title, 'due_date' => $t->due_date->toDateString(),
                'notes' => $t->notes, 'completed_at' => $t->completed_at?->toIso8601String(),
            ])->values(),
            'study_sessions' => $user->studySessions()->orderBy('id')->get()->map(fn ($s) => [
                'subject' => $s->subject_id !== null ? $subjectRef[$s->subject_id] : null,
                'task' => $s->task_id !== null ? ($taskRef[$s->task_id] ?? null) : null,
                'title' => $s->title, 'date' => $s->date->toDateString(), 'start_time' => substr($s->start_time, 0, 5),
                'duration_minutes' => $s->duration_minutes, 'status' => $s->status, 'actual_minutes' => $s->actual_minutes,
            ])->values(),
        ];
    }

    public function clear(User $user): void
    {
        DB::transaction(function () use ($user) {
            $user->studyTimer()->delete();
            $user->studySessions()->delete();
            $user->tasks()->delete();
            $user->recurringClasses()->delete();
            $user->timetableSlots()->delete();
            $user->periods()->delete();
            $user->terms()->delete();
            $user->subjects()->delete();
            $user->plannerSetting()->delete();
        });
    }

    /** Replace all planner data with the contents of a backup. Throws InvalidArgumentException on a bad file. */
    public function import(User $user, array $data): void
    {
        $this->assertValid($data);

        DB::transaction(function () use ($user, $data) {
            $this->clear($user);

            $s = $data['settings'] ?? [];
            $user->plannerSetting()->create([
                'timetable_type' => in_array($s['timetable_type'] ?? '', ['school', 'university', 'custom']) ? $s['timetable_type'] : 'school',
                'repeat_cycle' => ($s['repeat_cycle'] ?? '') === 'ab' ? 'ab' : 'weekly',
                'cycle_anchor' => $this->date($s['cycle_anchor'] ?? null),
                'periods_initialized' => true,
            ]);

            $subjectIds = [];
            foreach ($data['subjects'] as $i => $sub) {
                $subjectIds[$i] = $user->subjects()->create([
                    'name' => mb_substr(trim($sub['name']), 0, 80),
                    'color' => preg_match('/^#[0-9a-f]{6}$/i', $sub['color'] ?? '') ? strtolower($sub['color']) : '#8a948c',
                    'sort_order' => $i,
                ])->id;
            }
            foreach ($data['terms'] as $t) {
                $user->terms()->create(['name' => mb_substr($t['name'], 0, 60), 'start_date' => $t['start_date'], 'end_date' => $t['end_date']]);
            }
            $periodIds = [];
            $periods = $data['periods'] ?: array_map(fn ($p) => array_combine(['name', 'kind', 'start_time', 'end_time'], $p), Period::localizedDefaults());
            foreach ($periods as $i => $p) {
                $periodIds[$i] = $user->periods()->create([
                    'name' => mb_substr($p['name'], 0, 40), 'kind' => $p['kind'] === 'break' ? 'break' : 'class',
                    'start_time' => $p['start_time'], 'end_time' => $p['end_time'], 'sort_order' => $i,
                ])->id;
            }
            foreach ($data['timetable_slots'] as $slot) {
                if (! isset($periodIds[$slot['period']], $subjectIds[$slot['subject']])) continue;
                $user->timetableSlots()->updateOrCreate(
                    ['period_id' => $periodIds[$slot['period']], 'day' => (int) $slot['day'], 'week' => $slot['week'] === 'B' ? 'B' : 'A'],
                    ['subject_id' => $subjectIds[$slot['subject']]]
                );
            }
            foreach ($data['recurring_classes'] as $c) {
                $user->recurringClasses()->create([
                    'subject_id' => $c['subject'] !== null ? ($subjectIds[$c['subject']] ?? null) : null,
                    'name' => isset($c['name']) ? mb_substr($c['name'], 0, 80) : null,
                    'day' => (int) $c['day'], 'start_time' => $c['start_time'], 'end_time' => $c['end_time'],
                    'week' => in_array($c['week'] ?? '', ['every', 'A', 'B']) ? $c['week'] : 'every',
                    'location' => isset($c['location']) ? mb_substr($c['location'], 0, 120) : null,
                    'teacher' => isset($c['teacher']) ? mb_substr($c['teacher'], 0, 80) : null,
                ]);
            }
            $taskIds = [];
            foreach ($data['tasks'] ?? [] as $i => $t) {
                $subject = $t['subject'] !== null ? ($subjectIds[$t['subject']] ?? null) : null;
                $type = in_array($t['type'] ?? '', \App\Models\Task::TYPES, true) ? $t['type'] : 'homework';
                if ($type !== 'personal' && ! $subject) continue; // its subject is missing
                $taskIds[$i] = $user->tasks()->create([
                    'subject_id' => $type === 'personal' ? null : $subject, 'type' => $type,
                    'title' => mb_substr($t['title'], 0, 120), 'due_date' => $t['due_date'],
                    'notes' => isset($t['notes']) ? mb_substr($t['notes'], 0, 2000) : null,
                    'completed_at' => ! empty($t['completed_at']) ? \Carbon\Carbon::parse($t['completed_at']) : null,
                ])->id;
            }
            foreach ($data['study_sessions'] ?? [] as $s) {
                $duration = (int) $s['duration_minutes'];
                $user->studySessions()->create([
                    'subject_id' => $s['subject'] !== null ? ($subjectIds[$s['subject']] ?? null) : null,
                    'task_id' => $s['task'] !== null ? ($taskIds[$s['task']] ?? null) : null,
                    'title' => mb_substr($s['title'], 0, 120), 'date' => $s['date'], 'start_time' => $s['start_time'],
                    'duration_minutes' => $duration,
                    'status' => ($s['status'] ?? '') === 'completed' ? 'completed' : 'planned',
                    'actual_minutes' => isset($s['actual_minutes']) ? (int) $s['actual_minutes'] : null,
                ]);
            }
        });
    }

    private function assertValid(array $data): void
    {
        if (($data['app'] ?? null) !== 'StudyFlow' || ! is_int($data['version'] ?? null)) {
            throw new InvalidArgumentException('This file is not a StudyFlow backup.');
        }
        if ($data['version'] > self::VERSION) {
            throw new InvalidArgumentException('This backup was made by a newer version of StudyFlow.');
        }
        foreach (['subjects', 'terms', 'periods', 'timetable_slots', 'recurring_classes'] as $key) {
            if (! is_array($data[$key] ?? null)) throw new InvalidArgumentException('The backup is incomplete or damaged.');
        }
        $time = '/^([01]\d|2[0-3]):[0-5]\d$/';
        foreach ($data['subjects'] as $s) {
            if (! is_string($s['name'] ?? null) || trim($s['name']) === '') throw new InvalidArgumentException('A subject in the backup has no name.');
        }
        foreach ($data['terms'] as $t) {
            if (! is_string($t['name'] ?? null) || ! $this->date($t['start_date'] ?? null) || ! $this->date($t['end_date'] ?? null) || $t['end_date'] < $t['start_date']) {
                throw new InvalidArgumentException('A term in the backup has invalid dates.');
            }
        }
        foreach (array_merge($data['periods'], $data['recurring_classes']) as $p) {
            if (! preg_match($time, $p['start_time'] ?? '') || ! preg_match($time, $p['end_time'] ?? '') || $p['end_time'] <= $p['start_time']) {
                throw new InvalidArgumentException('A period or class in the backup has invalid times.');
            }
        }
        foreach ($data['periods'] as $p) {
            if (! is_string($p['name'] ?? null)) throw new InvalidArgumentException('A period in the backup has no name.');
        }
        foreach (['tasks', 'study_sessions'] as $key) {
            if (isset($data[$key]) && ! is_array($data[$key])) throw new InvalidArgumentException('The backup is incomplete or damaged.');
        }
        foreach ($data['tasks'] ?? [] as $t) {
            if (! is_string($t['title'] ?? null) || ! $this->date($t['due_date'] ?? null)) {
                throw new InvalidArgumentException('A task in the backup is missing its title or date.');
            }
        }
        foreach ($data['study_sessions'] ?? [] as $s) {
            if (! is_string($s['title'] ?? null) || ! $this->date($s['date'] ?? null) || ! preg_match($time, $s['start_time'] ?? '')
                || ! in_array((int) ($s['duration_minutes'] ?? 0), \App\Models\StudySession::DURATIONS, true)) {
                throw new InvalidArgumentException('A study session in the backup is invalid.');
            }
        }
        foreach (array_merge($data['timetable_slots'], $data['recurring_classes']) as $c) {
            if (! is_int($c['day'] ?? null) || $c['day'] < 1 || $c['day'] > 7) throw new InvalidArgumentException('A class in the backup has an invalid day.');
        }
    }

    private function date($value): ?string
    {
        return is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) && strtotime($value) ? $value : null;
    }
}
