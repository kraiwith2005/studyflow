<?php

namespace App\Services;

use App\Models\Task;
use App\Models\User;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Collection;

/**
 * Builds the items shown on the calendar for a date range:
 * tasks (all-day), study sessions (timed) and, when requested, timetable classes (timed).
 */
class CalendarBuilder
{
    public function __construct(private User $user) {}

    /** @return array<string, array{allDay: array, timed: array}> keyed by Y-m-d */
    public function build(Carbon $start, Carbon $end, bool $withClasses): array
    {
        $days = [];
        foreach (CarbonPeriod::create($start, $end) as $d) {
            $days[$d->toDateString()] = ['allDay' => [], 'timed' => []];
        }

        $tasks = $this->user->tasks()->with('subject')
            ->whereBetween('due_date', [$start->toDateString(), $end->toDateString()])
            ->orderByRaw("FIELD(type, 'exam', 'assignment', 'homework', 'personal')")->orderBy('title')->get();
        foreach ($tasks as $t) {
            $days[$t->due_date->toDateString()]['allDay'][] = \App\Support\ItemPayload::task($t);
        }

        $sessions = $this->user->studySessions()->with(['subject', 'task'])
            ->whereBetween('date', [$start->toDateString(), $end->toDateString()])->orderBy('start_time')->get();
        foreach ($sessions as $s) {
            $days[$s->date->toDateString()]['timed'][] = [
                'kind' => 'session', 'id' => $s->id, 'title' => $s->title,
                'subject' => $s->subject?->name, 'subject_id' => $s->subject_id,
                'color' => $s->color, 'start' => substr($s->start_time, 0, 5), 'end' => substr($s->end_time, 0, 5),
                'duration' => $s->duration_minutes, 'done' => $s->isDone(),
                'task_id' => $s->task_id, 'task' => $s->task?->title,
                'date' => $s->date->toDateString(),
            ];
        }

        if ($withClasses) {
            foreach ($this->classes($start, $end) as $date => $items) {
                array_push($days[$date]['timed'], ...$items);
            }
        }

        foreach ($days as &$day) {
            usort($day['timed'], fn ($a, $b) => [$a['start'], $a['end']] <=> [$b['start'], $b['end']]);
            $day['timed'] = $this->layout($day['timed']);
        }

        return $days;
    }

    /** Timetable classes for each date, respecting term dates, Week A/B and timetable type. */
    private function classes(Carbon $start, Carbon $end): array
    {
        $planner = $this->user->planner();
        $terms = $this->user->terms()->get();
        $slots = $planner->usesGrid()
            ? $this->user->timetableSlots()->with(['period', 'subject'])->get()->groupBy(fn ($s) => $s->day.'-'.$s->week)
            : collect();
        $recurring = $this->user->recurringClasses()->with('subject')->get()->groupBy('day');
        $out = [];

        foreach (CarbonPeriod::create($start, $end) as $d) {
            // Outside every term = holidays: no classes. With no terms set, classes run all year.
            if ($terms->isNotEmpty() && ! $terms->contains(fn ($t) => $d->betweenIncluded($t->start_date, $t->end_date))) {
                continue;
            }
            $iso = $d->dayOfWeekIso;
            $week = $this->weekLetter($planner, $d);
            $items = [];

            if (in_array($iso, $planner->gridDays(), true)) {
                foreach ($slots->get($iso.'-'.$week, collect()) as $slot) {
                    $items[] = $this->classItem($slot->subject->name, $slot->subject->color,
                        $slot->period->start_time, $slot->period->end_time, $slot->period->name, null, null, $d);
                }
            }
            foreach ($recurring->get($iso, collect()) as $c) {
                if ($c->week !== 'every' && $planner->repeat_cycle === 'ab' && $c->week !== $week) continue;
                $items[] = $this->classItem($c->display_name, $c->color, $c->start_time, $c->end_time, null, $c->location, $c->teacher, $d);
            }
            if ($items) $out[$d->toDateString()] = $items;
        }

        return $out;
    }

    private function classItem(string $title, string $color, string $start, string $end, ?string $period, ?string $location, ?string $teacher, Carbon $d): array
    {
        return [
            'kind' => 'class', 'title' => $title, 'color' => $color, 'start' => substr($start, 0, 5), 'end' => substr($end, 0, 5),
            'period' => $period, 'location' => $location, 'teacher' => $teacher, 'date' => $d->toDateString(), 'done' => false,
        ];
    }

    public function weekLetter($planner, Carbon $date): string
    {
        if ($planner->repeat_cycle !== 'ab' || ! $planner->cycle_anchor) return 'A';
        $weeks = intdiv((int) $planner->cycle_anchor->copy()->startOfWeek(Carbon::MONDAY)
            ->diffInDays($date->copy()->startOfWeek(Carbon::MONDAY), false), 7);

        return $weeks % 2 === 0 ? 'A' : 'B';
    }

    /** Side-by-side columns for overlapping timed items. Adds 'lane' and 'lanes'. */
    private function layout(array $items): array
    {
        $min = fn ($t) => (int) substr($t, 0, 2) * 60 + (int) substr($t, 3, 2);
        $clusters = []; $current = []; $clusterEnd = -1;
        foreach ($items as $item) {
            $s = $min($item['start']);
            if ($current && $s >= $clusterEnd) { $clusters[] = $current; $current = []; $clusterEnd = -1; }
            $current[] = $item;
            $clusterEnd = max($clusterEnd, $min($item['end']));
        }
        if ($current) $clusters[] = $current;

        $out = [];
        foreach ($clusters as $cluster) {
            $laneEnds = [];
            foreach ($cluster as &$item) {
                $s = $min($item['start']);
                $lane = 0;
                while (isset($laneEnds[$lane]) && $laneEnds[$lane] > $s) $lane++;
                $laneEnds[$lane] = $min($item['end']);
                $item['lane'] = $lane;
            }
            unset($item);
            foreach ($cluster as $item) { $item['lanes'] = count($laneEnds); $out[] = $item; }
        }

        return $out;
    }
}
