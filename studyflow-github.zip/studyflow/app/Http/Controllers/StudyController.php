<?php

namespace App\Http\Controllers;

use App\Models\StudySession;
use App\Models\Task;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class StudyController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $tab = $request->query('tab') === 'log' ? 'log' : 'focus';
        $weekStart = now()->startOfWeek(Carbon::SUNDAY);
        $week = $user->studySessions()->where('status', 'completed')
            ->whereBetween('date', [$weekStart->toDateString(), $weekStart->copy()->addDays(6)->toDateString()]);

        $subjects = $user->subjects()->get();
        $subjectFilter = $subjects->firstWhere('id', (int) $request->query('subject'));
        $sessions = $user->studySessions()->with(['subject', 'task'])
            ->when($subjectFilter, fn ($q) => $q->where('subject_id', $subjectFilter->id));

        $completed = (clone $sessions)->where('status', 'completed')->orderByDesc('date')->orderByDesc('start_time')->get();
        $planned = (clone $sessions)->where('status', 'planned')->orderBy('date')->orderBy('start_time')->get();
        $todayPlanned = $user->studySessions()->with('subject')->where('status', 'planned')
            ->whereDate('date', now()->toDateString())->orderBy('start_time')->get();

        $active = $user->tasks()->with('subject')->whereNull('completed_at')->where('type', '!=', 'personal')
            ->withCount(['studySessions as planned_sessions' => fn ($q) => $q->where('status', 'planned')])
            ->withSum(['studySessions as done_minutes' => fn ($q) => $q->where('status', 'completed')], 'actual_minutes')
            ->orderBy('due_date')->get();

        return view('study.index', [
            'tab' => $tab,
            'weekCount' => (clone $week)->count(),
            'weekMinutes' => (int) (clone $week)->sum('actual_minutes'),
            'timer' => $user->studyTimer,
            'todayPlanned' => $todayPlanned,
            'assessments' => $active->whereIn('type', ['assignment', 'exam'])->values(),
            'homework' => $active->where('type', 'homework')->values(),
            'subjects' => $subjects,
            'subjectFilter' => $subjectFilter,
            'completed' => $completed,
            'completedMinutes' => (int) $completed->sum('actual_minutes'),
            'planned' => $planned,
            'linkable' => $active,
            'durations' => StudySession::DURATIONS,
            'returnUrl' => $request->getRequestUri(),
        ]);
    }

    /* ---------- Timer (JSON) ---------- */

    public function start(Request $request)
    {
        $user = $request->user();
        if ($user->studyTimer) {
            return response()->json(['message' => __('A timer is already running. Stop it first.')], 409);
        }
        $data = $request->validate(['target' => ['required', 'string', 'regex:/^(session|task|subject):\d+$/']]);
        [$kind, $id] = explode(':', $data['target']);
        $id = (int) $id;

        $fields = match ($kind) {
            'session' => (function () use ($user, $id) {
                $s = $user->studySessions()->where('status', 'planned')->findOrFail($id);
                return ['study_session_id' => $s->id, 'subject_id' => $s->subject_id, 'task_id' => $s->task_id, 'label' => $s->title];
            })(),
            'task' => (function () use ($user, $id) {
                $t = $user->tasks()->where('type', '!=', 'personal')->whereNull('completed_at')->findOrFail($id);
                return ['task_id' => $t->id, 'subject_id' => $t->subject_id, 'label' => __('Study for :title', ['title' => $t->title])];
            })(),
            'subject' => (function () use ($user, $id) {
                $s = $user->subjects()->findOrFail($id);
                return ['subject_id' => $s->id, 'label' => $s->name];
            })(),
        };

        $timer = $user->studyTimer()->create($fields + [
            'status' => 'running', 'first_started_at' => now(), 'started_at' => now(), 'accumulated_seconds' => 0,
        ]);

        return response()->json(['timer' => $timer->toClient()]);
    }

    public function pause(Request $request)
    {
        $timer = $request->user()->studyTimer()->firstOrFail();
        if ($timer->status === 'running') {
            $timer->update(['status' => 'paused', 'accumulated_seconds' => $timer->elapsedSeconds(), 'started_at' => null]);
        }

        return response()->json(['timer' => $timer->fresh()->toClient()]);
    }

    public function resume(Request $request)
    {
        $timer = $request->user()->studyTimer()->firstOrFail();
        if ($timer->status === 'paused') {
            $timer->update(['status' => 'running', 'started_at' => now()]);
        }

        return response()->json(['timer' => $timer->fresh()->toClient()]);
    }

    /** Stop and record the time as a completed study session. */
    public function stop(Request $request)
    {
        $user = $request->user();
        $timer = $user->studyTimer()->firstOrFail();
        $seconds = $timer->elapsedSeconds();
        $minutes = (int) round($seconds / 60);

        if ($minutes < 1) {
            $timer->delete();
            return response()->json(['saved' => false, 'message' => __('Less than a minute was recorded, so nothing was saved.')]);
        }

        $minutes = min($minutes, 600);
        $start = $timer->first_started_at->copy();
        $startMin = $start->hour * 60 + $start->minute;
        if ($startMin + $minutes > 24 * 60) { // crossed midnight: keep it within the day it started
            $startMin = 24 * 60 - $minutes;
        }
        $startTime = sprintf('%02d:%02d', intdiv($startMin, 60), $startMin % 60);

        $planned = $timer->study_session_id ? $user->studySessions()->find($timer->study_session_id) : null;
        if ($planned) {
            $planned->update(['status' => 'completed', 'actual_minutes' => $minutes]);
            $session = $planned;
        } else {
            $session = $user->studySessions()->create([
                'subject_id' => $timer->subject_id, 'task_id' => $timer->task_id, 'title' => $timer->label,
                'date' => $start->toDateString(), 'start_time' => $startTime, 'duration_minutes' => $minutes,
                'status' => 'completed', 'actual_minutes' => $minutes,
            ]);
        }
        $timer->delete();

        $message = __('Saved :time of study.', ['time' => StudySession::durationLabel($minutes)]);
        session()->flash('status', $message);

        return response()->json(['saved' => true, 'minutes' => $minutes, 'session_id' => $session->id, 'message' => $message]);
    }

    public function discard(Request $request)
    {
        $request->user()->studyTimer()->delete();

        return response()->json(['discarded' => true]);
    }
}
