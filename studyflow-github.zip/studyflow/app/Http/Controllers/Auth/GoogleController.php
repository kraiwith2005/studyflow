<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use Throwable;

class GoogleController extends Controller
{
    public static function enabled(): bool
    {
        return filled(config('services.google.client_id')) && filled(config('services.google.client_secret'));
    }

    public function redirect()
    {
        abort_unless(self::enabled(), 404);

        return Socialite::driver('google')->redirect();
    }

    public function callback()
    {
        abort_unless(self::enabled(), 404);

        try {
            $google = Socialite::driver('google')->user();
        } catch (Throwable $e) {
            return redirect()->route('sign-in')->withErrors(['email' => __('Google sign-in was cancelled or failed. Try again.')]);
        }

        $email = strtolower($google->getEmail());
        $user = User::where('google_id', $google->getId())->first()
            ?? User::where('email', $email)->first();

        if ($user) {
            $user->forceFill(['google_id' => $google->getId()])->save();
        } else {
            $raw = $google->user ?? [];
            $user = User::create([
                'first_name' => $raw['given_name'] ?? ($google->getName() ?: 'Student'),
                'last_name' => $raw['family_name'] ?? '',
                'email' => $email,
                'google_id' => $google->getId(),
            ]);
            $user->forceFill(['email_verified_at' => now()])->save();
        }

        Auth::login($user, remember: true);
        request()->session()->regenerate();

        return redirect()->intended(route('calendar'));
    }
}
