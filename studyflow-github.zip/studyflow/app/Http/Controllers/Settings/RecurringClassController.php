<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Models\RecurringClass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class RecurringClassController extends Controller
{
    public function store(Request $request)
    {
        $data = $this->validated($request);
        if (! is_array($data)) return $data;
        $request->user()->recurringClasses()->create($data);

        return SettingsController::backTo('timetable', __('Class added.'));
    }

    public function update(Request $request, RecurringClass $class)
    {
        abort_unless($class->user_id === $request->user()->id, 404);
        $data = $this->validated($request, $class);
        if (! is_array($data)) return $data;
        $class->update($data);

        return SettingsController::backTo('timetable', __('Class saved.'));
    }

    public function destroy(Request $request, RecurringClass $class)
    {
        abort_unless($class->user_id === $request->user()->id, 404);
        $class->delete();

        return SettingsController::backTo('timetable', __('Class deleted.'));
    }

    private function validated(Request $request, ?RecurringClass $class = null)
    {
        $user = $request->user();
        foreach (['name', 'location', 'teacher'] as $f) {
            $request->merge([$f => trim((string) $request->input($f)) ?: null]);
        }
        $validator = Validator::make($request->all(), [
            'name' => ['nullable', 'string', 'max:80'],
            'subject_id' => ['nullable', 'integer', Rule::exists('subjects', 'id')->where('user_id', $user->id)],
            'day' => ['required', 'integer', 'between:1,7'],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i', 'after:start_time'],
            'week' => ['required', 'in:every,A,B'],
            'location' => ['nullable', 'string', 'max:120'],
            'teacher' => ['nullable', 'string', 'max:80'],
        ], ['end_time.after' => __('The end time must be after the start time.')]);

        $validator->after(function ($v) use ($request) {
            if (! $request->filled('name') && ! $request->filled('subject_id')) {
                $v->errors()->add('name', __('Pick a subject or enter a class name.'));
            }
        });

        if ($validator->fails()) {
            return SettingsController::backTo('timetable')->withErrors($validator, 'klass')->withInput()
                ->with('reopen', $class ? "class-{$class->id}" : 'class-new');
        }

        $data = $validator->validated();
        $data['subject_id'] = $data['subject_id'] ?? null;

        return $data;
    }
}
