<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class SubjectController extends Controller
{
    public function store(Request $request)
    {
        $data = $this->validated($request);
        if ($data instanceof \Illuminate\Http\RedirectResponse) return $data;

        $user = $request->user();
        $user->subjects()->create($data + ['sort_order' => (int) $user->subjects()->max('sort_order') + 1]);

        return SettingsController::backTo('subjects', __('Subject “:name” added.', ['name' => $data['name']]));
    }

    public function update(Request $request, Subject $subject)
    {
        $this->authorizeOwner($request, $subject);
        $data = $this->validated($request, $subject);
        if ($data instanceof \Illuminate\Http\RedirectResponse) return $data;

        $subject->update($data);

        return SettingsController::backTo('subjects', __('Subject saved.'));
    }

    public function destroy(Request $request, Subject $subject)
    {
        $this->authorizeOwner($request, $subject);
        $name = $subject->name;
        $subject->delete(); // grid cells are removed; recurring classes keep their own name

        return SettingsController::backTo('subjects', __('Subject “:name” deleted.', ['name' => $name]));
    }

    private function validated(Request $request, ?Subject $subject = null)
    {
        $request->merge(['name' => trim((string) $request->input('name'))]);
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:80',
                Rule::unique('subjects')->where('user_id', $request->user()->id)->ignore($subject?->id)],
            'color' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
        ], [
            'name.required' => __('Enter a subject name.'),
            'name.unique' => __('You already have a subject with this name.'),
            'color.regex' => __('Choose a colour.'),
        ]);

        if ($validator->fails()) {
            return SettingsController::backTo('subjects')
                ->withErrors($validator, 'subject')->withInput()
                ->with('reopen', $subject ? "subject-{$subject->id}" : 'subject-new');
        }

        $data = $validator->validated();
        $data['color'] = strtolower($data['color']);

        return $data;
    }

    private function authorizeOwner(Request $request, $model): void
    {
        abort_unless($model->user_id === $request->user()->id, 404);
    }
}
