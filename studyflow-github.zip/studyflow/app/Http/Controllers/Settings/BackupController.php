<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Services\PlannerData;
use Illuminate\Http\Request;
use InvalidArgumentException;

class BackupController extends Controller
{
    public function export(Request $request, PlannerData $data)
    {
        $json = json_encode($data->export($request->user()), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $file = 'studyflow-backup-'.now()->format('Y-m-d').'.json';

        return response($json, 200, [
            'Content-Type' => 'application/json; charset=utf-8',
            'Content-Disposition' => "attachment; filename=\"{$file}\"",
        ]);
    }

    public function import(Request $request, PlannerData $data)
    {
        $request->validate(['backup' => ['required', 'file', 'max:5120']], [
            'backup.required' => __('Choose a backup file to import.'),
            'backup.max' => __('The backup file must be smaller than 5 MB.'),
        ]);

        $decoded = json_decode((string) file_get_contents($request->file('backup')->getRealPath()), true);
        if (! is_array($decoded)) {
            return SettingsController::backTo('backup')->withErrors(['backup' => __('This file is not valid JSON.')], 'backup');
        }

        try {
            $data->import($request->user(), $decoded);
        } catch (InvalidArgumentException $e) {
            return SettingsController::backTo('backup')->withErrors(['backup' => __($e->getMessage())], 'backup');
        }

        return SettingsController::backTo('backup', __('Backup imported. Your planner has been restored.'));
    }

    public function clear(Request $request, PlannerData $data)
    {
        $request->validate(['confirm' => ['required', 'in:CLEAR']], ['confirm.in' => __('Type CLEAR to confirm.')]);
        $data->clear($request->user());

        return SettingsController::backTo('backup', __('All planner data cleared.'));
    }
}
