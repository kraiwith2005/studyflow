<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public const SECTIONS = ['subjects', 'terms', 'timetable', 'backup'];

    public function index(Request $request)
    {
        $user = $request->user();
        $planner = $user->planner();
        $subjects = $user->subjects()->withCount('slots')->get();
        $periods = $user->periods()->get();
        $weeks = $planner->weeks();

        $slots = $user->timetableSlots()->whereIn('week', $weeks)->get();
        $grid = $slots->mapWithKeys(fn ($s) => ["{$s->period_id}-{$s->day}-{$s->week}" => $s->subject_id]);
        $recurring = $user->recurringClasses()->with('subject')->get();

        $open = array_values(array_intersect(explode(',', (string) $request->query('open')), self::SECTIONS));

        return view('settings.index', [
            'user' => $user,
            'planner' => $planner,
            'subjects' => $subjects,
            'terms' => $user->terms()->get(),
            'periods' => $periods,
            'grid' => $grid,
            'recurring' => $recurring,
            'classCount' => ($planner->usesGrid() ? $slots->count() : 0) + $recurring->count(),
            'open' => $open,
            'presets' => Subject::PRESETS,
        ]);
    }

    /** Redirect back to Settings with a section kept open. */
    public static function backTo(string $section, ?string $status = null)
    {
        $redirect = redirect()->to(route('settings', ['open' => $section]).'#'.$section);

        return $status ? $redirect->with('status', $status) : $redirect;
    }
}
