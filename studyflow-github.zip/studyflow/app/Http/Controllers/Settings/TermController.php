<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Models\Term;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TermController extends Controller
{
    public function store(Request $request)
    {
        $data = $this->validated($request);
        if (! is_array($data)) return $data;

        $request->user()->terms()->create($data);

        return SettingsController::backTo('terms', __('Term “:name” added.', ['name' => $data['name']]));
    }

    public function update(Request $request, Term $term)
    {
        abort_unless($term->user_id === $request->user()->id, 404);
        $data = $this->validated($request, $term);
        if (! is_array($data)) return $data;

        $term->update($data);

        return SettingsController::backTo('terms', __('Term saved.'));
    }

    public function destroy(Request $request, Term $term)
    {
        abort_unless($term->user_id === $request->user()->id, 404);
        $term->delete();

        return SettingsController::backTo('terms', __('Term “:name” deleted.', ['name' => $term->name]));
    }

    private function validated(Request $request, ?Term $term = null)
    {
        $request->merge(['name' => trim((string) $request->input('name'))]);
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:60'],
            'start_date' => ['required', 'date_format:Y-m-d'],
            'end_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:start_date'],
        ], [
            'name.required' => __('Enter a term name.'),
            'end_date.after_or_equal' => __('The end date must be on or after the start date.'),
        ]);

        $validator->after(function ($v) use ($request, $term) {
            if ($v->errors()->isNotEmpty()) return;
            $overlap = $request->user()->terms()
                ->when($term, fn ($q) => $q->where('id', '!=', $term->id))
                ->where('start_date', '<=', $request->end_date)
                ->where('end_date', '>=', $request->start_date)
                ->first();
            if ($overlap) {
                $v->errors()->add('start_date', __('These dates overlap “:name”. Terms can’t overlap.', ['name' => $overlap->name]));
            }
        });

        if ($validator->fails()) {
            return SettingsController::backTo('terms')
                ->withErrors($validator, 'term')->withInput()
                ->with('reopen', $term ? "term-{$term->id}" : 'term-new');
        }

        return $validator->validated();
    }
}
