<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class TimetableController extends Controller
{
    /** AJAX: timetable type, repeat cycle and Week A anchor. */
    public function updateSettings(Request $request)
    {
        $data = $request->validate([
            'timetable_type' => ['required', 'in:school,university,custom'],
            'repeat_cycle' => ['required', 'in:weekly,ab'],
            'cycle_anchor' => ['nullable', 'date_format:Y-m-d'],
        ]);

        if ($data['repeat_cycle'] === 'ab') {
            // Always store the Monday of the chosen Week A (default: this week).
            $anchor = isset($data['cycle_anchor']) ? Carbon::parse($data['cycle_anchor']) : now();
            $data['cycle_anchor'] = $anchor->startOfWeek(Carbon::MONDAY)->toDateString();
        } else {
            $data['cycle_anchor'] = null;
        }

        $request->user()->planner()->update($data);

        return response()->json(['saved' => true] + $data);
    }

    /** Replace the list of periods (Edit period times). */
    public function updatePeriods(Request $request)
    {
        $user = $request->user();
        $rows = collect($request->input('periods', []))->values();
        $request->merge(['periods' => $rows->all()]);

        $validator = Validator::make($request->all(), [
            'periods' => ['required', 'array', 'min:1', 'max:20'],
            'periods.*.id' => ['nullable', 'integer'],
            'periods.*.name' => ['required', 'string', 'max:40'],
            'periods.*.kind' => ['required', 'in:class,break'],
            'periods.*.start_time' => ['required', 'date_format:H:i'],
            'periods.*.end_time' => ['required', 'date_format:H:i'],
        ], [
            'periods.required' => __('Keep at least one period.'),
            'periods.*.name.required' => __('Every period needs a name.'),
            'periods.*.start_time.required' => __('Every period needs a start time.'),
            'periods.*.end_time.required' => __('Every period needs an end time.'),
        ]);

        $validator->after(function ($v) use ($rows) {
            if ($v->errors()->isNotEmpty()) return;
            $sorted = $rows->sortBy('start_time')->values();
            foreach ($sorted as $i => $p) {
                if ($p['end_time'] <= $p['start_time']) {
                    $v->errors()->add('periods', __('“:name” must end after it starts.', ['name' => $p['name']]));
                    return;
                }
                if ($i > 0 && $p['start_time'] < $sorted[$i - 1]['end_time']) {
                    $v->errors()->add('periods', __('“:name” overlaps “:other”.', ['name' => $p['name'], 'other' => $sorted[$i - 1]['name']]));
                    return;
                }
            }
        });

        if ($validator->fails()) {
            return SettingsController::backTo('timetable')->withErrors($validator, 'periods')->withInput()->with('reopen', 'periods');
        }

        DB::transaction(function () use ($user, $rows) {
            $ownIds = $user->periods()->pluck('id')->all();
            $keep = [];
            foreach ($rows->sortBy('start_time')->values() as $i => $p) {
                $values = ['name' => trim($p['name']), 'kind' => $p['kind'], 'start_time' => $p['start_time'], 'end_time' => $p['end_time'], 'sort_order' => $i];
                if (! empty($p['id']) && in_array((int) $p['id'], $ownIds, true)) {
                    $user->periods()->whereKey($p['id'])->update($values);
                    $keep[] = (int) $p['id'];
                } else {
                    $keep[] = $user->periods()->create($values)->id;
                }
            }
            $user->periods()->whereNotIn('id', $keep)->delete(); // their grid cells go too
            // A period that became a break can't hold classes.
            $breakIds = $user->periods()->where('kind', 'break')->pluck('id');
            $user->timetableSlots()->whereIn('period_id', $breakIds)->delete();
        });

        return SettingsController::backTo('timetable', __('Period times saved.'));
    }

    /** AJAX: set or clear one grid cell. */
    public function setSlot(Request $request)
    {
        $user = $request->user();
        $planner = $user->planner();

        $data = $request->validate([
            'period_id' => ['required', 'integer', Rule::exists('periods', 'id')->where('user_id', $user->id)->where('kind', 'class')],
            'day' => ['required', 'integer', Rule::in($planner->gridDays())],
            'week' => ['required', Rule::in($planner->weeks())],
            'subject_id' => ['nullable', 'integer', Rule::exists('subjects', 'id')->where('user_id', $user->id)],
        ]);

        $key = ['user_id' => $user->id, 'period_id' => $data['period_id'], 'day' => $data['day'], 'week' => $data['week']];
        if (empty($data['subject_id'])) {
            $user->timetableSlots()->where($key)->delete();
        } else {
            $user->timetableSlots()->updateOrCreate($key, ['subject_id' => $data['subject_id']]);
        }

        return response()->json(['saved' => true, 'class_count' => $this->classCount($user)]);
    }

    public function clearGrid(Request $request)
    {
        $user = $request->user();
        $user->timetableSlots()->delete();

        return SettingsController::backTo('timetable', __('Timetable grid cleared.'));
    }

    private function classCount($user): int
    {
        $planner = $user->planner();
        $grid = $planner->usesGrid() ? $user->timetableSlots()->whereIn('week', $planner->weeks())->count() : 0;

        return $grid + $user->recurringClasses()->count();
    }
}
