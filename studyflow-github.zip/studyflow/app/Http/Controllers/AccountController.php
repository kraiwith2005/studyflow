<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;

class AccountController extends Controller
{
    public function edit(Request $request)
    {
        return view('account', ['user' => $request->user()]);
    }

    public function updateProfile(Request $request)
    {
        $user = $request->user();
        $data = $request->validate([
            'first_name' => ['required', 'string', 'max:60'],
            'last_name' => ['required', 'string', 'max:60'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
        ]);
        $data['email'] = strtolower(trim($data['email']));

        $user->update($data);

        return back()->with('status', __('Profile saved.'));
    }

    public function updatePassword(Request $request)
    {
        $user = $request->user();
        $rules = ['password' => ['required', 'confirmed', Password::min(8)->letters()->numbers()]];
        if ($user->hasPassword()) {
            $rules['current_password'] = ['required', 'current_password'];
        }
        $request->validateWithBag('password', $rules, [
            'current_password.current_password' => __('Your current password is incorrect.'),
        ]);

        $user->update(['password' => $request->password]);

        return back()->with('status', __('Password updated.'));
    }

    public function destroy(Request $request)
    {
        $user = $request->user();
        if ($user->hasPassword()) {
            $request->validateWithBag('delete', ['password' => ['required', 'current_password']], [
                'password.current_password' => __('Your password is incorrect.'),
            ]);
        } else {
            $request->validateWithBag('delete', ['confirm_email' => ['required', 'in:'.$user->email]], [
                'confirm_email.in' => __('Type your email address exactly as shown.'),
            ]);
        }

        Auth::logout();
        $user->delete(); // planner data is removed by cascading foreign keys
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('sign-in')->with('status', __('Your account and all its data have been deleted.'));
    }
}
