<?php

namespace App\Http\Controllers\Concerns;

use Illuminate\Http\Request;

trait ReturnsToPage
{
    /** Redirect to the page the form came from (only our own app pages are allowed). */
    protected function backToPage(Request $request, ?string $status = null)
    {
        $to = (string) $request->input('return', '');
        if (! preg_match('#^/(calendar|tasks|study)(\?[^\s]*)?$#', $to)) {
            $to = route('calendar', [], false);
        }
        $redirect = redirect()->to($to);

        return $status ? $redirect->with('status', $status) : $redirect;
    }
}
