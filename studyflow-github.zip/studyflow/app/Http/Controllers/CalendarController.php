<?php

namespace App\Http\Controllers;

use App\Models\StudySession;
use App\Services\CalendarBuilder;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CalendarController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $view = in_array($request->query('view'), ['month', 'week', 'day'], true) ? $request->query('view') : 'month';
        try {
            $date = Carbon::createFromFormat('Y-m-d', (string) $request->query('date'))->startOfDay();
        } catch (\Throwable) {
            $date = now()->startOfDay();
        }

        [$start, $end, $prev, $next] = match ($view) {
            'month' => [
                $date->copy()->startOfMonth()->startOfWeek(Carbon::SUNDAY),
                $date->copy()->endOfMonth()->endOfWeek(Carbon::SATURDAY)->startOfDay(),
                $date->copy()->subMonthNoOverflow()->startOfMonth(),
                $date->copy()->addMonthNoOverflow()->startOfMonth(),
            ],
            'week' => [
                $date->copy()->startOfWeek(Carbon::SUNDAY),
                $date->copy()->endOfWeek(Carbon::SATURDAY)->startOfDay(),
                $date->copy()->subWeek(), $date->copy()->addWeek(),
            ],
            'day' => [$date->copy(), $date->copy(), $date->copy()->subDay(), $date->copy()->addDay()],
        };

        $days = (new CalendarBuilder($user))->build($start, $end, withClasses: $view !== 'month');

        // Hours shown in Week/Day: 7 AM – 9 PM, widened to fit anything earlier or later.
        [$fromHour, $toHour] = [7, 21];
        foreach ($days as $day) {
            foreach ($day['timed'] as $item) {
                $fromHour = min($fromHour, (int) substr($item['start'], 0, 2));
                $endH = (int) substr($item['end'], 0, 2) + ((int) substr($item['end'], 3, 2) > 0 ? 1 : 0);
                $toHour = max($toHour, min(24, $endH));
            }
        }

        $planner = $user->planner();

        return view('calendar.index', [
            'view' => $view,
            'date' => $date,
            'start' => $start,
            'end' => $end,
            'prev' => $prev,
            'next' => $next,
            'days' => $days,
            'fromHour' => $fromHour,
            'toHour' => $toHour,
            'title' => match ($view) {
                'month' => fmt_date($date, 'month'),
                'week' => $this->weekTitle($start, $end),
                'day' => fmt_date($date, 'long'),
            },
            'subjects' => $user->subjects()->get(),
            'linkable' => $user->tasks()->where('type', '!=', 'personal')->whereNull('completed_at')
                ->orderBy('due_date')->with('subject')->get(),
            'durations' => StudySession::DURATIONS,
            'weekLetter' => $planner->repeat_cycle === 'ab' ? (new CalendarBuilder($user))->weekLetter($planner, $date) : null,
            'returnUrl' => $request->getRequestUri(),
        ]);
    }

    private function weekTitle(Carbon $start, Carbon $end): string
    {
        if (app()->getLocale() === 'th') {
            return $start->month === $end->month
                ? $start->day.' – '.fmt_date($end)
                : fmt_date($start).' – '.fmt_date($end);
        }

        return $start->format('M j').' – '.$end->format($start->year === $end->year ? 'M j, Y' : 'M j, Y');
    }
}
