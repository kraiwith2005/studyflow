<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ReturnsToPage;
use App\Models\StudySession;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class StudySessionController extends Controller
{
    use ReturnsToPage;

    public function store(Request $request)
    {
        $data = $this->validated($request);
        if (! is_array($data)) return $data;
        $request->user()->studySessions()->create($data);

        return $this->backToPage($request, ($data['status'] ?? null) === 'completed'
            ? __('Study logged: :title', ['title' => $data['title']])
            : __('Study session “:title” added.', ['title' => $data['title']]));
    }

    public function update(Request $request, StudySession $session)
    {
        $this->own($request, $session);
        $data = $this->validated($request, $session);
        if (! is_array($data)) return $data;
        $session->update($data);

        return $this->backToPage($request, __('Changes saved.'));
    }

    public function destroy(Request $request, StudySession $session)
    {
        $this->own($request, $session);
        $session->delete();

        return $this->backToPage($request, __('“:title” deleted.', ['title' => $session->title]));
    }

    public function toggle(Request $request, StudySession $session)
    {
        $this->own($request, $session);
        $done = ! $session->isDone();
        $session->update([
            'status' => $done ? 'completed' : 'planned',
            'actual_minutes' => $done ? ($session->actual_minutes ?? $session->duration_minutes) : null,
        ]);

        return $this->backToPage($request, $done ? __('Marked as done.') : __('Marked as not done.'));
    }

    private function validated(Request $request, ?StudySession $session = null)
    {
        $user = $request->user();
        $request->merge(['title' => trim((string) $request->input('title'))]);

        $validator = Validator::make($request->all(), [
            'title' => ['required', 'string', 'max:120'],
            'subject_id' => ['required', 'integer', Rule::exists('subjects', 'id')->where('user_id', $user->id)],
            'date' => ['required', 'date_format:Y-m-d'],
            'start_time' => ['required', 'date_format:H:i'],
            'duration_minutes' => ['required', 'integer', 'between:1,600'], // presets in the form; timer sessions can be any length
            'task_id' => ['nullable', 'integer', Rule::exists('tasks', 'id')->where('user_id', $user->id)->where(fn ($q) => $q->where('type', '!=', 'personal'))],
        ], [
            'title.required' => __('Enter a title.'),
            'subject_id.required' => __('Choose a subject.'),
            'duration_minutes.required' => __('Choose a duration.'),
        ]);

        $validator->after(function ($v) use ($request) {
            if ($v->errors()->isNotEmpty()) return;
            [$h, $m] = array_map('intval', explode(':', $request->start_time));
            if ($h * 60 + $m + (int) $request->duration_minutes > 24 * 60) {
                $v->errors()->add('start_time', __('The session must end by midnight.'));
            }
        });

        if ($validator->fails()) {
            return $this->backToPage($request)->withErrors($validator, 'session')->withInput()
                ->with('reopen', $session ? "session-{$session->id}" : 'new-session');
        }

        $data = $validator->validated();
        $data['task_id'] = $data['task_id'] ?? null;
        if (! $session && $request->boolean('mark_done')) { // "Log study": already happened
            $data['status'] = 'completed';
            $data['actual_minutes'] = $data['duration_minutes'];
        }

        return $data;
    }

    private function own(Request $request, StudySession $session): void
    {
        abort_unless($session->user_id === $request->user()->id, 404);
    }
}
