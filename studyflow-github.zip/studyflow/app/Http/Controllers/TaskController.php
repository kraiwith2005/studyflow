<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ReturnsToPage;
use App\Models\StudySession;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class TaskController extends Controller
{
    use ReturnsToPage;

    public function index(Request $request)
    {
        $user = $request->user();
        $filter = in_array($request->query('filter'), ['school', 'personal'], true) ? $request->query('filter') : 'all';
        $showCompleted = $request->boolean('completed');
        $search = trim((string) $request->query('q'));
        $highOnly = $request->boolean('high');
        $terms = $user->terms()->get();
        $term = $terms->firstWhere('id', (int) $request->query('term'));

        $query = $user->tasks()->with('subject')
            ->withCount([
                'studySessions as planned_sessions' => fn ($q) => $q->where('status', 'planned'),
                'studySessions as done_sessions' => fn ($q) => $q->where('status', 'completed'),
            ])
            ->withSum(['studySessions as done_minutes' => fn ($q) => $q->where('status', 'completed')], 'actual_minutes')
            ->when($filter === 'school', fn ($q) => $q->where('type', '!=', 'personal'))
            ->when($filter === 'personal', fn ($q) => $q->where('type', 'personal'))
            ->when(! $showCompleted, fn ($q) => $q->whereNull('completed_at'))
            ->when($highOnly, fn ($q) => $q->where('priority', 'high'))
            ->when($search !== '', function ($q) use ($search) {
                // Escape LIKE wildcards so "%" or "_" are searched literally.
                $like = '%'.addcslashes($search, '\\%_').'%';
                $q->where(fn ($w) => $w
                    ->where('title', 'like', $like)
                    ->orWhere('notes', 'like', $like)
                    ->orWhereHas('subject', fn ($s) => $s->where('name', 'like', $like)));
            })
            ->when($term, fn ($q) => $q->whereBetween('due_date', [$term->start_date->toDateString(), $term->end_date->toDateString()]))
            // Open tasks first by due date; completed ones at the end.
            ->orderByRaw('completed_at IS NOT NULL')->orderBy('due_date')
            ->orderByRaw("FIELD(priority, 'high', 'normal', 'low')")
            ->orderByRaw('due_time IS NULL')->orderBy('due_time')->orderBy('title');

        $tasks = $query->get();
        $groups = [
            'assessments' => ['assignment' => $tasks->where('type', 'assignment'), 'exam' => $tasks->where('type', 'exam')],
            'other' => ['personal' => $tasks->where('type', 'personal')],
        ];

        return view('tasks.index', [
            'groups' => $groups,
            'count' => $tasks->count(),
            'filter' => $filter,
            'showCompleted' => $showCompleted,
            'search' => $search,
            'highOnly' => $highOnly,
            'terms' => $terms,
            'term' => $term,
            'subjects' => $user->subjects()->get(),
            'linkable' => $user->tasks()->where('type', '!=', 'personal')->whereNull('completed_at')->orderBy('due_date')->orderByRaw('due_time IS NULL')->orderBy('due_time')->get(),
            'durations' => StudySession::DURATIONS,
            'returnUrl' => $request->getRequestUri(),
        ]);
    }

    /** "Due in 3 days", "Overdue by 2 days"… */
    public static function dueLabel(Task $task): array
    {
        if ($task->isDone()) return [__('Done'), 'done'];
        $days = (int) now()->startOfDay()->diffInDays($task->due_date->copy()->startOfDay(), false);
        $exam = $task->type === 'exam';

        return match (true) {
            $days < 0 => [trans_choice('Overdue by :count day|Overdue by :count days', -$days), 'overdue'],
            $days === 0 => [$exam ? __('Exam today') : __('Due today'), 'soon'],
            $days === 1 => [$exam ? __('Exam tomorrow') : __('Due tomorrow'), 'soon'],
            default => [trans_choice($exam ? 'Exam in :count day|Exam in :count days' : 'Due in :count day|Due in :count days', $days), $days <= 7 ? 'week' : 'later'],
        };
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        if (! is_array($data)) return $data;
        $request->user()->tasks()->create($data);

        return $this->backToPage($request, __(':type “:title” added.', ['type' => Task::typeLabel($data['type']), 'title' => $data['title']]));
    }

    public function update(Request $request, Task $task)
    {
        $this->own($request, $task);
        $data = $this->validated($request, $task);
        if (! is_array($data)) return $data;
        $task->update($data);

        return $this->backToPage($request, __('Changes saved.'));
    }

    public function destroy(Request $request, Task $task)
    {
        $this->own($request, $task);
        $task->delete();

        return $this->backToPage($request, __('“:title” deleted.', ['title' => $task->title]));
    }

    public function toggle(Request $request, Task $task)
    {
        $this->own($request, $task);
        $task->update(['completed_at' => $task->isDone() ? null : now()]);

        return $this->backToPage($request, $task->isDone() ? __('Marked as done.') : __('Marked as not done.'));
    }

    private function validated(Request $request, ?Task $task = null)
    {
        $user = $request->user();
        $request->merge(['title' => trim((string) $request->input('title'))]);
        $type = $task?->type ?? $request->input('type');

        $validator = Validator::make($request->all() + ['type' => $type], [
            'type' => ['required', Rule::in(Task::TYPES)],
            'title' => ['required', 'string', 'max:120'],
            'subject_id' => [$type === 'personal' ? 'nullable' : 'required', 'integer', Rule::exists('subjects', 'id')->where('user_id', $user->id)],
            'due_date' => ['required', 'date_format:Y-m-d'],
            'due_time' => ['nullable', 'date_format:H:i'],
            'notes' => ['nullable', 'string', 'max:2000'],
            'link' => ['nullable', 'string', 'max:500', 'url:http,https'],
            'priority' => ['nullable', Rule::in(Task::PRIORITIES)],
        ], [
            'title.required' => __('Enter a title.'),
            'subject_id.required' => __('Choose a subject.'),
            'link.url' => __('Enter a full link starting with http:// or https://'),
        ]);

        if ($validator->fails()) {
            return $this->backToPage($request)->withErrors($validator, 'task')->withInput()
                ->with('reopen', $task ? "task-{$task->id}" : "new-{$type}");
        }

        $data = $validator->validated();
        $data['priority'] = $data['priority'] ?? 'normal';
        // Browsers send textarea line breaks as \r\n; store plain \n, and empty as null.
        if (array_key_exists('notes', $data)) {
            $notes = trim(str_replace(["\r\n", "\r"], "\n", (string) $data['notes']));
            $data['notes'] = $notes === '' ? null : $notes;
        }
        if (array_key_exists('link', $data)) {
            $data['link'] = trim((string) $data['link']) === '' ? null : trim($data['link']);
        }
        if ($type === 'personal') $data['subject_id'] = null;
        if ($task) unset($data['type']); // type can't change after creation

        return $data;
    }

    private function own(Request $request, Task $task): void
    {
        abort_unless($task->user_id === $request->user()->id, 404);
    }
}
