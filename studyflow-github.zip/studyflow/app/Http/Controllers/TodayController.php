<?php

namespace App\Http\Controllers;

use App\Models\StudySession;
use App\Services\CalendarBuilder;
use Carbon\Carbon;
use Illuminate\Http\Request;

/** One screen with everything happening today: classes, what is due, and the study plan. */
class TodayController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $today = now()->startOfDay();
        $date = $today->toDateString();

        $day = (new CalendarBuilder($user))->build($today->copy(), $today->copy(), true)[$date];
        $classes = array_values(array_filter($day['timed'], fn ($i) => $i['kind'] === 'class'));
        usort($classes, fn ($a, $b) => $a['start'] <=> $b['start']);

        $open = $user->tasks()->with('subject')->whereNull('completed_at')
            ->withCount(['studySessions as planned_sessions' => fn ($q) => $q->where('status', 'planned')])
            ->withSum(['studySessions as done_minutes' => fn ($q) => $q->where('status', 'completed')], 'actual_minutes')
            ->where('due_date', '<=', $today->copy()->addDays(7)->toDateString())
            ->orderBy('due_date')->orderByRaw("FIELD(priority, 'high', 'normal', 'low')")
            ->orderByRaw('due_time IS NULL')->orderBy('due_time')->get();

        $sessions = $user->studySessions()->with(['subject', 'task'])
            ->whereDate('date', $date)->orderBy('start_time')->get();

        $weekStart = now()->startOfWeek(Carbon::SUNDAY);
        $week = $user->studySessions()->where('status', 'completed')
            ->whereBetween('date', [$weekStart->toDateString(), $weekStart->copy()->addDays(6)->toDateString()]);

        return view('today.index', [
            'todayDate' => $today,
            'classes' => $classes,
            'overdue' => $open->filter(fn ($t) => $t->due_date->lt($today))->values(),
            'dueToday' => $open->filter(fn ($t) => $t->due_date->isSameDay($today))->values(),
            'dueSoon' => $open->filter(fn ($t) => $t->due_date->gt($today))->values(),
            'plannedToday' => $sessions->where('status', 'planned')->values(),
            'doneToday' => $sessions->where('status', 'completed')->values(),
            'doneTodayMinutes' => (int) $sessions->where('status', 'completed')->sum('actual_minutes'),
            'weekCount' => (clone $week)->count(),
            'weekMinutes' => (int) (clone $week)->sum('actual_minutes'),
            'timer' => $user->studyTimer,
            'subjects' => $user->subjects()->get(),
            'terms' => $user->terms()->get(),
            'linkable' => $user->tasks()->where('type', '!=', 'personal')->whereNull('completed_at')
                ->orderBy('due_date')->orderByRaw('due_time IS NULL')->orderBy('due_time')->get(),
            'durations' => StudySession::DURATIONS,
            'returnUrl' => $request->getRequestUri(),
        ]);
    }

    /** The person finished or skipped the first-run tour. */
    public function tourDone(Request $request)
    {
        $request->user()->forceFill(['tour_completed_at' => now()])->save();

        return response()->noContent();
    }
}
