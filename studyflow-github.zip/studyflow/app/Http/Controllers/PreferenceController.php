<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PreferenceController extends Controller
{
    public function theme(Request $request)
    {
        $data = $request->validate(['theme' => ['required', 'in:light,dark']]);
        $request->user()->update(['theme' => $data['theme']]);

        return response()->json(['saved' => true, 'theme' => $data['theme']]);
    }
}
