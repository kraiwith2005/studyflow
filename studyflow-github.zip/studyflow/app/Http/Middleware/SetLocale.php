<?php

namespace App\Http\Middleware;

use Carbon\Carbon;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;

class SetLocale
{
    public const SUPPORTED = ['th', 'en'];
    public const DEFAULT = 'th';

    public function handle(Request $request, Closure $next)
    {
        $locale = $request->cookie('locale');
        if (! in_array($locale, self::SUPPORTED, true)) {
            $locale = self::DEFAULT;
        }
        App::setLocale($locale);
        Carbon::setLocale($locale);

        return $next($request);
    }
}
