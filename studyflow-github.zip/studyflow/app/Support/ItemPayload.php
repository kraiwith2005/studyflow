<?php

namespace App\Support;

use App\Models\StudySession;
use App\Models\Task;

/** JSON given to the item-details dialog (used by Calendar and Tasks). */
class ItemPayload
{
    public static function task(Task $t): array
    {
        return [
            'kind' => 'task', 'id' => $t->id, 'type' => $t->type, 'typeLabel' => Task::typeLabel($t->type),
            'title' => $t->title, 'subject' => $t->subject?->name, 'subject_id' => $t->subject_id,
            'color' => $t->color, 'done' => $t->isDone(), 'date' => $t->due_date->toDateString(), 'notes' => $t->notes,
        ];
    }

    public static function session(StudySession $s): array
    {
        return [
            'kind' => 'session', 'id' => $s->id, 'title' => $s->title,
            'subject' => $s->subject?->name, 'subject_id' => $s->subject_id,
            'color' => $s->color, 'start' => substr($s->start_time, 0, 5), 'end' => substr($s->end_time, 0, 5),
            'duration' => $s->duration_minutes, 'done' => $s->isDone(),
            'task_id' => $s->task_id, 'task' => $s->task?->title, 'date' => $s->date->toDateString(),
        ];
    }

    public static function json(array $i): string
    {
        $i['dateLabel'] = fmt_date($i['date'], 'long');
        if (isset($i['start'])) $i['timeLabel'] = fmt_time($i['start']).' – '.fmt_time($i['end']);
        if ($i['kind'] === 'task') {
            $i['urls'] = ['update' => route('tasks.update', $i['id']), 'destroy' => route('tasks.destroy', $i['id']), 'toggle' => route('tasks.toggle', $i['id'])];
        } elseif ($i['kind'] === 'session') {
            $i['typeLabel'] = __('Study session');
            $i['durationLabel'] = StudySession::durationLabel($i['duration']);
            $i['urls'] = ['update' => route('sessions.update', $i['id']), 'destroy' => route('sessions.destroy', $i['id']), 'toggle' => route('sessions.toggle', $i['id'])];
        } else {
            $i['typeLabel'] = __('Class');
        }

        return json_encode($i, JSON_UNESCAPED_UNICODE);
    }
}
