<?php

namespace App\Support;

/** Strings the front-end scripts need, in the current language. */
class JsStrings
{
    public static function all(): array
    {
        return [
            'saving' => __('Saving…'),
            'saved' => __('Saved'),
            'notSaved' => __('Not saved'),
            'showPassword' => __('Show password'),
            'hidePassword' => __('Hide password'),
            'toLight' => __('Switch to light mode'),
            'toDark' => __('Switch to dark mode'),
            'class' => __(':count class'),
            'classes' => __(':count classes'),
            'period' => __('Period :n'),
            'delete' => __('Delete'),
            'add' => __('Add'),
            'save' => __('Save'),
        ];
    }
}
