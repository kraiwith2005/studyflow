<?php

use Carbon\Carbon;
use Carbon\CarbonInterface;

if (! function_exists('fmt_time')) {
    /** "13:20:00" -> "13:20 น." (Thai) or "1:20 PM" (English) */
    function fmt_time(?string $time): string
    {
        if (! $time) return '';
        $t = Carbon::createFromFormat(strlen($time) === 5 ? 'H:i' : 'H:i:s', $time);

        return app()->getLocale() === 'th' ? $t->format('H:i') : $t->format('g:i A');
    }
}

if (! function_exists('fmt_date')) {
    /**
     * Thai: "8 พ.ย. 2569" (Buddhist year) · English: "8 Nov 2026".
     * $style: 'short' (day month year) | 'long' (weekday, full month) | 'month' (month year)
     */
    function fmt_date($date, string $style = 'short'): string
    {
        if (! $date) return '';
        $d = $date instanceof CarbonInterface ? $date : Carbon::parse($date);

        if (app()->getLocale() !== 'th') {
            return match ($style) {
                'long' => $d->format('l j F Y'),
                'month' => $d->format('F Y'),
                default => $d->format('j M Y'),
            };
        }

        $short = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
        $full = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
        $days = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
        $year = $d->year + 543;
        $m = $d->month - 1;

        return match ($style) {
            'long' => "วัน{$days[$d->dayOfWeek]}ที่ {$d->day} {$full[$m]} {$year}",
            'month' => "{$full[$m]} {$year}",
            default => "{$d->day} {$short[$m]} {$year}",
        };
    }
}

if (! function_exists('day_name')) {
    /** ISO day 1–7 -> localized name. $short for grid headers. */
    function day_name(int $iso, bool $short = false): string
    {
        $th = [1 => ['จันทร์', 'จ.'], 2 => ['อังคาร', 'อ.'], 3 => ['พุธ', 'พ.'], 4 => ['พฤหัสบดี', 'พฤ.'], 5 => ['ศุกร์', 'ศ.'], 6 => ['เสาร์', 'ส.'], 7 => ['อาทิตย์', 'อา.']];
        $en = [1 => ['Monday', 'MON'], 2 => ['Tuesday', 'TUE'], 3 => ['Wednesday', 'WED'], 4 => ['Thursday', 'THU'], 5 => ['Friday', 'FRI'], 6 => ['Saturday', 'SAT'], 7 => ['Sunday', 'SUN']];
        $set = app()->getLocale() === 'th' ? $th : $en;

        return $set[$iso][$short ? 1 : 0];
    }
}
