# StudyFlow

## ติดตั้งบน Mac แบบง่าย (แนะนำ)
1. แตกไฟล์ zip
2. **คลิกขวา** ที่ไฟล์ `StudyFlow-Mac.command` แล้วเลือก **Open** (ครั้งแรกต้องคลิกขวา เพราะ macOS จะถามยืนยัน)
3. รอให้ติดตั้งเสร็จ (ครั้งแรกอาจใช้ 5–15 นาที และอาจถามรหัสผ่านเครื่อง Mac)
4. เบราว์เซอร์จะเปิด http://localhost:8000 ให้เอง
5. ครั้งต่อไป ดับเบิลคลิกไฟล์เดิมเพื่อเปิดใช้งาน และเปิดหน้าต่าง Terminal ค้างไว้ระหว่างใช้

---

## Manual install (any OS)
Student planner built with Laravel 13 + MySQL.

## Requirements
- PHP 8.3 or newer (extensions: pdo_mysql, mbstring, xml, curl, zip, intl, bcmath)
- Composer 2
- MySQL 8 / MariaDB 10.6+ (XAMPP, MAMP, Laragon all work)

## Install
```bash
composer install
cp .env.example .env          # then edit DB_* to match your MySQL
php artisan key:generate
# create an empty database named "studyflow" (utf8mb4) in phpMyAdmin or MySQL
php artisan migrate
php artisan serve             # open http://localhost:8000
```

## Settings in .env
| Key | Purpose |
|---|---|
| `DB_*` | MySQL connection |
| `STUDYFLOW_SUPPORT_EMAIL` | Email shown in Settings › Support |
| `APP_TIMEZONE` | Default `Asia/Bangkok` |
| `MAIL_*` | Set real SMTP to send password-reset emails. With `MAIL_MAILER=log` the email is written to `storage/logs/laravel.log` |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Optional. When both are set, the “Continue with Google” button appears. Authorized redirect URI in Google Cloud: `APP_URL/auth/google/callback` |
